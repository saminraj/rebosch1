package com.net.bosch.weather.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.net.bosch.constants.Constants;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.weather.dto.DataRequestDTO;
import com.net.bosch.weather.service.WeatherService;

@RestController
@CrossOrigin
@RequestMapping("/weather")
public class WeatherController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	WeatherService weatherService;
	
	/**
	 * POST method to proxy service
	 */
	@PostMapping
	public String proxyService(@RequestBody @Valid DataRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("proxyService called");
		String response = weatherService.proxyWeatherService(requestDTO.getEndPoint(), requestDTO.getQueryString());
		logger.debug("[proxyService]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy location Search
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/locations/v1/cities/geoposition/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public String locationSearch(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("locationSearch called");
		logger.debug("locationSearch called httpServletRequest "+httpServletRequest.getQueryString());
		String response = weatherService.proxyWeatherService("/locations/v1/cities/geoposition/search",httpServletRequest.getQueryString());
		logger.debug("[locationSearch]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}

	/**
	 * GET method to proxy current conditions
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/currentconditions/v1/{locationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String currentConditionssearch(@PathVariable String locationId, HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("currentconditions called");
		logger.debug("currentconditions called httpServletRequest "+httpServletRequest.getQueryString());
		String response = weatherService.proxyWeatherService("/currentconditions/v1/"+locationId,httpServletRequest.getQueryString(), Constants.WEATHER_CURRENT_CONDITION, locationId);
		logger.debug("[currentconditions]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to forecastHourly
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/forecasts/v1/hourly/24hour/{locationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String forecastHourly(@PathVariable String locationId, HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("forecastHourly called");
		logger.debug("forecastHourly called httpServletRequest "+httpServletRequest.getQueryString());
		String response = weatherService.proxyWeatherService("/forecasts/v1/hourly/24hour/"+locationId,httpServletRequest.getQueryString(), Constants.WEATHER_24_HOURS, locationId);
		logger.debug("[forecastHourly]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to forecastDaily 
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/forecasts/v1/daily/5day/{locationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String forecastDaily(@PathVariable String locationId, HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("forecastDaily called");
		logger.debug("forecastDaily called httpServletRequest "+httpServletRequest.getQueryString());
		String response = weatherService.proxyWeatherService("/forecasts/v1/daily/5day/"+locationId,httpServletRequest.getQueryString(), Constants.WEATHER_5_DAYS, locationId);
		logger.debug("[forecastDaily]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String getTest() throws AppException {
		return "Success";
	}
	

}
