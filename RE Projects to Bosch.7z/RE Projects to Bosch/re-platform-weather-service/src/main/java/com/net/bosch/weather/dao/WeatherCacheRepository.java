package com.net.bosch.weather.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.weather.domain.WeatherCache;

@Repository
public interface WeatherCacheRepository extends CrudRepository<WeatherCache, String> {
	
		
		

}