package com.net.bosch.weather.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash(value = "WeatherCache", timeToLive = 7200)
public class WeatherCache implements DomainObject{

	private static final long serialVersionUID = -646307326078491498L;

	@Id
	public String id;
	
	
	public String data;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
}
