package com.net.bosch.dto.base;


public class DataResponseDTO extends ResponseDTO{
	
	private static final long serialVersionUID = 1L;

	private Object response;

	public Object getResponse() {
		return response;
	}

	public void setResponse(Object response) {
		this.response = response;
	}
}
