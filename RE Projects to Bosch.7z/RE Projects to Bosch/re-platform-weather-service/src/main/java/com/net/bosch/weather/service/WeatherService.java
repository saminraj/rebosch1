package com.net.bosch.weather.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.constants.Constants;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.utils.ProxyUtil;
import com.net.bosch.weather.dao.WeatherCacheRepository;
import com.net.bosch.weather.domain.WeatherCache;


@Service
public class WeatherService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
	
	@Autowired
	private WeatherCacheRepository weatherCacheRepository;
		
	ObjectMapper mapper = new ObjectMapper();
	
	public String proxyWeatherService(String endPoint, String queryString, String feature, String locationId) throws AppException {
		WeatherCache cache = null;
		try {
			cache = weatherCacheRepository.findById(feature+locationId).get();
		} catch (Exception e) {
			logger.info("The data not available in weather cache "+feature+locationId);
		}		
		if(cache != null){
			logger.info("got the data from weather cache "+feature+locationId);
			return cache.getData();
		}
		String data =  proxyWeatherService(endPoint, queryString);
		cache = new WeatherCache();
		cache.setId(feature+locationId);
		logger.info("data.asText() -> "+data);	
		cache.setData(data);
		weatherCacheRepository.save(cache);
		return data;
	}
	
	public String proxyWeatherService(String endPoint, String queryString) throws AppException {
		queryString = queryString.replaceAll("%3A", ":");
		queryString = queryString.concat("?&apikey=").concat(env.getProperty("accu.weather.key"));
		return  proxyService(endPoint, queryString, env.getProperty("accu.weather.baseurl"));
		
	}
	
	
	
	public String proxyService(String endPoint, String queryString, String baseURL) throws AppException {
		String proxyURI = null;
		try {
			proxyURI = URLDecoder.decode(queryString, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		logger.info("accu api : "+ baseURL+endPoint+"?"+proxyURI);
		return ProxyUtil.proxyGetService(baseURL+endPoint+"?",proxyURI);		
	}
}
