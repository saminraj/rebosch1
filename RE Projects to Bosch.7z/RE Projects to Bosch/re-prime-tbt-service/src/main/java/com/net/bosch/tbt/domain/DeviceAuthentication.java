package com.net.bosch.tbt.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash(value = "DeviceAuthentication", timeToLive = 7776000)
public class DeviceAuthentication implements DomainObject{

	private static final long serialVersionUID = -1447722022634230276L;

	@Id
	public String id;
	
	public String key;//Azure key
	
	public String guid;
	
	public String jwtToken;
	
	public String permissions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public String getJwtToken() {
		return jwtToken;
	}

	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
			
}
