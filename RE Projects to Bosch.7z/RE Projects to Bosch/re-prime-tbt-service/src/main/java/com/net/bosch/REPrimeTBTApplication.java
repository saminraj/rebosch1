package com.net.bosch;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.net.bosch.filter.AppFilter;

@EnableAutoConfiguration
@SpringBootApplication
@EnableScheduling
public class REPrimeTBTApplication extends SpringBootServletInitializer{
	
	private static final Logger logger = LoggerFactory.getLogger(REPrimeTBTApplication.class);
	
	@Autowired
	private Environment env;
	
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(REPrimeTBTApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(REPrimeTBTApplication.class, args);
	}

	/*public static void main(String[] args) {
		SpringApplication.run(REPrimeTBTApplication.class, args);
		logger.debug("REPrimeTBTApplication Started");
	}*/
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean
    public FilterRegistrationBean registerAppFilter(AppFilter filter) {
        FilterRegistrationBean reg = new FilterRegistrationBean(filter);
        reg.setOrder(3);
        return reg;
    }
	
	
}