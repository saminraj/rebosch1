package com.net.bosch.dto.base;

import com.net.bosch.domain.DomainObject;

public class RequestDTO implements DomainObject{
	
	private static final long serialVersionUID = -1117614688061102216L;
	
	private String appId;

	public RequestDTO() {
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	

}
