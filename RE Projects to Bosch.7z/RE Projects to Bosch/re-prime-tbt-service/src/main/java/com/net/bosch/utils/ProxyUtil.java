
package com.net.bosch.utils;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;


public class ProxyUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(ProxyUtil.class);
	
	public static JsonNode proxyGetService(String url, String queryString){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		logger.info("proxyGetService url -- > "+url);
		logger.info("proxyGetService queryString -- > "+queryString);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(null, headers);		
		ResponseEntity<JsonNode> response =  restTemplate.exchange(url+queryString,HttpMethod.GET,entity,JsonNode.class);
		return response.getBody();
	}	
	
	public static HttpEntity<byte[]> proxyMapPhotoService(String url, String queryString){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		logger.info("proxyGetService url -- > "+url);
		logger.info("proxyGetService queryString -- > "+queryString);
		String downloadURL = url+queryString;
        byte[] imageBytes = restTemplate.getForObject(downloadURL, byte[].class);        
		
		HttpHeaders header = new HttpHeaders();
	    header.set("Content-Disposition", "attachment; filename=1439911080563855663.jpg");
	    header.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
	    header.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    header.setContentLength(imageBytes.length);

	    return new HttpEntity<byte[]>(imageBytes, header);		
	}
}
