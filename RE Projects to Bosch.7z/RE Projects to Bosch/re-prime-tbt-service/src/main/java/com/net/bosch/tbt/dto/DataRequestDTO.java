package com.net.bosch.tbt.dto;

import java.io.Serializable;



//@JsonInclude(Include.NON_NULL)
public class DataRequestDTO implements Serializable{

	private static final long serialVersionUID = 1262911509336055237L;
	
	private String endPoint;
	
	private String queryString;

	public String getQueryString() {
		return queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}	
			
}
