package com.net.bosch.constants;

public class Constants {
	
	public static final String LONG_DATE_FORMAT = "hh:mm a MMM dd yyyy";
	public static final String SHORT_DATE_FORMAT = "dd-MMM-yyyy";
	public static final String RE_PRIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String RE_PRIME_MANUFACTURE_DATE = "MMM dd yyyy hh:mma";
	public static final String RE_PRIME_PURCHASE_DATE = "MMM dd yyyy hh:mma";

}
