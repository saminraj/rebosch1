package com.net.bosch.exceptions;

public class AppException extends RuntimeException
{

	private static final long serialVersionUID = -7374201234165750605L;

	public enum AppExceptionErrorCode{
		USER_DOES_NOT_EXIST,
		USER_ALREADY_EXISTS,
		USER_ID_IS_MANDATORY,
		INVALID_PASSWORD,
		PASSWORD_MISSING,
		EMAIL_ALREADY_EXISTS,
		OBJECT_ALREADY_EXISTS,
		OBJECT_DOES_NOT_EXIST,
		BAD_REQUEST_ERROR,		
		NOT_AUTHORIZED,
		VALIDATION_ERRORS,
		STALE_OBJECT_FOUND,
		PASSWORD_DOES_NOT_MATCH,
		NEWPASSWORD_SAME_AS_OLDPASSWORD, 
		EMAIL_NOT_REGISTERED,
		PARAMETER_MISSING,		
		;

		
	}
	
	private AppExceptionErrorCode errorCode;
	
	public AppException(){}
	
	public AppException(String message){
		super(message);
	}
	
	public AppException(String message, Throwable cause){
		super(message, cause);
	}

	public AppException(AppExceptionErrorCode errorCode){
		this.errorCode = errorCode;
	}

	public AppException(AppExceptionErrorCode errorCode, String message){
		super(message);
		this.errorCode = errorCode;
	}

	public AppException(AppExceptionErrorCode errorCode, String message, Throwable cause){
		super(message, cause);
		this.errorCode = errorCode;
	}

	public AppExceptionErrorCode getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(AppExceptionErrorCode errorCode) {
		this.errorCode = errorCode;
	}
	
	

}
