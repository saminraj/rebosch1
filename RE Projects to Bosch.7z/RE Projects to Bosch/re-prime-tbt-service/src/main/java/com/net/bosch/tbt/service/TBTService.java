package com.net.bosch.tbt.service;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.utils.ProxyUtil;


@Service
public class TBTService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
		
	ObjectMapper mapper = new ObjectMapper();
	
	public JsonNode proxyMapService(String endPoint, String queryString) throws AppException {
		queryString = queryString.replaceAll("%3A", ":");
		queryString = queryString.replaceAll("key=.*?(?=&|\\?|$)", "");
		queryString = queryString.concat("&key=").concat(env.getProperty("spring.tbt.map.googlekey"));
		return proxyService(endPoint, queryString, env.getProperty("spring.tbt.map.baseurl"));
	}
	
	public JsonNode proxyRoadService(String endPoint, String queryString) throws AppException {
		queryString = queryString.replaceAll("%7C", "|");
		queryString = queryString.replaceAll("key=.*?(?=&|\\?|$)", "");
		queryString = queryString.concat("&key=").concat(env.getProperty("spring.tbt.map.googlekey"));
		logger.info("proxyRoadService queryString now -> "+queryString);
		return proxyService(endPoint, queryString, env.getProperty("spring.tbt.roads.baseurl"));
	}
	
	public JsonNode proxyService(String endPoint, String queryString, String baseURL) throws AppException {
		String proxyURI = null;
		try {
			proxyURI = URLDecoder.decode(queryString, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		logger.info("Google api : "+ baseURL+endPoint+"?"+proxyURI);
		return ProxyUtil.proxyGetService(baseURL+endPoint+"?",proxyURI);		
	}
	
	public HttpEntity<byte[]> proxyMapPhotoService(String endPoint, String queryString) throws AppException {
		queryString = queryString.replaceAll("%3A", ":");
		queryString = queryString.replaceAll("key=.*?(?=&|\\?|$)", "");
		queryString = queryString.concat("&key=").concat(env.getProperty("spring.tbt.map.googlekey"));
		String proxyURI = null;
		try {
			proxyURI = URLDecoder.decode(queryString, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		String baseURL =  env.getProperty("spring.tbt.map.baseurl");
		logger.info("Google api : "+ baseURL+endPoint+"?"+proxyURI);	
		return ProxyUtil.proxyMapPhotoService(baseURL+endPoint+"?",proxyURI);
	}
}
