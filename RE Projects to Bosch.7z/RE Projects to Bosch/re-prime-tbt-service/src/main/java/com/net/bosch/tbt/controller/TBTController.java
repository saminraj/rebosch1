package com.net.bosch.tbt.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.tbt.dto.DataRequestDTO;
import com.net.bosch.tbt.service.TBTService;

@RestController
@CrossOrigin
@RequestMapping("/tbt")
public class TBTController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	TBTService tBTService;
	
	/**
	 * POST method to proxy service
	 */
	@PostMapping
	public JsonNode proxyService(@RequestBody @Valid DataRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("proxyService called");
		JsonNode response = tBTService.proxyMapService(requestDTO.getEndPoint(), requestDTO.getQueryString());
		logger.debug("[proxyService]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy placeTextsearch
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/place/textsearch/json")
	public JsonNode placeTextsearch(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("placeTextsearch called");
		logger.debug("placeTextsearch called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyMapService("/place/textsearch/json",httpServletRequest.getQueryString());
		logger.debug("[placeTextsearch]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}

	/**
	 * GET method to proxy nearbysearch
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/place/nearbysearch/json")
	public JsonNode placeNearbysearch(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("nearbysearch called");
		logger.debug("nearbysearch called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyMapService("/place/nearbysearch/json",httpServletRequest.getQueryString());
		logger.debug("[nearbysearch]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy placeDetails
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/place/details/json")
	public JsonNode placeDetails(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("placeDetails called");
		logger.debug("placeDetails called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyMapService("/place/details/json",httpServletRequest.getQueryString());
		logger.debug("[placeDetails]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy directions 
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/directions/json")
	public JsonNode directions(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("directions called");
		logger.debug("directions called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyMapService("/directions/json",httpServletRequest.getQueryString());
		logger.debug("[directions]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy directions 
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/v1/snapToRoads")
	public JsonNode roadsTosnap(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("roadsTosnap called");
		logger.debug("roadsTosnap called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyRoadService("/v1/snapToRoads",httpServletRequest.getQueryString());
		logger.debug("[roadsTosnap]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy directions 
	 * Given as separate method for the migration convince of the mobile application
	 */
	@GetMapping(value="/place/autocomplete/json")
	public JsonNode placeAutoComplete(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("placeAutoComplete called");
		logger.debug("placeAutoComplete called httpServletRequest "+httpServletRequest.getQueryString());
		JsonNode response = tBTService.proxyMapService("/place/autocomplete/json",httpServletRequest.getQueryString());
		logger.debug("[placeAutoComplete]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	/**
	 * GET method to proxy place photos
	 * Given as separate method for the migration convince of the mobile application
	 */
	@RequestMapping(value="/place/photo", method=RequestMethod.GET,  produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public HttpEntity<byte[]> placePhoto(HttpServletRequest httpServletRequest) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("placePhoto called");
		logger.debug("placePhoto called httpServletRequest "+httpServletRequest.getQueryString());
		HttpEntity<byte[]> response = tBTService.proxyMapPhotoService("/place/photo",httpServletRequest.getQueryString());
		logger.debug("[placePhoto]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String getTest() throws AppException {
		return "Success";
	}
	

}
