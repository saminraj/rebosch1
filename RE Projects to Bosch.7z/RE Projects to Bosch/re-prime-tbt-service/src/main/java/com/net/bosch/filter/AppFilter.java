package com.net.bosch.filter;

import java.io.IOException;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import redis.clients.jedis.Jedis;

import com.net.bosch.tbt.dao.DeviceAuthenticationRepository;
import com.net.bosch.tbt.domain.DeviceAuthentication;

@Component
public class AppFilter implements Filter {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Environment env;
	
	@Autowired
	DeviceAuthenticationRepository deviceAuthenticationRepository;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		logger.debug("Inside the App Filter---------------->");
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;		
		domainHandler(chain, request, response);		
	}

	@Override
	public void destroy() {
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}
	
	
	private boolean domainHandler(FilterChain chain, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		HttpSession session = request.getSession();
		String path = ( request).getRequestURI();
		logger.debug("Inside the App Filter getRequestURI ---------------->"+path);
		/*if( path.startsWith("/js/") || path.startsWith("/dataTables/") || path.startsWith("/css/") || path.startsWith("/images/")) {
			//Skip DomainCheck
			logger.debug("Skip DomainCheck ---------------->");
		} else {			
			String authToken = StringUtils.trimToNull(request.getHeader("Authorization"));
			logger.info("authToken Token {{}}", authToken);
			if (StringUtils.isEmpty(authToken)) {
				logger.debug("UI sent a null or empty token");
				//response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authorization Token is Required.");
				chain.doFilter(request, response);
				return false;
			}
			logger.debug("Token Validator token ----------------> " + authToken);
			DeviceAuthentication deviceAuthentication = null;
			String[] tokens = authToken.split("####");//Separator used in the authorization header to separate the 3 keys
			//Temp workaround for deviceToken null
			try {
				logger.debug("Token Validator tokens.length ----------------> " +tokens.length);
				if(tokens.length < 4 || tokens[2] == null || tokens[2].isEmpty()
						|| tokens[3] == null || tokens[3].isEmpty() || tokens[3].equalsIgnoreCase("false")){
					chain.doFilter(request, response);
					return false;
				}
			} catch (Exception e1) {
				e1.printStackTrace();
				chain.doFilter(request, response);
				return false;				
			}
			try {
				logger.debug("Token Validator jwtkey ----------------> " + tokens[0]);
				logger.debug("Token Validator accesskey ----------------> " + tokens[1]);
				logger.debug("Token Validator devicetoken or guid ----------------> " + tokens[2]);
				logger.debug("Token Validator auth enabled ----------------> " + tokens[3]);
				logger.info("spring.redis.host---> "+env.getProperty("spring.redis.host"));
				try {
					deviceAuthentication = deviceAuthenticationRepository.findById(tokens[2]).get();
				} catch (Exception e) {
					logger.info("Exception while connect to first redis server -> "+e.getMessage());
				}
				if(deviceAuthentication == null){
					//REDIS resiliency Implementation 10 DEC 2010 
					logger.debug("Redis connection  exception while try first server ----------------> ");
					logger.info("spring.redis.second.host---> "+env.getProperty("spring.redis.second.host"));
					Jedis jedis = new Jedis(env.getProperty("spring.redis.second.host"));
					Set<String> keys = jedis.keys("DeviceAuthentication:"+tokens[2]);
					logger.info("Key resultset ----> "+keys.toString()+" keys.size()  -> "+(keys.size()>0) );
					if(keys != null && !keys.isEmpty() && keys.size() > 0){
						deviceAuthentication =  new DeviceAuthentication();
				        for (String key : keys) {
				        	deviceAuthentication.setKey(jedis.hmget(key, "key").get(0));
				        	//break;
				        }
					}
			        jedis.close();
				}				
			} catch (Exception e) {	
				logger.error(e.getMessage());
			}
			if(deviceAuthentication != null)logger.debug("Token Validator deviceAuthentication key ----------------> " + deviceAuthentication.getKey());
			if (deviceAuthentication == null || !deviceAuthentication.getKey().equalsIgnoreCase(tokens[1])) {
				logger.debug("Invalid authentication token ----------------> " + authToken);
				
				// response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Auth token is invalid or incorrect");
				return false;
			}
		}*/
		chain.doFilter(request, response);
		return false;
	}
	
	
}
