package com.net.bosch.exceptions;

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;

@ControllerAdvice
public class GlobalExceptionHandlingControllerAdvice {

	protected Logger logger;
	
	@Autowired
	private MessageSource messageSource;

	public GlobalExceptionHandlingControllerAdvice() {
		logger = LoggerFactory.getLogger(getClass());
	}

	/**
	 * Convert a predefined exception to an HTTP Status code
	 */
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	public @ResponseBody ErrorResponse handleGeneralError(Exception exception) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode(AppExceptionErrorCode.VALIDATION_ERRORS);
		errorResponse.setErrorMessage(exception.getMessage());
		logger.debug("General Exception", exception);
		return errorResponse;
	}
	/**
	 * Convert a predefined exception to an HTTP Status code
	 */
	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(AppException.class)
	public @ResponseBody ErrorResponse handleAppError(AppException appException) {
		ErrorResponse errorResponse = new ErrorResponse();
		if (appException.getErrorCode()!=null)
			errorResponse.setErrorCode(appException.getErrorCode());
		errorResponse.setErrorMessage(appException.getMessage());
		logger.debug("AppException", appException);
		return errorResponse;
	}
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ErrorResponse processHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode(AppExceptionErrorCode.BAD_REQUEST_ERROR);
		errorResponse.setErrorMessage(ex.getMessage());
		logger.debug("HttpRequestMethodNotSupportedException", ex);
		return errorResponse;    
	}

	
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ErrorResponse processValidationError(MethodArgumentNotValidException ex) {
        BindingResult result = ex.getBindingResult();
        List<FieldError> fieldErrors = result.getFieldErrors();
        return processFieldErrors(fieldErrors);
    }
 
    private ErrorResponse processFieldErrors(List<FieldError> fieldErrors) {
        ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode(AppExceptionErrorCode.VALIDATION_ERRORS);
        for (FieldError fieldError: fieldErrors) {
            String localizedErrorMessage = resolveLocalizedErrorMessage(fieldError);
            errorResponse.addFieldError(fieldError.getObjectName(), fieldError.getField(), localizedErrorMessage);
        }
        return errorResponse;
    }
 
    private String resolveLocalizedErrorMessage(FieldError fieldError) {
        Locale currentLocale =  LocaleContextHolder.getLocale();
        String localizedErrorMessage = messageSource.getMessage(fieldError, currentLocale); 
        return localizedErrorMessage;
    }

}