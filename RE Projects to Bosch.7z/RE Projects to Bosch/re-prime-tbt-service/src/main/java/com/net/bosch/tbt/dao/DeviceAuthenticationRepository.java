package com.net.bosch.tbt.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.tbt.domain.DeviceAuthentication;

@Repository
public interface DeviceAuthenticationRepository extends CrudRepository<DeviceAuthentication, String> {
	
		
		

}