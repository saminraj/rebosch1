package com.net.nagarro.email.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.net.bosch.crmmaster.service.EmailService;
import com.net.bosch.utils.EmailHelper;

/**
 * @author pushkarkhosla
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class MaillServiceTest {

	private static final String NOREPLY_ROYALENFIELD_COM = "noreply@royalenfield.com";

	@InjectMocks
	private EmailService emailService;

	@Rule
	public SmtpServerRule smtpServerRule = new SmtpServerRule(2525);

	@Mock
	private JavaMailSender javaMailSender;
	@Mock
	private EmailHelper emailHelper;

	private MimeMessage mimeMessage;

	@Before
	public void setupMocks() throws MessagingException {
		mimeMessage = new JavaMailSenderImpl().createMimeMessage();

	}

	@Test
	public void sendMail() throws MessagingException {
		String from = NOREPLY_ROYALENFIELD_COM;
		String to = NOREPLY_ROYALENFIELD_COM;
		String subject = "subject";
		String msg = "<html>msg</html>";

		when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);

		emailService.sendEmail(from, to, null, subject, msg, null);

		assertEquals(from, mimeMessage.getFrom()[0].toString());
		assertEquals(to, mimeMessage.getAllRecipients()[0].toString());
		assertEquals(subject, mimeMessage.getSubject());
	}

	@Test
	public void sendMailWithAttachments() throws MessagingException {
		String from = NOREPLY_ROYALENFIELD_COM;
		String to = NOREPLY_ROYALENFIELD_COM;
		String subject = "subject";
		String msg = "<html>msg</html>";

		MockMultipartFile kycDoc = new MockMultipartFile("data", "filename.txt", "text/html", "some xml".getBytes());
		MockMultipartFile ownerDoc = new MockMultipartFile("data", "other-file-name.data", "text/html",
				"some other type".getBytes());

		Map<String, MultipartFile> docsMap = new HashMap<>();
		docsMap.put("kycDoc", kycDoc);
		docsMap.put("ownerDoc", ownerDoc);

		when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);

		emailService.sendEmail(from, to, null, subject, msg, docsMap);

		assertEquals(from, mimeMessage.getFrom()[0].toString());
		assertEquals(to, mimeMessage.getAllRecipients()[0].toString());
		assertEquals(subject, mimeMessage.getSubject());
	}

}
