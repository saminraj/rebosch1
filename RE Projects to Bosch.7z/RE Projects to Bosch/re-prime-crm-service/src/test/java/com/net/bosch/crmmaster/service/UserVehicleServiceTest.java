package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.SUCCESS_CODE;
import static com.net.bosch.constants.REResponse.CALL_CUSTOMER_SUPPORT;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import com.net.bosch.constants.VehicleStatus;
import com.net.bosch.crmmaster.dao.UserVehicleRepository;
import com.net.bosch.crmmaster.dto.AddVehicleRequestDTO;
import com.net.bosch.crmmaster.dto.GetVehicleVinRequestDTO;
import com.net.bosch.crmmaster.dto.ListRegistrationNumberRequestDTO;
import com.net.bosch.crmmaster.dto.RegistrationNumberRequest;
import com.net.bosch.crmmaster.dto.VehicleVerifyRequestDTO;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;
import com.net.bosch.crmmaster.dto.resultset.VehicleVinResponseObject;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicle;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicleDetails;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.dto.base.RequestDTO;
import com.net.bosch.utils.DateHelper;

@RunWith(MockitoJUnitRunner.class)
public class UserVehicleServiceTest {

	private static final String UPDATED_REGIS_NO = "222222222";

	private static final String PREVIOUS_REGIS_NO = "111111111";

	private static final String CLASSIC_350 = "Classic 350";

	private static final String ENGINE_NO = "32423423";

	private static final String MOBILE_NO = "234234234234";

	private static final String ME3U5S5F0AF006310 = "ME3U5S5F0AF006310";

	private static final String ME3U3S5F2LB887562 = "ME3U3S5F2LB887562";

	private static final String VEHICLE_MODEL_CODE = "800626";

	private static final String PHONE_NO = "9712129222";

	private static final String PURCHASE_DATE = "2010-06-21 18:30:00.000";

	private static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

	private static final String MMM_DD_YYYY_HH_MMA = "MMM dd yyyy hh:mma";

	private static final String JUN_22_2010_12_00AM = "Jun 22 2010 12:00AM";

	private static final String YOGENDRA_SINGH = "YOGENDRA SINGH";

	@Mock
	private StoredProcedureService storedProcedureService;

	@InjectMocks
	private UserVehicleService userVehicleService;

	@Mock
	private UserVehicleRepository userVehicleRepository;

	@Mock
	private AzureUploadService azureUploadService;

	@Mock
	private RestTemplateService restTemplateService;

	@Mock
	private EmailService emailService;

	private UserVehicle userVehicle = getUserVehicleStub();
	private RequestDTO vehicleRequestDTO = getGetVehicleRequestDTOStub();
	private GetVehicleVinRequestDTO getVehicleVinRequestDTO = getGetVehicleVinRequestDTOStub();
	private List<VehicleDetailsVO> vehicleDetailsVOList = getVehicleDetailsVOListStub();
	private List<VehicleVinResponseObject> VehicleVinResponseObjectList = getVehicleVinResponseStub();

	/**
	 * For getDetails API If User Vehicles Not Found.
	 */
	@Test
	public void testGetVehicleDetailsIfUserVehiclesNotFound() {

		when(storedProcedureService.callGetVehicleDetailsProcedure(vehicleRequestDTO.getLoggedInUserMobileNo()))
				.thenReturn(null);
		REBaseResponse br = userVehicleService.getUserVehicleDetails(vehicleRequestDTO);
		assertEquals("User Vehicles Not Found.", br.getErrorMessage());
	}

	@Test
	public void testGetVehicleVinIfUserVehiclesNotFound() {

		when(storedProcedureService.getVehicleVin(getVehicleVinRequestDTO)).thenReturn(null);
		REBaseResponse br = userVehicleService.getVehicleVin(getVehicleVinRequestDTO);
		assertEquals("User Vehicles Not Found.", br.getErrorMessage());
	}

	/**
	 * For getDetails API If User Vehicles Found Successfully.
	 */
	@Test
	public void testGetVehicleDetailsIfUserVehiclesFound() {

		when(storedProcedureService.callGetVehicleDetailsProcedure(vehicleRequestDTO.getLoggedInUserMobileNo()))
				.thenReturn(vehicleDetailsVOList);
		when(userVehicleRepository.save(any(UserVehicle.class))).thenReturn(userVehicle);
		when(restTemplateService.callShowAuthorizeApi(any(String.class))).thenReturn(true);
		REBaseResponse br = userVehicleService.getUserVehicleDetails(vehicleRequestDTO);
		assertEquals(SUCCESS_CODE, br.getCode());
		assertEquals(1, userVehicle.getUserVehicles().size());
	}

	@Test
	public void testGetVehicleVinIfUserVehiclesFound() {

		when(storedProcedureService.getVehicleVin(getVehicleVinRequestDTO)).thenReturn(VehicleVinResponseObjectList);

		REBaseResponse br = userVehicleService.getVehicleVin(getVehicleVinRequestDTO);
		assertEquals(SUCCESS_CODE, br.getCode());
		assertEquals(1, userVehicle.getUserVehicles().size());
	}

	/**
	 * For getDetails API If User Vehicles Already Available Then Not Processing
	 * Duplicate Records In Mongo.
	 */
	@Test
	public void testGetVehicleDetailsIfUserVehiclesAlreadyAvailable() {

		when(storedProcedureService.callGetVehicleDetailsProcedure(vehicleRequestDTO.getLoggedInUserMobileNo()))
				.thenReturn(vehicleDetailsVOList);
		when(restTemplateService.callShowAuthorizeApi(any(String.class))).thenReturn(true);
		REBaseResponse br = userVehicleService.getUserVehicleDetails(vehicleRequestDTO);
		assertEquals(SUCCESS_CODE, br.getCode());
		assertEquals(1, userVehicle.getUserVehicles().size());
	}

	/**
	 * For getDetails API If User Vehicles Already Available & CRM returns One More
	 * Vehicle Then Processing This new Vehicle in Mongo
	 */
	@Test
	public void testGetVehicleDetailsIfUserVehiclesAlreadyAvailableThenUpdateNewDetails() {

		VehicleDetailsVO object = new VehicleDetailsVO();
		object.setUserName(YOGENDRA_SINGH);
		object.setChassisNo("ME3U5S5F0AF008888");
		object.setDateOfMfg(DateHelper.formatDateToMMMDDYYYY(JUN_22_2010_12_00AM, MMM_DD_YYYY_HH_MMA));
		object.setEngineNo("U5S5F0AF008888");
		object.setId("2898888");
		object.setPurchaseDate(DateHelper.formatDateToMMMDDYYYY(PURCHASE_DATE, YYYY_MM_DD_HH_MM_SS));
		object.setMobileNo(PHONE_NO);
		object.setVehicleModelCode(VEHICLE_MODEL_CODE);
		object.setVehicleModelName("CLASSIC 600 MAROON");
		vehicleDetailsVOList.add(object);

		when(storedProcedureService.callGetVehicleDetailsProcedure(vehicleRequestDTO.getLoggedInUserMobileNo()))
				.thenReturn(vehicleDetailsVOList);
		when(restTemplateService.callShowAuthorizeApi(any(String.class))).thenReturn(true);
		when(userVehicleRepository.save(any(UserVehicle.class))).thenReturn(userVehicle);

		REBaseResponse br = userVehicleService.getUserVehicleDetails(vehicleRequestDTO);
		assertEquals(SUCCESS_CODE, br.getCode());
	}

	@Test
	public void testVerifyUserVehicleDetailsRegistrationNumberMustBeAlpanumeric() {

		VehicleVerifyRequestDTO verifyObjectTest = new VehicleVerifyRequestDTO();
		verifyObjectTest.setChassisNumber(ME3U3S5F2LB887562);
		verifyObjectTest.setRegistrationNumber("234234SSD!");

		REBaseResponse br = userVehicleService.verifyUserVehicleDetails(verifyObjectTest);
		assertEquals("1015", br.getCode());
	}

	@Test
	public void testVerifyUserVehicleDetailsInvalidRegistrationNumberLength() {

		VehicleVerifyRequestDTO verifyObjectTest = new VehicleVerifyRequestDTO();
		verifyObjectTest.setChassisNumber(ME3U3S5F2LB887562);
		verifyObjectTest.setRegistrationNumber("234234SSD123");

		REBaseResponse br = userVehicleService.verifyUserVehicleDetails(verifyObjectTest);
		assertEquals("1023", br.getCode());
	}

	/**
	 * For verifyVehicleDetails Success
	 */
	@Test
	public void testVerifyUserVehicleDetailsSuccess() {

		VehicleVerifyRequestDTO verifyObjectTest = new VehicleVerifyRequestDTO();
		verifyObjectTest.setChassisNumber(ME3U3S5F2LB887562);
		verifyObjectTest.setRegistrationNumber("");

		VehicleDetailsVO object = new VehicleDetailsVO();
		object.setUserName(YOGENDRA_SINGH);
		object.setChassisNo(ME3U5S5F0AF006310);
		object.setDateOfMfg(DateHelper.formatDateToMMMDDYYYY(JUN_22_2010_12_00AM, MMM_DD_YYYY_HH_MMA));
		object.setEngineNo("U5S5F0AF006310");
		object.setId("2898332");
		object.setPurchaseDate(DateHelper.formatDateToMMMDDYYYY(PURCHASE_DATE, YYYY_MM_DD_HH_MM_SS));
		object.setMobileNo(PHONE_NO);
		object.setVehicleModelCode(VEHICLE_MODEL_CODE);
		object.setVehicleModelName("CLASSIC 500 MAROON");
		object.setRegistrationNo("234234SSDF");

		Object[][] objectArr = new Object[1][2];
		objectArr[0][0] = object;
		objectArr[0][1] = CALL_CUSTOMER_SUPPORT;

		when(storedProcedureService.callVerifyUserVehicleDetailsProcedure(verifyObjectTest)).thenReturn(objectArr);

		REBaseResponse br = userVehicleService.verifyUserVehicleDetails(verifyObjectTest);
		assertEquals(SUCCESS_CODE, br.getCode());
	}

	/**
	 * Add Vehicle Flow Success
	 * 
	 * @throws IOException
	 */
	@Test
	public void testAddVehicleDetailUserSuccess() throws IOException {

		AddVehicleRequestDTO addVDto = new AddVehicleRequestDTO();
		addVDto.setLoggedInUserMobileNo("1234567890");
		addVDto.setGuid("guid");

		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(date);
		addVDto.setPurchaseDate(strDate);

		REBaseResponse response = new REBaseResponse();
		response.setCode(SUCCESS_CODE);
		when(emailService.validateFiles(any(MultipartFile[].class))).thenReturn(response);

		Map<String, MultipartFile> docsMap = new HashMap<>();
		docsMap.put("kycDoc", mock(MultipartFile.class));
		docsMap.put("ownerDoc", mock(MultipartFile.class));

		// doNothing().when(azureUploadService).uploadtoAzure(any(Map.class),
		// any(String.class),any(UserVehicleDetails.class),
		// any(AddVehicleRequestDTO.class));

		when(userVehicleRepository.save(any(UserVehicle.class))).thenReturn(userVehicle);

		/*
		 * doNothing().when(emailService).sendEmail(any(EmailConditions_Enum.class),
		 * any(EmailDTO.class), any(Map.class), any(String.class), any(String.class));
		 */
		String json = "{\"guid\":\"guid\",\"loggedInUserMobileNo\":\"1234567890\",\"purchaseDate\":\"23/10/2020\"}";
		REBaseResponse br = userVehicleService.addVehicle(json, null, null, null);
		assertEquals(SUCCESS_CODE, br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsInvalidRequest() {
		ListRegistrationNumberRequestDTO dto = new ListRegistrationNumberRequestDTO();
		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(dto);
		assertEquals("4001", br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsUserVehiclesNotFound() {
		ListRegistrationNumberRequestDTO requestDto = new ListRegistrationNumberRequestDTO();
		requestDto.setLoggedInUserMobileNo(MOBILE_NO);
		RegistrationNumberRequest dto = new RegistrationNumberRequest();
		dto.setEngineNo(ENGINE_NO);
		dto.setVehicleModelName(CLASSIC_350);
		dto.setPreviousRegistrationNumber(PREVIOUS_REGIS_NO);
		dto.setUpdatedRegistrationNumber(UPDATED_REGIS_NO);
		dto.setRemoveBike(false);

		List<RegistrationNumberRequest> list = new ArrayList<>();
		list.add(dto);
		requestDto.setVehicleList(list);

		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(requestDto);
		assertEquals("1002", br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsSuccess() {
		ListRegistrationNumberRequestDTO requestDto = new ListRegistrationNumberRequestDTO();
		requestDto.setGuid("guid");
		RegistrationNumberRequest dto = new RegistrationNumberRequest();
		dto.setEngineNo(ENGINE_NO);
		dto.setVehicleModelName(CLASSIC_350);
		dto.setPreviousRegistrationNumber(PREVIOUS_REGIS_NO);
		dto.setUpdatedRegistrationNumber(UPDATED_REGIS_NO);
		dto.setRemoveBike(false);
		List<RegistrationNumberRequest> list = new ArrayList<>();
		list.add(dto);
		requestDto.setVehicleList(list);
		requestDto.setLoggedInUserMobileNo(MOBILE_NO);

		when(userVehicleRepository.findByGuid("guid")).thenReturn(Optional.of(userVehicle));
		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(requestDto);
		assertEquals(SUCCESS_CODE, br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsInvalidRegistratonNumberLength() {
		ListRegistrationNumberRequestDTO requestDto = new ListRegistrationNumberRequestDTO();
		RegistrationNumberRequest dto = new RegistrationNumberRequest();
		dto.setEngineNo(ENGINE_NO);
		dto.setVehicleModelName(CLASSIC_350);
		dto.setPreviousRegistrationNumber(PREVIOUS_REGIS_NO);
		dto.setUpdatedRegistrationNumber("2222");
		dto.setRemoveBike(false);
		List<RegistrationNumberRequest> list = new ArrayList<>();
		list.add(dto);
		requestDto.setVehicleList(list);
		requestDto.setLoggedInUserMobileNo(MOBILE_NO);

		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(requestDto);
		assertEquals("1016", br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsValidRegistratonNumberPattern() {
		ListRegistrationNumberRequestDTO requestDto = new ListRegistrationNumberRequestDTO();
		RegistrationNumberRequest dto = new RegistrationNumberRequest();
		dto.setEngineNo(ENGINE_NO);
		dto.setVehicleModelName(CLASSIC_350);
		dto.setPreviousRegistrationNumber(PREVIOUS_REGIS_NO);
		dto.setUpdatedRegistrationNumber("2222@134A");
		dto.setRemoveBike(false);
		List<RegistrationNumberRequest> list = new ArrayList<>();
		list.add(dto);
		requestDto.setVehicleList(list);
		requestDto.setLoggedInUserMobileNo(MOBILE_NO);

		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(requestDto);
		assertEquals("1015", br.getCode());
	}

	@Test
	public void testUpdateBikeDetailsWithDeleteSuccess() {
		ListRegistrationNumberRequestDTO requestDto = new ListRegistrationNumberRequestDTO();

		RegistrationNumberRequest dto = new RegistrationNumberRequest();
		requestDto.setGuid("guid");
		dto.setEngineNo(ENGINE_NO);
		dto.setVehicleModelName(CLASSIC_350);
		dto.setPreviousRegistrationNumber(PREVIOUS_REGIS_NO);
		dto.setUpdatedRegistrationNumber(UPDATED_REGIS_NO);
		dto.setRemoveBike(true);
		List<RegistrationNumberRequest> list = new ArrayList<>();
		list.add(dto);
		requestDto.setVehicleList(list);
		requestDto.setLoggedInUserMobileNo(MOBILE_NO);
		when(userVehicleRepository.findByGuid("guid")).thenReturn(Optional.of(userVehicle));
		REBaseResponse br = userVehicleService.updateRegisNumberAndRemoveBike(requestDto);
		assertEquals(SUCCESS_CODE, br.getCode());
	}

	/**
	 * Below Methods are Stubs
	 */
	private static RequestDTO getGetVehicleRequestDTOStub() {
		RequestDTO requestDto = new RequestDTO();
		requestDto.setLoggedInUserMobileNo(PHONE_NO);
		return requestDto;
	}

	private static GetVehicleVinRequestDTO getGetVehicleVinRequestDTOStub() {
		GetVehicleVinRequestDTO requestDto = new GetVehicleVinRequestDTO();
		requestDto.setChassisNo(ME3U5S5F0AF006310);
		return requestDto;
	}

	private static List<VehicleDetailsVO> getVehicleDetailsVOListStub() {
		List<VehicleDetailsVO> resultList = new ArrayList<>();
		VehicleDetailsVO object = new VehicleDetailsVO();
		object.setUserName(YOGENDRA_SINGH);
		object.setChassisNo(ME3U5S5F0AF006310);
		object.setDateOfMfg(DateHelper.formatDateToMMMDDYYYY(JUN_22_2010_12_00AM, MMM_DD_YYYY_HH_MMA));
		object.setEngineNo("U5S5F0AF006310");
		object.setId("2898332");
		object.setPurchaseDate(DateHelper.formatDateToMMMDDYYYY(PURCHASE_DATE, YYYY_MM_DD_HH_MM_SS));
		object.setMobileNo(PHONE_NO);
		object.setVehicleModelCode(VEHICLE_MODEL_CODE);
		object.setVehicleModelName("CLASSIC 500 MAROON");
		object.setRegistrationNo(StringUtils.EMPTY);
		object.setInvoiceNo(StringUtils.EMPTY);
		object.setAlternateNo(StringUtils.EMPTY);

		resultList.add(object);
		return resultList;
	}

	private static List<VehicleVinResponseObject> getVehicleVinResponseStub() {
		List<VehicleVinResponseObject> resultList = new ArrayList<>();
		VehicleVinResponseObject object = new VehicleVinResponseObject();
		object.setChassisNo(ME3U5S5F0AF006310);

		resultList.add(object);
		return resultList;
	}

	private static UserVehicle getUserVehicleStub() {
		UserVehicle userVehicle = new UserVehicle();
		userVehicle.setGuid("guid");
		userVehicle.setId("342342242234234");
		List<UserVehicleDetails> userVehiclesList = new ArrayList<>();
		for (VehicleDetailsVO obj : getVehicleDetailsVOListStub()) {
			userVehiclesList.add(setUserVehicleDetails(obj));
		}
		userVehicle.setUserVehicles(userVehiclesList);
		return userVehicle;
	}

	private static UserVehicleDetails setUserVehicleDetails(final VehicleDetailsVO bean) {
		UserVehicleDetails objectToSave = new UserVehicleDetails();
		objectToSave.setUserName(bean.getUserName());
		objectToSave.setDateOfMfg(bean.getDateOfMfg());
		objectToSave.setChassisNo(bean.getChassisNo());
		objectToSave.setEngineNo(bean.getEngineNo());
		objectToSave.setMsdynName(bean.getId());
		objectToSave.setInvoiceNo(bean.getInvoiceNo());
		objectToSave.setAlternateNo(bean.getAlternateNo());
		objectToSave.setVehicleModelCode(bean.getVehicleModelCode());
		objectToSave.setVehicleModelName(bean.getVehicleModelName());
		objectToSave.setPurchaseDate(bean.getPurchaseDate());
		objectToSave.setRegistrationNo(bean.getRegistrationNo());
		objectToSave.setVehicleStatus(VehicleStatus.PENDING);

		return objectToSave;
	}
}
