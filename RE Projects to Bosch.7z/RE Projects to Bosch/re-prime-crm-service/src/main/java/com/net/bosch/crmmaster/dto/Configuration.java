package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

public class Configuration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String configName;
	private String soundHelper;
	@NotEmpty
	private String configId;
	private String customizedBikeName;

	private List<SelectedProducts> selectedProducts;

	/**
	 * @return the customizedBikeName
	 */
	public String getCustomizedBikeName() {
		return customizedBikeName;
	}

	/**
	 * @param customizedBikeName the customizedBikeName to set
	 */
	public void setCustomizedBikeName(String customizedBikeName) {
		this.customizedBikeName = customizedBikeName;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getSoundHelper() {
		return soundHelper;
	}

	public void setSoundHelper(String soundHelper) {
		this.soundHelper = soundHelper;
	}

	public List<SelectedProducts> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<SelectedProducts> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Configuration [configName=");
		builder.append(configName);
		builder.append(", soundHelper=");
		builder.append(soundHelper);
		builder.append(", configId=");
		builder.append(configId);
		builder.append(", selectedProducts=");
		builder.append(selectedProducts);
		builder.append(", customizedBikeName=");
		builder.append(customizedBikeName);
		builder.append("]");
		return builder.toString();
	}

}
