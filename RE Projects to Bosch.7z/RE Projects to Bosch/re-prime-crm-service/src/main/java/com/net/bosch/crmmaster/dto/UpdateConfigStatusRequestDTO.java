package com.net.bosch.crmmaster.dto;

public class UpdateConfigStatusRequestDTO {

	private String configId;
	private String configStatus;

	/**
	 * @param configId
	 * @param configStatus
	 */
	public UpdateConfigStatusRequestDTO(String configId, String configStatus) {
		super();
		this.configId = configId;
		this.configStatus = configStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateConfigStatusRequestDTO [configId=");
		builder.append(configId);
		builder.append(", configStatus=");
		builder.append(configStatus);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the configId
	 */
	public String getConfigId() {
		return configId;
	}

	/**
	 * @param configId the configId to set
	 */
	public void setConfigId(String configId) {
		this.configId = configId;
	}

	/**
	 * @return the configStatus
	 */
	public String getConfigStatus() {
		return configStatus;
	}

	/**
	 * @param configStatus the configStatus to set
	 */
	public void setConfigStatus(String configStatus) {
		this.configStatus = configStatus;
	}

}