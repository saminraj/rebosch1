package com.net.bosch.crmmaster.dto.firebase;

import java.util.ArrayList;
import java.util.List;

public class VehicleVO {

	List<VehicleInfoVO> vehicleInfo = new ArrayList<>();

	public void addVehicleInfoVO(VehicleInfoVO vehicleInfoVO) {
		vehicleInfo.add(vehicleInfoVO);
	}

	public List<VehicleInfoVO> getVehicleInfo() {
		return vehicleInfo;
	}

	public void setVehicleInfo(List<VehicleInfoVO> vehicleInfo) {
		this.vehicleInfo = vehicleInfo;
	}

}
