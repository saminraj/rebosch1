package com.net.bosch.utils;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.util.ObjectUtils;

import com.net.bosch.constants.REResponse;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyResponse;
import com.net.bosch.crmmaster.service.ExcellonSoapService;
import com.net.bosch.dto.base.REBaseResponse;

import https.royalenfield_com.generatepaymentkey.ReBaseResponse;
import https.royalenfield_com.generatepaymentkey.ReBaseResponse.Data;

/**
 * @author pushkarkhosla
 *
 */
public class SoapResponseHelper {

	/**
	 * Used in {@link ExcellonSoapService}.
	 * 
	 * @param reResponse
	 * @return
	 */
	public static ReBaseResponse getErrorResponse(REResponse reResponse) {
		ReBaseResponse response = new ReBaseResponse();
		response.setError(Boolean.TRUE);
		response.setCode(reResponse.getCode());
		response.setErrorMessage(reResponse.getMessage());
		return response;
	}

	/**
	 * Used in {@link ExcellonSoapService}.
	 * 
	 * @param paymentKeyRes
	 * @return
	 */
	public static ReBaseResponse convertResponseForExcellonGenratePaymentKey(REBaseResponse response) {
		ReBaseResponse soapResponse = new ReBaseResponse();
		soapResponse.setCode(response.getCode());
		soapResponse.setError(response.isError());
		soapResponse.setErrorMessage(response.getErrorMessage());
		if (!ObjectUtils.isEmpty(response.getData())) {
			GeneratePaymentKeyResponse paymentKeyRes = (GeneratePaymentKeyResponse) response.getData();
			ReBaseResponse.Data soapData = new Data();
			soapData.setPaymentKey(paymentKeyRes.getPaymentKey());
			soapData.setResultUrl(paymentKeyRes.getResultUrl());
			soapResponse.setData(soapData);
		}
		return soapResponse;
	}

	/**
	 * @param response
	 * @param errorResponse
	 * @return
	 * @throws IOException
	 */
	public static HttpServletResponse getSoapXMLResponse(HttpServletResponse response, String errorMsg)
			throws IOException {
		((HttpServletResponse) response).setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.getOutputStream().write(soapXMLError(HttpServletResponse.SC_UNAUTHORIZED, errorMsg).getBytes());
		return response;
	}

	/**
	 * @param errorCode
	 * @param errorMsg
	 * @return
	 */
	private static String soapXMLError(final int errorCode, final String errorMsg) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(
				"<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP-ENV:Header/><SOAP-ENV:Body><ns2:reBaseResponse xmlns:ns2=\"https://royalenfield.com/generatePaymentKey\"><ns2:code>");
		stringBuilder.append(errorCode);
		stringBuilder.append("</ns2:code><ns2:error>true</ns2:error><ns2:errorMessage>");
		stringBuilder.append(errorMsg);
		stringBuilder.append("</ns2:errorMessage></ns2:reBaseResponse></SOAP-ENV:Body></SOAP-ENV:Envelope>");
		return stringBuilder.toString();
	}
}
