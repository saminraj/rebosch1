package com.net.bosch.crmmaster.dto;

import java.util.List;

public class UserBookingsResponseDTO {

	private String paymentCaseId;
	private String billDeskTrnsactionId;
	private String paymentStatus;
	private String bookingStatus;
	private String bookingId;
	private String bookingDate;
	private String bookingPostedDate;
	private List<DynamicsBookingPaymentPartsDTO> partsData;
	private String dealerSource;
	private String modelCode;
	private String modelName;
	private String tentativeDeliveryDays;

	private UserBookingFinanceResponseDTO financerDetails;

	public String getTentativeDeliveryDays() {
		return tentativeDeliveryDays;
	}

	public void setTentativeDeliveryDays(String tentativeDeliveryDays) {
		this.tentativeDeliveryDays = tentativeDeliveryDays;
	}

	public String getModelCode() {
		return modelCode;
	}

	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	public String getDealerSource() {
		return dealerSource;
	}

	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the partsData
	 */
	public List<DynamicsBookingPaymentPartsDTO> getPartsData() {
		return partsData;
	}

	/**
	 * @param partsData the partsData to set
	 */
	public void setPartsData(List<DynamicsBookingPaymentPartsDTO> partsData) {
		this.partsData = partsData;
	}

	public String getBookingPostedDate() {
		return bookingPostedDate;
	}

	public void setBookingPostedDate(String bookingPostedDate) {
		this.bookingPostedDate = bookingPostedDate;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	public String getBillDeskTrnsactionId() {
		return billDeskTrnsactionId;
	}

	public void setBillDeskTrnsactionId(String billDeskTrnsactionId) {
		this.billDeskTrnsactionId = billDeskTrnsactionId;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}

	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	/**
	 * @return the financerDetails
	 */
	public UserBookingFinanceResponseDTO getFinancerDetails() {
		return financerDetails;
	}

	/**
	 * @param financerDetails the financerDetails to set
	 */
	public void setFinancerDetails(UserBookingFinanceResponseDTO financerDetails) {
		this.financerDetails = financerDetails;
	}

}
