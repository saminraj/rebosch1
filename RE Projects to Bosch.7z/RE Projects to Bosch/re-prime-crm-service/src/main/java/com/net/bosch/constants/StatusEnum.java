package com.net.bosch.constants;

public enum StatusEnum {
	ACTIVE("ACTIVE", 0), INACTIVE("INACTIVE", -1), ARCHIVED("ARCHIVED", -2), EXPIRED("EXPIRED", -3);
	
	private final String name;
	private final int code;
	
	private StatusEnum(String name, int code){
		this.name = name;
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public int getCode() {
		return code;
	}
	
	
}
