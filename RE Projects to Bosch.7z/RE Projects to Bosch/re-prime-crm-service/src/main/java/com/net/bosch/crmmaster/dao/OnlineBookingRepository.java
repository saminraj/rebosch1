package com.net.bosch.crmmaster.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.net.bosch.constants.BookingStatus;
import com.net.bosch.crmmaster.payment.collection.OnlineBooking;

@Repository
public interface OnlineBookingRepository extends MongoRepository<OnlineBooking, String> {

	List<OnlineBooking> findByGuid(@Param(value = "guid") String guid);

	Optional<OnlineBooking> findByBookingCaseId(@Param(value = "bookingCaseId") String bookingCaseId);

	Optional<OnlineBooking> findByBookingCaseIdAndBookingStatusIn(@Param(value = "bookingCaseId") String bookingCaseId,
			@Param(value = "bookingStatus") BookingStatus[] bookingStatus);

	Optional<OnlineBooking> findByBookingCaseIdAndGuid(@Param(value = "bookingCaseId") String bookingCaseId,
			@Param(value = "guid") String guid);

	List<OnlineBooking> findByInStoreDynamicsRequestMobileno(@Param(value = "mobileno") String mobileno);

	Optional<OnlineBooking> findByInStoreDynamicsRequestConfigid(@Param(value = "configid") String configid);
}