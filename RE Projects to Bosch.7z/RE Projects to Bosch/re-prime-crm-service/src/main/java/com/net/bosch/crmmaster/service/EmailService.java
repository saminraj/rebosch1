package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.FILE_EXTN_PATTERN;
import static com.net.bosch.constants.Constants.MAX_FILE_SIZE;
import static com.net.bosch.constants.Constants.REGISTRATION_NUMBER_UPDATE_OR_REMOVE_BIKE;
import static com.net.bosch.constants.Constants.VEHICLE_ONBOARDING;
import static com.net.bosch.utils.EmailHelper.convertCommaSeparatedEmailsToList;
import static com.net.bosch.utils.EmailHelper.convertToXhtml;
import static com.net.bosch.utils.EmailHelper.formatRegisNumUpdateEmailSubject;
import static com.net.bosch.utils.EmailHelper.formatUserAddvehicleEmailSubject;
import static com.net.bosch.utils.EmailHelper.getFileName;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.net.bosch.constants.EmailConditions_Enum;
import com.net.bosch.constants.EmailNotificationStatus;
import com.net.bosch.constants.REResponse;
import com.net.bosch.crmmaster.dto.EmailDTO;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.utils.APIResponseHelper;
import com.net.bosch.utils.EmailHelper;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class EmailService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${re.email.send.from}")
	private String fromEmailId;

	@Value("${re.custome.care.from.email}")
	private String reCustomerCareFromEmailId;

	@Value("${re.custome.care.to.email}")
	private String reCustomerCareToEmailId;

	@Value("${re.custome.care.cc.email}")
	private String reCustomerCareCCEmailId;

	@Value("${re.customer.care.registration.no.update.email}")
	private String reCustomerCareRegistrationNoUpdateEmailId;

	// Customer Registration Number Email constants starts.
	@Value("${re.customer.registration.number.email.subject}")
	private String customerRegistrationNoEmailSubject;

	@Value("${re.customer.registration.number.customer.care.email.subject}")
	private String customerRegistrationNumberCustomerCareEmailSubject;

	// Customer Add Vehicle Email constants starts.
	@Value("${re.add.vehicle.customer.email.subject}")
	private String customerAddVehicleEmailSubject;

	@Value("${re.add.vehicle.customer.care.email.subject}")
	private String customerAddVehicleCustomerCareEmailSubject;

	@Autowired
	private JavaMailSender javaMailSender;

	/**
	 * 
	 * */
	@Value("${re.registration.number.customer.email.template.url}")
	private String registrationNoCustomerTemplateUrl;

	@Value("${re.registration.number.customer.care.email.template.url}")
	private String registrationNoCustomerCareTemplateUrl;

	@Value("${re.add.vehicle.customer.email.template.url}")
	private String addVehicleCustomerTemplateUrl;

	@Value("${re.add.vehicle.customer.care.email.template.url}")
	private String addVehicleCustomerCareTemplateUrl;

	@Autowired
	private SpringTemplateEngine templateEngine;
	@Autowired
	private RestTemplateService restTemplateService;

	private static final String[] fileContentTypeArr = { "image/jpeg", "application/pdf" };

	@Async
	public void sendEmail(final EmailConditions_Enum emailTriggerEnum, final EmailDTO dto,
			final Map<String, MultipartFile> files, String azureKycFilePath, String azureOwnerShipFilePath)
			throws UnsupportedEncodingException, JsonProcessingException {
		String subject = null;
		String body = null;
		String deliveryStatus = null;

		List<String> attachments = new ArrayList<String>();
		if (isNotEmpty(azureKycFilePath)) {
			attachments.add(azureKycFilePath);
		}
		if (isNotEmpty(azureOwnerShipFilePath)) {
			attachments.add(azureOwnerShipFilePath);
		}

		switch (emailTriggerEnum) {

		case CUSTOMER_ADD_VEHICLE:
			/**
			 * Sending Email to Customer
			 */
			/**
			 * subject =
			 * formatUserAddvehicleEmailSubject(CUSTOMER_ADD_VEHICLE_EMAIL_SUBJECT,
			 * dto.getUserName()); body =
			 * convertEmailHtml(ADD_VEHICLE_CUSTOMER_TEMPLATE_URL, dto);
			 * sendEmail(FROM_EMAIL_ID, dto.getToEmailId(), subject, body, files);
			 * logEmailsInDb(dto.getToEmailId(), dto.getPrimaryPhoneNumber(), subject, body,
			 * azureKycFilePath, azureOwnerShipFilePath, "Customer Vehicle On-Boarding
			 * Email.");
			 */
			/**
			 * Sending Email to Customer Care
			 */
			subject = formatUserAddvehicleEmailSubject(customerAddVehicleCustomerCareEmailSubject, dto.getUserName());
			body = convertEmailHtml(addVehicleCustomerCareTemplateUrl, dto);
			deliveryStatus = sendEmail(fromEmailId, dto.getToEmailId(), reCustomerCareCCEmailId, subject, body, files);
			/*
			 * logEmailsInDb(reCustomerCareToEmailId, null, subject, body, azureKycFilePath,
			 * azureOwnerShipFilePath, "Customer Care Vehicle On-Boarding Email.");
			 */
			restTemplateService.callLoggingServiceToSaveEmailToAzure(VEHICLE_ONBOARDING, dto.getToEmailId(),
					deliveryStatus, subject, dto, "Customer Vehicle On-Boarding Email.", attachments);
			break;
		case CUSTOMER_REGISTRATION_NUMBER_UPDATE:
			/**
			 * Sending Email to Customer
			 */
			/**
			 * subject =
			 * formatRegisNumUpdateEmailSubject(CUSTOMER_REGISTRATION_NUMBER_EMAIL_SUBJECT,
			 * dto.getUserName()); body =
			 * convertEmailHtml(REGISTRATION_NO_CUSTOMER_TEMPLATE_URL, dto);
			 * sendEmail(FROM_EMAIL_ID, dto.getToEmailId(), subject, body, null);
			 * logEmailsInDb(dto.getToEmailId(), dto.getPrimaryPhoneNumber(), subject, body,
			 * azureKycFilePath, azureOwnerShipFilePath, "Customer Registration No./Remove
			 * Bike Email.");
			 */
			/**
			 * Sending Email to Customer Care email which goes to customer care will go from
			 * customer email id or noreply@royalenfield.com
			 */
			subject = formatRegisNumUpdateEmailSubject(customerRegistrationNumberCustomerCareEmailSubject,
					dto.getUserName());
			body = convertEmailHtml(registrationNoCustomerCareTemplateUrl, dto);
//			deliveryStatus = sendEmail(fromEmailId, reCustomerCareRegistrationNoUpdateEmailId, null, subject, body,
//					null);
			deliveryStatus = sendEmail(fromEmailId, reCustomerCareRegistrationNoUpdateEmailId, reCustomerCareCCEmailId, subject, body,
					null);
			/*
			 * logEmailsInDb(reCustomerCareRegistrationNoUpdateEmailId, null, subject, body,
			 * azureKycFilePath, azureOwnerShipFilePath,
			 * "Customer Care Registration No./Remove Bike Email.");
			 */
			String comments = "Customer Care Update Registration Number/Remove Bike Email. (Customer Email Id: "
					+ dto.getToEmailId() + " )";
			restTemplateService.callLoggingServiceToSaveEmailToAzure(REGISTRATION_NUMBER_UPDATE_OR_REMOVE_BIKE,
					reCustomerCareRegistrationNoUpdateEmailId, deliveryStatus, subject, dto, comments, attachments);
			break;
		default:
			break;
		}
	}

	/**
	 * This method sends e-mail with attachments.
	 * 
	 * @param from
	 * @param to
	 * @param subject
	 * @param body
	 * @param attachments
	 */
	public String sendEmail(final String from, final String to, final String ccEmails, final String subject,
			final String body, final Map<String, MultipartFile> docsMap) {
		logger.info("Sending Email From {{}}, To {{}}, CC {{}}, Subject {{}},Attachments {{}}", from, to, ccEmails,
				subject, docsMap);
		try {
			if (isEmpty(trimToNull(from)) || isEmpty(trimToNull(to))) {
				logger.error("Unable to Send Email. As User from {{}} or to {{}} E-Mail is Blank.", from, to);
				return EmailNotificationStatus.FAILED.getValue();
			}
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());

			if (MapUtils.isNotEmpty(docsMap)) {
				for (Map.Entry<String, MultipartFile> en : docsMap.entrySet()) {

					helper.addAttachment(getFileName(en.getKey(), en.getValue().getOriginalFilename()),
							new ByteArrayResource(en.getValue().getBytes()));
				}
			}
			helper.setText(body, true);
			helper.setSubject(subject);
			helper.setTo(to);
			helper.setFrom(from);

			List<String> ccEmailsList = convertCommaSeparatedEmailsToList(ccEmails);

			if (!CollectionUtils.isEmpty(ccEmailsList)) {
				logger.info("CC Emails {{}}", ccEmailsList);
				helper.setCc(ccEmailsList.toArray(new String[ccEmailsList.size()]));
			}

			javaMailSender.send(message);
			logger.info("Email Send successfully.");
			return EmailNotificationStatus.SUCCESS.getValue();
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Sending Mail to {{}} , {{}} with attachments. Exception Message {{}},Exception Details {{}}",
					to, reCustomerCareCCEmailId, e.getMessage(), e);
			return EmailNotificationStatus.FAILED.getValue();
		}
	}

	/**
	 * @param vehicleDocuments
	 * @return
	 * @throws IOException
	 */
	public REBaseResponse validateFiles(final MultipartFile[] vehicleDocuments) throws IOException {
		if (ArrayUtils.isEmpty(vehicleDocuments)) {
			logger.error("Vehicle Verification Documents are Required to send E-Mails to Customer Care.");
			return APIResponseHelper.getErrorResponse(REResponse.DOCUMENTS_REQUIRED);
		}
		for (MultipartFile multipart : vehicleDocuments) {

			if (ObjectUtils.isEmpty(multipart)) {
				return APIResponseHelper.getErrorResponse(REResponse.DOCUMENTS_REQUIRED);
			}
			String fileName = multipart.getOriginalFilename();
			String contentType = multipart.getContentType();

			logger.info("Validating File {{}} & File Content Type {{}}", fileName, multipart.getContentType());

			// Validating file content is empty or not
			if (ObjectUtils.isEmpty(multipart.getBytes())) {
				logger.error("File can not be empty/blank.");
				return APIResponseHelper.getErrorResponse(REResponse.DOCUMENTS_REQUIRED);
			}
			double fileSize = EmailHelper.getFileSizeInMB(multipart.getSize());
			if (fileSize > MAX_FILE_SIZE) {
				return APIResponseHelper.getErrorResponse(REResponse.MAXIMUM_FILE_SIZE_EXCEEDED);
			}
			// Validating file extension
			if (!FILE_EXTN_PATTERN.matcher(fileName).matches()) {
				logger.error("Invalid File Extension {{}} ,Only jpeg & pdf files are allowed.", fileName);
				return APIResponseHelper.getErrorResponse(REResponse.INVALID_DOCUMENTS_EXTENSION);
			}
			// Validating file content type
			if (!Arrays.asList(fileContentTypeArr).contains(contentType)) {
				logger.error("Invalid File Content Type {{}}", contentType);
				return APIResponseHelper.getErrorResponse(REResponse.INVALID_DOCUMENTS_EXTENSION);
			}
		}
		return APIResponseHelper.getSuccessResponse();

	}

	private String convertEmailHtml(String url, EmailDTO dto) throws UnsupportedEncodingException {
		logger.info("Processing Email Html Template With Dynamic Variables.");
		long startTime = System.currentTimeMillis();

		Context context = new Context();
		context.setVariable("data", dto);
		String renderedHtmlContent = templateEngine.process(url, context);
		String xHtml = convertToXhtml(renderedHtmlContent);

		logger.info("Email Html Template Convert Time {{}}", System.currentTimeMillis() - startTime);
		return xHtml;
	}

	/**
	 * @param toEmail
	 * @param mobileNo
	 * @param subject
	 * @param body
	 * @param azureKycFilePath
	 * @param azureOwnerShipFilePath
	 * @param comments
	 * @throws JsonProcessingException
	 */
	/*
	 * private void logEmailsInDb(String toEmail, String mobileNo, String subject,
	 * String body, String azureKycFilePath, String azureOwnerShipFilePath, String
	 * comments) {
	 * 
	 * EmailNotificationRequestDTO payload = new
	 * EmailNotificationRequestDTO(toEmail, mobileNo, subject, body,
	 * azureKycFilePath, azureOwnerShipFilePath, comments);
	 * 
	 * restTemplateService.callUtilitySaveEmailApi(payload); }
	 */

}
