package com.net.bosch.crmmaster.dto;

import java.util.List;

public class ServiceHistoryDTO {

	List<DMSServiceHistoryResponse> dmsServiceHistory;

	List<DMSServiceHistoryResponse> excellonServiceHistory;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ServiceHistoryDTO [dmsServiceHistory=");
		builder.append(dmsServiceHistory);
		builder.append(", excellonServiceHistory=");
		builder.append(excellonServiceHistory);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the dmsServiceHistory
	 */
	public List<DMSServiceHistoryResponse> getDmsServiceHistory() {
		return dmsServiceHistory;
	}

	/**
	 * @param dmsServiceHistory the dmsServiceHistory to set
	 */
	public void setDmsServiceHistory(List<DMSServiceHistoryResponse> dmsServiceHistory) {
		this.dmsServiceHistory = dmsServiceHistory;
	}

	/**
	 * @return the excellonServiceHistory
	 */
	public List<DMSServiceHistoryResponse> getExcellonServiceHistory() {
		return excellonServiceHistory;
	}

	/**
	 * @param excellonServiceHistory the excellonServiceHistory to set
	 */
	public void setExcellonServiceHistory(List<DMSServiceHistoryResponse> excellonServiceHistory) {
		this.excellonServiceHistory = excellonServiceHistory;
	}

}
