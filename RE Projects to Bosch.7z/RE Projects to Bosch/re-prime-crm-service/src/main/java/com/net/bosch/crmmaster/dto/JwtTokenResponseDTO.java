package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class JwtTokenResponseDTO implements Serializable{
	
	private static final long serialVersionUID = -1756482182697182691L;

	private Integer code;	
	private String message;	
	private Boolean success;
	private JwtTokenResponseDataDTO data;
	
	public Integer getCode() {
		return code;
	}
	
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Boolean getSuccess() {
		return success;
	}
	
	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public JwtTokenResponseDataDTO getData() {
		return data;
	}

	public void setData(JwtTokenResponseDataDTO data) {
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JwtTokenResponseDTO [code=");
		builder.append(code);
		builder.append(", message=");
		builder.append(message);
		builder.append(", success=");
		builder.append(success);
		builder.append("]");
		return builder.toString();
	}	
	
	
}
