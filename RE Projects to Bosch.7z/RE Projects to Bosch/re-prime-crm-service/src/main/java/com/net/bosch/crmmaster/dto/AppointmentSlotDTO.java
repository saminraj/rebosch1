package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
public class AppointmentSlotDTO{

	
	private String startTimeSlot;
	
	private String endTimeSlot;
	
	private Boolean availability;
	
	private String resourceId;
	
	private String branchId;
	
	private String date;

	public String getStartTimeSlot() {
		return startTimeSlot;
	}

	public void setStartTimeSlot(String startTimeSlot) {
		this.startTimeSlot = startTimeSlot;
	}

	public String getEndTimeSlot() {
		return endTimeSlot;
	}

	public void setEndTimeSlot(String endTimeSlot) {
		this.endTimeSlot = endTimeSlot;
	}

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

		
}
