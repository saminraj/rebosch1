package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class ValidatePaymentKeyExpiryResponse {

	private String paymentKey;
	private String dealerBookingId;
	private String dealerSource;
	private String bookingCaseId;
	private String expiryTime;
	private boolean valid;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ValidatePaymentKeyExpiryResponse [paymentKey=");
		builder.append(paymentKey);
		builder.append(", dealerBookingId=");
		builder.append(dealerBookingId);
		builder.append(", dealerSource=");
		builder.append(dealerSource);
		builder.append(", bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", expiryTime=");
		builder.append(expiryTime);
		builder.append(", valid=");
		builder.append(valid);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}

	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}

	/**
	 * @return the dealerBookingId
	 */
	public String getDealerBookingId() {
		return dealerBookingId;
	}

	/**
	 * @param dealerBookingId the dealerBookingId to set
	 */
	public void setDealerBookingId(String dealerBookingId) {
		this.dealerBookingId = dealerBookingId;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the expiryTime
	 */
	public String getExpiryTime() {
		return expiryTime;
	}

	/**
	 * @param expiryTime the expiryTime to set
	 */
	public void setExpiryTime(String expiryTime) {
		this.expiryTime = expiryTime;
	}

	public boolean getValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

}
