package com.net.bosch.crmmaster.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.domain.AppointmentFullSlots;

@Repository
public interface AppointmentFullSlotsRepository extends CrudRepository<AppointmentFullSlots, String> {

}