package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author pushkarkhosla
 *
 */
@JsonInclude(Include.NON_NULL)
public class InStoreDynamicsBookingPaymentRequestDTO extends DynamicsBookingPaymentRequestDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5362280973816709050L;

	private String narration;
	private String chequenumber;
	private String ddnumber;
	private String cardtype;
	private String bankname;
	private String paymentdate;
	private String dateofcheque;
	private String dateofdd;
	private String bankreferencenumber;
	private String approvalcode;
	private String bookingsource;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InStoreDynamicsBookingPaymentRequestDTO [narration=");
		builder.append(narration);
		builder.append(", chequenumber=");
		builder.append(chequenumber);
		builder.append(", ddnumber=");
		builder.append(ddnumber);
		builder.append(", cardtype=");
		builder.append(cardtype);
		builder.append(", bankname=");
		builder.append(bankname);
		builder.append(", paymentdate=");
		builder.append(paymentdate);
		builder.append(", dateofcheque=");
		builder.append(dateofcheque);
		builder.append(", dateofdd=");
		builder.append(dateofdd);
		builder.append(", bankreferencenumber=");
		builder.append(bankreferencenumber);
		builder.append(", approvalcode=");
		builder.append(approvalcode);
		builder.append(", bookingsource=");
		builder.append(bookingsource);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bankreferencenumber
	 */
	public String getBankreferencenumber() {
		return bankreferencenumber;
	}

	/**
	 * @param bankreferencenumber the bankreferencenumber to set
	 */
	public void setBankreferencenumber(String bankreferencenumber) {
		this.bankreferencenumber = bankreferencenumber;
	}

	/**
	 * @return the narration
	 */
	public String getNarration() {
		return narration;
	}

	/**
	 * @param narration the narration to set
	 */
	public void setNarration(String narration) {
		this.narration = narration;
	}

	/**
	 * @return the chequenumber
	 */
	public String getChequenumber() {
		return chequenumber;
	}

	/**
	 * @param chequenumber the chequenumber to set
	 */
	public void setChequenumber(String chequenumber) {
		this.chequenumber = chequenumber;
	}

	/**
	 * @return the ddnumber
	 */
	public String getDdnumber() {
		return ddnumber;
	}

	/**
	 * @param ddnumber the ddnumber to set
	 */
	public void setDdnumber(String ddnumber) {
		this.ddnumber = ddnumber;
	}

	/**
	 * @return the cardtype
	 */
	public String getCardtype() {
		return cardtype;
	}

	/**
	 * @param cardtype the cardtype to set
	 */
	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	/**
	 * @return the bankname
	 */
	public String getBankname() {
		return bankname;
	}

	/**
	 * @param bankname the bankname to set
	 */
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	/**
	 * @return the paymentdate
	 */
	public String getPaymentdate() {
		return paymentdate;
	}

	/**
	 * @param paymentdate the paymentdate to set
	 */
	public void setPaymentdate(String paymentdate) {
		this.paymentdate = paymentdate;
	}

	/**
	 * @return the dateofcheque
	 */
	public String getDateofcheque() {
		return dateofcheque;
	}

	/**
	 * @param dateofcheque the dateofcheque to set
	 */
	public void setDateofcheque(String dateofcheque) {
		this.dateofcheque = dateofcheque;
	}

	/**
	 * @return the dateofdd
	 */
	public String getDateofdd() {
		return dateofdd;
	}

	/**
	 * @param dateofdd the dateofdd to set
	 */
	public void setDateofdd(String dateofdd) {
		this.dateofdd = dateofdd;
	}

	/**
	 * @return the approvalcode
	 */
	public String getApprovalcode() {
		return approvalcode;
	}

	/**
	 * @param approvalcode the approvalcode to set
	 */
	public void setApprovalcode(String approvalcode) {
		this.approvalcode = approvalcode;
	}

	/**
	 * @return the bookingsource
	 */
	public String getBookingsource() {
		return bookingsource;
	}

	/**
	 * @param bookingsource the bookingsource to set
	 */
	public void setBookingsource(String bookingsource) {
		this.bookingsource = bookingsource;
	}

}
