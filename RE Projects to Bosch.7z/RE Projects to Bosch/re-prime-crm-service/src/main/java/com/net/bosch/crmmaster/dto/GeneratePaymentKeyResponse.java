package com.net.bosch.crmmaster.dto;

public class GeneratePaymentKeyResponse {

	private String resultUrl;
	private String paymentKey;

	public GeneratePaymentKeyResponse() {
	}

	/**
	 * @param resultUrl
	 * @param paymentKey
	 */
	public GeneratePaymentKeyResponse(String url, String paymentKey) {
		super();
		this.resultUrl = url;
		this.paymentKey = paymentKey;
	}

	/**
	 * @return the resultUrl
	 */
	public String getResultUrl() {
		return resultUrl;
	}

	/**
	 * @param resultUrl the resultUrl to set
	 */
	public void setResultUrl(String resultUrl) {
		this.resultUrl = resultUrl;
	}

	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}

	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GeneratePaymentKeyResponse [resultUrl=");
		builder.append(resultUrl);
		builder.append(", paymentKey=");
		builder.append(paymentKey);
		builder.append("]");
		return builder.toString();
	}

}
