package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.KYC_DOC_KEY;
import static com.net.bosch.constants.Constants.RC_DOC_KEY;
import static com.net.bosch.constants.Constants.REGISTRATION_NO_UPDATE_TRANSACTION_TYPE;
import static com.net.bosch.constants.Constants.SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.Constants.SP_NO_DATA_FOUND;
import static com.net.bosch.constants.Constants.VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.Constants.VEHICLE_VERIFIED_TRANSACTION_TYPE;
import static com.net.bosch.constants.REResponse.DUPLICATE_USER_VEHICLE_FOUND;
import static com.net.bosch.constants.REResponse.GENERIC_OR_UNKNOWN_ERROR;
import static com.net.bosch.constants.REResponse.INVALID_MOBILE_NUMBER;
import static com.net.bosch.constants.REResponse.INVALID_REQUEST;
import static com.net.bosch.constants.REResponse.NO_VERIFIED_USER_VEHICLE_FOUND;
import static com.net.bosch.constants.REResponse.USER_VEHICLES_NOT_FOUND;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static com.net.bosch.utils.DateHelper.formatExcellonServiceHistoryDate;
import static com.net.bosch.utils.DateHelper.formatExcellonServiceHistoryDateForFireBaseKey;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;
import com.net.bosch.constants.Constants;
import com.net.bosch.constants.EmailConditions_Enum;
import com.net.bosch.constants.REResponse;
import com.net.bosch.constants.ServiceHistoryOperationEnum;
import com.net.bosch.constants.VehicleStatus;
import com.net.bosch.crmmaster.dao.UserVehicleRepository;
import com.net.bosch.crmmaster.dto.AddVehicleRequestDTO;
import com.net.bosch.crmmaster.dto.EmailDTO;
import com.net.bosch.crmmaster.dto.ExcellonServiceHistoryResponse;
import com.net.bosch.crmmaster.dto.GetVehicleVinRequestDTO;
import com.net.bosch.crmmaster.dto.GetVinJobCardStatusRequestDTO;
import com.net.bosch.crmmaster.dto.ListRegistrationNumberRequestDTO;
import com.net.bosch.crmmaster.dto.RegistrationNumberRequest;
import com.net.bosch.crmmaster.dto.ServiceHistoryRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateMobileInVehicleRecordsDTO;
import com.net.bosch.crmmaster.dto.UpdateRegisNumberStatusDTO;
import com.net.bosch.crmmaster.dto.UserProfileResponseDTO;
import com.net.bosch.crmmaster.dto.UserVehicleDetailsDTO;
import com.net.bosch.crmmaster.dto.UservehicleDetailsRequestDTO;
import com.net.bosch.crmmaster.dto.VehicleVerifyRequestDTO;
import com.net.bosch.crmmaster.dto.VerifyVehicleDetailsResponseDTO;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsListVO;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;
import com.net.bosch.crmmaster.dto.resultset.VehicleJobCardStatusResponseObject;
import com.net.bosch.crmmaster.dto.resultset.VehicleVinResponseObject;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicle;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicleDetails;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.dto.base.RequestDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;
import com.net.bosch.utils.APIResponseHelper;
import com.net.bosch.utils.DateHelper;
import com.net.bosch.utils.ValidationUtil;

@Service
@Transactional
public class UserVehicleService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserVehicleRepository userVehicleRepository;

	@Autowired
	private AzureUploadService azureUploadService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private StoredProcedureService storedProcedureService;

	@Autowired
	private RestTemplateService restTemplateService;

	@Value("${re.prime.add.vehicle.verified.day.count}")
	private int addVehicleVerifiedDayCount;

	/**
	 * Get User Vehicle Details API
	 * 
	 * @param dto
	 * @return
	 */
	@Transactional(rollbackFor = Throwable.class)
	public REBaseResponse getUserVehicleDetails(RequestDTO dto) {
		logger.info("Calling getUserVehicleDetails() params {{}}", dto);
		try {
			List<VehicleDetailsVO> vehicleDetailsVOList = storedProcedureService
					.callGetVehicleDetailsProcedure(dto.getLoggedInUserMobileNo());
			if (CollectionUtils.isEmpty(vehicleDetailsVOList)) {
				logger.error(SP_NO_DATA_FOUND);
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			logger.info("User {{}}, Total DMS Vehicle {{}}, Vehicle Details{{}}", dto.getLoggedInUserMobileNo(),
					vehicleDetailsVOList.size(), vehicleDetailsVOList);

			VehicleDetailsListVO vehicleDetailsListVO = new VehicleDetailsListVO();
			List<VehicleDetailsVO> vehicleInfoList = new ArrayList<>();
			List<UserVehicleDetails> userVehicleDetailsList = new ArrayList<>();

			for (VehicleDetailsVO object : vehicleDetailsVOList) {
				userVehicleDetailsList.add(setUserVehicleDetails(object, dto.getAppId()));
				vehicleInfoList.add(convertPurchaseAndMfgDateToDDMMYYYYForAPIResponse(object));
			}
			// Verifying User Vehicle Details are already available in Mongo Or Not.
			UserVehicle prevoiusUserVehicle = fetchUserVehicleFromMongoByGuid(dto.getGuid());
			/**
			 * Calling User Service History
			 */
			callServiceHistory(dto.getGuid(), vehicleDetailsVOList, ServiceHistoryOperationEnum.INSERT);

			saveOrUpdateUserVehiclesInMongo(dto.getGuid(), dto.getLoggedInUserMobileNo(), userVehicleDetailsList,
					ObjectUtils.isEmpty(prevoiusUserVehicle) ? null : prevoiusUserVehicle);

			logger.info("User Vehicle List {{}}", vehicleInfoList);
			vehicleDetailsListVO.setVehicleInfo(vehicleInfoList);

			logger.info("Returning Success Response for Get Vehicle Details API.");
			return APIResponseHelper.getSuccessResponse(vehicleDetailsListVO);
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Getting User Vehicle Details By Mobile Number {{}}. Exception Message {{}},Exception Details {{}}",
					dto.getLoggedInUserMobileNo(), e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * Verify User Vehicle Details API
	 * 
	 * @param dto
	 * @return
	 */
	@Transactional(rollbackFor = Throwable.class)
	public REBaseResponse verifyUserVehicleDetails(final VehicleVerifyRequestDTO dto) {
		logger.info("Calling verifyUserVehicleDetails() Input Params {{}}", dto);
		try {
			REResponse response = ValidationUtil.validateVerifyApiParams(dto);
			if (REResponse.SUCCESS != response) {
				return APIResponseHelper.getErrorResponse(response);
			}

			/* check duplicate vehicle in mongo */
			UserVehicle userVehicle = fetchUserVehicleFromMongoByGuid(dto.getGuid());
			if (null != userVehicle && CollectionUtils.isNotEmpty(userVehicle.getUserVehicles())) {

				REBaseResponse fileResponse = checkDuplicateUserVehicleWithChassisAndRegistrationNumber(
						userVehicle.getUserVehicles(), dto.getChassisNumber(), dto.getRegistrationNumber());
				if (!StringUtils.equals(fileResponse.getCode(), Constants.SUCCESS_CODE)) {
					return fileResponse;
				}
			}

			Object[][] objectArray = storedProcedureService.callVerifyUserVehicleDetailsProcedure(dto);
			VehicleDetailsVO vehicleDetailsVOresultSet = (VehicleDetailsVO) objectArray[0][0];
			REResponse spStatus = (REResponse) objectArray[0][1];

			if (ObjectUtils.isEmpty(vehicleDetailsVOresultSet)) {
				logger.error(SP_NO_DATA_FOUND);
				return APIResponseHelper.getErrorResponse(spStatus);
			}
			vehicleDetailsVOresultSet = convertPurchaseAndMfgDateToDDMMYYYYForAPIResponse(vehicleDetailsVOresultSet);

			logger.info("Details Verified successfully. Returning Response {{}}", vehicleDetailsVOresultSet);

			VerifyVehicleDetailsResponseDTO responseDto = new VerifyVehicleDetailsResponseDTO();
			BeanUtils.copyProperties(vehicleDetailsVOresultSet, responseDto);
			responseDto.setVehiclePurchaseDateLessThan30Days(
					isPurchaseDateLessThanEqualTo30Days(vehicleDetailsVOresultSet.getPurchaseDate()));

			logger.info("Returning Success Response for Verify User Vehicle Details API.");
			return APIResponseHelper.getSuccessResponse(responseDto);
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Verifying User Vehicle Details. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * Add User Vehicle Details API
	 * 
	 * @param addVehicleRequestDTO
	 * @param kycDoc
	 * @param ownerDoc
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@Transactional(rollbackFor = Throwable.class)
	public REBaseResponse addVehicle(String json, MultipartFile kycDoc, MultipartFile ownerDoc,
			HttpServletRequest request) throws IOException {
		try {
			AddVehicleRequestDTO addVehicleRequestDTO = new ObjectMapper().readValue(json, AddVehicleRequestDTO.class);

			logger.info("Calling addVehicle() Input Params {{}},Kyc File {{}},Owner File {{}}", addVehicleRequestDTO,
					kycDoc, ownerDoc);

			if (isEmpty(trimToNull(addVehicleRequestDTO.getLoggedInUserMobileNo()))) {
				return APIResponseHelper.getErrorResponse(REResponse.USER_MOBILE_NUMBER_REQUIRED);
			}
			if (isEmpty(trimToNull(addVehicleRequestDTO.getGuid()))) {
				return APIResponseHelper.getErrorResponse(REResponse.USER_GUID_REQUIRED);
			}
			boolean isPurchaseDateLessThanEqualTo30Days = isPurchaseDateLessThanEqualTo30Days(
					addVehicleRequestDTO.getPurchaseDate());
			if (!isPurchaseDateLessThanEqualTo30Days) {
				logger.info("Verifying User Vehicle Documents.");
				if (ObjectUtils.isEmpty(kycDoc)) {
					REBaseResponse fileResponse = emailService.validateFiles(new MultipartFile[] { ownerDoc });
					if (!StringUtils.equals(fileResponse.getCode(), Constants.SUCCESS_CODE)) {
						return fileResponse;
					}
				} else {
					REBaseResponse fileResponse = emailService.validateFiles(new MultipartFile[] { kycDoc, ownerDoc });
					if (!StringUtils.equals(fileResponse.getCode(), Constants.SUCCESS_CODE)) {
						return fileResponse;
					}
				}

			}
			logger.info("Inside Add Vehicle request Details with params {{}}", addVehicleRequestDTO);

			List<UserVehicleDetails> userVehiclesList = new ArrayList<>();
			UserVehicle userVehicle = fetchUserVehicleFromMongoByGuid(addVehicleRequestDTO.getGuid());

			if (null == userVehicle || ObjectUtils.isEmpty(userVehicle)
					|| CollectionUtils.isEmpty(userVehicle.getUserVehicles())) {

				logger.info("User Have no previous Vehicle in Mongo. So adding New Bike.");
			} else {
				userVehiclesList.addAll(userVehicle.getUserVehicles());
			}

			/* check duplicate user vehicle */
			if (CollectionUtils.isNotEmpty(userVehiclesList)) {
				REBaseResponse fileResponse = checkDuplicateUserVehicle(userVehiclesList, addVehicleRequestDTO);
				if (!StringUtils.equals(fileResponse.getCode(), Constants.SUCCESS_CODE)) {
					return fileResponse;
				}
			}

			UserVehicleDetails object = new UserVehicleDetails();
			BeanUtils.copyProperties(addVehicleRequestDTO, object);
			object.setMsdynName(addVehicleRequestDTO.getId());

			if (isPurchaseDateLessThanEqualTo30Days) {
				object.setVehicleStatus(VehicleStatus.VERIFIED);
				List<VehicleDetailsVO> vehiclesList = new ArrayList<>();
				VehicleDetailsVO vehicleDetailsVOObject = new VehicleDetailsVO();
				vehicleDetailsVOObject.setChassisNo(addVehicleRequestDTO.getChassisNo());
				vehiclesList.add(vehicleDetailsVOObject);

				/**
				 * Calling User Service History
				 */
				callServiceHistory(addVehicleRequestDTO.getGuid(), vehiclesList, ServiceHistoryOperationEnum.INSERT);
			} else {
				object.setVehicleStatus(VehicleStatus.PENDING);
			}
			object.setVehicleUpdateStatus(VehicleStatus.VERIFIED);
			object.setConnectedMotorcycle(
					restTemplateService.callShowAuthorizeApi(addVehicleRequestDTO.getChassisNo()));
			object.setPurchaseDate(convertStrDateToRePattern(object.getPurchaseDate()));
			object.setDateOfMfg(convertStrDateToRePattern(object.getDateOfMfg()));
			Date currentDate = new Date();
			object.setCreatedOn(currentDate);
			object.setLastModified(currentDate);

			if (!isPurchaseDateLessThanEqualTo30Days) {
				// upload file to s3
				Map<String, MultipartFile> docsMap = new HashMap<>();
				boolean isKycDocPresent = false;
				if (!ObjectUtils.isEmpty(kycDoc)) {
					docsMap.put(KYC_DOC_KEY, kycDoc);
					isKycDocPresent = true;
				}
				docsMap.put(RC_DOC_KEY, ownerDoc);

				azureUploadService.uploadtoAzure(docsMap, addVehicleRequestDTO.getGuid(), object, addVehicleRequestDTO);
				// end

				EmailDTO emailDTO = new EmailDTO(addVehicleRequestDTO.getLoggedInUserName(),
						addVehicleRequestDTO.getLoggedInUserMobileNo(), addVehicleRequestDTO.getLoggedInUserEmail(),
						addVehicleRequestDTO.getChassisNo(), isKycDocPresent, addVehicleRequestDTO.getAppId());
				emailService.sendEmail(EmailConditions_Enum.CUSTOMER_ADD_VEHICLE, emailDTO, docsMap,
						object.getKycFilePath(), object.getOwnershipFilePath());
			}
			userVehiclesList.add(object);

			saveOrUpdateUserVehiclesInMongo(addVehicleRequestDTO.getGuid(),
					addVehicleRequestDTO.getLoggedInUserMobileNo(), userVehiclesList, userVehicle);

			logger.info("Returning Success Response for Add Vehicle API.");
			return APIResponseHelper.getSuccessResponse(REResponse.USER_VEHICLE_ADDED_SUCCESSFULLY);
		} catch (Exception e) {
			logger.error("Exception Occured While Adding User Vehicle. Exception Message {{}} Exception Details {{}}",
					e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * This is helper method to check duplicate User Vehicle
	 * 
	 * @param userVehiclesList
	 * @return
	 */
	public REBaseResponse checkDuplicateUserVehicle(List<UserVehicleDetails> userVehiclesList,
			@Valid AddVehicleRequestDTO dto) {
		logger.info("Calling checkDuplicateUserVehicle() params {{}}", userVehiclesList);

		if (isEmpty(trimToNull(dto.getEngineNo()))) {
			return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLE_ENGINE_NUMBER_REQUIRED);
		}
		if (isEmpty(trimToNull(dto.getChassisNo()))) {
			return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLE_CHASSIS_NUMBER_REQUIRED);
		}
		for (UserVehicleDetails userVehicleDetails : userVehiclesList) {
			if (dto.getEngineNo().equalsIgnoreCase(userVehicleDetails.getEngineNo())
					&& dto.getChassisNo().equalsIgnoreCase(userVehicleDetails.getChassisNo())) {
				if (userVehicleDetails.getVehicleStatus() == VehicleStatus.PENDING) {
					return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_PENDING);
				} else if (userVehicleDetails.getVehicleStatus() == VehicleStatus.VERIFIED) {
					return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_VERIFIED);
				}

			}
		}
		return APIResponseHelper.getSuccessResponse();
	}

	/**
	 * This is helper method to check duplicate User Vehicle
	 *
	 * @param userVehiclesList
	 * @return
	 */
	public REBaseResponse checkDuplicateUserVehicleWithChassisAndRegistrationNumber(
			List<UserVehicleDetails> userVehiclesList, String chassisNumber, String registrationNumber) {
		logger.info("Calling checkDuplicateUserVehicle() List Size {{}}", userVehiclesList.size());

		if (!isEmpty(trimToNull(chassisNumber))) {
			for (UserVehicleDetails userVehicleDetails : userVehiclesList) {
				if (chassisNumber.equalsIgnoreCase(userVehicleDetails.getChassisNo())) {
					if (userVehicleDetails.getVehicleStatus() == VehicleStatus.PENDING) {
						return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_PENDING);
					} else if (userVehicleDetails.getVehicleStatus() == VehicleStatus.VERIFIED) {
						return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_VERIFIED);
					}

				}
			}
		} else if (!isEmpty(trimToNull(registrationNumber))) {
			for (UserVehicleDetails userVehicleDetails : userVehiclesList) {
				if (registrationNumber.equalsIgnoreCase(userVehicleDetails.getRegistrationNo())) {
					if (userVehicleDetails.getVehicleStatus() == VehicleStatus.PENDING) {
						return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_PENDING);
					} else if (userVehicleDetails.getVehicleStatus() == VehicleStatus.VERIFIED) {
						return APIResponseHelper.getErrorResponse(REResponse.DUPLICATE_VEHICLE_FOUND_VERIFIED);
					}
				}
			}
		}
		return APIResponseHelper.getSuccessResponse();
	}

	/**
	 * Update Registration Number Or Remove User Vehicle API
	 * 
	 * @param listDto
	 * @return
	 */
	@Transactional(rollbackFor = Throwable.class)
	public REBaseResponse updateRegisNumberAndRemoveBike(ListRegistrationNumberRequestDTO listDto) {
		logger.info("Calling updateRegisNumberAndRemoveBike() Input Params {{}}", listDto);
		try {
			if (CollectionUtils.isEmpty(listDto.getVehicleList())) {
				logger.error("No Vehicle Details found for User in request {{}}", listDto);
				return APIResponseHelper.getErrorResponse(REResponse.INVALID_REQUEST);
			}
			REResponse response = ValidationUtil.validateRegistrationNumber(listDto.getVehicleList());
			if (REResponse.SUCCESS != response) {
				return APIResponseHelper.getErrorResponse(response);
			}

			// Fetching User Vehicle details from Mongo db User Vehicle table.
			UserVehicle userVehicle = fetchUserVehicleFromMongoByGuid(listDto.getGuid());
			if (ObjectUtils.isEmpty(userVehicle)) {
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			CopyOnWriteArrayList<UserVehicleDetails> userVehiclesList = new CopyOnWriteArrayList<>(
					!ObjectUtils.isEmpty(userVehicle) ? userVehicle.getUserVehicles() : null);

			if (CollectionUtils.isEmpty(userVehiclesList)) {
				logger.error("For Mobile Number {{}} No Vehicle found in Monbo Db User vehicle table.",
						listDto.getLoggedInUserMobileNo());
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			logger.info("User Vehicle List Size {{}} ", userVehiclesList.size());

			List<RegistrationNumberRequest> removeBikeFromUserList = new ArrayList<>();
			List<RegistrationNumberRequest> userRegistrationNumberUpdateList = new ArrayList<>();

			for (RegistrationNumberRequest bean : listDto.getVehicleList()) {
				if (bean.isRemoveBike()) {
					removeBikeFromUserList.add(bean);
				} else {
					if (!StringUtils.equals(bean.getPreviousRegistrationNumber(),
							bean.getUpdatedRegistrationNumber())) {
						userRegistrationNumberUpdateList.add(bean);
					}
				}
			}
			// Removing Bike from User Vehicle List
			userVehiclesList = removeBikeFromUsersVehicleList(removeBikeFromUserList, userVehiclesList);

			// Updating User Registration Number
			userVehiclesList = updateRegistrationNumber(userRegistrationNumberUpdateList, userVehiclesList);

			userVehicle.setUserVehicles(userVehiclesList);
			userVehicleRepository.save(userVehicle);
			logger.info("User Vehicle Details Updated Successfully In Mongo Db.");

			if (!removeBikeFromUserList.isEmpty() || !userRegistrationNumberUpdateList.isEmpty()) {
				EmailDTO emailDTO = new EmailDTO(listDto.getLoggedInUserName(), listDto.getLoggedInUserMobileNo(),
						listDto.getLoggedInUserEmail(), userRegistrationNumberUpdateList, removeBikeFromUserList,
						listDto.getAppId());
				emailService.sendEmail(EmailConditions_Enum.CUSTOMER_REGISTRATION_NUMBER_UPDATE, emailDTO, null, null,
						null);
			}
			logger.info("Returning Success Response for Update Registration No. API.");
			return APIResponseHelper.getSuccessResponse(REResponse.USER_VEHICLES_UPDATED_SUCCESSFULLY);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User Registration Number. Exception Message {{}} Exception Details {{}}",
					e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * This API is called from re-prime-master-service Batch Job to update the
	 * Registration No Status Flag to VERIFIED and Vehicle Status Flag to VERIFIED.
	 * 
	 * @param dto
	 * @return
	 */
	public REBaseResponse updateVehicleStatus(@Valid UpdateRegisNumberStatusDTO dto) {
		try {
			REResponse transactionStatus = validateDmsTransactionType(dto.getTransactionType());
			if (transactionStatus != REResponse.SUCCESS) {
				return APIResponseHelper.getSuccessResponse(transactionStatus);
			}
			UserVehicle vehicleObject = fetchUserVehicleFromMongoByGuid(dto.getGuid());
			if (ObjectUtils.isEmpty(vehicleObject)) {
				logger.info("Invalid GUID No. {{}}", dto.getGuid());
				return APIResponseHelper.getErrorResponse(REResponse.INVALID_USER_GUID);
			}
			List<UserVehicleDetails> userVehiclesList = vehicleObject.getUserVehicles();

			if (CollectionUtils.isEmpty(userVehiclesList)) {
				return APIResponseHelper.getSuccessResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			List<VehicleDetailsVO> serviceHistoryVehiclesList = new ArrayList<>();
			boolean isUpdateRequired = false;

			for (int i = 0; i < userVehiclesList.size(); i++) {
				if (StringUtils.equals(userVehiclesList.get(i).getChassisNo(), dto.getChassisNumber())) {

					logger.info("Chassis Number Matched Successfully.");

					UserVehicleDetails object = userVehiclesList.get(i);
					if (StringUtils.equals(dto.getTransactionType(), REGISTRATION_NO_UPDATE_TRANSACTION_TYPE)
							&& StringUtils.equals(userVehiclesList.get(i).getRegistrationNo(),
									dto.getNewRegistrationNumber())) {

						logger.info("Updating Registration Number Status.");
						logger.info(
								"For Chassis No {{}} User Registration No {{}} & SP Registration No {{}} Status Update To Verified.",
								dto.getChassisNumber(), userVehiclesList.get(i).getRegistrationNo(),
								dto.getNewRegistrationNumber());

						object.setVehicleUpdateStatus(VehicleStatus.VERIFIED);
						object.setLastModified(new Date());
						isUpdateRequired = true;

					} else if (StringUtils.equals(dto.getTransactionType(), VEHICLE_VERIFIED_TRANSACTION_TYPE)) {
						logger.info("Updating Vehicle Status to VERIFIED For Guid {{}} & Chassis No {{}}.",
								dto.getGuid(), dto.getChassisNumber());

						// Added below condition so that Service History can be duplicate in firebase.
						if (object.getVehicleStatus() != VehicleStatus.VERIFIED) {
							VehicleDetailsVO serviceHistoryVehicleObj = new VehicleDetailsVO();
							serviceHistoryVehicleObj.setChassisNo(dto.getChassisNumber());
							serviceHistoryVehiclesList.add(serviceHistoryVehicleObj);

							object.setVehicleStatus(VehicleStatus.VERIFIED);
							object.setLastModified(new Date());
							isUpdateRequired = true;
						} else {
							logger.info("Vehicle With Chassis no {{}} already Verified in Mongo Db.",
									object.getChassisNo());
							return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLE_STATUS_ALREADY_VERIFIED);
						}
					} else {
						logger.error(
								"Unhandled Transaction Type found {{}} or DMS Regis No {{}} & Mongo Regis No {{}} Not Matched Successfully.",
								dto.getTransactionType(), dto.getNewRegistrationNumber(),
								userVehiclesList.get(i).getRegistrationNo());
					}
					userVehiclesList.set(i, object);
				}
			}
			if (isUpdateRequired) {
				vehicleObject.setUserVehicles(userVehiclesList);
				userVehicleRepository.save(vehicleObject);
				logger.info("User Vehicle Details Updated For Transaction Type {{}} Successfully In Mongo Db.",
						dto.getTransactionType());

				/**
				 * sending notification
				 */
				if (StringUtils.equals(dto.getTransactionType(), VEHICLE_VERIFIED_TRANSACTION_TYPE)) {
					restTemplateService.callSendNotificationApi(dto.getLoggedInUserMobileNo(), dto.getChassisNumber(),
							dto.getGuid());
				}
				if (CollectionUtils.isNotEmpty(serviceHistoryVehiclesList) && !serviceHistoryVehiclesList.isEmpty()) {
					/**
					 * Calling User Service History
					 */
					callServiceHistory(dto.getGuid(), serviceHistoryVehiclesList, ServiceHistoryOperationEnum.INSERT);
				}
				return APIResponseHelper.getSuccessResponse(REResponse.USER_VEHICLES_UPDATED_SUCCESSFULLY);
			}
			logger.error("User Vehicle Details Not Updated For Transaction Type {{}} In Mongo Db.",
					dto.getTransactionType());

			return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_UPDATED);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User Vehicle Registration Number Status. Exception Message {{}} Exception Details {{}}",
					e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * This is helper method to remove User Vehicle
	 * 
	 * @param removeBikeFromUserList
	 * @param userVehiclesList
	 * @return
	 */
	private CopyOnWriteArrayList<UserVehicleDetails> removeBikeFromUsersVehicleList(
			List<RegistrationNumberRequest> removeBikeFromUserList,
			CopyOnWriteArrayList<UserVehicleDetails> userVehiclesList) {
		if (CollectionUtils.isEmpty(removeBikeFromUserList)) {
			logger.info("No Bike Selected to Remove.");
			return userVehiclesList;
		}
		logger.info("Removing Associated Vehicle {{}} \nfrom Users Vehicle List.{{}}", removeBikeFromUserList,
				userVehiclesList);
		for (RegistrationNumberRequest removeEngineNo : removeBikeFromUserList) {
			for (UserVehicleDetails bean : userVehiclesList) {
				if (StringUtils.equals(bean.getEngineNo(), removeEngineNo.getEngineNo())) {
					logger.info("Removing Engine No {{}} from User Vehicle List. {{}}", bean.getEngineNo(), bean);
					userVehiclesList.remove(bean);
				}
			}
		}
		logger.info("User Vehicle List Size {{}} After Removing Bikes.", userVehiclesList.size());
		return userVehiclesList;
	}

	/**
	 * This is helper method to Update User Vehicle Registration Number
	 * 
	 * @param updateMap
	 * @param userVehiclesList
	 * @return
	 */
	private CopyOnWriteArrayList<UserVehicleDetails> updateRegistrationNumber(
			List<RegistrationNumberRequest> updateList, CopyOnWriteArrayList<UserVehicleDetails> userVehiclesList) {
		if (CollectionUtils.isEmpty(updateList)) {
			logger.info("No Bike Selected to Update.");
			return userVehiclesList;
		}
		for (int j = 0; j < updateList.size(); j++) {
			for (int i = 0; i < userVehiclesList.size(); i++) {
				if (StringUtils.equals(updateList.get(j).getEngineNo(), userVehiclesList.get(i).getEngineNo())) {

					logger.info(
							"Updating Registration Number For VIN {{}} & Engine No {{}} Previous Regis No {{}} Updated Regis No {{}}",
							updateList.get(j).getChassisNo(), updateList.get(j).getEngineNo(),
							updateList.get(j).getPreviousRegistrationNumber(),
							updateList.get(j).getUpdatedRegistrationNumber());

					UserVehicleDetails object = userVehiclesList.get(i);
					object.setRegistrationNo(updateList.get(j).getUpdatedRegistrationNumber());
					object.setVehicleUpdateStatus(VehicleStatus.REGISTRATION_NO_UPDATE_PENDING);
					object.setLastModified(new Date());
					userVehiclesList.set(i, object);
				}
			}
		}
		return userVehiclesList;
	}

	/**
	 * This Helper method is used to Set user vehicles in Another class Object.
	 * 
	 * @param bean
	 * @param userId
	 * @return
	 */
	private UserVehicleDetails setUserVehicleDetails(final VehicleDetailsVO bean, String appId) {
		UserVehicleDetails objectToSave = new UserVehicleDetails();
		objectToSave.setUserName(bean.getUserName());
		objectToSave.setDateOfMfg(bean.getDateOfMfg());
		objectToSave.setChassisNo(bean.getChassisNo());
		objectToSave.setEngineNo(bean.getEngineNo());
		objectToSave.setMsdynName(bean.getId());
		objectToSave.setInvoiceNo(bean.getInvoiceNo());
		objectToSave.setAlternateNo(bean.getAlternateNo());
		objectToSave.setVehicleModelCode(bean.getVehicleModelCode());
		objectToSave.setVehicleModelName(bean.getVehicleModelName());
		objectToSave.setPurchaseDate(bean.getPurchaseDate());
		objectToSave.setRegistrationNo(bean.getRegistrationNo());
		objectToSave.setVehicleStatus(VehicleStatus.VERIFIED);
		objectToSave.setVehicleUpdateStatus(VehicleStatus.VERIFIED);
		objectToSave.setConnectedMotorcycle(restTemplateService.callShowAuthorizeApi(bean.getChassisNo()));

		objectToSave.setAppId(appId);
		Date currentDate = new Date();
		objectToSave.setCreatedOn(currentDate);
		objectToSave.setLastModified(currentDate);
		return objectToSave;
	}

	/**
	 * This helper method is used to Save or Update User Vehicles in User_Vehicle
	 * Mongo Table.
	 * 
	 * @param userId
	 * @param mobileNo
	 * @param userVehicleList
	 * @param userVehicle
	 * @return
	 */
	private UserVehicle saveOrUpdateUserVehiclesInMongo(final String guid, final String mobileNo,
			final List<UserVehicleDetails> userVehicleList, UserVehicle userVehicle) {
		try {
			if (CollectionUtils.isEmpty(userVehicleList)) {
				logger.info("No Vehicle Details available in List.");
				return null;
			}
			if (ObjectUtils.isEmpty(userVehicle)) {
				logger.info("Saving User Vehicle Details in Mongo Db.");
				userVehicle = new UserVehicle();
			} else {
				logger.info("Updating User Vehicle Details in Mongo Db.");
			}
			userVehicle.setGuid(guid);
			userVehicle.setPhoneNo(mobileNo);
			userVehicle.setUserVehicles(userVehicleList);

			return userVehicleRepository.save(userVehicle);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Saving User Vehicle Details in Mongo DB.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * This method updates the user in mongo db.
	 * 
	 * @param mongoUserObject
	 * @param userId
	 * @param ids
	 * @return
	 */
	/**
	 * private User updateUserVehicleIdInUsersInMongo(final User mongoUserObject,
	 * final UserVehicle userVehicle) { logger.info("Updating User {{}} Vehicle Id
	 * {{}} in Mongo Db Users table.", mongoUserObject.getId());
	 * mongoUserObject.setUserVehicleId(userVehicle.getId());
	 * mongoUserObject.setLastModified(new Date()); return
	 * userRepository.save(mongoUserObject); }
	 */

	/**
	 * This is helper method to help getUserVehicleDetails() which format dates for
	 * API response
	 * 
	 * @param object
	 * @return
	 */
	private static VehicleDetailsVO convertPurchaseAndMfgDateToDDMMYYYYForAPIResponse(VehicleDetailsVO object) {
		Calendar cal1 = DateHelper.convertStringDateToCalender(object.getDateOfMfg(), Constants.RE_PRIME_PATTERN);
		Calendar cal2 = DateHelper.convertStringDateToCalender(object.getPurchaseDate(), Constants.RE_PRIME_PATTERN);

		object.setDateOfMfg(DateHelper.convertCalenderToStringDate(cal1, DateHelper.DDMMYYYY_SLASH));
		object.setPurchaseDate(DateHelper.convertCalenderToStringDate(cal2, DateHelper.DDMMYYYY_SLASH));
		return object;
	}

	/**
	 * @param date
	 * @return
	 */
	private static String convertStrDateToRePattern(String date) {
		Calendar calendar = DateHelper.convertStringDateToCalender(date, DateHelper.DDMMYYYY_SLASH);
		return DateHelper.convertCalenderToStringDate(calendar, Constants.RE_PRIME_PATTERN);
	}

	/**
	 * This helper method is used to check User Vehicles in User_Vehicle mongo
	 * Table.
	 * 
	 * @param mobileNo
	 * @return
	 */
	/**
	 * private UserVehicle fetchUserVehicleFromMongoByMobileNo(final String
	 * mobileNo) { logger.info("Verifying User Vehicle with Mobile No {{}} is
	 * Available in Mongo db or not.", mobileNo); Optional<UserVehicle>
	 * userVehicleMongoObject = userVehicleRepository.findByPhoneNo(mobileNo); if
	 * (!userVehicleMongoObject.isPresent()) { logger.error("Unable to find user
	 * Vehicle with Mobile No {{}}.", mobileNo); return null; } logger.info("User
	 * Vehicle with Mobile No {{}} is Available in Mongo db.", mobileNo); return
	 * userVehicleMongoObject.get(); }
	 */

	/**
	 * This helper method is used to check User Vehicles in User_Vehicle mongo
	 * Table.
	 * 
	 * @param mobileNo
	 * @return
	 */
	private UserVehicle fetchUserVehicleFromMongoByGuid(final String guid) {
		logger.info("Verifying User Vehicle with Guid {{}} is Available in Mongo db or not.", guid);
		Optional<UserVehicle> userVehicleMongoObject = userVehicleRepository.findByGuid(guid);
		if (!userVehicleMongoObject.isPresent()) {
			logger.error("Unable to find user Vehicle with Guid {{}}.", guid);
			return null;
		}
		logger.info("User Vehicle with Guid {{}} is Available.", guid);
		return userVehicleMongoObject.get();
	}

	/**
	 * @param prevoiusUserVehicle
	 * @param spList
	 * @param mobileNo
	 * @return
	 * @throws ParseException
	 */

	/**
	 * 
	 * private UserVehicle verifyPreviousAndCurrentVehicleDetailsInMongo(UserVehicle
	 * prevoiusUserVehicle, List<UserVehicleDetails> spList, String mobileNo) {
	 * logger.info("Verifying Previous Vehicle Details With Current Stored Procedure
	 * Details."); CopyOnWriteArrayList<UserVehicleDetails> spListCopy = new
	 * CopyOnWriteArrayList<>(spList);
	 * 
	 * List<UserVehicleDetails> previousUserVehiclesList =
	 * prevoiusUserVehicle.getUserVehicles(); for (UserVehicleDetails spBean :
	 * spList) { for (UserVehicleDetails previousBean : previousUserVehiclesList) {
	 * if (spBean.equals(previousBean)) { spListCopy.remove(spBean); } } } if
	 * (CollectionUtils.isEmpty(spListCopy)) { logger.info("Vehicle Details Already
	 * Available in Mongo."); return null; } logger.info("Stored Procedure Have some
	 * new Vehicle details{{}} so Updating Vehicle details in Mongo.", spListCopy);
	 * previousUserVehiclesList.addAll(spListCopy);
	 * prevoiusUserVehicle.setUserVehicles(previousUserVehiclesList); return
	 * prevoiusUserVehicle; }
	 */

	@SuppressWarnings("deprecation")
	private boolean isPurchaseDateLessThanEqualTo30Days(String purchaseDate) throws ParseException {
		purchaseDate = trimToNull(purchaseDate);
		if (isEmpty(purchaseDate)) {
			logger.info("Purchase Date is Blank or Empty.");
			return false;
		}
		Date localPurchaseDate = new SimpleDateFormat(DateHelper.DDMMYYYY_SLASH).parse(purchaseDate);
		Date currentDate = new Date();
		currentDate.setDate(currentDate.getDate() + 1);
		currentDate.setHours(0);
		currentDate.setMinutes(0);
		currentDate.setSeconds(0);

		long daysBetween = ((currentDate.getTime() - localPurchaseDate.getTime()) / (1000 * 60 * 60 * 24));

		logger.info(
				"No of Days Between Purchase Date {{}} & Current Date {{}} is {{}}. Which should be less or equal to configured day count {{}}",
				purchaseDate, currentDate, daysBetween, addVehicleVerifiedDayCount);
		return (daysBetween <= addVehicleVerifiedDayCount);
	}

	/**
	 * @param guid
	 * @param vehicles
	 */
	@Async
	private void callServiceHistory(String guid, List<VehicleDetailsVO> vehicles,
			ServiceHistoryOperationEnum operationEnum) {
		ServiceHistoryRequestDTO dto = new ServiceHistoryRequestDTO();
		try {
			dto.setGuid(guid);
			dto.setVehicles(vehicles);
			dto.setOperationEnum(operationEnum);

			logger.info("Calling Service History For {{}}", dto);

			storedProcedureService.fetchAllServiceHistory(dto);

			callExcellonServiceHistory(guid, vehicles);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Service History For {{}}. Exception Message {{}} Exception Details {{}}",
					dto, e.getMessage(), e);
		}
	}

	/**
	 * @param guid
	 * @param vehicles
	 */
	@SuppressWarnings("unchecked")
	private void callExcellonServiceHistory(String guid, List<VehicleDetailsVO> vehicles) {
		long startTime = System.currentTimeMillis();
		try {
			logger.info("Processing Excellon Service History.");
			Firestore firestore = FirestoreClient.getFirestore();
			CollectionReference collectionReference = firestore.collection(guid)
					.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT).collection(SERVICE_HISTORY_FIREBASE_CONSTANT);

			for (VehicleDetailsVO bean : vehicles) {
				List<ExcellonServiceHistoryResponse> responseList = restTemplateService
						.callExcellonServiceHistoryApi(bean.getChassisNo());
				if (CollectionUtils.isEmpty(responseList)) {
					continue;
				}
				for (int i = 0; i < responseList.size(); i++) {
					Map<String, Object> map = (Map<String, Object>) responseList.get(i);

					String branchId = (String) map.get("StoreCode");
					String invoiceDate = formatExcellonServiceHistoryDate(
							(String) map.get("ActualDeliveryDateandTime"));
					String billAmount = String.valueOf((Double) map.get("InvoiceAmount"));
					String serviceInvoiceNum = (String) map.get("InvoiceNumber");
					String chassisNo = (String) map.get("PartitionKey");
					String regNo = (String) map.get("RegistrationNumber");
					String userID = (String) map.get("UserId");
					String userMobileNumber = (String) map.get("UserMobileNumber");
					String firebaseKey = formatExcellonServiceHistoryDateForFireBaseKey(
							(String) map.get("ActualDeliveryDateandTime"));

					if (isNotEmpty(invoiceDate) && isNotEmpty(billAmount) && isNotEmpty(serviceInvoiceNum)) {
						DocumentReference documentRef = collectionReference.document(firebaseKey);

						Map<String, Object> data = new HashMap<>();
						data.put("BranchId", branchId);
						data.put("InvoiceDate", invoiceDate);
						data.put("BillAmount", billAmount);
						data.put("ServiceInvoiceNum", serviceInvoiceNum);
						data.put("ChassisNo", chassisNo);
						data.put("RegNo", regNo);
						data.put("UserID", userID);
						data.put("UserMobileNumber", userMobileNumber);
						documentRef.set(data);
						logger.info("Excellon Service Details Posted To Firebase {{}}", data);
					} else {
						logger.error(
								"Due to Some Missing Details Excellon Service History for chassis no {{}} can not be written in Firebase ",
								chassisNo);
					}
				}
			}
			logger.info("Excellon-Service-History method Called In {{}}ms", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Processing Excellon-Service-History. Exception Message {{}}, Exception Details {{}}",
					e.getMessage(), e);
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse getVehicleVin(GetVehicleVinRequestDTO dto) {
		logger.info("Calling getVehicleVin() params {{}}", dto);
		try {
			Map<String, List<VehicleVinResponseObject>> vehicleInfoList = new HashMap<>();
			List<VehicleVinResponseObject> vehicleDetailsVOList = storedProcedureService.getVehicleVin(dto);

			if (CollectionUtils.isEmpty(vehicleDetailsVOList)) {
				logger.error(SP_NO_DATA_FOUND);
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			vehicleInfoList.put("vehicleInfo", vehicleDetailsVOList);
			logger.info("DMS Vehicle List Size {{}}, Details{{}}", vehicleDetailsVOList.size(), vehicleDetailsVOList);
			return APIResponseHelper.getSuccessResponse(vehicleInfoList);
		} catch (final Exception e) {
			logger.error("Exception Occured While getVehicleVin  {{}}. Exception Message {{}},Exception Details {{}}",
					dto, e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto.getGuid()
	 * @return
	 */
	public REBaseResponse updateMobileInVehicleRecords(@Valid UpdateMobileInVehicleRecordsDTO dto) {
		logger.info("Calling updateMobileInVehicleRecords() params {{}}", dto);
		try {
			UserVehicle vehicleObject = fetchUserVehicleFromMongoByGuid(dto.getGuid());
			if (null == vehicleObject || ObjectUtils.isEmpty(vehicleObject)) {
				logger.info("Invalid GUID No. {{}}", dto.getGuid());
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			vehicleObject.setPhoneNo(dto.getMobileNumber());
			userVehicleRepository.save(vehicleObject);
			logger.info("Mobile Number updated in Vehicle Record Successfully in updateMobileInVehicleRecords method");
			return APIResponseHelper.getSuccessResponse(REResponse.MOBILE_UPDATED_SUCCESSFULLY_IN_VEHICLE_RECORD);
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Updating Mobile No In Vehicle Collections.  {{}}. Exception Message {{}},Exception Details {{}}",
					dto, e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse getVinJobCardStatus(@Valid GetVinJobCardStatusRequestDTO dto) {
		logger.info("Calling getVinJobCardStatus() params {{}}", dto);
		try {
			Map<String, List<VehicleJobCardStatusResponseObject>> vehicleInfoList = new HashMap<>();
			List<VehicleJobCardStatusResponseObject> vehicleDetailsVOList = storedProcedureService
					.getVinJobCardStatus(dto);
			if (CollectionUtils.isEmpty(vehicleDetailsVOList)) {
				logger.error("No Result Found From Stored Procedure.");
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			vehicleInfoList.put("vehicleInfo", vehicleDetailsVOList);
			logger.info("DMS Vehicle List Size {{}}, Details{{}}", vehicleDetailsVOList.size(), vehicleDetailsVOList);
			return APIResponseHelper.getSuccessResponse(vehicleInfoList);
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Getting Job Card Status  {{}}. Exception Message {{}},Exception Details {{}}",
					dto, e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	private REResponse validateDmsTransactionType(String transactionType) {
		if (StringUtils.equals(transactionType, REGISTRATION_NO_UPDATE_TRANSACTION_TYPE)
				|| StringUtils.equals(transactionType, VEHICLE_VERIFIED_TRANSACTION_TYPE)) {
			return REResponse.SUCCESS;
		}
		return REResponse.INVALID_DMS_TRANSACTION_TYPE;
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse getFullVehicleDetails(@Valid GetVehicleVinRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info(">> In getFullVehicleDetails()--");
		try {
			List<VehicleDetailsVO> vehicleDetailsVOList = storedProcedureService.getFullVehicleDetails(dto);

			if (CollectionUtils.isEmpty(vehicleDetailsVOList)) {
				logger.error(SP_NO_DATA_FOUND);
				return APIResponseHelper.getErrorResponse(REResponse.USER_VEHICLES_NOT_FOUND);
			}
			logger.info("<<< Out getFullVehicleDetails() In {{}}ms. Vehicle List Size {{}}",
					System.currentTimeMillis() - startTime, vehicleDetailsVOList.size());

			return APIResponseHelper.getSuccessResponse(vehicleDetailsVOList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Getting Full Vehicle Details {{}}. Exception Message {{}},Exception Details {{}}",
					dto, e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * 
	 * @param chassisNo   Always expected for the calls from WEB Service module
	 * @param phoneNumber
	 * @param guid
	 * @return
	 */
	public Boolean isChassisMappedtoUser(String chassisNo, String guid) {
		logger.debug("checking isValidUser -> chassisNo-> " + chassisNo + " guid-> " + guid);
		if (chassisNo == null || chassisNo.isEmpty())
			return true; // Workaround for backward compatibility
		List<UserVehicleDetails> userVehiclesList = new ArrayList<>();
		UserVehicle userVehicle = fetchUserVehicleFromMongoByGuid(guid);
		if (null == userVehicle || ObjectUtils.isEmpty(userVehicle)
				|| CollectionUtils.isEmpty(userVehicle.getUserVehicles())) {
			logger.info("User Have no Vehicle in Mongo. ");
			return false;
		} else {
			userVehiclesList.addAll(userVehicle.getUserVehicles());
		}

		for (UserVehicleDetails userVehicleDetails : userVehiclesList) {
			logger.info(" userVehicleDetails.getChassisNo() -> " + userVehicleDetails.getChassisNo());
			if (chassisNo.equalsIgnoreCase(userVehicleDetails.getChassisNo())) {
				if (userVehicleDetails.getVehicleStatus() == VehicleStatus.PENDING) {
					throw new AppException(AppExceptionErrorCode.VEHICLE_NOT_VERIFIED,
							"Vehicle verfication is pending");
				} else if (userVehicleDetails.getVehicleStatus() == VehicleStatus.VERIFIED) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 
	 * @param mobileNo
	 * @param guid
	 * @return
	 */
	public REBaseResponse fetchMongoVehicleDetails(UservehicleDetailsRequestDTO userDetails) {
		logger.info("In getUserVehicleDetails() ----");
		try {
			if (isNotEmpty(userDetails.getGuid())) {
				logger.info("Searching with guid {{}}", userDetails.getGuid());
				return getUserVehicleDetailsByGuid(userDetails.getGuid());
			}
			if (isNotEmpty(userDetails.getMobileNo())) {
				logger.info("Searching with mobile No:{}", userDetails.getMobileNo());
				UserProfileResponseDTO userProfileResponse = restTemplateService
						.callWebAPItoGetBasicDetails(userDetails.getMobileNo());
				if (null == userProfileResponse) {
					logger.error("No User details found with mobile No {{}}", userDetails.getMobileNo());
					return getErrorResponse(INVALID_MOBILE_NUMBER);
				}
				return getUserVehicleDetailsByGuid(userProfileResponse.getData().getGuid());
			}
			return getErrorResponse(INVALID_REQUEST);
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While Getting user vehicle details for {{}}. Exception Message {{}},Exception Details {{}}",
					userDetails, e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * 
	 * @param guid
	 * @return
	 */
	private REBaseResponse getUserVehicleDetailsByGuid(String guid) {
		logger.info("In getUserVehicleDetailsByGuid() --- Searching with guid {{}}", guid);

		List<UserVehicle> resultList = userVehicleRepository.findAllByGuid(guid);
		if (CollectionUtils.isEmpty(resultList)) {
			logger.error("No User vehicle details found for guid.");
			return getErrorResponse(USER_VEHICLES_NOT_FOUND);
		}
		if (resultList.size() > 1) {
			logger.error("Duplicate Guid {{}} Found in User Vehicle Collection.", guid);
			return getErrorResponse(DUPLICATE_USER_VEHICLE_FOUND);
		}
		CopyOnWriteArrayList<UserVehicleDetails> userVehicles = new CopyOnWriteArrayList<>(
				resultList.get(0).getUserVehicles());
		logger.info("Found Total {{}} Records with Guid {{}}.", userVehicles.size(), guid);
		userVehicles = getVerifiedVehicles(userVehicles);
		if (CollectionUtils.isEmpty(userVehicles)) {
			logger.error("For Guid {{}} No Vehicles are in VERIFIED state.", guid);
			return getErrorResponse(NO_VERIFIED_USER_VEHICLE_FOUND);
		}
		logger.info("{} user vehicle details found in verified state.", userVehicles.size());
		return getSuccessResponse(new UserVehicleDetailsDTO(guid, userVehicles));
	}

	/**
	 * 
	 * @param userVehicles
	 * @return
	 */
	private CopyOnWriteArrayList<UserVehicleDetails> getVerifiedVehicles(
			CopyOnWriteArrayList<UserVehicleDetails> userVehicles) {
		for (UserVehicleDetails userVehicle : userVehicles) {
			if (userVehicle.getVehicleStatus() != VehicleStatus.VERIFIED) {
				logger.error("Removing the Chassis No {{}} Having Vehicle status As {{}} from Result List.",
						userVehicle.getChassisNo(), userVehicle.getVehicleStatus());
				userVehicles.remove(userVehicle);
			}
		}
		return userVehicles;
	}

	public REBaseResponse updateConnectedFlag(@Valid GetVehicleVinRequestDTO dto) {
		try {
			List<UserVehicle> vehicleDataObject = userVehicleRepository.findByUserVehiclesChassisNo(dto.getChassisNo());
			if (ObjectUtils.isEmpty(vehicleDataObject)) {
				logger.info("Invalid Chassis Number {{}} No details found in collection.", dto.getChassisNo());
				return APIResponseHelper.getErrorResponse(REResponse.INVALID_CHASSIS_NUMBER);
			}
			logger.info("User Vehicle List to Update Connected Status is {{}} ", vehicleDataObject);
			for (UserVehicle userVehicle : vehicleDataObject) {
				List<UserVehicleDetails> userVehiclesList = userVehicle.getUserVehicles();
				for (int i = 0; i < userVehiclesList.size(); i++) {
					if (StringUtils.equals(userVehiclesList.get(i).getChassisNo(), dto.getChassisNo())) {
						logger.info("for Guid {{}} Chassis Number Matched Successfully.", userVehicle.getGuid());
						UserVehicleDetails vehicle = userVehiclesList.get(i);
						vehicle.setConnectedMotorcycle(true);
						vehicle.setLastModified(new Date());
						userVehiclesList.set(i, vehicle);
					}
				}
				userVehicle.setUserVehicles(userVehiclesList);
				userVehicleRepository.save(userVehicle);
			}
			logger.info("User Vehicle Details Updated For Chassis Number {{}} Successfully In Mongo Db.",
					dto.getChassisNo());
			return APIResponseHelper.getSuccessResponse(REResponse.USER_VEHICLES_UPDATED_SUCCESSFULLY);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User Vehicle Connected Status. Exception Message {{}} Exception Details {{}}",
					e.getMessage(), e);
			return APIResponseHelper.getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}
}
