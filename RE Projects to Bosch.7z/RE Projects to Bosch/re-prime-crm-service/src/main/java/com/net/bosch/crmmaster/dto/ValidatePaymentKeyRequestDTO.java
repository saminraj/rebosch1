package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class ValidatePaymentKeyRequestDTO {

	@NotNull
	@NotBlank
	private String paymentKey;

	private String appId;

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ValidatePaymentKeyRequestDTO [paymentKey=");
		builder.append(paymentKey);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}

	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}

}
