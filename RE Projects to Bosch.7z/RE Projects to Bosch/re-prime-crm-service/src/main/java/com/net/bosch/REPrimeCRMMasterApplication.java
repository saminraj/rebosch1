package com.net.bosch;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.net.bosch.filter.AppFilter;

//@EnableRetry
@EnableMongoAuditing
@EnableAutoConfiguration
@EnableRedisRepositories
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class REPrimeCRMMasterApplication extends SpringBootServletInitializer {

	private static final Logger log = LoggerFactory.getLogger(REPrimeCRMMasterApplication.class);

	@Autowired
	private Environment env;

	@Value("${azure.storage.connection}")
	private String connectionString;

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(REPrimeCRMMasterApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(REPrimeCRMMasterApplication.class, args);
	}

	

	@Bean
	public FilterRegistrationBean<AppFilter> registerAppFilter(AppFilter filter) {
		FilterRegistrationBean<AppFilter> reg = new FilterRegistrationBean<AppFilter>(filter);
		reg.setOrder(3);

		return reg;
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public CloudStorageAccount createAzureInstance() throws InvalidKeyException, URISyntaxException {
		return CloudStorageAccount.parse(connectionString);
	}

	JedisConnectionFactory jedisConnectionFactory() {
		log.info("REPrimeCRMMasterApplication.jedisConnectionFactory()=================================== IN ");
		RedisStandaloneConfiguration redisStandaloneConfiguration = null;
		try {
			String redisHost = env.getProperty("spring.redis.host");
			String redisPassKey = env.getProperty("spring.redis.password");
			String redisPort = env.getProperty("spring.redis.port");

			if (redisHost == null) {
				redisHost = "PRIMEDEV-Redis.redis.cache.windows.net";
			}
			if (redisPassKey == null) {
				redisPassKey = "jgkbih4VXqJO1nCN8l4X4m1UqIOWcQj15zbOx3fxYhk=";
			}
			if (redisPort == null) {
				redisPort = "6379";
			}
			redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisHost);
			redisStandaloneConfiguration.setPort(Integer.parseInt(redisPort));
			redisStandaloneConfiguration.setPassword(RedisPassword.of(redisPassKey));
		} catch (Exception e) {
			log.error(
					"Exception Occured While executing jedisConnectionFactory  Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
		log.info("REPrimeCRMMasterApplication.jedisConnectionFactory()=================================== OUT ");
		return new JedisConnectionFactory(redisStandaloneConfiguration);
	}

	@Bean
	public RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> template = new RedisTemplate<>();
		try {
			template.setConnectionFactory(jedisConnectionFactory());
		} catch (Exception e) {
			log.error(
					"Exception Occured While initializing redisTemplate  Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
		return template;
	}

}
