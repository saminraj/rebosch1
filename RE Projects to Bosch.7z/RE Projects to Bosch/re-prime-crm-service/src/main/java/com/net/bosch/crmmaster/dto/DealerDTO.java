package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


//@JsonInclude(Include.NON_NULL)
public class DealerDTO{

	private static final long serialVersionUID = -2541122859222308326L;

	private String id;	
	
	private String dealerid;
	
	private String dealername;
	
	private String branchid;
	
	private String branchname;
	
	private String address;
	
	private String lanlong;
	
	private String city;
	
	private String state;
	
	private String country;
	
	private String pincode;
	
	private String contactnumber;
	
	private String branch_type;
	
	private String is_pick_and_drop_available;		

	private String active;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDealerid() {
		return dealerid;
	}

	public void setDealerid(String dealerid) {
		this.dealerid = dealerid;
	}

	public String getDealername() {
		return dealername;
	}

	public void setDealername(String dealername) {
		this.dealername = dealername;
	}

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLanlong() {
		return lanlong;
	}

	public void setLanlong(String lanlong) {
		this.lanlong = lanlong;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getBranch_type() {
		return branch_type;
	}

	public void setBranch_type(String branch_type) {
		this.branch_type = branch_type;
	}

	public String getIs_pick_and_drop_available() {
		return is_pick_and_drop_available;
	}

	public void setIs_pick_and_drop_available(String is_pick_and_drop_available) {
		this.is_pick_and_drop_available = is_pick_and_drop_available;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	
			
}
