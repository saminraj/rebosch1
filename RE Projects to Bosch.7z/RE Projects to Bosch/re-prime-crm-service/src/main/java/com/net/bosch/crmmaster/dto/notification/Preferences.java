
package com.net.bosch.crmmaster.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "webHookDNId"
})
public class Preferences {

    @JsonProperty("webHookDNId")
    private String webHookDNId="1001";

    @JsonProperty("webHookDNId")
    public String getWebHookDNId() {
        return webHookDNId;
    }

    @JsonProperty("webHookDNId")
    public void setWebHookDNId(String webHookDNId) {
        this.webHookDNId = webHookDNId;
    }

}
