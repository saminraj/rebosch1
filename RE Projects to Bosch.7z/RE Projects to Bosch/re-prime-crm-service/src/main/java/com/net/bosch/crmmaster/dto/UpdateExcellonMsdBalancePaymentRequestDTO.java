package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class UpdateExcellonMsdBalancePaymentRequestDTO {

	@NotNull
	@NotBlank
	private String bookingCaseId;

	@NotNull
	@NotBlank
	private String paymentCaseId;
	private String paymentStatus;
	private String billDeskTransactionId;

	private String dealerSource;
	private String paymentDoneDateTime;
	private String billDeskAuthStatus;

	private DynamicsBalancePaymentResponse dynamicsBalancePaymentResponse;
	private ExcellonBalancePaymentResponse excellonBalancePaymentResponse;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateExcellonMsdBalancePaymentRequestDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", billDeskTransactionId=");
		builder.append(billDeskTransactionId);
		builder.append(", dealerSource=");
		builder.append(dealerSource);
		builder.append(", paymentDoneDateTime=");
		builder.append(paymentDoneDateTime);
		builder.append(", billDeskAuthStatus=");
		builder.append(billDeskAuthStatus);
		builder.append(", dynamicsBalancePaymentResponse=");
		builder.append(dynamicsBalancePaymentResponse);
		builder.append(", excellonBalancePaymentResponse=");
		builder.append(excellonBalancePaymentResponse);
		builder.append("]");
		return builder.toString();
	}

	
	/**
	 * @return the billDeskAuthStatus
	 */
	public String getBillDeskAuthStatus() {
		return billDeskAuthStatus;
	}


	/**
	 * @param billDeskAuthStatus the billDeskAuthStatus to set
	 */
	public void setBillDeskAuthStatus(String billDeskAuthStatus) {
		this.billDeskAuthStatus = billDeskAuthStatus;
	}


	/**
	 * @return the paymentDoneDateTime
	 */
	public String getPaymentDoneDateTime() {
		return paymentDoneDateTime;
	}

	/**
	 * @param paymentDoneDateTime the paymentDoneDateTime to set
	 */
	public void setPaymentDoneDateTime(String paymentDoneDateTime) {
		this.paymentDoneDateTime = paymentDoneDateTime;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the billDeskTransactionId
	 */
	public String getBillDeskTransactionId() {
		return billDeskTransactionId;
	}

	/**
	 * @param billDeskTransactionId the billDeskTransactionId to set
	 */
	public void setBillDeskTransactionId(String billDeskTransactionId) {
		this.billDeskTransactionId = billDeskTransactionId;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the dynamicsBalancePaymentResponse
	 */
	public DynamicsBalancePaymentResponse getDynamicsBalancePaymentResponse() {
		return dynamicsBalancePaymentResponse;
	}

	/**
	 * @param dynamicsBalancePaymentResponse the dynamicsBalancePaymentResponse to
	 *                                       set
	 */
	public void setDynamicsBalancePaymentResponse(DynamicsBalancePaymentResponse dynamicsBalancePaymentResponse) {
		this.dynamicsBalancePaymentResponse = dynamicsBalancePaymentResponse;
	}

	/**
	 * @return the excellonBalancePaymentResponse
	 */
	public ExcellonBalancePaymentResponse getExcellonBalancePaymentResponse() {
		return excellonBalancePaymentResponse;
	}

	/**
	 * @param excellonBalancePaymentResponse the excellonBalancePaymentResponse to
	 *                                       set
	 */
	public void setExcellonBalancePaymentResponse(ExcellonBalancePaymentResponse excellonBalancePaymentResponse) {
		this.excellonBalancePaymentResponse = excellonBalancePaymentResponse;
	}
}
