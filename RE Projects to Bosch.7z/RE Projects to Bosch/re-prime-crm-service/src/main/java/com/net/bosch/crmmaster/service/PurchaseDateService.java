package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.CHASSIS_NO;
import static com.net.bosch.constants.Constants.INVALID_SERVICE_HISTORY;
import static com.net.bosch.constants.Constants.SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.Constants.VALID_SERVICE_HISTORY;
import static com.net.bosch.constants.Constants.VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.REResponse.NO_DATA_FOUND_TO_WRITE_IN_FIREBASE;
import static com.net.bosch.constants.REResponse.SERVICE_HISTORY_SUCCESSFULLY_WRITTEN_TO_FIREBASE;
import static com.net.bosch.constants.REResponse.USER_GUID_REQUIRED;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static com.net.bosch.utils.ApplicationHelper.checkOptionalUserVehicle;
import static com.net.bosch.utils.ApplicationHelper.formatExcellonFireBaseKey;
import static com.net.bosch.utils.DateHelper.formatExcellonServiceHistoryDate;
import static com.net.bosch.utils.DateHelper.formatExcellonServiceHistoryDateForFireBaseKey;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.cloud.FirestoreClient;
import com.net.bosch.constants.REResponse;
import com.net.bosch.constants.VehicleStatus;
import com.net.bosch.crmmaster.dao.UserVehicleRepository;
import com.net.bosch.crmmaster.dto.DMSServiceHistoryResponse;
import com.net.bosch.crmmaster.dto.ExcellonServiceHistoryResponse;
import com.net.bosch.crmmaster.dto.ServiceHistoryDTO;
import com.net.bosch.crmmaster.dto.UpdateDatesAndServiceHistoryRequestDTO;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicle;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicleDetails;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class PurchaseDateService {

	private static final String CALL = "{call ";

	private static final String USER_ID = "UserID";

	private static final String REG_NO = "RegNo";

	private static final String SERVICE_INVOICE_NUM = "ServiceInvoiceNum";

	private static final String BILL_AMOUNT = "BillAmount";

	private static final String INVOICE_DATE = "InvoiceDate";

	private static final String BRANCH_ID = "BranchId";

	private static final String USER_MOBILE_NUMBER = "UserMobileNumber";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private DataSource dataSource;
	@Autowired
	private RestTemplateService restTemplateService;
	@Autowired
	private UserVehicleRepository userVehicleRepository;

	@Value("${spring.sqlserver.sp_prefix}")
	private String spPrefix;

	/**
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public REBaseResponse verifyPurchaseDates(String fromDate, String toDate) {
		long startTime = System.currentTimeMillis();
		logger.info("In verifyPurchaseDates()--");
		try {
			List<UserVehicle> resultList = getMongoVehicles(fromDate, toDate);
			if (null == resultList) {
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			logger.info("verifyPurchaseDates() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());
			return getSuccessResponse(resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Verifying Purchase Dates.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public REBaseResponse updatePurchaseDateAndManufacturingDatesWithDates(String fromDate, String toDate) {
		long startTime = System.currentTimeMillis();
		logger.info("In updatePurchaseDates()--");
		try {
			List<UserVehicle> resultList = getMongoVehicles(fromDate, toDate);
			if (null == resultList) {
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			int counter = 1;
			for (UserVehicle parent : resultList) {
				if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
					logger.error("For Guid {{}} No Vehicles Found in Mongo Db..", parent.getGuid());
					continue;
				}
				List<UserVehicleDetails> childList = parent.getUserVehicles();

				for (int j = 0; j < childList.size(); j++) {
					UserVehicleDetails child = childList.get(j);

					if (isEmpty(child.getChassisNo())) {
						logger.error("For Guid {{}} Chassis No is Blank/Empty In Mongo Db.", parent.getGuid());
						continue;
					}
					VehicleDetailsVO dmsObject = callSP(child.getChassisNo());
					if (null == dmsObject || ObjectUtils.isEmpty(dmsObject)) {
						logger.error(
								"For Chassis No {{}} No Records Found from DMS SP. So Not Updating In Mongo Db & not calling service history.",
								child.getChassisNo());
						continue;
					}
					logger.info("Setting DMS Purchase Date {{}} & Replacing Existing Purchase Date {{}}",
							dmsObject.getPurchaseDate(), child.getPurchaseDate());
					child.setPurchaseDate(dmsObject.getPurchaseDate());

					logger.info("Setting DMS MFG Date {{}} & Replacing Existing MFG Date {{}}",
							dmsObject.getDateOfMfg(), child.getDateOfMfg());
					child.setDateOfMfg(dmsObject.getDateOfMfg());
					child.setLastModified(new Date());
					childList.set(j, child);

				}
				parent.setUserVehicles(childList);
				userVehicleRepository.save(parent);

				logger.info("{{}} For GUID {{}} {{}} Vehicles Purchase Date Updated Successfully.", counter,
						parent.getGuid(), parent.getUserVehicles().size());

				counter++;
			}

			logger.info("updatePurchaseDates() called in {{}}ms.", System.currentTimeMillis() - startTime);
			return getSuccessResponse(getMongoVehicles(fromDate, toDate));
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Purchase Dates.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse updatePurchaseDateAndManufacturingDatesWithChassisNo(
			@Valid UpdateDatesAndServiceHistoryRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateDatesAndServiceHistory()--");
		try {
			if (CollectionUtils.isEmpty(dto.getChassisNumbers())) {
				logger.error("No Chassis Number found in Input Chassis Number List..");
				return getErrorResponse(REResponse.INVALID_REQUEST);
			}
			List<UserVehicle> resultList = userVehicleRepository.findByUserVehiclesChassisNoIn(dto.getChassisNumbers());
			if (CollectionUtils.isEmpty(resultList)) {
				logger.error("No Records found in Mongo db with given Chassis Number List..");
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			if (dto.isUpdateRecords()) {
				logger.info("Records Proceessing Started..");

				int counter = 1;
				for (UserVehicle parent : resultList) {
					if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
						logger.error("For Guid {{}} No Vehicles Found in Mongo Db", parent.getGuid());
						continue;
					}
					List<UserVehicleDetails> childList = parent.getUserVehicles();

					for (int j = 0; j < childList.size(); j++) {
						UserVehicleDetails child = childList.get(j);

						if (isEmpty(child.getChassisNo())) {
							logger.error("For Guid {{}} Chassis No is Blank/Empty In Mongo Db.", parent.getGuid());
							continue;
						}
						VehicleDetailsVO dmsObject = callSP(child.getChassisNo());
						if (null == dmsObject || ObjectUtils.isEmpty(dmsObject)) {
							logger.error(
									"For Chassis No {{}} No Records Found from DMS SP. So Not Updating In Mongo Db & not calling service history.",
									child.getChassisNo());
							continue;
						}
						logger.info("Setting DMS Purchase Date {{}} & Replacing Existing Purchase Date {{}}",
								dmsObject.getPurchaseDate(), child.getPurchaseDate());
						child.setPurchaseDate(dmsObject.getPurchaseDate());

						logger.info("Setting DMS MFG Date {{}} & Replacing Existing MFG Date {{}}",
								dmsObject.getDateOfMfg(), child.getDateOfMfg());
						child.setDateOfMfg(dmsObject.getDateOfMfg());
						child.setLastModified(new Date());
						
						childList.set(j, child);

					}
					parent.setUserVehicles(childList);
					userVehicleRepository.save(parent);

					logger.info("{{}} For GUID {{}} {{}} Vehicles Purchase Date Updated Successfully.", counter,
							parent.getGuid(), parent.getUserVehicles().size());

					counter++;
				}
			}
			logger.info("updateDatesAndServiceHistory() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());

			return getSuccessResponse(
					dto.isUpdateRecords() ? userVehicleRepository.findByUserVehiclesChassisNoIn(dto.getChassisNumbers())
							: resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Dates & Service History.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse updateServiceHistoryWithDates(boolean updateRecords, String fromDate, String toDate) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateServiceHistory()--");
		try {
			List<UserVehicle> resultList = getMongoVehicles(fromDate, toDate);
			if (null == resultList) {
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			if (updateRecords) {
				logger.info("Records proceessing started.");

				for (UserVehicle parent : resultList) {
					if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
						logger.error("For guid {{}} No Vehicles  Found in Mongo Db.", parent.getGuid());
						continue;
					}
					List<VehicleDetailsVO> serviceHistoryVehiclesList = new ArrayList<>();
					for (UserVehicleDetails bean : parent.getUserVehicles()) {
						if (bean.getVehicleStatus() == VehicleStatus.VERIFIED) {
							VehicleDetailsVO serviceHistoryVehicleObj = new VehicleDetailsVO();
							serviceHistoryVehicleObj.setChassisNo(bean.getChassisNo());
							serviceHistoryVehiclesList.add(serviceHistoryVehicleObj);
						}
					}
					if (CollectionUtils.isNotEmpty(serviceHistoryVehiclesList)) {
						callServiceHistory(parent.getGuid(), serviceHistoryVehiclesList);
					}
					logger.info("Service History Updated for Guid {{}} having {{}} VERIFIED vehicles.",
							parent.getGuid(), serviceHistoryVehiclesList.size());
				}
			}
			logger.info("updateServiceHistory() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());

			return getSuccessResponse(resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Service History.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse updateServiceHistoryWithChassisNo(@Valid UpdateDatesAndServiceHistoryRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateServiceHistoryWithChassisNo()--");
		try {
			if (CollectionUtils.isEmpty(dto.getChassisNumbers())) {
				logger.error("No Chassis Number found in Input Chassis Number List.");
				return getErrorResponse(REResponse.INVALID_REQUEST);
			}
			List<UserVehicle> resultList = userVehicleRepository.findByUserVehiclesChassisNoIn(dto.getChassisNumbers());
			if (CollectionUtils.isEmpty(resultList)) {
				logger.error("No Records found in Mongo db with given Chassis Number List.");
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			if (dto.isUpdateRecords()) {
				logger.info("Records Proceesssing Started.");

				for (UserVehicle parent : resultList) {
					if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
						logger.error("For Guid {{}} No Vehicle Found in Mongo Db.", parent.getGuid());
						continue;
					}
					List<VehicleDetailsVO> serviceHistoryVehiclesList = new ArrayList<>();

					for (UserVehicleDetails bean : parent.getUserVehicles()) {
						if (bean.getVehicleStatus() == VehicleStatus.VERIFIED) {
							VehicleDetailsVO serviceHistoryVehicleObj = new VehicleDetailsVO();
							serviceHistoryVehicleObj.setChassisNo(bean.getChassisNo());
							serviceHistoryVehiclesList.add(serviceHistoryVehicleObj);
						}
					}
					if (CollectionUtils.isNotEmpty(serviceHistoryVehiclesList)) {
						callServiceHistory(parent.getGuid(), serviceHistoryVehiclesList);
					}
					logger.info("Service History Updated for Guid {{}} having {{}} VERIFIED vehicles.",
							parent.getGuid(), serviceHistoryVehiclesList.size());
				}
			}
			logger.info("updateServiceHistoryWithChassisNo() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());
			return getSuccessResponse(resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Service History With Chassis No.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse updateExcellonServiceHistoryWithDates(boolean updateRecords, String fromDate, String toDate) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateExcellonServiceHistoryWithDates()--");
		try {
			List<UserVehicle> resultList = getMongoVehicles(fromDate, toDate);
			if (null == resultList) {
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			if (updateRecords) {
				logger.info("Records Proceessing Started.");
				for (UserVehicle parent : resultList) {
					if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
						logger.error("For Guid {{}} No Vehicles Found in Mongo Db.", parent.getGuid());
						continue;
					}
					List<VehicleDetailsVO> serviceHistoryVehiclesList = new ArrayList<>();
					for (UserVehicleDetails bean : parent.getUserVehicles()) {
						if (bean.getVehicleStatus() == VehicleStatus.VERIFIED) {
							VehicleDetailsVO serviceHistoryVehicleObj = new VehicleDetailsVO();
							serviceHistoryVehicleObj.setChassisNo(bean.getChassisNo());
							serviceHistoryVehiclesList.add(serviceHistoryVehicleObj);
						}
					}
					if (CollectionUtils.isNotEmpty(serviceHistoryVehiclesList)) {
						callExcellonServiceHistory(parent.getGuid(), serviceHistoryVehiclesList);
					}
					logger.info("Excellon Service History Updated for Guid {{}} having {{}} VERIFIED vehicles.",
							parent.getGuid(), serviceHistoryVehiclesList.size());
				}
			}
			logger.info("updateExcellonServiceHistoryWithDates() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());
			return getSuccessResponse(resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Excellon Service History.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse updateExcellonServiceHistoryWithChassisNo(@Valid UpdateDatesAndServiceHistoryRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateExcellonServiceHistoryWithChassisNo()--");
		try {
			if (CollectionUtils.isEmpty(dto.getChassisNumbers())) {
				logger.error("No Chassis Number found in Input Chassis Number List.");
				return getErrorResponse(REResponse.INVALID_REQUEST);
			}
			List<UserVehicle> resultList = userVehicleRepository.findByUserVehiclesChassisNoIn(dto.getChassisNumbers());
			if (CollectionUtils.isEmpty(resultList)) {
				logger.error("No Records found in Mongo db with given Chassis Number List.");
				return getErrorResponse(REResponse.NO_RECORDS_FOUND);
			}
			if (dto.isUpdateRecords()) {
				logger.info("Records Proceessing Started.");
				for (UserVehicle parent : resultList) {
					if (CollectionUtils.isEmpty(parent.getUserVehicles())) {
						logger.error("For Guid {{}} No Vehicles Found in Mongo Db.", parent.getGuid());
						continue;
					}
					List<VehicleDetailsVO> serviceHistoryVehiclesList = new ArrayList<>();

					for (UserVehicleDetails bean : parent.getUserVehicles()) {
						if (!dto.getChassisNumbers().contains(bean.getChassisNo())) {
							continue;
						}
						if (bean.getVehicleStatus() == VehicleStatus.VERIFIED) {
							VehicleDetailsVO serviceHistoryVehicleObj = new VehicleDetailsVO();
							serviceHistoryVehicleObj.setChassisNo(bean.getChassisNo());
							serviceHistoryVehiclesList.add(serviceHistoryVehicleObj);
						}
					}
					if (CollectionUtils.isNotEmpty(serviceHistoryVehiclesList)) {
						callExcellonServiceHistory(parent.getGuid(), serviceHistoryVehiclesList);
					}
					logger.info("Excellon Service History Updated for Guid {{}} having {{}} VERIFIED vehicles.",
							parent.getGuid(), serviceHistoryVehiclesList.size());
				}
			}
			logger.info("updateExcellonServiceHistoryWithChassisNo() called in {{}}ms. Found {{}} Records.",
					System.currentTimeMillis() - startTime, resultList.size());
			return getSuccessResponse(resultList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating Excellon Service History.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param chassisNo
	 * @return
	 */
	public REBaseResponse isServiceHistoryExistInDms(String chassisNo) {
		long startTime = System.currentTimeMillis();
		logger.info("In isServiceHistoryExistInDms()--");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		List<Map<String, Object>> listMap = new LinkedList<Map<String, Object>>();
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_GetServiceHistory(' ','");
			stringBuilder.append(chassisNo);
			stringBuilder.append("',' ',' ',' ')}");
			String spQuery = stringBuilder.toString();
			logger.info("Query {{}}", spQuery);
			statement = connection.prepareCall(spQuery);
			if (statement.execute()) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					Map<String, Object> data = new HashMap<>();
					data.put("branchId", resultSet.getString(BRANCH_ID));
					data.put("invoiceDate", resultSet.getString(INVOICE_DATE));
					data.put("billAmount", resultSet.getString(BILL_AMOUNT));
					data.put("serviceInvoiceNum", resultSet.getString(SERVICE_INVOICE_NUM));
					data.put("chassisNo", resultSet.getString("ChassisNo"));
					data.put("regNo", resultSet.getString(REG_NO));
					data.put("userID", resultSet.getString(USER_ID));
					data.put("userMobileNumber", resultSet.getString("User_MobileNumber"));
					listMap.add(data);
				}
			} else {
				logger.error("Unable to execute Statement.");
			}
			logger.info("isServiceHistoryExistInDms() called in {{}}ms. Found {{}} Service History Records.",
					System.currentTimeMillis() - startTime, listMap.size());

			return listMap.isEmpty() ? getErrorResponse(REResponse.NO_RECORDS_FOUND) : getSuccessResponse(listMap);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Verifying Purchase Dates.Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		} finally {
			closeJdbcConnection(connection, statement, resultSet);
		}
	}

	/**
	 * @param connection
	 * @param statement
	 * @param resultSet
	 * @param chassisNo
	 * @return
	 */
	private VehicleDetailsVO callSP(final String chassisNo) {
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getVehicleDetails(' ', ? ,' ',' ',' ')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			statement.setString(1, chassisNo);
			if (statement.execute()) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					return new VehicleDetailsVO(resultSet);
				}
			}
			return null;
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While calling Vehicle Details Procudure for chassis No {{}} Exception Message {{}},Exception Details {{}}",
					chassisNo, e.getMessage(), e);
			return null;
		} finally {
			closeJdbcConnection(connection, statement, resultSet);
		}
	}

	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	private Date formatStrToDates(String date) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return simpleDateFormat.parse(date);
	}

	/**
	 * @param fromDate
	 * @param toDate
	 * @return
	 * @throws ParseException
	 */
	private List<UserVehicle> getMongoVehicles(String fromDate, String toDate) throws ParseException {
		Date from = formatStrToDates(fromDate);
		Date to = isEmpty(toDate) ? new Date() : formatStrToDates(toDate);

		logger.info("From Date {{}},To Date {{}}", from, to);

		List<UserVehicle> resultList = userVehicleRepository.findByCreatedOnBetween(from, to);
		if (CollectionUtils.isEmpty(resultList)) {
			logger.error("No Records Found with Given From Date {{}} & To Date {{}}", fromDate, toDate);
			return Collections.emptyList();
		}
		return resultList;
	}

	/**
	 * @param guid
	 * @param vehicles
	 */
	private void callServiceHistory(String guid, List<VehicleDetailsVO> vehicles) {
		Connection connection = null;
		try {
			connection = dataSource.getConnection();

			logger.info("Processing Service History For Guid {{}}", guid);
			Firestore firestore = FirestoreClient.getFirestore();

			logger.info("Deleting All Service History for Guid {{}}", guid);
			ApiFuture<QuerySnapshot> future = firestore.collection(guid)
					.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT).collection(SERVICE_HISTORY_FIREBASE_CONSTANT)
					.get();
			int deleted = 1;
			List<QueryDocumentSnapshot> documents = future.get().getDocuments();
			for (QueryDocumentSnapshot document : documents) {
				document.getReference().delete();
				deleted++;
			}
			logger.info("Deleted {{}} Service History for Guid {{}}", deleted, guid);

			CollectionReference collectionReference = firestore.collection(guid)
					.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT).collection(SERVICE_HISTORY_FIREBASE_CONSTANT);

			for (VehicleDetailsVO bean : vehicles) {
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append(CALL);
				stringBuilder.append(spPrefix);
				stringBuilder.append("_sp_GetServiceHistory(' ','");
				stringBuilder.append(bean.getChassisNo());
				stringBuilder.append("',' ',' ',' ')}");
				String str = stringBuilder.toString();
				logger.info("SP Query {{}}", str);

				try (CallableStatement statement = connection.prepareCall(str);) {
					if (statement.execute()) {
						try (ResultSet resultSet = statement.getResultSet();) {
							if (resultSet.next()) {
								do {
									String branchId = resultSet.getString(BRANCH_ID);
									String invoiceDate = resultSet.getString(INVOICE_DATE);
									String billAmount = resultSet.getString(BILL_AMOUNT);
									String serviceInvoiceNum = resultSet.getString(SERVICE_INVOICE_NUM);
									String chassisNo = resultSet.getString(CHASSIS_NO);
									String regNo = resultSet.getString(REG_NO);
									String userID = resultSet.getString(USER_ID);
									String userMobileNumber = resultSet.getString("User_MobileNumber");

									if (isNotEmpty(invoiceDate) && isNotEmpty(billAmount)
											&& isNotEmpty(serviceInvoiceNum)) {
										DocumentReference documentRef = collectionReference.document(serviceInvoiceNum);

										Map<String, Object> data = new HashMap<>();
										data.put(BRANCH_ID, branchId);
										data.put(INVOICE_DATE, invoiceDate);
										data.put(BILL_AMOUNT, billAmount);
										data.put(SERVICE_INVOICE_NUM, serviceInvoiceNum);
										data.put(CHASSIS_NO, chassisNo);
										data.put(REG_NO, regNo);
										data.put(USER_ID, userID);
										data.put(USER_MOBILE_NUMBER, userMobileNumber);
										logger.info("Service Details Posted To Firebase {{}}", data);
										documentRef.set(data);
									} else {
										logger.error(
												"Due to Some Missing Details Service History for chassis no {{}} can not be written in Firebase ",
												chassisNo);
									}
								} while (resultSet.next());
							} else {
								logger.error(
										"For Chassis No {{}} ResultSet object is empty/No Service History is Available In DMS.",
										bean.getChassisNo());
							}
						}
					} else {
						logger.error("Unable to execute Statement for Guid {{}} & Chassis No {{}}", guid,
								bean.getChassisNo());
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Service History For Guid {{}}. Exception Message {{}} Exception Details {{}}",
					guid, e.getMessage(), e);
		} finally {
			closeJdbcConnection(connection, null, null);
		}
	}

	/**
	 * @param guid
	 * @param vehicles
	 */
	@SuppressWarnings("unchecked")
	private void callExcellonServiceHistory(String guid, List<VehicleDetailsVO> vehicles) {
		long startTime = System.currentTimeMillis();
		try {
			logger.info("Processing Excellon Service History.");
			Firestore firestore = FirestoreClient.getFirestore();
			CollectionReference collectionReference = firestore.collection(guid)
					.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT).collection(SERVICE_HISTORY_FIREBASE_CONSTANT);

			for (VehicleDetailsVO bean : vehicles) {
				List<ExcellonServiceHistoryResponse> responseList = restTemplateService
						.callExcellonServiceHistoryApi(bean.getChassisNo());
				if (CollectionUtils.isEmpty(responseList)) {
					continue;
				}
				for (int i = 0; i < responseList.size(); i++) {
					Map<String, Object> map = (Map<String, Object>) responseList.get(i);
					String branchId = (String) map.get("StoreCode");
					String invoiceDate = formatExcellonServiceHistoryDate(
							(String) map.get("ActualDeliveryDateandTime"));
					String billAmount = String.valueOf((Double) map.get("InvoiceAmount"));
					String serviceInvoiceNum = (String) map.get("InvoiceNumber");
					String chassisNo = (String) map.get("PartitionKey");
					String regNo = (String) map.get("RegistrationNumber");
					String userID = (String) map.get("UserId");
					String userMobileNumber = (String) map.get(USER_MOBILE_NUMBER);
					String firebaseKey = formatExcellonServiceHistoryDateForFireBaseKey(
							(String) map.get("ActualDeliveryDateandTime"));

					if (isNotEmpty(invoiceDate) && isNotEmpty(billAmount) && isNotEmpty(serviceInvoiceNum)) {
						DocumentReference documentRef = collectionReference.document(firebaseKey);

						Map<String, Object> data = new HashMap<>();
						data.put(BRANCH_ID, branchId);
						data.put(INVOICE_DATE, invoiceDate);
						data.put(BILL_AMOUNT, billAmount);
						data.put(SERVICE_INVOICE_NUM, serviceInvoiceNum);
						data.put("ChassisNo", chassisNo);
						data.put(REG_NO, regNo);
						data.put(USER_ID, userID);
						data.put(USER_MOBILE_NUMBER, userMobileNumber);
						documentRef.set(data);
						logger.info("Excellon Service Details Posted To Firebase {{}}", data);
					} else {
						logger.error(
								"Due to Some Missing Details Excellon Service History for chassis no {{}} can not be written in Firebase ",
								chassisNo);
					}
				}
			}
			logger.info("Excellon-Service-History method Called In {{}}ms", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Processing Excellon-Service-History. Exception Message {{}}, Exception Details {{}}",
					e.getMessage(), e);
		}
	}

	private void closeJdbcConnection(Connection connection, CallableStatement statement, ResultSet resultSet) {
		try {
			if (null != resultSet)
				resultSet.close();
			if (null != statement)
				statement.close();
			if (null != connection)
				connection.close();
		} catch (SQLException e) {
			logger.error(
					"Exception Occured While closing connection object.Input Params {Result Set{}},{Statement{}} & {Connection{}} Exception Message {{}},Exception Details {{}}.",
					resultSet, statement, connection, e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @param chassisNo
	 * @return
	 */
	public REBaseResponse verifyAndUpdateServiceHistory(String chassisNo, String guid, boolean updateRecords) {
		long startTime = System.currentTimeMillis();
		logger.info(">> In verifyServiceHistoryForDmsAndExcellon()--");
		ServiceHistoryDTO serviceHistory = new ServiceHistoryDTO();

		if (updateRecords && isEmpty(guid)) {
			return getErrorResponse(USER_GUID_REQUIRED);
		}
		if (isNotEmpty(guid)) {
			UserVehicle vehicleObj = checkOptionalUserVehicle(userVehicleRepository.findByGuid(guid));
			if (null == vehicleObj) {
				return getErrorResponse(NO_DATA_FOUND_TO_WRITE_IN_FIREBASE);
			}
			if (CollectionUtils.isEmpty(vehicleObj.getUserVehicles())) {
				logger.error("No Vehicles Found in Mongo DB.");
				return getErrorResponse(NO_DATA_FOUND_TO_WRITE_IN_FIREBASE);
			}
			logger.info("Given Guid Has {{}} Vehicles.", vehicleObj.getUserVehicles().size());
			Set<String> uniqueChassisNoList = new HashSet<>();

			for (UserVehicleDetails bean : vehicleObj.getUserVehicles()) {
				if (bean.getVehicleStatus() == VehicleStatus.VERIFIED) {
					uniqueChassisNoList.add(bean.getChassisNo());
				}
			}
			if (CollectionUtils.isEmpty(uniqueChassisNoList)) {
				logger.error("No Vehicles Found in VERIFIED state in Mongo DB.");
				return getErrorResponse(NO_DATA_FOUND_TO_WRITE_IN_FIREBASE);
			}
			List<DMSServiceHistoryResponse> dmsServiceList = new ArrayList<>();
			List<DMSServiceHistoryResponse> excellonServiceList = new ArrayList<>();
			logger.info("Given Guid Has Valid {{}} VERIFIED Vehicles/Unique Chassis No.", uniqueChassisNoList.size());

			for (String chassisNumber : uniqueChassisNoList) {

				dmsServiceList.addAll(getServiceHistoryFromDms(chassisNumber));

				List<ExcellonServiceHistoryResponse> excellonServiceHistory = restTemplateService
						.callExcellonServiceHistoryApi(chassisNumber);
				excellonServiceList.addAll(validateExcellonServiceHistory(excellonServiceHistory));
			}
			serviceHistory.setDmsServiceHistory(dmsServiceList);
			serviceHistory.setExcellonServiceHistory(excellonServiceList);
		} else {
			List<DMSServiceHistoryResponse> dmsServiceHistory = getServiceHistoryFromDms(chassisNo);
			serviceHistory.setDmsServiceHistory(dmsServiceHistory);

			List<ExcellonServiceHistoryResponse> excellonServiceHistory = restTemplateService
					.callExcellonServiceHistoryApi(chassisNo);
			serviceHistory.setExcellonServiceHistory(validateExcellonServiceHistory(excellonServiceHistory));
		}

		if (CollectionUtils.isEmpty(serviceHistory.getDmsServiceHistory())
				&& CollectionUtils.isEmpty(serviceHistory.getExcellonServiceHistory())) {
			return getErrorResponse(NO_DATA_FOUND_TO_WRITE_IN_FIREBASE);
		}
		logger.info("DMSserviceHistory : {{}}, ExcellonServiceHistory : {{}}",
				serviceHistory.getDmsServiceHistory().size(), serviceHistory.getExcellonServiceHistory().size());
		if (updateRecords) {
			return writeDataToFireBase(guid, chassisNo, serviceHistory, startTime);
		}
		logger.info(
				"<< Out verifyServiceHistoryForDmsAndExcellon() called in {{}}ms. Found {{}} DMS Service History Records, {{}} Excellon Service History Records.",
				System.currentTimeMillis() - startTime, serviceHistory.getDmsServiceHistory().size(),
				serviceHistory.getExcellonServiceHistory().size());

		return getSuccessResponse(serviceHistory);
	}

	/**
	 * get Service History from DMS.
	 * 
	 * @param chassisNo
	 * @return
	 */
	private List<DMSServiceHistoryResponse> getServiceHistoryFromDms(String chassisNo) {
		long startTime = System.currentTimeMillis();
		logger.info("In getServiceHistoryFromDms()--");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		List<DMSServiceHistoryResponse> dmsServiceList = new LinkedList<>();
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_GetServiceHistory(' ','");
			stringBuilder.append(chassisNo);
			stringBuilder.append("',' ',' ',' ')}");
			String spQuery = stringBuilder.toString();
			logger.info("Query {{}}", spQuery);
			statement = connection.prepareCall(spQuery);
			if (statement.execute()) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					DMSServiceHistoryResponse data = new DMSServiceHistoryResponse();
					data.setBranchId(resultSet.getString(BRANCH_ID));
					data.setInvoiceDate(resultSet.getString(INVOICE_DATE));
					data.setBillAmount(resultSet.getString(BILL_AMOUNT));
					data.setServiceInvoiceNum(resultSet.getString(SERVICE_INVOICE_NUM));
					data.setChassisNo(resultSet.getString("ChassisNo"));
					data.setRegNo(resultSet.getString(REG_NO));
					data.setUserID(resultSet.getString(USER_ID));
					data.setUserMobileNumber(resultSet.getString("User_MobileNumber"));

					data.setStatus((isNotEmpty(resultSet.getString(INVOICE_DATE))
							&& isNotEmpty(resultSet.getString(BILL_AMOUNT))
							&& isNotEmpty(resultSet.getString(SERVICE_INVOICE_NUM))) ? VALID_SERVICE_HISTORY
									: INVALID_SERVICE_HISTORY);
					dmsServiceList.add(data);
				}
			} else {
				logger.error("Unable to execute Statement.");
			}
			logger.info("Out getServiceHistoryFromDms() called in {{}}ms. Found {{}} Service History Records.",
					System.currentTimeMillis() - startTime, dmsServiceList.size());

			return dmsServiceList;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Service History SP for Chassis No {{}}.Exception Message {{}}",
					chassisNo, e.getMessage());
			return Collections.emptyList();
		} finally {
			closeJdbcConnection(connection, statement, resultSet);
		}
	}

	/**
	 * @param excellonServiceHistory
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<DMSServiceHistoryResponse> validateExcellonServiceHistory(
			List<ExcellonServiceHistoryResponse> excellonServiceHistory) {
		List<DMSServiceHistoryResponse> excellonServiceHistoryList = new ArrayList<>();
		for (int i = 0; i < excellonServiceHistory.size(); i++) {
			Map<String, Object> map = (Map<String, Object>) excellonServiceHistory.get(i);

			String invoiceDate = formatExcellonServiceHistoryDate(String.valueOf(map.get("ActualDeliveryDateandTime")));
			String billAmount = String.valueOf(map.get("InvoiceAmount"));
			String serviceInvoiceNum = String.valueOf(map.get("InvoiceNumber"));

			DMSServiceHistoryResponse excellonServiceResponse = new DMSServiceHistoryResponse();
			excellonServiceResponse.setBranchId(String.valueOf(map.get("StoreCode")));
			excellonServiceResponse.setInvoiceDate(invoiceDate);
			excellonServiceResponse.setBillAmount(billAmount);
			excellonServiceResponse.setServiceInvoiceNum(serviceInvoiceNum);
			excellonServiceResponse.setChassisNo(String.valueOf(map.get("PartitionKey")));
			excellonServiceResponse.setRegNo(String.valueOf(map.get("RegistrationNumber")));
			excellonServiceResponse.setUserID(String.valueOf(map.get("UserId")));
			excellonServiceResponse.setUserMobileNumber(String.valueOf(map.get(USER_MOBILE_NUMBER)));
			excellonServiceResponse
					.setStatus((isNotEmpty(invoiceDate) && isNotEmpty(billAmount) && isNotEmpty(serviceInvoiceNum))
							? VALID_SERVICE_HISTORY
							: INVALID_SERVICE_HISTORY);

			excellonServiceHistoryList.add(excellonServiceResponse);

		}
		return excellonServiceHistoryList;
	}

	/**
	 * to write service history data to firebase for excellon and dms.
	 * 
	 * @param guid
	 * @param serviceHistory
	 */
	private REBaseResponse writeDataToFireBase(String guid, String chassisNo, ServiceHistoryDTO serviceHistory,
			long startTime) {
		try {
			logger.info("Processing Service History For Guid {{}}", guid);
			Firestore firestore = FirestoreClient.getFirestore();

			int deleted;
			List<QueryDocumentSnapshot> documents;
			try {
				logger.info("Deleting All Service History for Guid {{}}", guid);
				ApiFuture<QuerySnapshot> future = firestore.collection(guid)
						.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
						.collection(SERVICE_HISTORY_FIREBASE_CONSTANT).get();
				deleted = 0;
				documents = future.get().getDocuments();
				for (QueryDocumentSnapshot document : documents) {
					document.getReference().delete();
					deleted++;
				}
				logger.info("Deleted {{}} Service History for Guid {{}}", deleted, guid);
			} catch (Exception e) {
				logger.info("Exception occured while deleting service history in firebase. {{}}", e.getMessage());
			}
			Thread.sleep(3000);
			if (CollectionUtils.isNotEmpty(serviceHistory.getExcellonServiceHistory())) {
				setServiceHistoryForExcellon(serviceHistory.getExcellonServiceHistory(), guid, chassisNo);
			}

			if (CollectionUtils.isNotEmpty(serviceHistory.getDmsServiceHistory())) {
				setServiceHistoryForDMS(serviceHistory.getDmsServiceHistory(), guid);
			}
			logger.info(
					"Out verifyServiceHistoryForDmsAndExcellon() called in {{}}ms. Found {{}} DMS Service History Records, {{}} Excellon Service History Records.",
					System.currentTimeMillis() - startTime, serviceHistory.getDmsServiceHistory().size(),
					serviceHistory.getExcellonServiceHistory().size());

			return getSuccessResponse(SERVICE_HISTORY_SUCCESSFULLY_WRITTEN_TO_FIREBASE);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Writing Service History for Guid {{}} & Chassis No {{}}. Exception Message {{}} Exception Details {{}}",
					guid, chassisNo, e.getMessage(), e);
			return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * to write service history for DMS in firebase.
	 * 
	 * @param dmsServiceHistory
	 * @param collectionReference
	 * @throws InterruptedException
	 */
	private void setServiceHistoryForDMS(List<DMSServiceHistoryResponse> dmsServiceHistory, String guid) {
		Firestore firestore = FirestoreClient.getFirestore();

		logger.debug("Writing DMS Service History to Firebase...");
		for (DMSServiceHistoryResponse dmsServiceResponse : dmsServiceHistory) {

			if (isNotEmpty(dmsServiceResponse.getInvoiceDate()) && isNotEmpty(dmsServiceResponse.getBillAmount())
					&& isNotEmpty(dmsServiceResponse.getServiceInvoiceNum())) {

				Map<String, String> data = new HashMap<>();
				data.put(BRANCH_ID, dmsServiceResponse.getBranchId());
				data.put(INVOICE_DATE, dmsServiceResponse.getInvoiceDate());
				data.put(BILL_AMOUNT, dmsServiceResponse.getBillAmount());
				data.put(SERVICE_INVOICE_NUM, dmsServiceResponse.getServiceInvoiceNum());
				data.put(CHASSIS_NO, dmsServiceResponse.getChassisNo());
				data.put(REG_NO, dmsServiceResponse.getRegNo());
				data.put(USER_ID, dmsServiceResponse.getUserID());
				data.put(USER_MOBILE_NUMBER, dmsServiceResponse.getUserMobileNumber());

				firestore.collection(guid).document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
						.collection(SERVICE_HISTORY_FIREBASE_CONSTANT)
						.document(dmsServiceResponse.getServiceInvoiceNum()).set(data);
				logger.info("DMS Service Details Posted To Firebase {{}}", data);
			} else {
				logger.error(
						"Due to Some Missing Details DMS Service History for chassis no {{}} can not be written in Firebase ",
						dmsServiceResponse.getChassisNo());
			}
		}
		logger.info("DMS Service History Successfully Wtitten to Firebase.");
	}

	/**
	 * to write service history for excellon in firebase.
	 * 
	 * @param excellonServiceHistory
	 * @param collectionReference
	 * @throws InterruptedException
	 */
	private void setServiceHistoryForExcellon(List<DMSServiceHistoryResponse> excellonServiceHistory, String guid,
			String chassisNo) {
		Firestore firestore = FirestoreClient.getFirestore();
		logger.debug("Writing Excellon Service History to Firebase...");

		for (DMSServiceHistoryResponse bean : excellonServiceHistory) {

			if (isNotEmpty(bean.getInvoiceDate()) && isNotEmpty(bean.getBillAmount())
					&& isNotEmpty(bean.getServiceInvoiceNum())) {
				String firebaseKey = formatExcellonFireBaseKey(bean.getInvoiceDate());

				Map<String, String> firebaseDataMap = new HashMap<>();
				firebaseDataMap.put(BRANCH_ID, bean.getBranchId());
				firebaseDataMap.put(INVOICE_DATE, bean.getInvoiceDate());
				firebaseDataMap.put(BILL_AMOUNT, bean.getBillAmount());
				firebaseDataMap.put(SERVICE_INVOICE_NUM, bean.getServiceInvoiceNum());
				firebaseDataMap.put("ChassisNo", bean.getChassisNo());
				firebaseDataMap.put(REG_NO, bean.getRegNo());
				firebaseDataMap.put(USER_ID, bean.getUserID());
				firebaseDataMap.put(USER_MOBILE_NUMBER, bean.getUserMobileNumber());

				firestore.collection(guid).document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
						.collection(SERVICE_HISTORY_FIREBASE_CONSTANT).document(firebaseKey).set(firebaseDataMap);

				logger.info("Excellon Service Details Posted To Firebase {}", firebaseDataMap);
			} else {
				logger.error(
						"Due to Some Missing Details Excellon Service History for chassis no {{}}, data {{}} can not be written in Firebase ",
						chassisNo, bean);
			}
		}
		logger.info("Excellon Service History Successfully Wtitten to Firebase.");
	}
}
