package com.net.bosch.crmmaster.dto;

import static com.net.bosch.constants.Constants.ONLINE_BALANCE_PAYMENT_DATE_PATTERN;
import static com.net.bosch.utils.DateHelper.convertCalenderToStringDate;

import java.util.Calendar;
import java.util.Date;

import com.net.bosch.utils.ApplicationHelper;

public class SavePaymentKeyRequest {

	private String paymentKey;
	private String dealerBookingId;
	private String dealerSource;
	private String bookingCaseId;
	private String expiryTime;

	public SavePaymentKeyRequest() {
	}

	/**
	 * @param dto
	 * @param paymentKey
	 */
	public SavePaymentKeyRequest(final GeneratePaymentKeyRequestDTO dto, final String paymentKey) {
		super();
		this.paymentKey = paymentKey;
		this.dealerBookingId = dto.getBookingId();
		this.dealerSource = ApplicationHelper.getDealerSource(dto.getBookingId());

		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.HOUR, 24);

		this.expiryTime = convertCalenderToStringDate(cal, ONLINE_BALANCE_PAYMENT_DATE_PATTERN);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SavePaymentKeyRequest [paymentKey=");
		builder.append(paymentKey);
		builder.append(", dealerBookingId=");
		builder.append(dealerBookingId);
		builder.append(", dealerSource=");
		builder.append(dealerSource);
		builder.append(", bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", expiryTime=");
		builder.append(expiryTime);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}

	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}

	/**
	 * @return the dealerBookingId
	 */
	public String getDealerBookingId() {
		return dealerBookingId;
	}

	/**
	 * @param dealerBookingId the dealerBookingId to set
	 */
	public void setDealerBookingId(String dealerBookingId) {
		this.dealerBookingId = dealerBookingId;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the expiryTime
	 */
	public String getExpiryTime() {
		return expiryTime;
	}

	/**
	 * @param expiryTime the expiryTime to set
	 */
	public void setExpiryTime(String expiryTime) {
		this.expiryTime = expiryTime;
	}

}
