package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;
@JsonInclude(Include.NON_NULL)
public class DealerListDTO extends ResponseDTO{

	private static final long serialVersionUID = -3225775892344748154L;
	
	List<DealerDTO> data;

	public List<DealerDTO> getData() {
		return data;
	}

	public void setData(List<DealerDTO> data) {
		this.data = data;
	}
	
	
	
		
}
