package com.net.bosch.exceptions;

/**
 * @author pushkarkhosla
 *
 */
public class InvalidBookingCaseIdException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4764698044654350252L;

	public InvalidBookingCaseIdException() {
	}

	public InvalidBookingCaseIdException(String msg) {
		super(msg);
	}
}
