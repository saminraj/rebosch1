package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.BILL_DESK_AUTH_STATUS_PENDING;
import static com.net.bosch.constants.Constants.CANCEL_TRANSACTION;
import static com.net.bosch.constants.Constants.DMS_DEALER_SOURCE;
import static com.net.bosch.constants.Constants.EXCELLON_DEALER_SOURCE;
import static com.net.bosch.constants.Constants.INITIATED_PAYMENT_STATUS;
import static com.net.bosch.constants.Constants.PENDING_RESOLUTION_TRANSACTION_STATUS;
import static com.net.bosch.constants.Constants.RETRY_COUNT;
import static com.net.bosch.constants.Constants.SUCCESSFUL_TRANSACTION;
import static com.net.bosch.constants.REResponse.DEALER_SOURCE_NOT_FOUND;
import static com.net.bosch.constants.REResponse.GENERIC_OR_UNKNOWN_ERROR;
import static com.net.bosch.constants.REResponse.INVALID_BOOKING_CASE_ID;
import static com.net.bosch.constants.REResponse.NO_BALANCE_PAYMENT_BOOKING_DETAILS_FOUND;
import static com.net.bosch.constants.REResponse.NO_BOOKING_DETAILS_FOUND;
import static com.net.bosch.constants.REResponse.PAYMENT_DETAILS_UPDATED_SUCCESSFULLY_FOR_BALANCE_PAYMENT;
import static com.net.bosch.constants.REResponse.PAYMENT_KEY_EXPIRED;
import static com.net.bosch.constants.REResponse.UNABLE_TO_SAVE_ONLINE_BALANCE_PAYMENT_DETAILS;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static com.net.bosch.utils.ApplicationHelper.checkOnlinePaymentOptional;
import static com.net.bosch.utils.ApplicationHelper.generatePaymentCashIdForBalancePayment;
import static com.net.bosch.utils.ApplicationHelper.generatePaymentCashIdForSubsequentBalancePayment;
import static com.net.bosch.utils.ApplicationHelper.getBalancePaymentDetailsAndResponse;
import static com.net.bosch.utils.ApplicationHelper.getBalancePaymentSearchResponse;
import static com.net.bosch.utils.DateHelper.DMS_EXCELLON_BALANCE_PAYMENT_DATE_FORMAT;
import static com.net.bosch.utils.DateHelper.convertCalenderToStringDate;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.net.bosch.constants.Constants;
import com.net.bosch.constants.PaymentStage;
import com.net.bosch.constants.REResponse;
import com.net.bosch.crmmaster.dao.OnlinePaymentDetailsRepository;
import com.net.bosch.crmmaster.dto.BalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.BalancePaymentResponse;
import com.net.bosch.crmmaster.dto.DMSBookingDetailsResponse;
import com.net.bosch.crmmaster.dto.DynamicsBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.ExcellonBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyRequestDTO;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyResponse;
import com.net.bosch.crmmaster.dto.SearchBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyExpiryResponse;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyRequestDTO;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyResponse;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentInfo;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.excellon.schemas.PushMYOBookingDetailDataResponse;
import com.net.bosch.excellon.soap.client.ExcellonSoapClient;
import com.net.bosch.utils.ApplicationHelper;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class BalancePaymentService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private HMACService hMACService;
	@Autowired
	private RestTemplateService restTemplateService;
	@Autowired
	private OnlineBookingService onlineBookingService;
	@Autowired
	private OnlinePaymentDetailsRepository onlinePaymentDetailsRepository;
	@Autowired
	private ExcellonSoapClient excellonSoapClient;

	/**
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public REBaseResponse generatePaymentKey(@Valid GeneratePaymentKeyRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In generatePaymentKey() -- ");
		try {
			String paymentKey = hMACService.getPaymentKey(dto.getBookingId());
			if (isEmpty(paymentKey)) {
				logger.error("Error Occured While Generating Payment Key.");
				return getErrorResponse(REResponse.TINY_URL_BALANCE_PAYMENT_GENERATION_ERROR);
			}
			Map<String, Object> savePaymentKeyResponse = restTemplateService.callPaymentServiceAPIToSavePaymentKey(dto,
					paymentKey);

			if (MapUtils.isNotEmpty(savePaymentKeyResponse)) {
				Map<String, Object> responseMap = (Map<String, Object>) savePaymentKeyResponse.get("response");
				if (MapUtils.isNotEmpty(responseMap)) {
					String tinyUrl = (String) responseMap.get("url");

					logger.info("generatePaymentKey() method Called in {{}}ms.",
							System.currentTimeMillis() - startTime);
					return getSuccessResponse(new GeneratePaymentKeyResponse(tinyUrl, paymentKey));
				}
			}
			logger.info("generatePaymentKey() method Called in {{}}ms.", System.currentTimeMillis() - startTime);

			return getErrorResponse(REResponse.TINY_URL_BALANCE_PAYMENT_GENERATION_ERROR);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Generating Payment Key. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse validatePaymentKey(@Valid ValidatePaymentKeyRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In validatePaymentKey() -- ");
		try {
			ValidatePaymentKeyExpiryResponse response = restTemplateService
					.callPaymentServiceAPItoValidatePaymentKey(dto.getPaymentKey());
			if (null == response) {
				return getErrorResponse(PAYMENT_KEY_EXPIRED);
			}
			if (isEmpty(response.getDealerSource())) {
				return getErrorResponse(DEALER_SOURCE_NOT_FOUND);
			}
			REBaseResponse baseResponse = null;
			switch (response.getDealerSource()) {
			case DMS_DEALER_SOURCE:
				DMSBookingDetailsResponse dmsResponse = restTemplateService
						.callDMSAPIToGetBookingDetails(response.getDealerBookingId());
				if (null == dmsResponse) {
					logger.error("No Response found from DMS-Booking-Details-API.");
					return getErrorResponse(NO_BOOKING_DETAILS_FOUND);
				}
				baseResponse = getSuccessResponse(new ValidatePaymentKeyResponse(response.getDealerBookingId(),
						response.getDealerSource(), dmsResponse));
				break;
			case EXCELLON_DEALER_SOURCE:
				PushMYOBookingDetailDataResponse excellonResponse = excellonSoapClient
						.callExcellonBookingDetailsSoapService(response.getDealerBookingId());
				if (null == excellonResponse) {
					logger.error("No Response found from Excellon-Booking-Details-API.");
					return getErrorResponse(NO_BOOKING_DETAILS_FOUND);
				}
				baseResponse = getSuccessResponse(new ValidatePaymentKeyResponse(response.getDealerBookingId(),
						response.getDealerSource(), excellonResponse));
				break;
			default:
				logger.error("Found Unhandled Dealer Source {{}} In Validating Payment Key.",
						response.getDealerSource());
				baseResponse = getErrorResponse(DEALER_SOURCE_NOT_FOUND);
				break;
			}
			logger.info("validatePaymentKey() method Called in {{}}ms.", System.currentTimeMillis() - startTime);
			return baseResponse;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Validating Payment Key. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse saveBalancePayment(@Valid BalancePaymentRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In saveBalancePayment() -- ");
		try {
			Object[][] objectArr = checkPreviousBalancePaymentDetails(dto);
			OnlinePaymentDetails paymentDetails = (OnlinePaymentDetails) objectArr[0][0];
			if (null == paymentDetails) {
				return getErrorResponse(UNABLE_TO_SAVE_ONLINE_BALANCE_PAYMENT_DETAILS);
			}
			onlinePaymentDetailsRepository.save(paymentDetails);

			BalancePaymentResponse balancePaymentResponse = (BalancePaymentResponse) objectArr[0][1];
			REBaseResponse response = getSuccessResponse(balancePaymentResponse);
			logger.info("saveBalancePayment() method Called in {{}}ms.", System.currentTimeMillis() - startTime);

			return response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Saving Balance Payment. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse updateBalancePayment(@Valid UpdateBalancePaymentRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateBalancePayment() --");
		try {
			OnlinePaymentDetails paymentDetails = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseId(dto.getBookingCaseId()));

			if (null == paymentDetails) {
				logger.error("Payment Record not found for Booking Case Id {{}}", dto.getBookingCaseId());
				return getErrorResponse(INVALID_BOOKING_CASE_ID);
			}
			List<OnlinePaymentInfo> paymentInfoList = paymentDetails.getPaymentInfo();
			if (CollectionUtils.isEmpty(paymentInfoList)) {
				logger.error("Unable to get Balance Payment Details Object, No details found");
				return getErrorResponse(INVALID_BOOKING_CASE_ID);
			}

			for (int i = 0; i < paymentInfoList.size(); i++) {
				if (StringUtils.equals(paymentInfoList.get(i).getPaymentCaseId(), dto.getPaymentCaseId())) {

					logger.info("Payment-Case-Id Matched Successfully While Saving Balance Payment Response.");

					OnlinePaymentInfo paymentInfo = paymentInfoList.get(i);
					paymentInfo.setBillDeskTrnsactionId(dto.getBillDeskTransactionId());
					paymentInfo.setPaymentStatus(dto.getPaymentStatus());
					paymentInfo.setPaymentRawRespObj(dto.getPaymentRawResponse());

					switch (paymentDetails.getDealerSource()) {
					case DMS_DEALER_SOURCE:

						paymentInfo.getDynamicsBalancePaymentRequestDTO()
								.setPaymentDoneDateTime(convertCalenderToStringDate(Calendar.getInstance(),
										DMS_EXCELLON_BALANCE_PAYMENT_DATE_FORMAT));
						paymentInfo.getDynamicsBalancePaymentRequestDTO()
								.setPaymentReference(dto.getBillDeskTransactionId());
						paymentInfo.getDynamicsBalancePaymentRequestDTO().setPaymentStatus(dto.getPaymentStatus());

						break;
					case EXCELLON_DEALER_SOURCE:

						paymentInfo.getExcellonBalancePaymentRequestDTO()
								.setPaymentDateTime(convertCalenderToStringDate(Calendar.getInstance(),
										DMS_EXCELLON_BALANCE_PAYMENT_DATE_FORMAT));
						paymentInfo.getExcellonBalancePaymentRequestDTO()
								.setPaymentRefNo(dto.getBillDeskTransactionId());
						paymentInfo.getExcellonBalancePaymentRequestDTO().setPaymentStatus(dto.getPaymentStatus());

						break;
					default:
						logger.error("Found Unhandled Dealer Source {{}} While Saving Balance Payment Response.",
								dto.getDealerSource());
						break;
					}
					if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), CANCEL_TRANSACTION)) {
						logger.info("Payment Status is cancel For {{}}, Setting retry count to {{}}.",
								dto.getPaymentCaseId(), RETRY_COUNT);
						paymentInfo.setRetryCount(RETRY_COUNT);
					}
					paymentInfoList.set(i, paymentInfo);
					break;
				}
			}
			paymentDetails.setPaymentInfo(paymentInfoList);
			onlinePaymentDetailsRepository.save(paymentDetails);

			logger.info("updateBalancePayment() method Called in {{}}ms.", System.currentTimeMillis() - startTime);

			return getSuccessResponse(PAYMENT_DETAILS_UPDATED_SUCCESSFULLY_FOR_BALANCE_PAYMENT);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User DMS-Excellon-Response. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	public REBaseResponse updateExcellonMsdBalancePaymentResponse(
			@Valid UpdateExcellonMsdBalancePaymentRequestDTO dto) {
		try {
			OnlinePaymentDetails paymentDetails = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseId(dto.getBookingCaseId()));

			if (null == paymentDetails) {
				logger.error("Payment Record not found for Booking Case Id {{}}", dto.getBookingCaseId());
				return getErrorResponse(INVALID_BOOKING_CASE_ID);
			}
			List<OnlinePaymentInfo> paymentInfoList = paymentDetails.getPaymentInfo();
			if (CollectionUtils.isEmpty(paymentInfoList)) {
				logger.error("Unable to get Balance Payment Details Object, No details found");
				return getErrorResponse(INVALID_BOOKING_CASE_ID);
			}
			for (int i = 0; i < paymentInfoList.size(); i++) {
				if (StringUtils.equals(paymentInfoList.get(i).getPaymentCaseId(), dto.getPaymentCaseId())) {

					logger.info(
							"Payment-Case-Id Matched Successfully While Saving Balance Payment Response from Batch Job.");
					OnlinePaymentInfo paymentInfo = updateExcellonMsdBalancePaymentResponseHelper(
							paymentInfoList.get(i), dto, paymentDetails);

					paymentInfoList.set(i, paymentInfo);
					break;
				}
			}

			paymentDetails.setPaymentInfo(paymentInfoList);
			onlinePaymentDetailsRepository.save(paymentDetails);
			logger.info("updateBalancePayment() method Called.");
			return getSuccessResponse(PAYMENT_DETAILS_UPDATED_SUCCESSFULLY_FOR_BALANCE_PAYMENT);

		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User DMS-Excellon-Response from Batch. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	private OnlinePaymentInfo updateExcellonMsdBalancePaymentResponseHelper(OnlinePaymentInfo paymentInfo,
			UpdateExcellonMsdBalancePaymentRequestDTO dto, OnlinePaymentDetails paymentDetails) {
		paymentInfo.setBillDeskTrnsactionId(dto.getBillDeskTransactionId());
		paymentInfo.setPaymentStatus(dto.getPaymentStatus());
		switch (paymentDetails.getDealerSource()) {
		case DMS_DEALER_SOURCE:

			updateDMSBalancePaymentResponse(paymentInfo, dto);
			break;
		case EXCELLON_DEALER_SOURCE:
			if (null != dto.getExcellonBalancePaymentResponse()) {
				logger.info("updating response object for Excellon in Mongo from batch Job");
				paymentInfo.setExcellonBalancePaymentResponse(dto.getExcellonBalancePaymentResponse());
				paymentInfo.getExcellonBalancePaymentRequestDTO().setPaymentRefNo(dto.getBillDeskTransactionId());
				paymentInfo.getExcellonBalancePaymentRequestDTO().setPaymentStatus(dto.getPaymentStatus());

				if (StringUtils.isEmpty(paymentInfo.getExcellonBalancePaymentRequestDTO().getPaymentDateTime())) {
					paymentInfo.getExcellonBalancePaymentRequestDTO().setPaymentDateTime(dto.getPaymentDoneDateTime());
				}

				if (dto.getExcellonBalancePaymentResponse().isRequestSuccessful()) {
					paymentInfo.getExcellonBalancePaymentResponse().setPostedTimestamp(new Date());
				}
			}
			break;
		default:
			logger.error("Found Unhandled Dealer Source {{}} While Saving Balance Payment Response.",
					dto.getDealerSource());
			break;
		}
		return updateExcellonMsdBalancePaymentResponseForPendingResolutionAndCancelTransaction(paymentInfo, dto);
	}

	private OnlinePaymentInfo updateDMSBalancePaymentResponse(OnlinePaymentInfo paymentInfo,
			UpdateExcellonMsdBalancePaymentRequestDTO dto) {
		if (null != dto.getDynamicsBalancePaymentResponse()) {
			logger.info("updating response object for DMS in Mongo from batch Job");
			paymentInfo.setDynamicsBalancePaymentResponse(dto.getDynamicsBalancePaymentResponse());
			paymentInfo.getDynamicsBalancePaymentRequestDTO().setPaymentReference(dto.getBillDeskTransactionId());
			paymentInfo.getDynamicsBalancePaymentRequestDTO().setPaymentStatus(dto.getPaymentStatus());

			if (StringUtils.isEmpty(paymentInfo.getDynamicsBalancePaymentRequestDTO().getPaymentDoneDateTime())) {
				paymentInfo.getDynamicsBalancePaymentRequestDTO().setPaymentDoneDateTime(dto.getPaymentDoneDateTime());
			}

			if (isNotEmpty(dto.getDynamicsBalancePaymentResponse().getResult()) && StringUtils
					.equalsIgnoreCase(dto.getDynamicsBalancePaymentResponse().getResult(), Constants.SUCCESS)) {
				paymentInfo.getDynamicsBalancePaymentResponse().setPostedTimestamp(new Date());
			}
		}
		return paymentInfo;
	}

	private OnlinePaymentInfo updateExcellonMsdBalancePaymentResponseForPendingResolutionAndCancelTransaction(
			OnlinePaymentInfo paymentInfo, UpdateExcellonMsdBalancePaymentRequestDTO dto) {

		if (!StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), SUCCESSFUL_TRANSACTION)
				|| ApplicationHelper.isRecordToBeProcessed(paymentInfo)) {

			paymentInfo.setRetryCount(paymentInfo.getRetryCount() + 1);

			if (paymentInfo.getRetryCount() == RETRY_COUNT
					&& (StringUtils.equalsIgnoreCase(dto.getBillDeskAuthStatus(), BILL_DESK_AUTH_STATUS_PENDING))) {

				logger.info("Retry Count is {{}} and Status is {{}} . Setting Status to Pending Resolution",
						RETRY_COUNT, dto.getPaymentStatus());
				paymentInfo.setPaymentStatus(PENDING_RESOLUTION_TRANSACTION_STATUS);
			}
		}
		if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), CANCEL_TRANSACTION)) {
			logger.info("Payment Status is cancel For {{}}, Setting retry count to {{}} ", dto.getPaymentCaseId(),
					RETRY_COUNT);
			paymentInfo.setRetryCount(RETRY_COUNT);
		}
		return paymentInfo;
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse searchBalancePayment(@Valid SearchBalancePaymentRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In searchBalancePayment() -- ");
		try {
			OnlinePaymentDetails searchDetails = null;
			if (isNotEmpty(dto.getBookingCaseId())) {
				logger.info("Searching Balance Payment Details With Booking-Cash-Id {{}}", dto.getBookingCaseId());

				searchDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByBookingCaseId(dto.getBookingCaseId()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			if (isNotEmpty(dto.getDmsBookingId())) {
				logger.info("Searching Balance Payment Details With DMS-Booking-Id {{}}", dto.getDmsBookingId());

				searchDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByDmsBookingId(dto.getDmsBookingId()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			if (isNotEmpty(dto.getExcellonBookingId())) {
				logger.info("Searching Balance Payment Details With Excellon-Booking-Id {{}}",
						dto.getExcellonBookingId());

				searchDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByExcellonBookingId(dto.getExcellonBookingId()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			if (isNotEmpty(dto.getExcellonResponseKey())) {
				logger.info("Searching Balance Payment Details With Excellon-Response-Id {{}}",
						dto.getExcellonResponseKey());

				searchDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByExcellonResponseKey(dto.getExcellonResponseKey()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			if (isNotEmpty(dto.getPaymentCaseId())) {
				logger.info("Searching Balance Payment Details With Payment-Cash-Id {{}}", dto.getPaymentCaseId());

				searchDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByPaymentInfoPaymentCaseId(dto.getPaymentCaseId()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			if (isNotEmpty(dto.getBillDeskTransactionId())) {
				logger.info("Searching Balance Payment Details With Bill-Desk-Transaction-Id {{}}",
						dto.getBillDeskTransactionId());

				searchDetails = checkOnlinePaymentOptional(onlinePaymentDetailsRepository
						.findByPaymentInfoBillDeskTrnsactionId(dto.getBillDeskTransactionId()));

				return getBalancePaymentSearchResponse(searchDetails);
			}
			logger.info("searchBalancePayment() method Called in {{}}ms.", System.currentTimeMillis() - startTime);

			return getErrorResponse(NO_BALANCE_PAYMENT_BOOKING_DETAILS_FOUND);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Searching Balance Payment Details. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	private Object[][] checkPreviousBalancePaymentDetails(final BalancePaymentRequestDTO dto) {
		switch (dto.getDealerSource()) {
		case DMS_DEALER_SOURCE:

			logger.info("Verifying DMS-Balance-Payment Booking Id {{}} is available in Mongo or not .",
					dto.getDmsExcellonBookingId());

			OnlinePaymentDetails previousDmsDetails = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByDmsBookingId(dto.getDmsExcellonBookingId()));

			return (null == previousDmsDetails) ? getFirstBalancePaymentObj(dto)
					: mergeSubsequentBalancePaymentObj(previousDmsDetails, dto);

		case EXCELLON_DEALER_SOURCE:

			logger.info(
					"Verifying Excellon-Balance-Payment Booking Id {{}} or Response key {{}} is available in Mongo or not .",
					dto.getDmsExcellonBookingId(), dto.getExcellonResponseKey());

			OnlinePaymentDetails previousExcellonDetails = null;
			if (isNotEmpty(dto.getExcellonResponseKey())) {
				logger.info("Verifying Excellon Previous Details with Response key is available in Mongo or not {{}}.",
						dto.getExcellonResponseKey());
				previousExcellonDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByExcellonResponseKey(dto.getExcellonResponseKey()));
			}
			if (null == previousExcellonDetails) {
				logger.info("Verifying Excellon Previous Details with Booking Id is available in Mongo or not {{}}.",
						dto.getDmsExcellonBookingId());
				previousExcellonDetails = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByExcellonBookingId(dto.getDmsExcellonBookingId()));
			}
			return (null == previousExcellonDetails) ? getFirstBalancePaymentObj(dto)
					: mergeSubsequentBalancePaymentObj(previousExcellonDetails, dto);
		default:
			logger.error("Found Unhandled Dealer Source {{}} In Checking Previous Details.", dto.getDealerSource());
			return getBalancePaymentDetailsAndResponse(null, null);
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	private Object[][] getFirstBalancePaymentObj(final BalancePaymentRequestDTO dto) {

		logger.info("Adding entry for First-Balance-Payment.");

		OnlinePaymentDetails entity = new OnlinePaymentDetails();
		entity.setBookingCaseId(onlineBookingService.generateBookingId());
		entity.setDealerSource(dto.getDealerSource());

		switch (dto.getDealerSource()) {
		case DMS_DEALER_SOURCE:
			entity.setDmsBookingId(dto.getDmsExcellonBookingId());
			break;
		case EXCELLON_DEALER_SOURCE:
			entity.setExcellonBookingId(dto.getDmsExcellonBookingId());
			break;
		default:
			logger.error("Found Unhandled Dealer Source {{}} In Saving First Balance Payment.", dto.getDealerSource());
			break;
		}
		List<OnlinePaymentInfo> paymentInfoList = new ArrayList<>();
		OnlinePaymentInfo object = getInitialOnlinePaymentInfoObj(dto);
		object.setPaymentCaseId(generatePaymentCashIdForBalancePayment(entity.getBookingCaseId()));

		paymentInfoList.add(object);
		entity.setPaymentInfo(paymentInfoList);

		return getBalancePaymentDetailsAndResponse(entity,
				new BalancePaymentResponse(dto.getDealerSource(), entity.getBookingCaseId(),
						dto.getDmsExcellonBookingId(), object.getPaymentCaseId(), object.getPaymentStatus(),
						object.getPaymentStage()));
	}

	/**
	 * @param previousDetails
	 * @param dto
	 * @return
	 */
	private Object[][] mergeSubsequentBalancePaymentObj(final OnlinePaymentDetails previousDetails,
			final BalancePaymentRequestDTO dto) {

		logger.info("Adding entry for Subsequent-Balance-Payment.");

		List<OnlinePaymentInfo> paymentInfoList = previousDetails.getPaymentInfo();
		OnlinePaymentInfo object = getInitialOnlinePaymentInfoObj(dto);
		object.setPaymentCaseId(
				generatePaymentCashIdForSubsequentBalancePayment(paymentInfoList, previousDetails.getBookingCaseId()));

		paymentInfoList.add(object);
		previousDetails.setPaymentInfo(paymentInfoList);

		return getBalancePaymentDetailsAndResponse(previousDetails,
				new BalancePaymentResponse(dto.getDealerSource(), previousDetails.getBookingCaseId(),
						dto.getDmsExcellonBookingId(), object.getPaymentCaseId(), object.getPaymentStatus(),
						object.getPaymentStage()));
	}

	/**
	 * @param dto
	 * @return
	 */
	private OnlinePaymentInfo getInitialOnlinePaymentInfoObj(final BalancePaymentRequestDTO dto) {
		OnlinePaymentInfo object = new OnlinePaymentInfo();
		object.setPaymentTimeStamp(new Date());
		object.setAmountPaid(dto.getTotalOnlinePaidAmount());
		object.setPaymentStage(PaymentStage.BALANCE_PAYMENT);
		object.setPaymentStatus(INITIATED_PAYMENT_STATUS);
		object.setAppId(dto.getAppId());

		switch (dto.getDealerSource()) {
		case DMS_DEALER_SOURCE:
			object.setDynamicsBalancePaymentRequestDTO(new DynamicsBalancePaymentRequestDTO(
					dto.getDmsExcellonBookingId(), dto.getTotalOnlinePaidAmount()));
			break;
		case EXCELLON_DEALER_SOURCE:
			object.setExcellonBalancePaymentRequestDTO(new ExcellonBalancePaymentRequestDTO(
					dto.getDmsExcellonBookingId(), dto.getTotalOnlinePaidAmount()));
			break;
		default:
			logger.error("Found Unhandled Dealer Source {{}} In Creating Initial Balance Payment Object.",
					dto.getDealerSource());
			break;
		}
		return object;
	}

}
