package com.net.bosch.crmmaster.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;

@JsonInclude(Include.NON_NULL)
public class ServiceInProgressListDTO extends ResponseDTO {

	private static final long serialVersionUID = 8311364701473779729L;

	private Map<String, ServiceInProgressDTO> data;

	public Map<String, ServiceInProgressDTO> getData() {
		return data;
	}

	public void setData(Map<String, ServiceInProgressDTO> data) {
		this.data = data;
	}

	
}
