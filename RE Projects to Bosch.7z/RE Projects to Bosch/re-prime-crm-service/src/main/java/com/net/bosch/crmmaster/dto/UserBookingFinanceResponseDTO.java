package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

/**
 * @author pushkarkhosla
 *
 */
public class UserBookingFinanceResponseDTO {

	/**
	 * Financier Details.
	 */

	@NotBlank
	@NotEmpty
	private String financerName;

	@NotBlank
	@NotEmpty
	private String financerLoanId;

	@NotBlank
	@NotEmpty
	private String financerStatus;

	private String financerLoanAmount;
	private String financerTenure;
	private String financerInterestRate;

	public UserBookingFinanceResponseDTO() {

	}

	public UserBookingFinanceResponseDTO(FinanceBookingDetailsDTO financeDetails) {
		this.financerName = financeDetails.getFinancerName();
		this.financerStatus = financeDetails.getFinancerStatus();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserBookingFinanceResponseDTO [financerName=");
		builder.append(financerName);
		builder.append(", financerLoanId=");
		builder.append(financerLoanId);
		builder.append(", financerStatus=");
		builder.append(financerStatus);
		builder.append(", financerLoanAmount=");
		builder.append(financerLoanAmount);
		builder.append(", financerTenure=");
		builder.append(financerTenure);
		builder.append(", financerInterestRate=");
		builder.append(financerInterestRate);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the financerName
	 */
	public String getFinancerName() {
		return financerName;
	}

	/**
	 * @param financerName the financerName to set
	 */
	public void setFinancerName(String financerName) {
		this.financerName = financerName;
	}

	/**
	 * @return the financerStatus
	 */
	public String getFinancerStatus() {
		return financerStatus;
	}

	/**
	 * @param financerStatus the financerStatus to set
	 */
	public void setFinancerStatus(String financerStatus) {
		this.financerStatus = financerStatus;
	}

	/**
	 * @return the financerLoanAmount
	 */
	public String getFinancerLoanAmount() {
		return financerLoanAmount;
	}

	/**
	 * @param financerLoanAmount the financerLoanAmount to set
	 */
	public void setFinancerLoanAmount(String financerLoanAmount) {
		this.financerLoanAmount = financerLoanAmount;
	}

	/**
	 * @return the financerTenure
	 */
	public String getFinancerTenure() {
		return financerTenure;
	}

	/**
	 * @param financerTenure the financerTenure to set
	 */
	public void setFinancerTenure(String financerTenure) {
		this.financerTenure = financerTenure;
	}

	/**
	 * @return the financerInterestRate
	 */
	public String getFinancerInterestRate() {
		return financerInterestRate;
	}

	/**
	 * @param financerInterestRate the financerInterestRate to set
	 */
	public void setFinancerInterestRate(String financerInterestRate) {
		this.financerInterestRate = financerInterestRate;
	}

	/**
	 * @return the financerLoanId
	 */
	public String getFinancerLoanId() {
		return financerLoanId;
	}

	/**
	 * @param financerLoanId the financerLoanId to set
	 */
	public void setFinancerLoanId(String financerLoanId) {
		this.financerLoanId = financerLoanId;
	}

}
