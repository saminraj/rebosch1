package com.net.bosch.crmmaster.dto;

import static com.net.bosch.constants.Constants.DMS_EXCELLON_PAYMENT_SOURCE;

import java.io.Serializable;

public class ExcellonBalancePaymentRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2588682019403950134L;

	private String paymentRefNo;
	private String bookingDocName;
	private double paymentAmount;
	private String paymentDateTime;
	private String paymentSource;
	private String paymentStatus;

	public ExcellonBalancePaymentRequestDTO() {
	}

	/**
	 * @param bookingDocName
	 * @param paymentAmount
	 * @param paymentDateTime
	 */
	public ExcellonBalancePaymentRequestDTO(String bookingDocName, double paymentAmount) {
		super();
		this.bookingDocName = bookingDocName;
		this.paymentAmount = paymentAmount;
		this.paymentSource = DMS_EXCELLON_PAYMENT_SOURCE;
	}

	/**
	 * @return the paymentRefNo
	 */
	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	/**
	 * @param paymentRefNo the paymentRefNo to set
	 */
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	/**
	 * @return the bookingDocName
	 */
	public String getBookingDocName() {
		return bookingDocName;
	}

	/**
	 * @param bookingDocName the bookingDocName to set
	 */
	public void setBookingDocName(String bookingDocName) {
		this.bookingDocName = bookingDocName;
	}

	/**
	 * @return the paymentAmount
	 */
	public double getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * @return the paymentDateTime
	 */
	public String getPaymentDateTime() {
		return paymentDateTime;
	}

	/**
	 * @param paymentDateTime the paymentDateTime to set
	 */
	public void setPaymentDateTime(String paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}

	/**
	 * @return the paymentSource
	 */
	public String getPaymentSource() {
		return paymentSource;
	}

	/**
	 * @param paymentSource the paymentSource to set
	 */
	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcellonBalancePaymentRequestDTO [paymentRefNo=");
		builder.append(paymentRefNo);
		builder.append(", bookingDocName=");
		builder.append(bookingDocName);
		builder.append(", paymentAmount=");
		builder.append(paymentAmount);
		builder.append(", paymentDateTime=");
		builder.append(paymentDateTime);
		builder.append(", paymentSource=");
		builder.append(paymentSource);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append("]");
		return builder.toString();
	}

}
