package com.net.bosch.crmmaster.scheduler;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.net.bosch.crmmaster.dto.AppointmentSlotDTO;
import com.net.bosch.crmmaster.dto.DealerDTO;
import com.net.bosch.crmmaster.service.AppointmentService;
import com.net.bosch.crmmaster.service.FirebaseService;
import com.net.bosch.crmmaster.service.StoredProcedureService;

@Component
public class Scheduler {

	@Autowired
	AppointmentService appointmentService;
	
	@Autowired
	StoredProcedureService storedProcedureService;	
	
	@Autowired
	FirebaseService firebaseService;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
//	@Autowired
//	private Environment env;
	
//	cron.expression = * */15 9-18 * * ?
	String cronJobExp = "* */15 9-18 * * ?"; 
	
//	String dbURL = env.getProperty("spring.sqlserver.url");
	
	
	
//	@Scheduled(fixedDelay = 15*60*1000, initialDelay = 30*1000)
	public void scheduleFixedDelayTask() {
		logger.info( "Fixed delay task - " + new Date(System.currentTimeMillis()).toLocaleString());
	    migrateJobForSPToRedis();
	}
	
	
//	@Scheduled(fixedDelay = 120*60*1000, initialDelay = 30*1000)
	public void scheduleDealerListTask() {
		logger.info( "Fixed delay task for dealers- " + new Date(System.currentTimeMillis()).toLocaleString());
	    migrateJobForDealerList();
	}
	
	
	
	
	
	private void migrateJobForSPToRedis() {
		HashMap<String, List<AppointmentSlotDTO>> appointList = storedProcedureService.fetchAppointmentsFromSP();
		logger.info("Scheduler.migrateJobForSPToRedis()appointList.size:"+appointList.size());
		appointmentService.createAppointmentSlots(appointList);
	}
	
	
	private void migrateJobForDealerList() {
		logger.info("Scheduler.migrateJobForDealerList() in");
		List<DealerDTO> dealerList = storedProcedureService.fetchDealerList();
		logger.info("Scheduler.migrateJobForDealerList() dealerList.size"+dealerList.size());
		try {
			firebaseService.addDealers(dealerList);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@Scheduled(fixedDelay = 7*60*1000)
//	public void scheduleVehicleListTask() {
//		logger.info( "Fixed delay task for Vehicle- " + new Date(System.currentTimeMillis()).toLocaleString());
//		migrateJobForVehicleList();
//	}
//	
//	private void migrateJobForVehicleList() {
//		logger.info("Scheduler.migrateJobForVehicleList() in");
//		List<VehicleDTO> vehicleList = storedProcedureService.fetchVehicleList();
//		logger.info("Scheduler.migrateJobForVehicleList() vehicleList.size"+vehicleList.size());
//		try {
//			firebaseService.addVehicleList(vehicleList);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//	}
//	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
////	@Scheduled(cron = "0 1 1 ? * *")
//	@Scheduled(cron = "${scheduler.configurationLoadRate}", zone = "IST")
//	public void scheduleTestTask() {
//		logger.info( "scheduleTestTask - " + new Date(System.currentTimeMillis()).toLocaleString());
//	}
//	
//	
//	public String getConfigRefreshValue() {
//		String cronJobExp = "* */5 9-18 * * ?";
//		
//		return cronJobExp;
//	}
	
	
	
	
	
	
}