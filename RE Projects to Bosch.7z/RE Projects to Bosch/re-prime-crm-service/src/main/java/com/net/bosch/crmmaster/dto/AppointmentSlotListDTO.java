package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;

@JsonInclude(Include.NON_NULL)
public class AppointmentSlotListDTO extends ResponseDTO{

	private static final long serialVersionUID = 5257724847074591355L;
	
	List< AppointmentSlotDTO> data;

	public List<AppointmentSlotDTO> getData() {
		return data;
	}

	public void setData(List<AppointmentSlotDTO> data) {
		this.data = data;
	}
	
	
	
		
}
