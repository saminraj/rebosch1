package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DealerSearchDTO{
	
	private String zipCode;
	
	private String latitude;
	
	private String longitude;
	
	@NotNull
	private String distance = "10";
	
	private String searchText = "";
	
	private Boolean isTextSearch = false;
	
	private Boolean includeAllDealers = false;

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public Boolean getIsTextSearch() {
		return isTextSearch;
	}

	public void setIsTextSearch(Boolean isTextSearch) {
		this.isTextSearch = isTextSearch;
	}

	public Boolean getIncludeAllDealers() {
		return includeAllDealers;
	}

	public void setIncludeAllDealers(Boolean includeAllDealers) {
		this.includeAllDealers = includeAllDealers;
	}
}
