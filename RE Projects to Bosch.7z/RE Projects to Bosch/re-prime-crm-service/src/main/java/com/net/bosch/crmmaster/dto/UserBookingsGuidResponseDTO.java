package com.net.bosch.crmmaster.dto;

public class UserBookingsGuidResponseDTO {

	private UserBookingsResponseDTO fireBaseObj;
	private String guid;

	public UserBookingsGuidResponseDTO() {
	}

	/**
	 * @param fireBaseObj
	 * @param guid
	 */
	public UserBookingsGuidResponseDTO(UserBookingsResponseDTO fireBaseObj, String guid) {
		super();
		this.fireBaseObj = fireBaseObj;
		this.guid = guid;
	}

	/**
	 * @return the fireBaseObj
	 */
	public UserBookingsResponseDTO getFireBaseObj() {
		return fireBaseObj;
	}

	/**
	 * @param fireBaseObj the fireBaseObj to set
	 */
	public void setFireBaseObj(UserBookingsResponseDTO fireBaseObj) {
		this.fireBaseObj = fireBaseObj;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

}
