package com.net.bosch.crmmaster.dto;

import com.net.bosch.dto.base.ResponseDTO;



public class ServiceEstimateDTO extends ResponseDTO{	
	
	private static final long serialVersionUID = 8375427463528782489L;

	private String item;
	
	private String totalEstimate;
	
	private String estimateDate;

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getTotalEstimate() {
		return totalEstimate;
	}

	public void setTotalEstimate(String totalEstimate) {
		this.totalEstimate = totalEstimate;
	}

	public String getEstimateDate() {
		return estimateDate;
	}

	public void setEstimateDate(String estimateDate) {
		this.estimateDate = estimateDate;
	}

	
}
