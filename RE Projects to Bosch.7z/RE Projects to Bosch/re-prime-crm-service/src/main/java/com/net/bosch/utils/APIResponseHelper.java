package com.net.bosch.utils;

import com.net.bosch.constants.REResponse;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
public class APIResponseHelper {

	private APIResponseHelper() {
	}

	/**
	 * This Base method will return success JSON response.
	 * 
	 * @param object
	 * @return
	 */
	public static REBaseResponse getSuccessResponse(final Object object) {
		REBaseResponse response = new REBaseResponse();
		response.setError(Boolean.FALSE);
		response.setCode(REResponse.SUCCESS.getCode());
		response.setData((object instanceof REResponse) ? ((REResponse) object).getMessage() : object);
		return response;
	}

	/**
	 * This Base method will only return success
	 * 
	 * @return
	 */
	public static REBaseResponse getSuccessResponse() {
		return getSuccessResponse(null);
	}

	/**
	 * This Base method will Give Generic or Unknown error message, if any unhandle
	 * exception occurs.
	 * 
	 * @return
	 */
	public static REBaseResponse getErrorResponse() {
		return getErrorResponse(REResponse.GENERIC_OR_UNKNOWN_ERROR);
	}

	public static REBaseResponse getErrorResponse(REResponse reResponse, String errorMessage) {
		REBaseResponse response = new REBaseResponse();
		response.setError(Boolean.TRUE);
		response.setCode(reResponse.getCode());
		response.setErrorMessage(errorMessage);
		return response;
	}

	/**
	 * This base method will return specific error.
	 * 
	 * @param reResponse
	 * @return
	 */
	public static REBaseResponse getErrorResponse(REResponse reResponse) {
		REBaseResponse response = new REBaseResponse();
		response.setError(Boolean.TRUE);
		response.setCode(reResponse.getCode());
		response.setErrorMessage(reResponse.getMessage());
		return response;
	}
	
	/**
	 * This base method will return specific error.
	 * 
	 * @param reResponse
	 * @return
	 */
	public static REBaseResponse getErrorResponse(REResponse reResponse, Object object) {
		REBaseResponse response = new REBaseResponse();
		response.setError(Boolean.TRUE);
		response.setCode(reResponse.getCode());
		response.setErrorMessage(reResponse.getMessage());
		response.setData((object instanceof REResponse) ? ((REResponse) object).getMessage() : object);
		return response;
	}

}
