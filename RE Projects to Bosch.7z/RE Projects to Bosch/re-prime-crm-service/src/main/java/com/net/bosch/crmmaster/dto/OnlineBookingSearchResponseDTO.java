package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.net.bosch.constants.BookingStatus;

/**
 * @author pushkarkhosla
 *
 */
public class OnlineBookingSearchResponseDTO {

	private DealerDetails dealerObj;
	private String customerID;
	private String appId;
	private VariantDetails variantDetails;
	private BookingStatus bookingStatus;

	private String dynamicsMessage;
	private List<Object> accessory = null;
	private String doYouOwnA4WheelerDynamics;
	private String doYouOwnA4WheelerExcellon;
	private String haveYouBeenOnAnyRidesDynamics;
	private String haveYouBeenOnAnyRidesExcellon;
	private String interestedInExchangeDynamics;
	private String interestedInExchangeExcellon;
	private String financeRequiredDynamics;
	private String financeRequiredExcellon;
	private String purposeOfUseDynamics;
	private String purposeOfUseExcellon;
	private String professionDynamics;
	private String professionExcellon;
	private String ownershipStatusDynamics;
	private String ownershipStatusExcellon;
	private String salutationDynamics;
	private String salutationExcellon;
	private String bookingAmt;
	private String paymentStatusReason;
	private String paymentStatus;
	private String paymentStatusCode;
	private String transactionID;
	private String paymentRefNo;
	private Locality locality;
	private String twoWheelerExchangedModel;
	private String websiteBookingDateTime;
	private String doYouOwnA4Wheeler;
	private String haveYouBeenOnAnyRides;
	private String interestedInExchange;
	private String preferredFinancier;
	private String financeRequired;
	private String area;
	private String city;
	private String district;
	private String state;
	private String country;
	private String purposeOfUse;
	private String profession;
	private String ownershipStatus;
	private String modelCode;
	private String storeCode;
	private String zipCode;
	private String addressLine2;
	private String addressLine1;
	private String dateOfBirth;
	private String email;
	private String alternateMobileNo;
	private String mobile;
	private String fatherName;
	private String lastName;
	private String firstName;
	private String salutation;

	private Double insuranceAmount;
	private Double accessoriesAmount;
	private Double rsaAmount;
	private Double onRoadPrice;

	private List<ExcellonMyoAccessoriesDataRequestDTO> excellonRideSurePackageData; // Excellon Ride Sure Package Data
	private OnlinePaymentDetailsResponseDTO paymentDetails;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OnlineBookingSearchResponseDTO [dealerObj=");
		builder.append(dealerObj);
		builder.append(", customerID=");
		builder.append(customerID);
		builder.append(", appId=");
		builder.append(appId);
		builder.append(", variantDetails=");
		builder.append(variantDetails);
		builder.append(", bookingStatus=");
		builder.append(bookingStatus);
		builder.append(", dynamicsMessage=");
		builder.append(dynamicsMessage);
		builder.append(", accessory=");
		builder.append(accessory);
		builder.append(", doYouOwnA4WheelerDynamics=");
		builder.append(doYouOwnA4WheelerDynamics);
		builder.append(", doYouOwnA4WheelerExcellon=");
		builder.append(doYouOwnA4WheelerExcellon);
		builder.append(", haveYouBeenOnAnyRidesDynamics=");
		builder.append(haveYouBeenOnAnyRidesDynamics);
		builder.append(", haveYouBeenOnAnyRidesExcellon=");
		builder.append(haveYouBeenOnAnyRidesExcellon);
		builder.append(", interestedInExchangeDynamics=");
		builder.append(interestedInExchangeDynamics);
		builder.append(", interestedInExchangeExcellon=");
		builder.append(interestedInExchangeExcellon);
		builder.append(", financeRequiredDynamics=");
		builder.append(financeRequiredDynamics);
		builder.append(", financeRequiredExcellon=");
		builder.append(financeRequiredExcellon);
		builder.append(", purposeOfUseDynamics=");
		builder.append(purposeOfUseDynamics);
		builder.append(", purposeOfUseExcellon=");
		builder.append(purposeOfUseExcellon);
		builder.append(", professionDynamics=");
		builder.append(professionDynamics);
		builder.append(", professionExcellon=");
		builder.append(professionExcellon);
		builder.append(", ownershipStatusDynamics=");
		builder.append(ownershipStatusDynamics);
		builder.append(", ownershipStatusExcellon=");
		builder.append(ownershipStatusExcellon);
		builder.append(", salutationDynamics=");
		builder.append(salutationDynamics);
		builder.append(", salutationExcellon=");
		builder.append(salutationExcellon);
		builder.append(", bookingAmt=");
		builder.append(bookingAmt);
		builder.append(", paymentStatusReason=");
		builder.append(paymentStatusReason);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", paymentStatusCode=");
		builder.append(paymentStatusCode);
		builder.append(", transactionID=");
		builder.append(transactionID);
		builder.append(", paymentRefNo=");
		builder.append(paymentRefNo);
		builder.append(", locality=");
		builder.append(locality);
		builder.append(", twoWheelerExchangedModel=");
		builder.append(twoWheelerExchangedModel);
		builder.append(", websiteBookingDateTime=");
		builder.append(websiteBookingDateTime);
		builder.append(", doYouOwnA4Wheeler=");
		builder.append(doYouOwnA4Wheeler);
		builder.append(", haveYouBeenOnAnyRides=");
		builder.append(haveYouBeenOnAnyRides);
		builder.append(", interestedInExchange=");
		builder.append(interestedInExchange);
		builder.append(", preferredFinancier=");
		builder.append(preferredFinancier);
		builder.append(", financeRequired=");
		builder.append(financeRequired);
		builder.append(", area=");
		builder.append(area);
		builder.append(", city=");
		builder.append(city);
		builder.append(", district=");
		builder.append(district);
		builder.append(", state=");
		builder.append(state);
		builder.append(", country=");
		builder.append(country);
		builder.append(", purposeOfUse=");
		builder.append(purposeOfUse);
		builder.append(", profession=");
		builder.append(profession);
		builder.append(", ownershipStatus=");
		builder.append(ownershipStatus);
		builder.append(", modelCode=");
		builder.append(modelCode);
		builder.append(", storeCode=");
		builder.append(storeCode);
		builder.append(", zipCode=");
		builder.append(zipCode);
		builder.append(", addressLine2=");
		builder.append(addressLine2);
		builder.append(", addressLine1=");
		builder.append(addressLine1);
		builder.append(", dateOfBirth=");
		builder.append(dateOfBirth);
		builder.append(", email=");
		builder.append(email);
		builder.append(", alternateMobileNo=");
		builder.append(alternateMobileNo);
		builder.append(", mobile=");
		builder.append(mobile);
		builder.append(", fatherName=");
		builder.append(fatherName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", salutation=");
		builder.append(salutation);
		builder.append(", insuranceAmount=");
		builder.append(insuranceAmount);
		builder.append(", accessoriesAmount=");
		builder.append(accessoriesAmount);
		builder.append(", rsaAmount=");
		builder.append(rsaAmount);
		builder.append(", onRoadPrice=");
		builder.append(onRoadPrice);
		builder.append(", excellonRideSurePackageData=");
		builder.append(excellonRideSurePackageData);
		builder.append(", paymentDetails=");
		builder.append(paymentDetails);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the excellonRideSurePackageData
	 */
	public List<ExcellonMyoAccessoriesDataRequestDTO> getExcellonRideSurePackageData() {
		return excellonRideSurePackageData;
	}

	/**
	 * @param excellonRideSurePackageData the excellonRideSurePackageData to set
	 */
	public void setExcellonRideSurePackageData(List<ExcellonMyoAccessoriesDataRequestDTO> excellonRideSurePackageData) {
		this.excellonRideSurePackageData = excellonRideSurePackageData;
	}

	/**
	 * @return the bookingStatus
	 */
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the paymentDetails
	 */
	public OnlinePaymentDetailsResponseDTO getPaymentDetails() {
		return paymentDetails;
	}

	/**
	 * @param paymentDetails the paymentDetails to set
	 */
	public void setPaymentDetails(OnlinePaymentDetailsResponseDTO paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	/**
	 * @return the dealerObj
	 */
	public DealerDetails getDealerObj() {
		return dealerObj;
	}

	/**
	 * @param dealerObj the dealerObj to set
	 */
	public void setDealerObj(DealerDetails dealerObj) {
		this.dealerObj = dealerObj;
	}

	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}

	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the variantDetails
	 */
	public VariantDetails getVariantDetails() {
		return variantDetails;
	}

	/**
	 * @param variantDetails the variantDetails to set
	 */
	public void setVariantDetails(VariantDetails variantDetails) {
		this.variantDetails = variantDetails;
	}

	/**
	 * @return the dynamicsMessage
	 */
	public String getDynamicsMessage() {
		return dynamicsMessage;
	}

	/**
	 * @param dynamicsMessage the dynamicsMessage to set
	 */
	public void setDynamicsMessage(String dynamicsMessage) {
		this.dynamicsMessage = dynamicsMessage;
	}

	/**
	 * @return the accessory
	 */
	public List<Object> getAccessory() {
		return accessory;
	}

	/**
	 * @param accessory the accessory to set
	 */
	public void setAccessory(List<Object> accessory) {
		this.accessory = accessory;
	}

	/**
	 * @return the doYouOwnA4WheelerDynamics
	 */
	public String getDoYouOwnA4WheelerDynamics() {
		return doYouOwnA4WheelerDynamics;
	}

	/**
	 * @param doYouOwnA4WheelerDynamics the doYouOwnA4WheelerDynamics to set
	 */
	public void setDoYouOwnA4WheelerDynamics(String doYouOwnA4WheelerDynamics) {
		this.doYouOwnA4WheelerDynamics = doYouOwnA4WheelerDynamics;
	}

	/**
	 * @return the doYouOwnA4WheelerExcellon
	 */
	public String getDoYouOwnA4WheelerExcellon() {
		return doYouOwnA4WheelerExcellon;
	}

	/**
	 * @param doYouOwnA4WheelerExcellon the doYouOwnA4WheelerExcellon to set
	 */
	public void setDoYouOwnA4WheelerExcellon(String doYouOwnA4WheelerExcellon) {
		this.doYouOwnA4WheelerExcellon = doYouOwnA4WheelerExcellon;
	}

	/**
	 * @return the haveYouBeenOnAnyRidesDynamics
	 */
	public String getHaveYouBeenOnAnyRidesDynamics() {
		return haveYouBeenOnAnyRidesDynamics;
	}

	/**
	 * @param haveYouBeenOnAnyRidesDynamics the haveYouBeenOnAnyRidesDynamics to set
	 */
	public void setHaveYouBeenOnAnyRidesDynamics(String haveYouBeenOnAnyRidesDynamics) {
		this.haveYouBeenOnAnyRidesDynamics = haveYouBeenOnAnyRidesDynamics;
	}

	/**
	 * @return the haveYouBeenOnAnyRidesExcellon
	 */
	public String getHaveYouBeenOnAnyRidesExcellon() {
		return haveYouBeenOnAnyRidesExcellon;
	}

	/**
	 * @param haveYouBeenOnAnyRidesExcellon the haveYouBeenOnAnyRidesExcellon to set
	 */
	public void setHaveYouBeenOnAnyRidesExcellon(String haveYouBeenOnAnyRidesExcellon) {
		this.haveYouBeenOnAnyRidesExcellon = haveYouBeenOnAnyRidesExcellon;
	}

	/**
	 * @return the interestedInExchangeDynamics
	 */
	public String getInterestedInExchangeDynamics() {
		return interestedInExchangeDynamics;
	}

	/**
	 * @param interestedInExchangeDynamics the interestedInExchangeDynamics to set
	 */
	public void setInterestedInExchangeDynamics(String interestedInExchangeDynamics) {
		this.interestedInExchangeDynamics = interestedInExchangeDynamics;
	}

	/**
	 * @return the interestedInExchangeExcellon
	 */
	public String getInterestedInExchangeExcellon() {
		return interestedInExchangeExcellon;
	}

	/**
	 * @param interestedInExchangeExcellon the interestedInExchangeExcellon to set
	 */
	public void setInterestedInExchangeExcellon(String interestedInExchangeExcellon) {
		this.interestedInExchangeExcellon = interestedInExchangeExcellon;
	}

	/**
	 * @return the financeRequiredDynamics
	 */
	public String getFinanceRequiredDynamics() {
		return financeRequiredDynamics;
	}

	/**
	 * @param financeRequiredDynamics the financeRequiredDynamics to set
	 */
	public void setFinanceRequiredDynamics(String financeRequiredDynamics) {
		this.financeRequiredDynamics = financeRequiredDynamics;
	}

	/**
	 * @return the financeRequiredExcellon
	 */
	public String getFinanceRequiredExcellon() {
		return financeRequiredExcellon;
	}

	/**
	 * @param financeRequiredExcellon the financeRequiredExcellon to set
	 */
	public void setFinanceRequiredExcellon(String financeRequiredExcellon) {
		this.financeRequiredExcellon = financeRequiredExcellon;
	}

	/**
	 * @return the purposeOfUseDynamics
	 */
	public String getPurposeOfUseDynamics() {
		return purposeOfUseDynamics;
	}

	/**
	 * @param purposeOfUseDynamics the purposeOfUseDynamics to set
	 */
	public void setPurposeOfUseDynamics(String purposeOfUseDynamics) {
		this.purposeOfUseDynamics = purposeOfUseDynamics;
	}

	/**
	 * @return the purposeOfUseExcellon
	 */
	public String getPurposeOfUseExcellon() {
		return purposeOfUseExcellon;
	}

	/**
	 * @param purposeOfUseExcellon the purposeOfUseExcellon to set
	 */
	public void setPurposeOfUseExcellon(String purposeOfUseExcellon) {
		this.purposeOfUseExcellon = purposeOfUseExcellon;
	}

	/**
	 * @return the professionDynamics
	 */
	public String getProfessionDynamics() {
		return professionDynamics;
	}

	/**
	 * @param professionDynamics the professionDynamics to set
	 */
	public void setProfessionDynamics(String professionDynamics) {
		this.professionDynamics = professionDynamics;
	}

	/**
	 * @return the professionExcellon
	 */
	public String getProfessionExcellon() {
		return professionExcellon;
	}

	/**
	 * @param professionExcellon the professionExcellon to set
	 */
	public void setProfessionExcellon(String professionExcellon) {
		this.professionExcellon = professionExcellon;
	}

	/**
	 * @return the ownershipStatusDynamics
	 */
	public String getOwnershipStatusDynamics() {
		return ownershipStatusDynamics;
	}

	/**
	 * @param ownershipStatusDynamics the ownershipStatusDynamics to set
	 */
	public void setOwnershipStatusDynamics(String ownershipStatusDynamics) {
		this.ownershipStatusDynamics = ownershipStatusDynamics;
	}

	/**
	 * @return the ownershipStatusExcellon
	 */
	public String getOwnershipStatusExcellon() {
		return ownershipStatusExcellon;
	}

	/**
	 * @param ownershipStatusExcellon the ownershipStatusExcellon to set
	 */
	public void setOwnershipStatusExcellon(String ownershipStatusExcellon) {
		this.ownershipStatusExcellon = ownershipStatusExcellon;
	}

	/**
	 * @return the salutationDynamics
	 */
	public String getSalutationDynamics() {
		return salutationDynamics;
	}

	/**
	 * @param salutationDynamics the salutationDynamics to set
	 */
	public void setSalutationDynamics(String salutationDynamics) {
		this.salutationDynamics = salutationDynamics;
	}

	/**
	 * @return the salutationExcellon
	 */
	public String getSalutationExcellon() {
		return salutationExcellon;
	}

	/**
	 * @param salutationExcellon the salutationExcellon to set
	 */
	public void setSalutationExcellon(String salutationExcellon) {
		this.salutationExcellon = salutationExcellon;
	}

	/**
	 * @return the bookingAmt
	 */
	public String getBookingAmt() {
		return bookingAmt;
	}

	/**
	 * @param bookingAmt the bookingAmt to set
	 */
	public void setBookingAmt(String bookingAmt) {
		this.bookingAmt = bookingAmt;
	}

	/**
	 * @return the paymentStatusReason
	 */
	public String getPaymentStatusReason() {
		return paymentStatusReason;
	}

	/**
	 * @param paymentStatusReason the paymentStatusReason to set
	 */
	public void setPaymentStatusReason(String paymentStatusReason) {
		this.paymentStatusReason = paymentStatusReason;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the paymentStatusCode
	 */
	public String getPaymentStatusCode() {
		return paymentStatusCode;
	}

	/**
	 * @param paymentStatusCode the paymentStatusCode to set
	 */
	public void setPaymentStatusCode(String paymentStatusCode) {
		this.paymentStatusCode = paymentStatusCode;
	}

	/**
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}

	/**
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	/**
	 * @return the paymentRefNo
	 */
	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	/**
	 * @param paymentRefNo the paymentRefNo to set
	 */
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	/**
	 * @return the locality
	 */
	public Locality getLocality() {
		return locality;
	}

	/**
	 * @param locality the locality to set
	 */
	public void setLocality(Locality locality) {
		this.locality = locality;
	}

	/**
	 * @return the twoWheelerExchangedModel
	 */
	public String getTwoWheelerExchangedModel() {
		return twoWheelerExchangedModel;
	}

	/**
	 * @param twoWheelerExchangedModel the twoWheelerExchangedModel to set
	 */
	public void setTwoWheelerExchangedModel(String twoWheelerExchangedModel) {
		this.twoWheelerExchangedModel = twoWheelerExchangedModel;
	}

	/**
	 * @return the websiteBookingDateTime
	 */
	public String getWebsiteBookingDateTime() {
		return websiteBookingDateTime;
	}

	/**
	 * @param websiteBookingDateTime the websiteBookingDateTime to set
	 */
	public void setWebsiteBookingDateTime(String websiteBookingDateTime) {
		this.websiteBookingDateTime = websiteBookingDateTime;
	}

	/**
	 * @return the doYouOwnA4Wheeler
	 */
	public String getDoYouOwnA4Wheeler() {
		return doYouOwnA4Wheeler;
	}

	/**
	 * @param doYouOwnA4Wheeler the doYouOwnA4Wheeler to set
	 */
	public void setDoYouOwnA4Wheeler(String doYouOwnA4Wheeler) {
		this.doYouOwnA4Wheeler = doYouOwnA4Wheeler;
	}

	/**
	 * @return the haveYouBeenOnAnyRides
	 */
	public String getHaveYouBeenOnAnyRides() {
		return haveYouBeenOnAnyRides;
	}

	/**
	 * @param haveYouBeenOnAnyRides the haveYouBeenOnAnyRides to set
	 */
	public void setHaveYouBeenOnAnyRides(String haveYouBeenOnAnyRides) {
		this.haveYouBeenOnAnyRides = haveYouBeenOnAnyRides;
	}

	/**
	 * @return the interestedInExchange
	 */
	public String getInterestedInExchange() {
		return interestedInExchange;
	}

	/**
	 * @param interestedInExchange the interestedInExchange to set
	 */
	public void setInterestedInExchange(String interestedInExchange) {
		this.interestedInExchange = interestedInExchange;
	}

	/**
	 * @return the preferredFinancier
	 */
	public String getPreferredFinancier() {
		return preferredFinancier;
	}

	/**
	 * @param preferredFinancier the preferredFinancier to set
	 */
	public void setPreferredFinancier(String preferredFinancier) {
		this.preferredFinancier = preferredFinancier;
	}

	/**
	 * @return the financeRequired
	 */
	public String getFinanceRequired() {
		return financeRequired;
	}

	/**
	 * @param financeRequired the financeRequired to set
	 */
	public void setFinanceRequired(String financeRequired) {
		this.financeRequired = financeRequired;
	}

	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the purposeOfUse
	 */
	public String getPurposeOfUse() {
		return purposeOfUse;
	}

	/**
	 * @param purposeOfUse the purposeOfUse to set
	 */
	public void setPurposeOfUse(String purposeOfUse) {
		this.purposeOfUse = purposeOfUse;
	}

	/**
	 * @return the profession
	 */
	public String getProfession() {
		return profession;
	}

	/**
	 * @param profession the profession to set
	 */
	public void setProfession(String profession) {
		this.profession = profession;
	}

	/**
	 * @return the ownershipStatus
	 */
	public String getOwnershipStatus() {
		return ownershipStatus;
	}

	/**
	 * @param ownershipStatus the ownershipStatus to set
	 */
	public void setOwnershipStatus(String ownershipStatus) {
		this.ownershipStatus = ownershipStatus;
	}

	/**
	 * @return the modelCode
	 */
	public String getModelCode() {
		return modelCode;
	}

	/**
	 * @param modelCode the modelCode to set
	 */
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	/**
	 * @return the storeCode
	 */
	public String getStoreCode() {
		return storeCode;
	}

	/**
	 * @param storeCode the storeCode to set
	 */
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the alternateMobileNo
	 */
	public String getAlternateMobileNo() {
		return alternateMobileNo;
	}

	/**
	 * @param alternateMobileNo the alternateMobileNo to set
	 */
	public void setAlternateMobileNo(String alternateMobileNo) {
		this.alternateMobileNo = alternateMobileNo;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the fatherName
	 */
	public String getFatherName() {
		return fatherName;
	}

	/**
	 * @param fatherName the fatherName to set
	 */
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * @param salutation the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	/**
	 * @return the insuranceAmount
	 */
	public Double getInsuranceAmount() {
		return insuranceAmount;
	}

	/**
	 * @param insuranceAmount the insuranceAmount to set
	 */
	public void setInsuranceAmount(Double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}

	/**
	 * @return the accessoriesAmount
	 */
	public Double getAccessoriesAmount() {
		return accessoriesAmount;
	}

	/**
	 * @param accessoriesAmount the accessoriesAmount to set
	 */
	public void setAccessoriesAmount(Double accessoriesAmount) {
		this.accessoriesAmount = accessoriesAmount;
	}

	/**
	 * @return the rsaAmount
	 */
	public Double getRsaAmount() {
		return rsaAmount;
	}

	/**
	 * @param rsaAmount the rsaAmount to set
	 */
	public void setRsaAmount(Double rsaAmount) {
		this.rsaAmount = rsaAmount;
	}

	/**
	 * @return the onRoadPrice
	 */
	public Double getOnRoadPrice() {
		return onRoadPrice;
	}

	/**
	 * @param onRoadPrice the onRoadPrice to set
	 */
	public void setOnRoadPrice(Double onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}

}
