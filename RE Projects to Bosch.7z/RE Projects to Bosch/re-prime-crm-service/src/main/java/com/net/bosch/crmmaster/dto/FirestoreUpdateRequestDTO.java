package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class FirestoreUpdateRequestDTO {

	private String txnDate;
	private String guid;
	private String paymentStatus;
	private String caseId;
	private String caserefId;
	private String txnId;
	private String bookingAmount; // Transaction Amount
	private String bookingStatus;
	private String modelDetail;
	private String totalAmount;
	private OnlinePaymentRequestDTO dto;
	

	/**
	 * @param guid
	 * @param paymentStatus
	 * @param caseId
	 * @param caserefId
	 * @param txnId
	 * @param bookingAmount
	 * @param bookingStatus
	 * @param modelDetail
	 * @param totalAmount
	 */
	public FirestoreUpdateRequestDTO(String guid, String caseId, String caserefId, String bookingStatus,
			String paymentStatus, String txnId, String bookingAmount, String modelDetail, String totalAmount) {
		super();
		this.guid = guid;
		this.caseId = caseId;
		this.caserefId = caserefId;
		this.bookingStatus = bookingStatus;
		this.paymentStatus = paymentStatus;
		this.txnId = txnId;
		this.txnDate = null;
		this.bookingAmount = bookingAmount;
		this.modelDetail = modelDetail;
		this.totalAmount = totalAmount;
		
	}

	/**
	 * @return the dto
	 */
	public OnlinePaymentRequestDTO getDto() {
		return dto;
	}

	/**
	 * @param dto the dto to set
	 */
	public void setDto(OnlinePaymentRequestDTO dto) {
		this.dto = dto;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FirestoreUpdateRequestDTO [txnDate=");
		builder.append(txnDate);
		builder.append(", guid=");
		builder.append(guid);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", caseId=");
		builder.append(caseId);
		builder.append(", caserefId=");
		builder.append(caserefId);
		builder.append(", txnId=");
		builder.append(txnId);
		builder.append(", bookingAmount=");
		builder.append(bookingAmount);
		builder.append(", bookingStatus=");
		builder.append(bookingStatus);
		builder.append(", modelDetail=");
		builder.append(modelDetail);
		builder.append(", totalAmount=");
		builder.append(totalAmount);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the txnDate
	 */
	public String getTxnDate() {
		return txnDate;
	}

	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the caserefId
	 */
	public String getCaserefId() {
		return caserefId;
	}

	/**
	 * @param caserefId the caserefId to set
	 */
	public void setCaserefId(String caserefId) {
		this.caserefId = caserefId;
	}

	/**
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * @param txnId the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	/**
	 * @return the bookingAmount
	 */
	public String getBookingAmount() {
		return bookingAmount;
	}

	/**
	 * @param bookingAmount the bookingAmount to set
	 */
	public void setBookingAmount(String bookingAmount) {
		this.bookingAmount = bookingAmount;
	}

	/**
	 * @return the bookingStatus
	 */
	public String getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the modelDetail
	 */
	public String getModelDetail() {
		return modelDetail;
	}

	/**
	 * @param modelDetail the modelDetail to set
	 */
	public void setModelDetail(String modelDetail) {
		this.modelDetail = modelDetail;
	}

	/**
	 * @return the totalAmount
	 */
	public String getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

}