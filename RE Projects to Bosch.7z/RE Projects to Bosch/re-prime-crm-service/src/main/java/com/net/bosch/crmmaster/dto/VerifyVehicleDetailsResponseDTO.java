package com.net.bosch.crmmaster.dto;

import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;

public class VerifyVehicleDetailsResponseDTO extends VehicleDetailsVO {

	private boolean isVehiclePurchaseDateLessThan30Days;

	/**
	 * @return the isVehiclePurchaseDateLessThan30Days
	 */
	public boolean isVehiclePurchaseDateLessThan30Days() {
		return isVehiclePurchaseDateLessThan30Days;
	}

	/**
	 * @param isVehiclePurchaseDateLessThan30Days the
	 *                                            isVehiclePurchaseDateLessThan30Days
	 *                                            to set
	 */
	public void setVehiclePurchaseDateLessThan30Days(boolean isVehiclePurchaseDateLessThan30Days) {
		this.isVehiclePurchaseDateLessThan30Days = isVehiclePurchaseDateLessThan30Days;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VerifyVehicleDetailsResponseDTO [isVehiclePurchaseDateLessThan30Days=");
		builder.append(isVehiclePurchaseDateLessThan30Days);
		builder.append("]");
		return builder.toString();
	}

}
