package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
public class DeviceDetailsDTO {	

	private String guid;	
	
	private String phone_number;
	
	private String device_token;	
	
	private String device_type;
	
	private String device_key;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getDevice_token() {
		return device_token;
	}

	public void setDevice_token(String device_token) {
		this.device_token = device_token;
	}

	public String getDevice_type() {
		return device_type;
	}

	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}

	public String getDevice_key() {
		return device_key;
	}

	public void setDevice_key(String device_key) {
		this.device_key = device_key;
	}
			
}
