package com.net.bosch.crmmaster.dto.resultset;

import java.util.List;

/**
 * @author pushkarkhosla
 *
 */
public class VehicleDetailsListVO {

	private List<VehicleDetailsVO> vehicleInfo;

	public List<VehicleDetailsVO> getVehicleInfo() {
		return vehicleInfo;
	}

	public void setVehicleInfo(List<VehicleDetailsVO> vehicleInfo) {
		this.vehicleInfo = vehicleInfo;
	}

	@Override
	public String toString() {
		return "VehicleDetailsListVO [vehicleInfo=" + vehicleInfo + "]";
	}

}
