package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class UpdateBalancePaymentRequestDTO {

	@NotNull
	@NotBlank
	private String bookingCaseId;

	@NotNull
	@NotBlank
	private String paymentCaseId;

	private String dealerSource;

	private String paymentStatus;
	private String billDeskTransactionId;

	private String appId;

	/**
	 * Bill-Desk-Payment Response Params
	 */
	private PaymentRawResponse paymentRawResponse;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateBalancePaymentRequestDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", dealerSource=");
		builder.append(dealerSource);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", billDeskTransactionId=");
		builder.append(billDeskTransactionId);
		builder.append(", appId=");
		builder.append(appId);
		builder.append(", paymentRawResponse=");
		builder.append(paymentRawResponse);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the paymentRawResponse
	 */
	public PaymentRawResponse getPaymentRawResponse() {
		return paymentRawResponse;
	}

	/**
	 * @param paymentRawResponse the paymentRawResponse to set
	 */
	public void setPaymentRawResponse(PaymentRawResponse paymentRawResponse) {
		this.paymentRawResponse = paymentRawResponse;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the billDeskTransactionId
	 */
	public String getBillDeskTransactionId() {
		return billDeskTransactionId;
	}

	/**
	 * @param billDeskTransactionId the billDeskTransactionId to set
	 */
	public void setBillDeskTransactionId(String billDeskTransactionId) {
		this.billDeskTransactionId = billDeskTransactionId;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}
}
