package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceInProgressDTO implements Serializable{

	private static final long serialVersionUID = -3995195687556955856L;

	@JsonProperty("JobcardStatus")
	private String jobcardStatus;

	@JsonProperty("DealerInfo")
	private String dealerInfo;

	@JsonProperty("ModelName")
	private String modelName;

	@JsonProperty("Paybleamount")
	private String paybleamount;

	@JsonProperty("PickupAddres")
	private String pickupAddres;

	@JsonProperty("CustomerRemarks")
	private String customerRemarks;
	
	private String appointmentNumber;
	
	private String appointmentStatus;
	
	private String isServiceInProgress;
	
	private String appointmentDate;
	
	private String modelCode;
	
	private String registrationNumber;
	
	private Integer serviceBookingType = 1;
	
	private String jobCardNumber;
	
	private String appointmentCategory;
	
	private String slotId;
	
	private String TechnicianName;
	
	private String TechnicianMobile;
	
	private String confirmVisitFlag;

	public String getJobcardStatus() {
		return jobcardStatus;
	}

	public void setJobcardStatus(String jobcardStatus) {
		this.jobcardStatus = jobcardStatus;
	}

	public String getDealerInfo() {
		return dealerInfo;
	}

	public void setDealerInfo(String dealerInfo) {
		this.dealerInfo = dealerInfo;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getPaybleamount() {
		return paybleamount;
	}

	public void setPaybleamount(String paybleamount) {
		this.paybleamount = paybleamount;
	}

	public String getPickupAddres() {
		return pickupAddres;
	}

	public void setPickupAddres(String pickupAddres) {
		this.pickupAddres = pickupAddres;
	}

	public String getCustomerRemarks() {
		return customerRemarks;
	}

	public void setCustomerRemarks(String customerRemarks) {
		this.customerRemarks = customerRemarks;
	}

	public String getAppointmentNumber() {
		return appointmentNumber;
	}

	public void setAppointmentNumber(String appointmentNumber) {
		this.appointmentNumber = appointmentNumber;
	}

	public String getIsServiceInProgress() {
		return isServiceInProgress;
	}

	public void setIsServiceInProgress(String isServiceInProgress) {
		this.isServiceInProgress = isServiceInProgress;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getModelCode() {
		return modelCode;
	}

	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public Integer getServiceBookingType() {
		return serviceBookingType;
	}

	public void setServiceBookingType(Integer serviceBookingType) {
		this.serviceBookingType = serviceBookingType;
	}

	public String getJobCardNumber() {
		return jobCardNumber;
	}

	public void setJobCardNumber(String jobCardNumber) {
		this.jobCardNumber = jobCardNumber;
	}

	public String getAppointmentCategory() {
		return appointmentCategory;
	}

	public void setAppointmentCategory(String appointmentCategory) {
		this.appointmentCategory = appointmentCategory;
	}

	public String getSlotId() {
		return slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public String getTechnicianName() {
		return TechnicianName;
	}

	public void setTechnicianName(String technicianName) {
		TechnicianName = technicianName;
	}

	public String getTechnicianMobile() {
		return TechnicianMobile;
	}

	public void setTechnicianMobile(String technicianMobile) {
		TechnicianMobile = technicianMobile;
	}

	public String getConfirmVisitFlag() {
		return confirmVisitFlag;
	}

	public void setConfirmVisitFlag(String confirmVisitFlag) {
		this.confirmVisitFlag = confirmVisitFlag;
	}
}
