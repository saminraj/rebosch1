package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.net.bosch.crmmaster.vehicle.collection.UserVehicleDetails;

public class UserVehicleDetailsDTO {

	private String guid;

	private List<UserVehicleDetails> userVehicles;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the userVehicles
	 */
	public List<UserVehicleDetails> getUserVehicles() {
		return userVehicles;
	}

	/**
	 * @param userVehicles the userVehicles to set
	 */
	public void setUserVehicles(List<UserVehicleDetails> userVehicles) {
		this.userVehicles = userVehicles;
	}

	public UserVehicleDetailsDTO(String guid, List<UserVehicleDetails> userVehicles) {
		super();
		this.guid = guid;
		this.userVehicles = userVehicles;
	}

	public UserVehicleDetailsDTO() {
		super();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserVehicleDetailsDTO [guid=");
		builder.append(guid);
		builder.append(", userVehicles=");
		builder.append(userVehicles);
		builder.append("]");
		return builder.toString();
	}

}
