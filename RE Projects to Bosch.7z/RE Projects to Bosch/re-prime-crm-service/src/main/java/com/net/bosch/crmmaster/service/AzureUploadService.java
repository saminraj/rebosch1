package com.net.bosch.crmmaster.service;

import java.io.File;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Files;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.StandardBlobTier;
import com.net.bosch.crmmaster.dto.AddVehicleRequestDTO;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicleDetails;

@Service
public class AzureUploadService {

	private static final Logger logger = LoggerFactory.getLogger(AzureUploadService.class);

	@Value("${azure.storage.connection}")
	private String connectionString;

	@Autowired
	CloudStorageAccount storageAccount;

	@Value("${azure.container.name.addvehicle}")
	private String containerName;

	@Value("${azure.base.url}")
	private String azureUrl;

	public void uploadtoAzure(Map<String, MultipartFile> userDocs, String userGuid, UserVehicleDetails userVehicle,
			AddVehicleRequestDTO addVehicleRequestDTO) {

		logger.info("Inside uploadtoAzure to add user docuemnts to Azure");
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		try {
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);

			for (Map.Entry<String, MultipartFile> entry : userDocs.entrySet()) {
				logger.info("Uploading file to Azure");
				MultipartFile multipartFile = entry.getValue();
				byte[] bytes = multipartFile.getBytes();

				String fileExtension = Files.getFileExtension(multipartFile.getOriginalFilename());

				String url = userGuid + "/" + entry.getKey() + "_"
						+ addVehicleRequestDTO.getEngineNo().concat(".").concat(fileExtension);
				CloudBlockBlob blob = container.getBlockBlobReference(url);
				blob.uploadFromByteArray(bytes, 0, bytes.length);
				blob.uploadStandardBlobTier(StandardBlobTier.COOL);
				if (entry.getKey().equalsIgnoreCase("kycDoc")) {
					userVehicle.setKycFilePath(azureUrl.concat(containerName).concat(File.separator).concat(url));
					logger.info("KYC Doc URL {{}}", userVehicle.getKycFilePath());
				} else if (entry.getKey().equalsIgnoreCase("RCDoc")) {
					userVehicle.setOwnershipFilePath(azureUrl.concat(containerName).concat(File.separator).concat(url));
					logger.info("Ownership Doc URL {{}}", userVehicle.getOwnershipFilePath());
				}
			}
			logger.info("File Uploaded to Azure Successfully.");
		} catch (StorageException ex) {
			logger.error("Error returned from the service. Http code: {{}} and error code: {{}}",
					ex.getHttpStatusCode(), ex.getErrorCode());
		} catch (Exception ex) {
			logger.error(
					"Exception Occured While Uploading file to Azure. Excption Message {{}},Exception Details {{}}",
					ex.getMessage(), ex);
		}
	}

}
