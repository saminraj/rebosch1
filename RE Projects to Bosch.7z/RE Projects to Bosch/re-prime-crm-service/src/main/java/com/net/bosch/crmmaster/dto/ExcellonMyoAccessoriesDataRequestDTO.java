package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class ExcellonMyoAccessoriesDataRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5303776356224742609L;

	private long docId;
	private String configid;
	private String paymentRefNo;
	private String accessoriesCode;
	private String accessoriesName;
	private float accessoriesQty;
	private float accessoreisPrice;

	/**
	 * @return the docId
	 */
	public long getDocId() {
		return docId;
	}

	/**
	 * @param docId the docId to set
	 */
	public void setDocId(long docId) {
		this.docId = docId;
	}

	public String getConfigid() {
		return configid;
	}

	public void setConfigid(String configid) {
		this.configid = configid;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getAccessoriesCode() {
		return accessoriesCode;
	}

	public void setAccessoriesCode(String accessoriesCode) {
		this.accessoriesCode = accessoriesCode;
	}

	public String getAccessoriesName() {
		return accessoriesName;
	}

	public void setAccessoriesName(String accessoriesName) {
		this.accessoriesName = accessoriesName;
	}

	/**
	 * @return the accessoriesQty
	 */
	public float getAccessoriesQty() {
		return accessoriesQty;
	}

	/**
	 * @param accessoriesQty the accessoriesQty to set
	 */
	public void setAccessoriesQty(float accessoriesQty) {
		this.accessoriesQty = accessoriesQty;
	}

	/**
	 * @return the accessoreisPrice
	 */
	public float getAccessoreisPrice() {
		return accessoreisPrice;
	}

	/**
	 * @param accessoreisPrice the accessoreisPrice to set
	 */
	public void setAccessoreisPrice(float accessoreisPrice) {
		this.accessoreisPrice = accessoreisPrice;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcellonMyoAccessoriesDataRequestDTO [configid=");
		builder.append(configid);
		builder.append(", paymentRefNo=");
		builder.append(paymentRefNo);
		builder.append(", accessoriesCode=");
		builder.append(accessoriesCode);
		builder.append(", accessoriesName=");
		builder.append(accessoriesName);
		builder.append(", accessoriesQty=");
		builder.append(accessoriesQty);
		builder.append(", accessoreisPrice=");
		builder.append(accessoreisPrice);
		builder.append("]");
		return builder.toString();
	}
}
