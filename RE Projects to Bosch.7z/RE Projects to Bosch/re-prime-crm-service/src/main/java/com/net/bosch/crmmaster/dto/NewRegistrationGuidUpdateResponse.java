package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class NewRegistrationGuidUpdateResponse {

	private String guid;
	private String mobileNo;
	private String status;

	public NewRegistrationGuidUpdateResponse() {

	}

	/**
	 * @param guid
	 * @param mobileNo
	 * @param status
	 */
	public NewRegistrationGuidUpdateResponse(String guid, String mobileNo, String status) {
		super();
		this.guid = guid;
		this.mobileNo = mobileNo;
		this.status = status;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
