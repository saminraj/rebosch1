package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class VehicleRequestDTO implements Serializable {

	private static final long serialVersionUID = -3541122859222308326L;

	@JsonProperty("RegistrationNo")
	private String registrationNo;

	@JsonProperty("ChassisNo")
	private String chassisNo;

	@JsonProperty("EngineNo")
	private String engineNo;

	@JsonProperty("Mobileno")
	private String mobileNo;

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

}
