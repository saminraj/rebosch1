package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pushkarkhosla
 *
 */
public class DMSBookingDetailsDTO {

	@JsonProperty("BookingNo")
	private String bookingNo;

	/**
	 * @param bookingNo
	 */
	public DMSBookingDetailsDTO(String bookingNo) {
		super();
		this.bookingNo = bookingNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DMSBookingDetailsDTO [bookingNo=");
		builder.append(bookingNo);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingNo
	 */
	public String getBookingNo() {
		return bookingNo;
	}

	/**
	 * @param bookingNo the bookingNo to set
	 */
	public void setBookingNo(String bookingNo) {
		this.bookingNo = bookingNo;
	}
}
