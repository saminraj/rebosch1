package com.net.bosch.crmmaster.dto;

import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class RegistrationNumberRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 84121436864643211L;

	@NotNull
	@NotBlank
	private String engineNo;

	@NotNull
	@NotBlank
	private String previousRegistrationNumber;

	@NotNull
	@NotBlank
	private String updatedRegistrationNumber;

	@NotNull
	@NotBlank
	private String vehicleModelName;

	private String chassisNo;

	private boolean removeBike;

	/**
	 * @return the chassisNo
	 */
	public String getChassisNo() {
		return chassisNo;
	}

	/**
	 * @param chassisNo the chassisNo to set
	 */
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	/**
	 * @return the engineNo
	 */
	public String getEngineNo() {
		return engineNo;
	}

	/**
	 * @param engineNo the engineNo to set
	 */
	public void setEngineNo(String engineNo) {
		this.engineNo = trimToNull(engineNo);
	}

	/**
	 * @return the previousRegistrationNumber
	 */
	public String getPreviousRegistrationNumber() {
		return previousRegistrationNumber;
	}

	/**
	 * @param previousRegistrationNumber the previousRegistrationNumber to set
	 */
	public void setPreviousRegistrationNumber(String previousRegistrationNumber) {
		this.previousRegistrationNumber = trimToNull(previousRegistrationNumber);
	}

	/**
	 * @return the updatedRegistrationNumber
	 */
	public String getUpdatedRegistrationNumber() {
		return updatedRegistrationNumber;
	}

	/**
	 * @param updatedRegistrationNumber the updatedRegistrationNumber to set
	 */
	public void setUpdatedRegistrationNumber(String updatedRegistrationNumber) {
		this.updatedRegistrationNumber = trimToNull(updatedRegistrationNumber);
	}

	/**
	 * @return the removeBike
	 */
	public boolean isRemoveBike() {
		return removeBike;
	}

	/**
	 * @param removeBike the removeBike to set
	 */
	public void setRemoveBike(boolean removeBike) {
		this.removeBike = removeBike;
	}

	/**
	 * @return the vehicleModelName
	 */
	public String getVehicleModelName() {
		return vehicleModelName;
	}

	/**
	 * @param vehicleModelName the vehicleModelName to set
	 */
	public void setVehicleModelName(String vehicleModelName) {
		this.vehicleModelName = vehicleModelName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RegistrationNumberRequest [engineNo=");
		builder.append(engineNo);
		builder.append(", previousRegistrationNumber=");
		builder.append(previousRegistrationNumber);
		builder.append(", updatedRegistrationNumber=");
		builder.append(updatedRegistrationNumber);
		builder.append(", vehicleModelName=");
		builder.append(vehicleModelName);
		builder.append(", chassisNo=");
		builder.append(chassisNo);
		builder.append(", removeBike=");
		builder.append(removeBike);
		builder.append("]");
		return builder.toString();
	}

}
