package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.net.bosch.dto.base.RequestDTO;

/**
 * @author pushkarkhosla
 *
 */

public class ListRegistrationNumberRequestDTO extends RequestDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6836375255110179649L;

	private List<RegistrationNumberRequest> vehicleList;

	public List<RegistrationNumberRequest> getVehicleList() {
		return vehicleList;
	}

	public void setVehicleList(List<RegistrationNumberRequest> vehicleList) {
		this.vehicleList = vehicleList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ListRegistrationNumberRequestDTO [vehicleList=");
		builder.append(vehicleList);
		builder.append(", getLoggedInUserMobileNo()=");
		builder.append(getLoggedInUserMobileNo());
		builder.append(", getLoggedInUserName()=");
		builder.append(getLoggedInUserName());
		builder.append(", getLoggedInUserEmail()=");
		builder.append(getLoggedInUserEmail());
		builder.append(", getGuid()=");
		builder.append(getGuid());
		builder.append(", getAppId()=");
		builder.append(getAppId());
		builder.append("]");
		return builder.toString();
	}

}
