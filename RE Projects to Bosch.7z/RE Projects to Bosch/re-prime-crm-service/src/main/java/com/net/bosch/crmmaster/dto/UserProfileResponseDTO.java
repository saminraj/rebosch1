package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class UserProfileResponseDTO extends BaseResponseDTO {

	private UserProfileResponseParamsDTO data;

	/**
	 *
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserProfileResponseDTO [data=");
		builder.append(data);
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the data
	 */
	public UserProfileResponseParamsDTO getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(UserProfileResponseParamsDTO data) {
		this.data = data;
	}

}
