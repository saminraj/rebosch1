package com.net.bosch.crmmaster.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.net.bosch.constants.Constants;
import com.net.bosch.crmmaster.dto.DealerDTO;
import com.net.bosch.crmmaster.dto.UserBookingsResponseDTO;

@Service
public class FirebaseService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Environment env;

	@Autowired
	private MessageSource messageSource;

	ObjectMapper mapper = new ObjectMapper();

	public static String firebaseDBURL = "https://re-prime-dev.firebaseio.com/"; // value will change from propery file
	// at init method
	public static String dealersDB = "CRMCORE"; // value will change from propery file at init method

	Firestore db;

	@PostConstruct
	public void init() throws FileNotFoundException {
		logger.info("init FirebaseService");

		try {
			firebaseDBURL = env.getProperty("spring.firebase.db.url");
		} catch (Exception e) {
		}
		if (firebaseDBURL == null) {
			firebaseDBURL = "https://re-prime-dev.firebaseio.com/";
		}
		logger.info("firebaseDBURL: " + firebaseDBURL);

		try {

			FirebaseApp firebaseApp = null;
			List<FirebaseApp> firebaseApps = FirebaseApp.getApps();
			if (firebaseApps == null || firebaseApps.isEmpty()) {

				String firebasePath = null;
				try {
					firebasePath = env.getProperty("spring.firebase.path");
					if (firebasePath == null) {
						firebasePath = "/usr/firebaseconfig/service.json";
					}
				} catch (Exception e) {
				}
				logger.info("firebasePath: " + firebasePath);

				InputStream serviceAccount = new FileInputStream(firebasePath);

				GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);

				FirebaseOptions options = new FirebaseOptions.Builder().setCredentials(credentials)
						.setDatabaseUrl(firebaseDBURL).build();
				firebaseApp = FirebaseApp.initializeApp(options);
				db = FirestoreClient.getFirestore();
				logger.info("Initializing Firebase Successful");

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			dealersDB = env.getProperty("spring.firebase.db.dealer");
		} catch (Exception e) {
		}
		if (dealersDB == null) {
			dealersDB = "CRMCORE";
		}
		logger.info("dealersDB: " + dealersDB);

		logger.info("firebase set up successfully");
	}

	public void addDealers(List<DealerDTO> dealerList) throws JsonProcessingException {
		final FirebaseDatabase database = FirebaseDatabase.getInstance();
//	     TODO: value must be from property file
//		DatabaseReference ref = database.getReference("CRMCORE");
		DatabaseReference ref = database.getReference(dealersDB);
		DatabaseReference dealerReference = ref.child("dealers");
		dealerReference.setValueAsync(dealerList);
		logger.info("firebase addDealers successfully");
	}

	public void addVehicleList() {

		Firestore firestore = FirestoreClient.getFirestore();
		DocumentReference docRef = firestore.collection("VehicleList").document("dealerlist1");
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("dealerid", "" + System.currentTimeMillis());
		data.put("dealername", "dealername 222");
		data.put("phone", 9999);
		// asynchronously write data
		docRef.set(data);

	}

	public String getCollection(String collection) throws Exception {

		String result = "";
		Firestore db = FirestoreClient.getFirestore();

		ApiFuture<QuerySnapshot> query = db.collection(collection).get();
		QuerySnapshot querySnapshot = query.get();

		List<QueryDocumentSnapshot> documents = querySnapshot.getDocuments();

		for (QueryDocumentSnapshot document : documents) {
			result += document.getId() + " :: " + document.getString("ActiveCustomerName") + " :: "
					+ document.getString("ChassisNo");
		}
		return result;
	}

	public void getFireStoreDataById(String id) {

	}

	/**
	 *
	 * @param bookingsResponseDTO
	 * @param guid
	 */
	public void myBookingToFireStore(UserBookingsResponseDTO bookingsResponseDTO, String guid) {
		try {
//			logger.debug("Processing Started for Writing data to firebase for Guid {{}} & Payment Cash Id {{}}.", guid,
//					bookingsResponseDTO.getPaymentCaseId());

			db.collection(guid).document(Constants.FIRESTORE_KEY_MY_BOOKING)
					.collection(Constants.FIRESTORE_KEY_BIKE_BOOKING).document(bookingsResponseDTO.getPaymentCaseId())
					.set(bookingsResponseDTO);

			// logger.info("Data Successfully Written to firebase.");
		} catch (Exception e) {
			logger.error(
					"Error occurred in Writing data to FireStore For Guid {{}} & Payment Cash Id {{}}. Exception Message {{}}, Exception Details {{}}",
					guid, bookingsResponseDTO.getPaymentCaseId(), e.getMessage(), e);
		}
	}

}