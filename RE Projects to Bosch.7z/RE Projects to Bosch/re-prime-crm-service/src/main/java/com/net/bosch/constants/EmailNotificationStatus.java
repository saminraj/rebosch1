/**
 * 
 */
package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum EmailNotificationStatus {

	SUCCESS("SUCCESS"), PENDING("PENDING"), FAILED("FAILED");

	private String value;

	/**
	 * @param value
	 */
	private EmailNotificationStatus(String value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

}
