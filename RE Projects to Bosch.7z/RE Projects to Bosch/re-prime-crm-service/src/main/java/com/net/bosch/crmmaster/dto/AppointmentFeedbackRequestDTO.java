package com.net.bosch.crmmaster.dto;


public class AppointmentFeedbackRequestDTO{	
		
    private String jobCardNumber;

	public String getJobCardNumber() {
		return jobCardNumber;
	}

	public void setJobCardNumber(String jobCardNumber) {
		this.jobCardNumber = jobCardNumber;
	}
	
	
	
	
	
}
