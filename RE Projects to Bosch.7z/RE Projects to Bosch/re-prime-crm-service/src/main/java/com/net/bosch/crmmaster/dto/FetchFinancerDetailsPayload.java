package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class FetchFinancerDetailsPayload {

	private String dmsBookingId;
	private String bookingCashId;

	public FetchFinancerDetailsPayload() {

	}

	public FetchFinancerDetailsPayload(String bookingCashId) {
		this.bookingCashId = bookingCashId;
	}

	/**
	 * @return the dmsBookingId
	 */
	public String getDmsBookingId() {
		return dmsBookingId;
	}

	/**
	 * @param dmsBookingId the dmsBookingId to set
	 */
	public void setDmsBookingId(String dmsBookingId) {
		this.dmsBookingId = dmsBookingId;
	}

	/**
	 * @return the bookingCashId
	 */
	public String getBookingCashId() {
		return bookingCashId;
	}

	/**
	 * @param bookingCashId the bookingCashId to set
	 */
	public void setBookingCashId(String bookingCashId) {
		this.bookingCashId = bookingCashId;
	}

}
