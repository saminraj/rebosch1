package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

/**
 * @author pushkarkhosla
 *
 */
public class FinanceBookingDetailsDTO extends UserBookingFinanceResponseDTO {

	@NotBlank
	@NotEmpty
	private String bookingCashId;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FinanceBookingDetailsDTO [bookingCashId=");
		builder.append(bookingCashId);
		builder.append(", FinancerName()=");
		builder.append(getFinancerName());
		builder.append(", FinancerStatus()=");
		builder.append(getFinancerStatus());
		builder.append(", FinancerLoanAmount()=");
		builder.append(getFinancerLoanAmount());
		builder.append(", FinancerTenure()=");
		builder.append(getFinancerTenure());
		builder.append(", FinancerInterestRate()=");
		builder.append(getFinancerInterestRate());
		builder.append(", FinancerLoanId()=");
		builder.append(getFinancerLoanId());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingCashId
	 */
	public String getBookingCashId() {
		return bookingCashId;
	}

	/**
	 * @param bookingCashId the bookingCashId to set
	 */
	public void setBookingCashId(String bookingCashId) {
		this.bookingCashId = bookingCashId;
	}

}
