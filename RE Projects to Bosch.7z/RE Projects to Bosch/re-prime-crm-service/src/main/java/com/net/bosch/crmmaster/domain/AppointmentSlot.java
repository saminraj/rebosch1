package com.net.bosch.crmmaster.domain;

import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash("Appointment")
public class AppointmentSlot implements DomainObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5732876080515619243L;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	public Date startTimeSlot;
	
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	public Date endTimeSlot;
	
	@NotNull
	public Boolean availability;
	
	@org.springframework.data.annotation.Id
	public String id;
	
	@Indexed
	public String branchId;
	
	@Indexed
	public String date;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getStartTimeSlot() {
		return startTimeSlot;
	}

	public void setStartTimeSlot(Date startTimeSlot) {
		this.startTimeSlot = startTimeSlot;
	}

	public Date getEndTimeSlot() {
		return endTimeSlot;
	}

	public void setEndTimeSlot(Date endTimeSlot) {
		this.endTimeSlot = endTimeSlot;
	}

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
			
}
