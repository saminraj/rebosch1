package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.RequestDTO;

@JsonInclude(Include.NON_NULL)
public class AddVehicleRequestDTO extends RequestDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2303725028044474056L;

	private String userName;
	private String chassisNo;
	private String dateOfMfg;
	private String engineNo;
	private String id;
	private String purchaseDate;
	private String mobileNo;
	private String vehicleModelCode;
	private String vehicleModelName;
	private String registrationNo;
	private String invoiceNo;
	private String alternateNo;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the chassisNo
	 */
	public String getChassisNo() {
		return chassisNo;
	}

	/**
	 * @param chassisNo the chassisNo to set
	 */
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getDateOfMfg() {
		return dateOfMfg;
	}

	public void setDateOfMfg(String dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the vehicleModelCode
	 */
	public String getVehicleModelCode() {
		return vehicleModelCode;
	}

	/**
	 * @param vehicleModelCode the vehicleModelCode to set
	 */
	public void setVehicleModelCode(String vehicleModelCode) {
		this.vehicleModelCode = vehicleModelCode;
	}

	/**
	 * @return the vehicleModelName
	 */
	public String getVehicleModelName() {
		return vehicleModelName;
	}

	/**
	 * @param vehicleModelName the vehicleModelName to set
	 */
	public void setVehicleModelName(String vehicleModelName) {
		this.vehicleModelName = vehicleModelName;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getAlternateNo() {
		return alternateNo;
	}

	public void setAlternateNo(String alternateNo) {
		this.alternateNo = alternateNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AddVehicleRequestDTO [userName=");
		builder.append(userName);
		builder.append(", chassisNo=");
		builder.append(chassisNo);
		builder.append(", dateOfMfg=");
		builder.append(dateOfMfg);
		builder.append(", engineNo=");
		builder.append(engineNo);
		builder.append(", id=");
		builder.append(id);
		builder.append(", purchaseDate=");
		builder.append(purchaseDate);
		builder.append(", mobileNo=");
		builder.append(mobileNo);
		builder.append(", vehicleModelCode=");
		builder.append(vehicleModelCode);
		builder.append(", vehicleModelName=");
		builder.append(vehicleModelName);
		builder.append(", registrationNo=");
		builder.append(registrationNo);
		builder.append(", invoiceNo=");
		builder.append(invoiceNo);
		builder.append(", alternateNo=");
		builder.append(alternateNo);
		builder.append("]");
		return builder.toString();
	}

}
