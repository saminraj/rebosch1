package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.net.bosch.crmmaster.payment.collection.OnlinePaymentInfo;

/**
 * @author pushkarkhosla
 *
 */
public class SearchBalancePaymentResponse {

	private String bookingCaseId;
	private String guid;
	private String dealerSource;
	private String dmsBookingId;
	private String excellonResponseKey;
	private String excellonBookingId;
	private List<OnlinePaymentInfo> paymentInfo;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SearchBalancePaymentResponse [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", guid=");
		builder.append(guid);
		builder.append(", dealerSource=");
		builder.append(dealerSource);
		builder.append(", dmsBookingId=");
		builder.append(dmsBookingId);
		builder.append(", excellonResponseKey=");
		builder.append(excellonResponseKey);
		builder.append(", excellonBookingId=");
		builder.append(excellonBookingId);
		builder.append(", paymentInfo=");
		builder.append(paymentInfo);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the dmsBookingId
	 */
	public String getDmsBookingId() {
		return dmsBookingId;
	}

	/**
	 * @param dmsBookingId the dmsBookingId to set
	 */
	public void setDmsBookingId(String dmsBookingId) {
		this.dmsBookingId = dmsBookingId;
	}

	/**
	 * @return the excellonResponseKey
	 */
	public String getExcellonResponseKey() {
		return excellonResponseKey;
	}

	/**
	 * @param excellonResponseKey the excellonResponseKey to set
	 */
	public void setExcellonResponseKey(String excellonResponseKey) {
		this.excellonResponseKey = excellonResponseKey;
	}

	/**
	 * @return the excellonBookingId
	 */
	public String getExcellonBookingId() {
		return excellonBookingId;
	}

	/**
	 * @param excellonBookingId the excellonBookingId to set
	 */
	public void setExcellonBookingId(String excellonBookingId) {
		this.excellonBookingId = excellonBookingId;
	}

	/**
	 * @return the paymentInfo
	 */
	public List<OnlinePaymentInfo> getPaymentInfo() {
		return paymentInfo;
	}

	/**
	 * @param paymentInfo the paymentInfo to set
	 */
	public void setPaymentInfo(List<OnlinePaymentInfo> paymentInfo) {
		this.paymentInfo = paymentInfo;
	}

}
