package com.net.bosch.crmmaster.domain;

import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.domain.DomainObject;

@JsonInclude(Include.NON_NULL)
@RedisHash(value = "DealerServiceSlots", timeToLive = 1036800)
public class DealerServiceSlots implements DomainObject{

	private static final long serialVersionUID = -3874574926830778247L;

	@Id 
	private String id;	
	
	private Integer totalDoorStepCount = 0;	
	
	private Integer totalPickupCount = 0;
	
	private Integer currentDoorStepCount = 0;	
	
	private Integer currentPickupCount = 0;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getTotalDoorStepCount() {
		return totalDoorStepCount;
	}

	public void setTotalDoorStepCount(Integer totalDoorStepCount) {
		this.totalDoorStepCount = totalDoorStepCount;
	}

	public Integer getTotalPickupCount() {
		return totalPickupCount;
	}

	public void setTotalPickupCount(Integer totalPickupCount) {
		this.totalPickupCount = totalPickupCount;
	}

	public Integer getCurrentDoorStepCount() {
		return currentDoorStepCount;
	}

	public void setCurrentDoorStepCount(Integer currentDoorStepCount) {
		this.currentDoorStepCount = currentDoorStepCount;
	}

	public Integer getCurrentPickupCount() {
		return currentPickupCount;
	}

	public void setCurrentPickupCount(Integer currentPickupCount) {
		this.currentPickupCount = currentPickupCount;
	}
	
			
}
