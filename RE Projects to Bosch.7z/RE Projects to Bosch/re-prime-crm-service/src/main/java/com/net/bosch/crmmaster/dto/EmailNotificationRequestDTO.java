package com.net.bosch.crmmaster.dto;

import com.net.bosch.constants.EmailNotificationStatus;
import com.net.bosch.constants.EmailTable;

/**
 * @author pushkarkhosla
 *
 */
public class EmailNotificationRequestDTO {

	private Integer appId;
	private String emailId;
	private String templateName;
	private String sourceKey;
	private String sourceData;

	private String mobileNo;

	private String content;
	private String subject;

	private String comments;
	private String pdfUrl1;
	private String pdfUrl2;
	private String pdfUrl3;
	private EmailNotificationStatus status;
	private EmailTable table;

	public EmailNotificationRequestDTO() {
	}

	/**
	 * @param emailId
	 * @param mobileNo
	 * @param content
	 * @param subject
	 * @param comments
	 * @param pdfUrl1
	 * @param pdfUrl2
	 */
	public EmailNotificationRequestDTO(String emailId, String mobileNo, String subject, String content, String pdfUrl1,
			String pdfUrl2, String comments) {
		super();
		this.appId = 2;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.content = content;
		this.subject = subject;
		this.pdfUrl1 = pdfUrl1;
		this.pdfUrl2 = pdfUrl2;
		this.comments = comments;
		this.status = EmailNotificationStatus.SUCCESS;
		this.table = EmailTable.VEHICLE_ON_BOARDING;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmailNotificationRequestDTO [appId=");
		builder.append(appId);
		builder.append(", emailId=");
		builder.append(emailId);
		builder.append(", templateName=");
		builder.append(templateName);
		builder.append(", sourceKey=");
		builder.append(sourceKey);
		builder.append(", sourceData=");
		builder.append(sourceData);
		builder.append(", mobileNo=");
		builder.append(mobileNo);
		builder.append(", subject=");
		builder.append(subject);
		builder.append(", comments=");
		builder.append(comments);
		builder.append(", pdfUrl1=");
		builder.append(pdfUrl1);
		builder.append(", pdfUrl2=");
		builder.append(pdfUrl2);
		builder.append(", pdfUrl3=");
		builder.append(pdfUrl3);
		builder.append(", status=");
		builder.append(status);
		builder.append(", table=");
		builder.append(table);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the appId
	 */
	public Integer getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the sourceKey
	 */
	public String getSourceKey() {
		return sourceKey;
	}

	/**
	 * @param sourceKey the sourceKey to set
	 */
	public void setSourceKey(String sourceKey) {
		this.sourceKey = sourceKey;
	}

	/**
	 * @return the sourceData
	 */
	public String getSourceData() {
		return sourceData;
	}

	/**
	 * @param sourceData the sourceData to set
	 */
	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the pdfUrl1
	 */
	public String getPdfUrl1() {
		return pdfUrl1;
	}

	/**
	 * @param pdfUrl1 the pdfUrl1 to set
	 */
	public void setPdfUrl1(String pdfUrl1) {
		this.pdfUrl1 = pdfUrl1;
	}

	/**
	 * @return the pdfUrl2
	 */
	public String getPdfUrl2() {
		return pdfUrl2;
	}

	/**
	 * @param pdfUrl2 the pdfUrl2 to set
	 */
	public void setPdfUrl2(String pdfUrl2) {
		this.pdfUrl2 = pdfUrl2;
	}

	/**
	 * @return the pdfUrl3
	 */
	public String getPdfUrl3() {
		return pdfUrl3;
	}

	/**
	 * @param pdfUrl3 the pdfUrl3 to set
	 */
	public void setPdfUrl3(String pdfUrl3) {
		this.pdfUrl3 = pdfUrl3;
	}

	/**
	 * @return the status
	 */
	public EmailNotificationStatus getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(EmailNotificationStatus status) {
		this.status = status;
	}

	/**
	 * @return the table
	 */
	public EmailTable getTable() {
		return table;
	}

	/**
	 * @param table the table to set
	 */
	public void setTable(EmailTable table) {
		this.table = table;
	}

}
