package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class UserProfilePhoneResponseDTO {

	private String number;
	private String callingCode;

	/**
	 *
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserProfilePhoneResponseDTO [number=");
		builder.append(number);
		builder.append(", callingCode=");
		builder.append(callingCode);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the callingCode
	 */
	public String getCallingCode() {
		return callingCode;
	}

	/**
	 * @param callingCode the callingCode to set
	 */
	public void setCallingCode(String callingCode) {
		this.callingCode = callingCode;
	}

}
