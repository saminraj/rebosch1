package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum ServiceHistoryOperationEnum {

	DELETE_INSERT("DELETE AND INSERT"), DELETE("ONLY DELETE"), INSERT("ONLY INSERT"),DO_NOTHING("DO_NOTHING");

	private String value;

	private ServiceHistoryOperationEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
