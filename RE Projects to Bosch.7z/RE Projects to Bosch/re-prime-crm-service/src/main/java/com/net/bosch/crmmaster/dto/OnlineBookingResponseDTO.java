package com.net.bosch.crmmaster.dto;

import com.net.bosch.constants.BookingStatus;

/**
 * @author pushkarkhosla
 *
 */
public class OnlineBookingResponseDTO {

	private String bookingCaseId;
	private String paymentCaseId;
	private String customerID;
	private String guid;
	private String paymentStatus;
	private BookingStatus bookingStatus;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OnlineBookingResponseDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", customerID=");
		builder.append(customerID);
		builder.append(", guid=");
		builder.append(guid);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", bookingStatus=");
		builder.append(bookingStatus);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the bookingStatus
	 */
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}

	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

}
