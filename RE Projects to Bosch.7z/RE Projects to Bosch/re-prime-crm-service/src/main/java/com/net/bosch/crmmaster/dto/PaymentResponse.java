package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class PaymentResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3350513100645269694L;

	private String checkSum;
	private String errorDescription;
	private String errorStatus;
	private String additionalInfo7;
	private String additionalInfo6;
	private String additionalInfo5;
	private String additionalInfo4;
	private String additionalInfo3;
	private String additionalInfo2;
	private String additionalInfo1;
	private String settlementType;
	private String authStatus;
	private String txnDate;
	private String securityPassword;
	private String securityID;
	private String securityType;
	private String itemCode;
	private String currencyName;
	private String txnType;
	private String bankMerchantID;
	private String bankID;
	private String txnAmount;
	private String bankReferenceNo;
	private String txnReferenceNo;
	private String customerID;
	private String merchantID;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PaymentResponse [checkSum=");
		builder.append(checkSum);
		builder.append(", errorDescription=");
		builder.append(errorDescription);
		builder.append(", errorStatus=");
		builder.append(errorStatus);
		builder.append(", additionalInfo7=");
		builder.append(additionalInfo7);
		builder.append(", additionalInfo6=");
		builder.append(additionalInfo6);
		builder.append(", additionalInfo5=");
		builder.append(additionalInfo5);
		builder.append(", additionalInfo4=");
		builder.append(additionalInfo4);
		builder.append(", additionalInfo3=");
		builder.append(additionalInfo3);
		builder.append(", additionalInfo2=");
		builder.append(additionalInfo2);
		builder.append(", additionalInfo1=");
		builder.append(additionalInfo1);
		builder.append(", settlementType=");
		builder.append(settlementType);
		builder.append(", authStatus=");
		builder.append(authStatus);
		builder.append(", txnDate=");
		builder.append(txnDate);
		builder.append(", securityPassword=");
		builder.append(securityPassword);
		builder.append(", securityID=");
		builder.append(securityID);
		builder.append(", securityType=");
		builder.append(securityType);
		builder.append(", itemCode=");
		builder.append(itemCode);
		builder.append(", currencyName=");
		builder.append(currencyName);
		builder.append(", txnType=");
		builder.append(txnType);
		builder.append(", bankMerchantID=");
		builder.append(bankMerchantID);
		builder.append(", bankID=");
		builder.append(bankID);
		builder.append(", txnAmount=");
		builder.append(txnAmount);
		builder.append(", bankReferenceNo=");
		builder.append(bankReferenceNo);
		builder.append(", txnReferenceNo=");
		builder.append(txnReferenceNo);
		builder.append(", customerID=");
		builder.append(customerID);
		builder.append(", merchantID=");
		builder.append(merchantID);
		builder.append("]");
		return builder.toString();
	}

	public String getCheckSum() {
		return checkSum;
	}

	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}

	public String getAdditionalInfo7() {
		return additionalInfo7;
	}

	public void setAdditionalInfo7(String additionalInfo7) {
		this.additionalInfo7 = additionalInfo7;
	}

	public String getAdditionalInfo6() {
		return additionalInfo6;
	}

	public void setAdditionalInfo6(String additionalInfo6) {
		this.additionalInfo6 = additionalInfo6;
	}

	public String getAdditionalInfo5() {
		return additionalInfo5;
	}

	public void setAdditionalInfo5(String additionalInfo5) {
		this.additionalInfo5 = additionalInfo5;
	}

	public String getAdditionalInfo4() {
		return additionalInfo4;
	}

	public void setAdditionalInfo4(String additionalInfo4) {
		this.additionalInfo4 = additionalInfo4;
	}

	public String getAdditionalInfo3() {
		return additionalInfo3;
	}

	public void setAdditionalInfo3(String additionalInfo3) {
		this.additionalInfo3 = additionalInfo3;
	}

	public String getAdditionalInfo2() {
		return additionalInfo2;
	}

	public void setAdditionalInfo2(String additionalInfo2) {
		this.additionalInfo2 = additionalInfo2;
	}

	public String getAdditionalInfo1() {
		return additionalInfo1;
	}

	public void setAdditionalInfo1(String additionalInfo1) {
		this.additionalInfo1 = additionalInfo1;
	}

	public String getSettlementType() {
		return settlementType;
	}

	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}

	public String getAuthStatus() {
		return authStatus;
	}

	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public String getSecurityPassword() {
		return securityPassword;
	}

	public void setSecurityPassword(String securityPassword) {
		this.securityPassword = securityPassword;
	}

	public String getSecurityID() {
		return securityID;
	}

	public void setSecurityID(String securityID) {
		this.securityID = securityID;
	}

	public String getSecurityType() {
		return securityType;
	}

	public void setSecurityType(String securityType) {
		this.securityType = securityType;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getBankMerchantID() {
		return bankMerchantID;
	}

	public void setBankMerchantID(String bankMerchantID) {
		this.bankMerchantID = bankMerchantID;
	}

	public String getBankID() {
		return bankID;
	}

	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	public String getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getBankReferenceNo() {
		return bankReferenceNo;
	}

	public void setBankReferenceNo(String bankReferenceNo) {
		this.bankReferenceNo = bankReferenceNo;
	}

	public String getTxnReferenceNo() {
		return txnReferenceNo;
	}

	public void setTxnReferenceNo(String txnReferenceNo) {
		this.txnReferenceNo = txnReferenceNo;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

}
