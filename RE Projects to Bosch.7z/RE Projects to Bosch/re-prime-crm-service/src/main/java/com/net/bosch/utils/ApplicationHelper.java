package com.net.bosch.utils;

import static com.net.bosch.constants.Constants.APP_ID_KEY;
import static com.net.bosch.constants.Constants.APP_ID_VALUE_FOR_PAYMENT_SERVICE;
import static com.net.bosch.constants.Constants.APP_ID_VALUE_FOR_RE_UTILITY_SAVE_EMAIL;
import static com.net.bosch.constants.Constants.AUTHORIZATION;
import static com.net.bosch.constants.Constants.BALANCE_PAYMENT;
import static com.net.bosch.constants.Constants.BEARER;
import static com.net.bosch.constants.Constants.DDMMYYYY_SLASH;
import static com.net.bosch.constants.Constants.FAILED;
import static com.net.bosch.constants.Constants.FIRST_PAYMENT;
import static com.net.bosch.constants.Constants.HYPHEN;
import static com.net.bosch.constants.Constants.PIPE_SEPARATOR;
import static com.net.bosch.constants.Constants.SUCCESS_CODE;
import static com.net.bosch.constants.REResponse.NO_BALANCE_PAYMENT_BOOKING_DETAILS_FOUND;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.constants.BookingStatus;
import com.net.bosch.constants.PaymentStage;
import com.net.bosch.crmmaster.dto.BalancePaymentResponse;
import com.net.bosch.crmmaster.dto.DMSBookingDetailsDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingPaymentPartsDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.EmailNotificationRequestDTO;
import com.net.bosch.crmmaster.dto.ExcellonBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.ExcellonMyoAccessoriesDataRequestDTO;
import com.net.bosch.crmmaster.dto.FirestoreUpdateRequestDTO;
import com.net.bosch.crmmaster.dto.SearchBalancePaymentResponse;
import com.net.bosch.crmmaster.dto.UserBookingsResponseDTO;
import com.net.bosch.crmmaster.payment.collection.OnlineBooking;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentInfo;
import com.net.bosch.crmmaster.service.OnlineBookingService;
import com.net.bosch.crmmaster.service.RestTemplateService;
import com.net.bosch.crmmaster.vehicle.collection.UserVehicle;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.excellon.schemas.PushMYOBookingDetailDataResponse;
import com.net.bosch.excellon.soap.client.ExcellonSoapClient;

/**
 * @author pushkarkhosla
 *
 */
public class ApplicationHelper {

	private static final String NA = "NA";
	private static final String ZERO = "0";
	private static final String CHECK_WITH_DEALER = "Check With Dealer";
	private static final String SUCCESS = "SUCCESS";
	private static final Logger logger = LoggerFactory.getLogger(ApplicationHelper.class);

	private ApplicationHelper() {

	}

	/**
	 * @param bookingId
	 * @return
	 */
	public static String generatePaymentCashId(String bookingId) {
		return bookingId.concat(FIRST_PAYMENT);
	}

	/**
	 * @param bookingId
	 * @return
	 */
	public static String generatePaymentCashIdForBalancePayment(String bookingId) {
		return bookingId.concat(BALANCE_PAYMENT);
	}

	/**
	 * @return
	 */
	public static Date populateFromTimeInQuery() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MINUTE, -30);
		Date currentDate = cal.getTime();
		logger.info("Setting Current Time {{}}", getDate(currentDate));
		return currentDate;
	}

	/**
	 * @return
	 */
	public static Date populatePastDurationTimeInQuery() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MINUTE, -1440);
		Date durationDate = cal.getTime();
		logger.info("Setting Current Time {{}}", getDate(durationDate));
		return durationDate;
	}

	/**
	 * @param date
	 * @return
	 */
	public static String getDate(Date date) {
		return new SimpleDateFormat(DDMMYYYY_SLASH).format(date);
	}

	/**
	 * Used in {@link OnlineBookingService}.
	 * 
	 * @param resOptional
	 * @return
	 */
	public static OnlineBooking checkOnlineBookingOptional(Optional<OnlineBooking> resOptional) {
		if (!resOptional.isPresent()) {
			logger.error("No Online Bike Booking Details Found with Given Details.");
			return null;
		}
		return resOptional.get();
	}

	/**
	 * Used in {@link OnlineBookingService}.
	 * 
	 * @param resOptional
	 * @return
	 */
	public static OnlinePaymentDetails checkOnlinePaymentOptional(Optional<OnlinePaymentDetails> resOptional) {
		if (!resOptional.isPresent()) {
			logger.error("No Online Payment Details Found with Payment Id.");
			return null;
		}
		return resOptional.get();
	}

	/**
	 * Used In {@link ExcellonSoapClient}.
	 * 
	 * @param obj
	 * @return
	 */
	public static String convertObjectToJson(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			logger.error("Exception Occured While Conveting Object to Json. Exception Message {{}}", e.getMessage());
			return null;
		}
	}

	/**
	 * Used In {@link ExcellonSoapClient}.
	 * 
	 * @param response
	 * @return
	 */
	public static PushMYOBookingDetailDataResponse validateExcellonBookingDetailsAPIResponse(
			final PushMYOBookingDetailDataResponse response) {
		logger.info("Validating Excellon-Soap-Booking-Details API Response.");

		if (ObjectUtils.isEmpty(response) || !response.getPushMYOBookingDetailDataResult().isIsRequestSuccessful()) {
			logger.error("Excellon-Soap-Booking-Details API Response is Blank/Null. or IsRequestSuccessful is {{}}",
					response.getPushMYOBookingDetailDataResult().isIsRequestSuccessful());
			return null;
		}

		if (response.getPushMYOBookingDetailDataResult().isIsRequestSuccessful()
				&& (ObjectUtils.isEmpty(response.getPushMYOBookingDetailDataResult().getPushBookingDataDataResponse())
						|| ObjectUtils.isEmpty(response.getPushMYOBookingDetailDataResult()
								.getPushBookingDataDataResponse().getPushBookingData()))) {
			logger.error("Excellon-Soap-Booking-Details API Response is successfully but No Booking Details found.");
			return null;
		}
		logger.info("Excellon-Soap-Booking-Details API Response Validated Successfully.");
		return response;
	}

	/**
	 * Used In {@link RestTemplateService}.
	 * 
	 * @param payload
	 * @return
	 */
	public static HttpEntity<Object> getHttpEntity(final Object payload) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		if (!(payload instanceof DMSBookingDetailsDTO || payload instanceof FirestoreUpdateRequestDTO)) {
			headers.add(APP_ID_KEY,
					(payload instanceof EmailNotificationRequestDTO) ? APP_ID_VALUE_FOR_RE_UTILITY_SAVE_EMAIL
							: APP_ID_VALUE_FOR_PAYMENT_SERVICE);
		}

		return new HttpEntity<>(payload, headers);
	}

	/**
	 * Used in {@link RestTemplateService}
	 * 
	 * @param authToken
	 * @param payload
	 * @return
	 */
	public static HttpEntity<Object> getInstoreBookingDMSHttpEntity(final String authToken, final Object payload) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTHORIZATION, BEARER.concat(authToken));
		return new HttpEntity<>(payload, headers);
	}

	/**
	 * @param entity
	 * @param response
	 * @return
	 */
	public static Object[][] getBalancePaymentDetailsAndResponse(OnlinePaymentDetails entity,
			BalancePaymentResponse response) {
		Object[][] objectArr = new Object[1][2];
		objectArr[0][0] = entity;
		objectArr[0][1] = response;
		return objectArr;
	}

	/**
	 * @param paymentInfoList
	 * @param bookingCaseId
	 * @return
	 */
	public static String generatePaymentCashIdForSubsequentBalancePayment(final List<OnlinePaymentInfo> paymentInfoList,
			final String bookingCaseId) {
		return bookingCaseId.concat(HYPHEN).concat(String.format("%02d", paymentInfoList.size() + 2));
	}

	/**
	 * @param searchDetails
	 * @return
	 */
	public static REBaseResponse getBalancePaymentSearchResponse(final OnlinePaymentDetails searchDetails) {
		if (null == searchDetails) {
			return getErrorResponse(NO_BALANCE_PAYMENT_BOOKING_DETAILS_FOUND);
		}
		SearchBalancePaymentResponse response = new SearchBalancePaymentResponse();
		BeanUtils.copyProperties(searchDetails, response);

		return getSuccessResponse(response);
	}

	/**
	 * @param bookingId
	 * @return
	 */
	public static String getDealerSource(String bookingId) {
		if (StringUtils.startsWith(bookingId, "BKG")) {
			return "D";
		} else if (StringUtils.startsWith(bookingId, "BKNG")) {
			return "E";
		} else {
			logger.error("BookingId is {{}} Not Matching standard format", bookingId);
			return StringUtils.EMPTY;
		}
	}

	/**
	 * @param paymentInfoLoopObject
	 * @return
	 */
	public static boolean isRecordToBeProcessed(OnlinePaymentInfo paymentInfoLoopObject) {

		if (null == paymentInfoLoopObject.getPaymentStage()
				|| paymentInfoLoopObject.getPaymentStage() == PaymentStage.INITIAL_PAYMENT) {

			if (!ObjectUtils.isEmpty(paymentInfoLoopObject.getDynamicsRequest())) {

				if (ObjectUtils.isEmpty(paymentInfoLoopObject.getDynamicsResponse())) {
					return true;
				}
				return StringUtils.isEmpty(paymentInfoLoopObject.getDynamicsResponse().getBookingid());

			} else if (!ObjectUtils.isEmpty(paymentInfoLoopObject.getExcellonRequest())) {

				if (ObjectUtils.isEmpty(paymentInfoLoopObject.getExcellonResponse())) {
					return true;
				}
				return !paymentInfoLoopObject.getExcellonResponse().isRequestSuccessful();
			}
		} else if (null != paymentInfoLoopObject.getPaymentStage()
				&& paymentInfoLoopObject.getPaymentStage() == PaymentStage.BALANCE_PAYMENT) {

			return isRecordToBeProcessedForBalancePayment(paymentInfoLoopObject);
		}
		return false;
	}

	/**
	 * @param paymentInfoLoopObject
	 * @return
	 */
	public static boolean isRecordToBeProcessedForBalancePayment(OnlinePaymentInfo paymentInfoLoopObject) {
		if (!ObjectUtils.isEmpty(paymentInfoLoopObject.getDynamicsBalancePaymentRequestDTO())) {

			if (ObjectUtils.isEmpty(paymentInfoLoopObject.getDynamicsBalancePaymentResponse())) {
				return true;
			}
			return !StringUtils.equalsIgnoreCase(paymentInfoLoopObject.getDynamicsBalancePaymentResponse().getResult(),
					SUCCESS);

		} else if (!ObjectUtils.isEmpty(paymentInfoLoopObject.getExcellonBalancePaymentRequestDTO())) {

			if (ObjectUtils.isEmpty(paymentInfoLoopObject.getExcellonBalancePaymentResponse())) {
				return true;
			}
			return !paymentInfoLoopObject.getExcellonBalancePaymentResponse().isRequestSuccessful();
		}
		return false;
	}

	/**
	 * @param paymentInfoLoopObject
	 * @return
	 */
	public static boolean isInStoreRecordToBeProcessed(OnlinePaymentInfo paymentInfoLoopObject) {

		if (!ObjectUtils.isEmpty(paymentInfoLoopObject.getInStoreDynamicsRequest())) {

			return ObjectUtils.isEmpty(paymentInfoLoopObject.getDynamicsResponse())
					|| StringUtils.isEmpty(paymentInfoLoopObject.getDynamicsResponse().getBookingid());
		}
		return false;
	}

	/*
	 * @param tdd
	 * 
	 * @param bookingDate
	 * 
	 * @return
	 */
	public static String validateAndConvertTentativeDeliveryDays(String tdd, Date bookingDate) {
		if (isEmpty(tdd) || StringUtils.equals(tdd, ZERO) || (null == bookingDate)) {
			return CHECK_WITH_DEALER;
		}
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(bookingDate);
			cal.add(Calendar.DATE, Integer.parseInt(tdd));

			return DateHelper.convertDateToString(cal.getTime(), DateHelper.DDMMYYYY_HYPHEN);
		} catch (Exception e) {
			logger.error("Exception Occured While Parsing TDD {{}}, Exception Message {{}}", tdd, e.getMessage());
			return CHECK_WITH_DEALER;
		}
	}

	/**
	 * @param dmsObj
	 * @return
	 */
	public static List<DynamicsBookingPaymentPartsDTO> getDMSPartsListForFirebase(
			DynamicsBookingPaymentRequestDTO dmsObj) {
		return getPartsListForFirebase(dmsObj, null, null);
	}

	/**
	 * @param excellonObj
	 * @param onlineBookingObj
	 * @return
	 */
	public static List<DynamicsBookingPaymentPartsDTO> getExcellonPartsListForFirebase(
			ExcellonBookingPaymentRequestDTO excellonObj, OnlineBooking onlineBookingObj) {

		return getPartsListForFirebase(null, excellonObj, onlineBookingObj);
	}

	/**
	 * @param dmsObj
	 * @param excellonObj
	 * @return
	 */
	private static List<DynamicsBookingPaymentPartsDTO> getPartsListForFirebase(DynamicsBookingPaymentRequestDTO dmsObj,
			ExcellonBookingPaymentRequestDTO excellonObj, OnlineBooking onlineBookingObj) {

		String configDescription = null;
		List<DynamicsBookingPaymentPartsDTO> resultList = new LinkedList<>();

		if (null != dmsObj) {
			if (CollectionUtils.isNotEmpty(dmsObj.getParts())) {
				resultList.addAll(dmsObj.getParts());
			}
			if (isNotEmpty(dmsObj.getBadgename())) {
				resultList
						.add(new DynamicsBookingPaymentPartsDTO("Personalized Badge : ".concat(dmsObj.getBadgename())));
			}
			configDescription = dmsObj.getConfigdescription();
		}
		if (null != excellonObj) {
			configDescription = excellonObj.getConfigdescription();

			List<ExcellonMyoAccessoriesDataRequestDTO> excellonParts = CollectionUtils.isEmpty(
					excellonObj.getMyoAccessoriesData()) ? new LinkedList<>() : excellonObj.getMyoAccessoriesData();

			if (null != onlineBookingObj
					&& CollectionUtils.isNotEmpty(onlineBookingObj.getExcellonRideSurePackageData())) {
				excellonParts.addAll(onlineBookingObj.getExcellonRideSurePackageData());
			}
			if (CollectionUtils.isNotEmpty(excellonParts)) {
				for (ExcellonMyoAccessoriesDataRequestDTO bean : excellonParts) {
					resultList.add(new DynamicsBookingPaymentPartsDTO(bean));
				}
			}
		}
		if (isEmpty(configDescription)) {
			return resultList;
		}
		if (configDescription.contains(PIPE_SEPARATOR)) {
			String[] configDescriptionparts = configDescription.split("\\|");
			for (String desc : configDescriptionparts) {

				resultList.add(new DynamicsBookingPaymentPartsDTO(desc));
			}
			return resultList;
		}
		resultList.add(new DynamicsBookingPaymentPartsDTO(configDescription));
		return resultList;
	}

	/**
	 * @param onlineBookingObj
	 * @param paymentInfo
	 * @param userBookings
	 * @return
	 */
	public static UserBookingsResponseDTO validateAndGetBookingStatusForFirebase(OnlineBooking onlineBookingObj,
			OnlinePaymentInfo paymentInfo, UserBookingsResponseDTO userBookings) {

		if (null == onlineBookingObj) {
			userBookings.setBookingStatus(FAILED);
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			return userBookings;
		}
		if (null == onlineBookingObj.getBookingStatus()) {
			if (!StringUtils.equals(userBookings.getBookingId(), NA)) {
				userBookings.setBookingStatus(SUCCESS);
				userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
				userBookings.setTentativeDeliveryDays(validateAndConvertTentativeDeliveryDays(
						userBookings.getTentativeDeliveryDays(), paymentInfo.getPaymentTimeStamp()));
				return userBookings;
			}
			userBookings.setBookingStatus(NA);
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			return userBookings;
		}
		switch (onlineBookingObj.getBookingStatus()) {
		case FAILED:
		case CANCELLED:
			userBookings.setBookingStatus(String.valueOf(onlineBookingObj.getBookingStatus()));
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			break;
		case INITIATED:
			userBookings.setBookingStatus(String.valueOf(onlineBookingObj.getBookingStatus()));
			userBookings.setPaymentStatus(NA);
			userBookings.setTentativeDeliveryDays(NA);
			break;
		case PENDING:
		case READY_TO_POST:
			userBookings.setBookingStatus(String.valueOf(BookingStatus.PENDING));
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			break;
		case POST_FAIL:
			userBookings.setBookingStatus(String.valueOf(BookingStatus.FAILED));
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			break;
		case POST_SUCCESS:
			userBookings.setBookingStatus(SUCCESS);
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(validateAndConvertTentativeDeliveryDays(
					userBookings.getTentativeDeliveryDays(), paymentInfo.getPaymentTimeStamp()));
			break;
		default:
			userBookings.setBookingStatus(FAILED);
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setTentativeDeliveryDays(NA);
			break;
		}
		return userBookings;
	}

	/**
	 * to format firebase key for excellon.
	 * 
	 * @param invoiceDate
	 * @return
	 */
	public static String formatExcellonFireBaseKey(String invoiceDate) {
		if (isEmpty(invoiceDate)) {
			return invoiceDate;
		}
		return invoiceDate.replace(" ", "-");
	}

	/**
	 * @param response
	 * @return
	 */
	public static UserVehicle checkOptionalUserVehicle(Optional<UserVehicle> response) {
		if (response.isPresent()) {
			return response.get();
		}
		logger.error("No Vehicle Found In Mongo for Given GUID.");
		return null;
	}

	/**
	 * @param paymentResponse
	 * @return
	 */
	public static OnlinePaymentInfo getInitialPaymentObject(OnlinePaymentDetails paymentResponse) {
		if ((null == paymentResponse) || ObjectUtils.isEmpty(paymentResponse)) {
			logger.error("Payment Obj is Null/Blank.");
			return null;
		}
		if (CollectionUtils.isEmpty(paymentResponse.getPaymentInfo())) {
			logger.error("Payment Obj have Empty Payment Info List.");
			return null;
		}
		for (OnlinePaymentInfo bean : paymentResponse.getPaymentInfo()) {
			if (bean.getPaymentCaseId().endsWith(FIRST_PAYMENT)) {
				logger.info("First Payment Obj Found .");
				return bean;
			}
		}
		logger.error("Payment Obj not contains First Payment Obj.");
		return null;
	}

	@SuppressWarnings("unchecked")
	public static boolean validateShowAuthorizeApiResponse(REBaseResponse response) {
		if (ObjectUtils.isEmpty(response)) {
			logger.error("Show-Authorize API response is Blank.");
			return false;
		}
		if (!StringUtils.equals(response.getCode(), SUCCESS_CODE)) {
			logger.error("Show-Authorize API response code is not success {{}}.", response.getCode());
			return false;
		}
		LinkedHashMap<String, Object> responseObject = (LinkedHashMap<String, Object>) response.getData();

		return ObjectUtils.isEmpty(responseObject) ? false : true;
	}



}
