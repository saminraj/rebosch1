package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pushkarkhosla
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExcellonServiceHistoryResponse {

	@JsonProperty("ActualDeliveryDateandTime")
	private String actualDeliveryDateandTime;

	@JsonProperty("InvoiceAmount")
	private Double invoiceAmount;

	@JsonProperty("InvoiceNumber")
	private String invoiceNumber;

	@JsonProperty("RegistrationNumber")
	private String registrationNumber;

	@JsonProperty("StoreCode")
	private String storeCode;

	@JsonProperty("UserId")
	private String userId;

	@JsonProperty("UserMobileNumber")
	private String userMobileNumber;

	@JsonProperty("PartitionKey")
	private String partitionKey;

	@JsonProperty("RowKey")
	private String rowKey;

	@JsonProperty("Timestamp")
	private String Timestamp;

	@JsonProperty("ETag")
	private String eTag;

	private String status;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcellonServiceHistoryResponse [actualDeliveryDateandTime=");
		builder.append(actualDeliveryDateandTime);
		builder.append(", invoiceAmount=");
		builder.append(invoiceAmount);
		builder.append(", invoiceNumber=");
		builder.append(invoiceNumber);
		builder.append(", registrationNumber=");
		builder.append(registrationNumber);
		builder.append(", storeCode=");
		builder.append(storeCode);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", userMobileNumber=");
		builder.append(userMobileNumber);
		builder.append(", partitionKey=");
		builder.append(partitionKey);
		builder.append(", rowKey=");
		builder.append(rowKey);
		builder.append(", Timestamp=");
		builder.append(Timestamp);
		builder.append(", eTag=");
		builder.append(eTag);
		builder.append(", status=");
		builder.append(status);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the actualDeliveryDateandTime
	 */
	public String getActualDeliveryDateandTime() {
		return actualDeliveryDateandTime;
	}

	/**
	 * @param actualDeliveryDateandTime the actualDeliveryDateandTime to set
	 */
	public void setActualDeliveryDateandTime(String actualDeliveryDateandTime) {
		this.actualDeliveryDateandTime = actualDeliveryDateandTime;
	}

	/**
	 * @return the invoiceAmount
	 */
	public Double getInvoiceAmount() {
		return invoiceAmount;
	}

	/**
	 * @param invoiceAmount the invoiceAmount to set
	 */
	public void setInvoiceAmount(Double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	/**
	 * @return the invoiceNumber
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	/**
	 * @param invoiceNumber the invoiceNumber to set
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	/**
	 * @return the registrationNumber
	 */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	/**
	 * @param registrationNumber the registrationNumber to set
	 */
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	/**
	 * @return the storeCode
	 */
	public String getStoreCode() {
		return storeCode;
	}

	/**
	 * @param storeCode the storeCode to set
	 */
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userMobileNumber
	 */
	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	/**
	 * @param userMobileNumber the userMobileNumber to set
	 */
	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	/**
	 * @return the partitionKey
	 */
	public String getPartitionKey() {
		return partitionKey;
	}

	/**
	 * @param partitionKey the partitionKey to set
	 */
	public void setPartitionKey(String partitionKey) {
		this.partitionKey = partitionKey;
	}

	/**
	 * @return the rowKey
	 */
	public String getRowKey() {
		return rowKey;
	}

	/**
	 * @param rowKey the rowKey to set
	 */
	public void setRowKey(String rowKey) {
		this.rowKey = rowKey;
	}

	/**
	 * @return the timestamp
	 */
	public String getTimestamp() {
		return Timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(String timestamp) {
		Timestamp = timestamp;
	}

	/**
	 * @return the eTag
	 */
	public String geteTag() {
		return eTag;
	}

	/**
	 * @param eTag the eTag to set
	 */
	public void seteTag(String eTag) {
		this.eTag = eTag;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
