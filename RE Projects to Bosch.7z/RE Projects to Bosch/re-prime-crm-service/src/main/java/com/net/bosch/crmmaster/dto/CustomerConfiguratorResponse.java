package com.net.bosch.crmmaster.dto;

public class CustomerConfiguratorResponse {

	private String id;
	private String bikeId;
	private String phoneNo;
	private double totalPrice;
	private String variantCode;
	private Configuration configuration;

	private int appId;

	private String configCity;
	private String configState;
	private boolean myoCity;
	private ConfiguratorDealerDetails dealerDetail;
	private String modelImage;
	private String bikeName;

	private String email;
	private String salutation;
	private String customerFirstName;
	private String customerLastName;

	private String badgename;
	private double exShowroomPrice;
	private double roadTaxAmount;
	private double insuranceAmount;
	private String configCityID;
	private String configStateID;
	private boolean isConfigurable;
	private String configStatus;

	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * @param salutation the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	/**
	 * @return the modelImage
	 */
	public String getModelImage() {
		return modelImage;
	}

	/**
	 * @param modelImage the modelImage to set
	 */
	public void setModelImage(String modelImage) {
		this.modelImage = modelImage;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the bikeId
	 */
	public String getBikeId() {
		return bikeId;
	}

	/**
	 * @param bikeId the bikeId to set
	 */
	public void setBikeId(String bikeId) {
		this.bikeId = bikeId;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the totalPrice
	 */
	public double getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @return the variantCode
	 */
	public String getVariantCode() {
		return variantCode;
	}

	/**
	 * @param variantCode the variantCode to set
	 */
	public void setVariantCode(String variantCode) {
		this.variantCode = variantCode;
	}

	/**
	 * @return the configuration
	 */
	public Configuration getConfiguration() {
		return configuration;
	}

	/**
	 * @param configuration the configuration to set
	 */
	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}

	/**
	 * @return the appId
	 */
	public int getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(int appId) {
		this.appId = appId;
	}

	/**
	 * @return the configCity
	 */
	public String getConfigCity() {
		return configCity;
	}

	/**
	 * @param configCity the configCity to set
	 */
	public void setConfigCity(String configCity) {
		this.configCity = configCity;
	}

	/**
	 * @return the configState
	 */
	public String getConfigState() {
		return configState;
	}

	/**
	 * @param configState the configState to set
	 */
	public void setConfigState(String configState) {
		this.configState = configState;
	}

	/**
	 * @return the myoCity
	 */
	public boolean isMyoCity() {
		return myoCity;
	}

	/**
	 * @param myoCity the myoCity to set
	 */
	public void setMyoCity(boolean myoCity) {
		this.myoCity = myoCity;
	}

	/**
	 * @return the dealerDetail
	 */
	public ConfiguratorDealerDetails getDealerDetail() {
		return dealerDetail;
	}

	/**
	 * @param dealerDetail the dealerDetail to set
	 */
	public void setDealerDetail(ConfiguratorDealerDetails dealerDetail) {
		this.dealerDetail = dealerDetail;
	}

	/**
	 * @return the bikeName
	 */
	public String getBikeName() {
		return bikeName;
	}

	/**
	 * @param bikeName the bikeName to set
	 */
	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the customerFirstName
	 */
	public String getCustomerFirstName() {
		return customerFirstName;
	}

	/**
	 * @param customerFirstName the customerFirstName to set
	 */
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	/**
	 * @return the customerLastName
	 */
	public String getCustomerLastName() {
		return customerLastName;
	}

	/**
	 * @param customerLastName the customerLastName to set
	 */
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	/**
	 * @return the badgename
	 */
	public String getBadgename() {
		return badgename;
	}

	/**
	 * @param badgename the badgename to set
	 */
	public void setBadgename(String badgename) {
		this.badgename = badgename;
	}

	/**
	 * @return the exShowroomPrice
	 */
	public double getExShowroomPrice() {
		return exShowroomPrice;
	}

	/**
	 * @param exShowroomPrice the exShowroomPrice to set
	 */
	public void setExShowroomPrice(double exShowroomPrice) {
		this.exShowroomPrice = exShowroomPrice;
	}

	/**
	 * @return the roadTaxAmount
	 */
	public double getRoadTaxAmount() {
		return roadTaxAmount;
	}

	/**
	 * @param roadTaxAmount the roadTaxAmount to set
	 */
	public void setRoadTaxAmount(double roadTaxAmount) {
		this.roadTaxAmount = roadTaxAmount;
	}

	/**
	 * @return the insuranceAmount
	 */
	public double getInsuranceAmount() {
		return insuranceAmount;
	}

	/**
	 * @param insuranceAmount the insuranceAmount to set
	 */
	public void setInsuranceAmount(double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}

	/**
	 * @return the configCityID
	 */
	public String getConfigCityID() {
		return configCityID;
	}

	/**
	 * @param configCityID the configCityID to set
	 */
	public void setConfigCityID(String configCityID) {
		this.configCityID = configCityID;
	}

	/**
	 * @return the configStateID
	 */
	public String getConfigStateID() {
		return configStateID;
	}

	/**
	 * @param configStateID the configStateID to set
	 */
	public void setConfigStateID(String configStateID) {
		this.configStateID = configStateID;
	}

	/**
	 * @return the isConfigurable
	 */
	public boolean isConfigurable() {
		return isConfigurable;
	}

	/**
	 * @param isConfigurable the isConfigurable to set
	 */
	public void setConfigurable(boolean isConfigurable) {
		this.isConfigurable = isConfigurable;
	}

	/**
	 * @return the configStatus
	 */
	public String getConfigStatus() {
		return configStatus;
	}

	/**
	 * @param configStatus the configStatus to set
	 */
	public void setConfigStatus(String configStatus) {
		this.configStatus = configStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerConfiguratorResponse [id=");
		builder.append(id);
		builder.append(", bikeId=");
		builder.append(bikeId);
		builder.append(", phoneNo=");
		builder.append(phoneNo);
		builder.append(", totalPrice=");
		builder.append(totalPrice);
		builder.append(", variantCode=");
		builder.append(variantCode);
		builder.append(", configuration=");
		builder.append(configuration);
		builder.append(", appId=");
		builder.append(appId);
		builder.append(", configCity=");
		builder.append(configCity);
		builder.append(", configState=");
		builder.append(configState);
		builder.append(", myoCity=");
		builder.append(myoCity);
		builder.append(", dealerDetail=");
		builder.append(dealerDetail);
		builder.append(", modelImage=");
		builder.append(modelImage);
		builder.append(", bikeName=");
		builder.append(bikeName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", salutation=");
		builder.append(salutation);
		builder.append(", customerFirstName=");
		builder.append(customerFirstName);
		builder.append(", customerLastName=");
		builder.append(customerLastName);
		builder.append(", badgename=");
		builder.append(badgename);
		builder.append(", exShowroomPrice=");
		builder.append(exShowroomPrice);
		builder.append(", roadTaxAmount=");
		builder.append(roadTaxAmount);
		builder.append(", insuranceAmount=");
		builder.append(insuranceAmount);
		builder.append(", configCityID=");
		builder.append(configCityID);
		builder.append(", configStateID=");
		builder.append(configStateID);
		builder.append(", isConfigurable=");
		builder.append(isConfigurable);
		builder.append(", configStatus=");
		builder.append(configStatus);
		builder.append("]");
		return builder.toString();
	}

}