package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.CONFIG_STATUS_BOOKED;
import static com.net.bosch.constants.Constants.DMS_DO_NOT_RETRY_MESSAGE;
import static com.net.bosch.constants.Constants.DMS_SUCCESS_MESSAGE;
import static com.net.bosch.constants.Constants.RETRY_COUNT;
import static com.net.bosch.constants.REResponse.GENERIC_OR_UNKNOWN_ERROR;
import static com.net.bosch.constants.REResponse.INSTORE_BOOKING_POSTING_IS_UNDER_PROCESS;
import static com.net.bosch.constants.REResponse.INSTORE_POSTING_FAILED;
import static com.net.bosch.constants.REResponse.INVALID_BOOKING_CASE_ID;
import static com.net.bosch.constants.REResponse.INVALID_REQUEST;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static com.net.bosch.utils.ApplicationHelper.checkOnlineBookingOptional;
import static com.net.bosch.utils.ApplicationHelper.checkOnlinePaymentOptional;
import static com.net.bosch.utils.ApplicationHelper.getInitialPaymentObject;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.net.bosch.constants.BookingStatus;
import com.net.bosch.constants.REResponse;
import com.net.bosch.constants.TransactionType;
import com.net.bosch.crmmaster.dao.OnlineBookingRepository;
import com.net.bosch.crmmaster.dao.OnlinePaymentDetailsRepository;
import com.net.bosch.crmmaster.dto.DynamicsBookingResponse;
import com.net.bosch.crmmaster.dto.InstoreBookingDMSResponseDTO;
import com.net.bosch.crmmaster.dto.NewRegistrationGuidUpdateDTO;
import com.net.bosch.crmmaster.dto.NewRegistrationGuidUpdateResponse;
import com.net.bosch.crmmaster.dto.OnlineBookingRequestDTO;
import com.net.bosch.crmmaster.dto.OnlineBookingSearchResponseDTO;
import com.net.bosch.crmmaster.dto.OnlinePaymentDetailsResponseDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdRequestDTO;
import com.net.bosch.crmmaster.dto.UserProfileResponseDTO;
import com.net.bosch.crmmaster.payment.collection.OnlineBooking;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentInfo;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class InStoreBookingService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OnlineBookingService onlineBookingService;
	@Autowired
	private OnlineBookingRepository onlineBookingRepository;
	@Autowired
	private OnlinePaymentDetailsRepository onlinePaymentDetailsRepository;
	@Autowired
	private RestTemplateService restTemplateService;

	/**
	 * @param dto
	 * @param paymentCaseId
	 * @return
	 */
	public REBaseResponse createInstoreBooking(@Valid OnlineBookingRequestDTO dto, String bookingCaseId,
			String configId) {
		long startTime = System.currentTimeMillis();
		logger.info("In createInstoreBooking() --");
		try {
			if (StringUtils.isNotBlank(configId)) {
				logger.info("Retrying DMS-Instore-Booking for Config Id {{}} & Mobile No {{}}", configId,
						dto.getMobile());

				OnlineBooking bookingResponse = checkOnlineBookingOptional(
						onlineBookingRepository.findByInStoreDynamicsRequestConfigid(configId));
				if (null == bookingResponse) {
					logger.error("Invalid Config-Id {{}} found while Retrying DMS-Instore-Booking.", configId);
					return getErrorResponse(INVALID_BOOKING_CASE_ID);
				}
				OnlinePaymentDetails paymentResponse = checkOnlinePaymentOptional(
						onlinePaymentDetailsRepository.findByBookingCaseId(bookingResponse.getBookingCaseId()));
				if (null == paymentResponse) {
					logger.error(
							"Invalid Booking-Cash-Id {{}} found in Payment collection while Retrying DMS-Instore-Booking.",
							bookingResponse.getBookingCaseId());
					return getErrorResponse(INVALID_BOOKING_CASE_ID);
				}
				if (isNotEmpty(paymentResponse.getDmsBookingId())) {
					logger.info(
							"For Booking-Cash-Id {{}}, Config Id {{}} & Mobile No {{}} DMS-Instore-Booking is already Posted By Batch-Job.",
							bookingResponse.getBookingCaseId(), configId, bookingResponse.getMobile());

					return getSuccessResponse(copyOnlineBookingResponse(bookingResponse, paymentResponse));
				}
				OnlinePaymentInfo firstPaymentObj = getInitialPaymentObject(paymentResponse);
				if (null == firstPaymentObj) {

					logger.error("Payment First Object Not Found for Booking-Cash-Id {{}}.",
							bookingResponse.getBookingCaseId());
					logger.info("Out createInstoreBooking(1) in {{}}ms.", System.currentTimeMillis() - startTime);
					return getErrorResponse(INVALID_BOOKING_CASE_ID);
				}
				if (StringUtils.equals(firstPaymentObj.getTransactionStage(),
						TransactionType.INSTORE_DMS_POSTED.getValue())
						&& (null == bookingResponse.getDynamicsResponse())) {

					logger.info("Out createInstoreBooking(2) in {{}}ms.", System.currentTimeMillis() - startTime);
					return getErrorResponse(INSTORE_BOOKING_POSTING_IS_UNDER_PROCESS,
							copyOnlineBookingResponse(bookingResponse, paymentResponse));
				}
				if (bookingResponse.getBookingStatus() == BookingStatus.POST_SUCCESS) {

					logger.info("Out createInstoreBooking(3) in {{}}ms.", System.currentTimeMillis() - startTime);
					return getSuccessResponse(copyOnlineBookingResponse(bookingResponse, paymentResponse));
				}
				if (bookingResponse.getBookingStatus() == BookingStatus.POST_FAIL
						&& firstPaymentObj.getRetryCount() == RETRY_COUNT) {

					logger.info("Out createInstoreBooking(4) in {{}}ms.", System.currentTimeMillis() - startTime);
					return getErrorResponse(INSTORE_POSTING_FAILED,
							copyOnlineBookingResponse(bookingResponse, paymentResponse));
				}
				REBaseResponse baseResponse = postInstoreTransactionToDMS(bookingResponse, paymentResponse, configId);

				logger.info("Out createInstoreBooking(5) in {{}}ms.", System.currentTimeMillis() - startTime);
				return baseResponse;
			}
			logger.info("Saving New DMS-Instore-Booking for Mobile No {{}}.", dto.getMobile());

			UserProfileResponseDTO userDetailsResponse = restTemplateService
					.callWebAPItoGetBasicDetails(dto.getInStoreDynamicsRequest().getMobileno());
			if (null != userDetailsResponse) {
				logger.info(
						"For DMS-Instore-Booking User Mobile no {{}} is Already registered, so setting user guid {{}}",
						dto.getInStoreDynamicsRequest().getMobileno(), userDetailsResponse.getData().getGuid());

				dto.setGuid(userDetailsResponse.getData().getGuid());
			}
			OnlineBooking bookingResponse = onlineBookingService.saveUserOnlineBikeBookingDetails(dto);
			OnlinePaymentDetails paymentResponse = onlineBookingService.saveInitialOnlineBookingPayment(bookingResponse,
					null, bookingResponse.getInStoreDynamicsRequest(), TransactionType.INSTORE_DMS_POSTED);

			bookingResponse.getInStoreDynamicsRequest()
					.setReferencenumber(paymentResponse.getPaymentInfo().get(0).getPaymentCaseId());
			paymentResponse.getPaymentInfo().get(0).getInStoreDynamicsRequest()
					.setReferencenumber(paymentResponse.getPaymentInfo().get(0).getPaymentCaseId());

			REBaseResponse baseResponse = postInstoreTransactionToDMS(bookingResponse, paymentResponse, null);

			logger.info("Out createInstoreBooking(6) in {{}}ms.", System.currentTimeMillis() - startTime);
			return baseResponse;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Saving DMS-Instore-Booking for Mobile No {{}}. Exception Message {{}},Exception Details {{}}",
					dto.getMobile(), e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param bookingResponse
	 * @param paymentResponse
	 * @param bookingCaseId
	 */
	private REBaseResponse postInstoreTransactionToDMS(OnlineBooking bookingResponse,
			OnlinePaymentDetails paymentResponse, String configId) {
		logger.info("Initiating DMS-Instore-Booking for Booking-Cash-Id {{}} & Mobile No {{}}",
				bookingResponse.getBookingCaseId(), bookingResponse.getMobile());

		InstoreBookingDMSResponseDTO inStoreBookingResponse = restTemplateService
				.postInstoreTransactionToDMS(bookingResponse.getInStoreDynamicsRequest());

		if (ObjectUtils.isEmpty(inStoreBookingResponse) || StringUtils.isBlank(inStoreBookingResponse.getBookingId())) {
			logger.error("DMS-Instore-Booking Failed for Booking-Cash-Id {{}} & Mobile No {{}}",
					bookingResponse.getBookingCaseId(), bookingResponse.getMobile());

			bookingResponse.setBookingStatus(BookingStatus.POST_FAIL);
			if (StringUtils.isNotBlank(configId)) {
				paymentResponse.getPaymentInfo().get(0).setRetryCount(1);
				logger.error(
						"Retrying DMS-Instore-Booking for Booking-Cash-Id {{}} & Mobile No {{}}, Increasing Retry Count.",
						bookingResponse.getBookingCaseId(), bookingResponse.getMobile());
			}
			validateDMSNotImplementedMessage(paymentResponse, inStoreBookingResponse.getMessage());

			return getErrorResponse(INSTORE_POSTING_FAILED, updateDMSResponseAndGetReturnResponse(bookingResponse,
					paymentResponse, inStoreBookingResponse, TransactionType.INSTORE_DMS_FAILED));
		}
		logger.info("DMS-Instore-Booking Posted Succesfully for Booking-Cash-Id {{}} & Mobile No {{}}",
				bookingResponse.getBookingCaseId(), bookingResponse.getMobile());
		bookingResponse.setBookingStatus(BookingStatus.POST_SUCCESS);

		onlineBookingService.updateConfigurationStatusInMongo(bookingResponse.getInStoreDynamicsRequest().getConfigid(),
				CONFIG_STATUS_BOOKED);

		return getSuccessResponse(updateDMSResponseAndGetReturnResponse(bookingResponse, paymentResponse,
				inStoreBookingResponse, TransactionType.INSTORE_DMS_POSTED));
	}

	/**
	 * @param bookingResponse
	 * @param paymentResponse
	 * @param inStoreBookingResponse
	 * @return
	 */
	private OnlineBookingSearchResponseDTO updateDMSResponseAndGetReturnResponse(OnlineBooking bookingResponse,
			OnlinePaymentDetails paymentResponse, InstoreBookingDMSResponseDTO inStoreBookingResponse,
			TransactionType transactionType) {

		DynamicsBookingResponse dynamicsResponse = new DynamicsBookingResponse(inStoreBookingResponse.getMessage(),
				inStoreBookingResponse.getBookingId());

		if (TransactionType.INSTORE_DMS_POSTED == transactionType) {
			dynamicsResponse.setPostedTimestamp(new Date());
			paymentResponse.setDmsBookingId(inStoreBookingResponse.getBookingId());
		}
		bookingResponse.setDynamicsResponse(dynamicsResponse);
		paymentResponse.getPaymentInfo().get(0).setDynamicsResponse(dynamicsResponse);
		paymentResponse.getPaymentInfo().get(0).setTransactionStage(transactionType.getValue());

		bookingResponse = onlineBookingRepository.save(bookingResponse);
		paymentResponse = onlinePaymentDetailsRepository.save(paymentResponse);

		logger.info(
				"For Booking-Cash-Id {{}} & Mobile No {{}} DMS-Instore-Booking Response Updated in Mongo collections.",
				bookingResponse.getBookingCaseId(), bookingResponse.getMobile());

		return copyOnlineBookingResponse(bookingResponse, paymentResponse);
	}

	/**
	 * @param bookingResponse
	 * @param paymentResponse
	 * @return
	 */
	private OnlineBookingSearchResponseDTO copyOnlineBookingResponse(OnlineBooking bookingResponse,
			OnlinePaymentDetails paymentResponse) {

		OnlineBookingSearchResponseDTO bookingResult = new OnlineBookingSearchResponseDTO();
		OnlinePaymentDetailsResponseDTO paymentDetailsResult = new OnlinePaymentDetailsResponseDTO();

		BeanUtils.copyProperties(bookingResponse, bookingResult);
		BeanUtils.copyProperties(paymentResponse, paymentDetailsResult);
		bookingResult.setPaymentDetails(paymentDetailsResult);

		return bookingResult;
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse updateDMSResponseForInstoreBookings(@Valid UpdateExcellonMsdRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateDMSResponseForInstoreBookings() --");

		OnlineBooking onlineBooking = checkOnlineBookingOptional(
				onlineBookingRepository.findByBookingCaseId(dto.getBookingCaseId()));
		if (null == onlineBooking) {
			logger.error("Invalid Booking-Cash-Id {{}} found while Updating DMS-Instore-Booking response.",
					dto.getBookingCaseId());

			return getErrorResponse(REResponse.INVALID_BOOKING_CASE_ID);
		}
		OnlinePaymentDetails paymentDetails = checkOnlinePaymentOptional(
				onlinePaymentDetailsRepository.findByBookingCaseId(dto.getBookingCaseId()));
		if (null == paymentDetails) {
			logger.error(
					"Invalid Booking-Cash-Id {{}} found in Payment collection while Updating DMS-Instore-Booking response.",
					onlineBooking.getPaymentObjectId());
			return getErrorResponse(REResponse.INVALID_BOOKING_CASE_ID);
		}
		if (!ObjectUtils.isEmpty(dto.getDynamicsResponse())) {

			onlineBooking.setBookingStatus(dto.getBookingStatus());
			onlineBooking.setDynamicsResponse(dto.getDynamicsResponse());
			paymentDetails.getPaymentInfo().get(0).setDynamicsResponse(dto.getDynamicsResponse());

			if (isNotEmpty(dto.getDynamicsResponse().getBookingid())) {
				paymentDetails.setDmsBookingId(dto.getDynamicsResponse().getBookingid());
				Date dmsPostedDate = new Date();
				onlineBooking.getDynamicsResponse().setPostedTimestamp(dmsPostedDate);
				paymentDetails.getPaymentInfo().get(0).getDynamicsResponse().setPostedTimestamp(dmsPostedDate);
				paymentDetails.getPaymentInfo().get(0)
						.setTransactionStage(TransactionType.INSTORE_DMS_POSTED.getValue());

				logger.info("DMS-Instore-Booking Posted Succesfully for Booking-Cash-Id {{}} & Mobile No {{}}",
						onlineBooking.getBookingCaseId(), onlineBooking.getMobile());
			} else {
				logger.error(
						"For Booking-Cash-Id {{}} & Mobile No {{}} DMS-Instore-Booking Failed so Increasing the Retry Count.",
						onlineBooking.getBookingCaseId(), onlineBooking.getMobile());

				int previousRetryCount = paymentDetails.getPaymentInfo().get(0).getRetryCount();
				paymentDetails.getPaymentInfo().get(0).setRetryCount(
						(previousRetryCount < RETRY_COUNT) ? (previousRetryCount + 1) : previousRetryCount);

				validateDMSNotImplementedMessage(paymentDetails, dto.getDynamicsResponse().getMessage());
			}
			updateBatchDMSResponse(onlineBooking, paymentDetails);

			logger.info("Out updateDMSResponseForInstoreBookings() in {{}}ms.", System.currentTimeMillis() - startTime);
			return getSuccessResponse(REResponse.DMS_EXCELLON_RESPONSE_UPDATED_SUCCESSFULLY);
		}
		logger.error(
				"For Booking-Cash-Id {{}} & Mobile No {{}} DMS-Instore-Booking Response is NULL/BLANK so Increasing the Retry Count.",
				onlineBooking.getBookingCaseId(), onlineBooking.getMobile());

		int previousRetryCount = paymentDetails.getPaymentInfo().get(0).getRetryCount();
		paymentDetails.getPaymentInfo().get(0)
				.setRetryCount((previousRetryCount < RETRY_COUNT) ? (previousRetryCount + 1) : previousRetryCount);
		paymentDetails.getPaymentInfo().get(0).setTransactionStage(TransactionType.INSTORE_DMS_FAILED.getValue());

		updateBatchDMSResponse(onlineBooking, paymentDetails);

		logger.info("Out updateDMSResponseForInstoreBookings() in {{}}ms.", System.currentTimeMillis() - startTime);
		return getSuccessResponse(REResponse.DMS_EXCELLON_RESPONSE_UPDATED_SUCCESSFULLY);
	}

	/**
	 * @param onlineBooking
	 * @param paymentDetails
	 */
	private void updateBatchDMSResponse(OnlineBooking onlineBooking, OnlinePaymentDetails paymentDetails) {
		onlineBookingRepository.save(onlineBooking);
		onlinePaymentDetailsRepository.save(paymentDetails);

		logger.info("DMS-Instore-Booking Response Updated in Mongo collections.");
	}

	/**
	 * @param paymentDetails
	 * @param dmsMessage
	 * @return
	 */
	private OnlinePaymentDetails validateDMSNotImplementedMessage(OnlinePaymentDetails paymentDetails,
			String dmsMessage) {
		if (isNotEmpty(dmsMessage) && dmsMessage.contains(DMS_DO_NOT_RETRY_MESSAGE)
				|| dmsMessage.toLowerCase().contains(DMS_SUCCESS_MESSAGE.toLowerCase())) {
			logger.error(
					"For Booking-Cash-Id {{}} & Mobile No {{}} DMS-Instore-Booking Duplicate Error Message {{}} Found so Setting Retry Count to {{}}",
					paymentDetails.getBookingCaseId(),
					paymentDetails.getPaymentInfo().get(0).getInStoreDynamicsRequest().getMobileno(), dmsMessage,
					RETRY_COUNT);

			paymentDetails.getPaymentInfo().get(0).setRetryCount(RETRY_COUNT);
		}
		return paymentDetails;
	}

	/**
	 * @param dtoList
	 * @return
	 */
	public REBaseResponse updateGuidForInstoreBookings(@Valid List<NewRegistrationGuidUpdateDTO> dtoList) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateGuidForInstoreBookings() --");
		try {
			if (CollectionUtils.isEmpty(dtoList)) {
				logger.error("For GUID Update in InStore-Booking Input List is Blank/Null.");
				return getErrorResponse(INVALID_REQUEST);
			}
			List<NewRegistrationGuidUpdateResponse> returnList = new LinkedList<>();

			for (NewRegistrationGuidUpdateDTO bean : dtoList) {
				if (isEmpty(bean.getGuid()) || isEmpty(bean.getMobileNo())) {
					logger.error("Found Blank Guid {{}} or Mobile No {{}} while Updating Guid for InStore-Booking.",
							bean.getGuid(), bean.getMobileNo());
					returnList.add(new NewRegistrationGuidUpdateResponse(bean.getGuid(), bean.getMobileNo(),
							"Either Guid or Mobile is Blank."));
					continue;
				}
				List<OnlineBooking> bookingList = onlineBookingRepository
						.findByInStoreDynamicsRequestMobileno(bean.getMobileNo());
				if (CollectionUtils.isEmpty(bookingList)) {
					returnList.add(new NewRegistrationGuidUpdateResponse(bean.getGuid(), bean.getMobileNo(),
							"No Bookings Found With Mobile No."));
				} else {
					updateGuidForInstoreBookings(bookingList, bean, returnList);
				}
			}
			logger.info("Out updateGuidForInstoreBookings() in {{}}ms.", System.currentTimeMillis() - startTime);
			return getSuccessResponse(returnList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating GUID for Instore Bookings. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param bookingList
	 * @param bean
	 * @param returnList
	 */
	private void updateGuidForInstoreBookings(List<OnlineBooking> bookingList, NewRegistrationGuidUpdateDTO bean,
			List<NewRegistrationGuidUpdateResponse> returnList) {

		for (OnlineBooking bookingBean : bookingList) {
			OnlinePaymentDetails paymentResponse = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseId(bookingBean.getBookingCaseId()));
			if (null != paymentResponse) {

				logger.info(
						"Found Booking Details For Mobile No {{}} in Both Collection. So Updating in Both Collections.",
						bean.getMobileNo());
				bookingBean.setGuid(bean.getGuid());
				paymentResponse.setGuid(bean.getGuid());

				onlineBookingRepository.save(bookingBean);
				onlinePaymentDetailsRepository.save(paymentResponse);

				returnList.add(new NewRegistrationGuidUpdateResponse(bean.getGuid(), bean.getMobileNo(),
						"Guid Updated Successfully for Booking Cash Id " + bookingBean.getBookingCaseId()));
			} else {
				logger.debug(
						"Found Booking Details For Mobile No {{}} Only in parent Collection. So Updating in Parent Collection Only.",
						bean.getMobileNo());

				bookingBean.setGuid(bean.getGuid());
				onlineBookingRepository.save(bookingBean);

				returnList.add(new NewRegistrationGuidUpdateResponse(bean.getGuid(), bean.getMobileNo(),
						"Guid Updated Successfully Only In Booking for Booking Cash Id "
								+ bookingBean.getBookingCaseId()));
			}
		}
	}
}
