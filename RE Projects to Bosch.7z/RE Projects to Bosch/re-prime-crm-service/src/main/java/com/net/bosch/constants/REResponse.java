package com.net.bosch.constants;

/**
 * These Enums are used for API responses Code & Message.
 * 
 * @author pushkarkhosla
 *
 */
public enum REResponse {

	/**
	 * Success Code & Message.
	 */
	SUCCESS("200", "Success."),

	/**
	 * Error Code & Message.
	 */
	GENERIC_OR_UNKNOWN_ERROR("4000", "Generic Or Unknown Error."), INVALID_REQUEST("4001", "Invalid Request."),

	/**
	 * User Specific Error & Message.
	 */
	USER_NOT_FOUND("1001", "User Not Found."), USER_VEHICLES_NOT_FOUND("1002", "User Vehicles Not Found."),
	INVALID_PURCHASE_DATE("1003", "Invalid Purchase Date."), INVALID_ENGINE_NUMBER("1004", "Invalid Engine Number."),

	DOCUMENTS_REQUIRED("1005", "Documents Required."), INVALID_DOCUMENTS_EXTENSION("1006", "Incompatible file format."),
	INVALID_MOBILE_NUMBER("1007", "Invalid Mobile Number."),
	USER_VEHICLE_ADDED_SUCCESSFULLY("1008", "User Vehicle Added Successfully."),
	NO_MODELS_AVAILABLE("1009", "No Models Available."),
	NO_MODEL_VARIENTS_AVAILABLE("1010", "Models Varients Not Available."),
	USER_VEHICLES_UPDATED_SUCCESSFULLY("1011", "User Vehicles Updated Successfully."),

	MAXIMUM_FILE_SIZE_EXCEEDED("1012", "Maximum File Size Exceeded."),

	INVALID_PURCHASE_DATE_FORMAT("1013", "Invalid Purchase Date Format."),
	PURCHASE_DATE_CAN_NOT_BE_FUTURE_DATE("1014", "Purchase Date Can not be Future Date."),

	REGISTRATION_NUMBER_MUST_BE_ALPHANUMERIC("1015", "Registration Number must be Alphanumeric."),
	INVALID_REGISTRATION_NUMBER_LENGTH("1016", "Enter Characters within the range of 8-10 digits."),

	ENGINE_NUMBER_MUST_BE_ALPHANUMERIC("1017", "Enter valid engine number"),
	INVALID_ENGINE_NUMBER_LENGTH("1018", "Enter valid engine number"),

	USER_MOBILE_NUMBER_REQUIRED("1019", "User Mobile Number Is Required."),
	USER_GUID_REQUIRED("1020", "User GUID is Required."),

	ONE_FIELD_IS_MANDATORY("1021", "One of the fields is mandatory."),

	INVALID_REGIS_NUMBER("1022", "Enter valid registration number."),
	INVALID_REGIS_NUMBER_LENGTH("1023", "Registration number must be in range of 8-10 characters."),

	INVALID_CHASSIS_NUMBER("1024", "Enter valid chassis number."),
	INVALID_CHASSIS_NUMBER_LENGTH("1025", "Chassis number must have 17 characters."),
	CHASSIS_NUMBER_MUST_BE_ALPHANUMERIC("1026", "Chassis Number must be Alphanumeric."),
	PLEASE_TRY_ADDING_VEHICLE_WITH_CHASSIS_NO("1027", "Please try adding vehicle with Chassis Number."),
	CALL_CUSTOMER_SUPPORT("1028", "Call the customer support."),
	NO_BOOKING_DETAILS_FOUND("1029", "No Bike Booking Details Found."),
	ONLINE_PAYMENT_DETAILS_SAVED_SUCCESSFULLY("1030", "Payment Details Saved Successfully."),
	INVALID_GUID_OR_BOOKING_CASE_ID("1031", "Invalid Guid Or Booking Case Id."),
	INVALID_BOOKING_CASE_ID("1032", "Invalid Booking Case Id."),
	ONLINE_BOOKING_DETAILS_UPDATED_SUCCESSFULLY("1033", "Booking Details Updated Successfully."),
	DMS_EXCELLON_RESPONSE_UPDATED_SUCCESSFULLY("1034", "DMS-Excellon Response Updated Successfully."),
	PAYMENT_KEY_BALANCE_PAYMENT_GENERATION_ERROR("1035", "Payment Key Generation Error for Balance Payment."),
	ONLINE_BALANCE_PAYMENT_DETAILS_SAVED_SUCCESSFULLY("1036", "Balance Payment Details Saved Successfully."),
	UNABLE_TO_SAVE_ONLINE_BALANCE_PAYMENT_DETAILS("1037", "Unable to save Balance Payment Details."),
	PAYMENT_DETAILS_UPDATED_SUCCESSFULLY_FOR_BALANCE_PAYMENT("1038",
			"Payment Details Updated Successfully for Balance Payment."),
	INVALID_PAYMENT_KEY("1039", "Invalid Payment Key."), PAYMENT_KEY_EXPIRED("1040", "Payment link is Expired."),
	DEALER_SOURCE_NOT_FOUND("1041", "Dealer Source Not Found."),
	NO_BALANCE_PAYMENT_BOOKING_DETAILS_FOUND("1042", "No Balance Payment Booking Details Found."),
	TINY_URL_BALANCE_PAYMENT_GENERATION_ERROR("1043", "Tiny URL Generation Error for Balance Payment."),
	BOOKING_ID_REQUIRED("1044", "Booking Id Required."),
	MOBILE_UPDATED_SUCCESSFULLY_IN_VEHICLE_RECORD("1045", "Mobile Number updated successfully in Vehicle Record."),
	NO_RECORDS_FOUND("1046", "No Records Found."), DMS_POSTED_SUCCESSFULLY("1047", "DMS Posted Successfully."),
	DMS_POSTING_FAILS("1048", "DMS Posting Fails."), USER_VEHICLES_NOT_UPDATED("1049", "User Vehicles Not Updated."),
	DUPLICATE_VEHICLE_FOUND("1050", "Engine number and chassis number already exists."),
	USER_VEHICLE_CHASSIS_NUMBER_REQUIRED("1051", "User Vehicle Chassis Number Is Required."),
	USER_VEHICLE_ENGINE_NUMBER_REQUIRED("1052", "User Vehicle Engine Number Is Required."),
	DUPLICATE_VEHICLE_FOUND_PENDING("1053",
			"This motorcycle onboarding is already in-progress. You will see your motorcycle under the Motorcycle menu once your request is approved."),
	DUPLICATE_VEHICLE_FOUND_VERIFIED("1054",
			"This motorcycle already exists against your profile. Please try entering a different chassis number to add a new motorcycle."),
	USER_VEHICLE_STATUS_ALREADY_VERIFIED("1055", "User Vehicles Status Already Verified."),
	INVALID_DMS_TRANSACTION_TYPE("1056", "Invalid DMS Transaction Type."),
	INVALID_USER_GUID("1057", "Invalid User GUID."),
	NO_DATA_FOUND_TO_WRITE_IN_FIREBASE("1058", "No Data Found to write in Firebase."),
	SERVICE_HISTORY_SUCCESSFULLY_WRITTEN_TO_FIREBASE("1059", "Service History Successfully Written to Firebase."),
	INSTORE_POSTING_FAILED("1060", "Instore Posting Failed."),
	INVALID_TRANSACTION_TYPE("1061", "Invalid Transaction Type Found."),
	INSTORE_BOOKING_POSTING_IS_UNDER_PROCESS("1062", "Instore Booking Posting is Under Process."),
	FINANCE_DETAILS_SUCCESSFULLY_WRITTEN_TO_FIREBASE("1063", "Finance Details Successfully Written to Firebase."),
	DUPLICATE_USER_VEHICLE_FOUND("1064", "Duplicate User Vehicle Details Available."),
	NO_VERIFIED_USER_VEHICLE_FOUND("1065", "No Verified Vehicles Found with Given Details.");

	private String code;
	private String message;

	private REResponse(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

}
