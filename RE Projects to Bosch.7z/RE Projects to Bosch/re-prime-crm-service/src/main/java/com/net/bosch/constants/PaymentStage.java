package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum PaymentStage {

	INITIAL_PAYMENT("INITIAL PAYMENT"), BALANCE_PAYMENT("BALANCE PAYMENT");

	private String value;

	private PaymentStage(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
