package com.net.bosch.crmmaster.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.crmmaster.dto.AppointmentSlotDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotListDTO;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash("BookedAppointment")
public class BookedAppointmentSlot implements DomainObject{	
	
	private static final long serialVersionUID = 690094843433563154L;

	@Id
	public String id;
	
	List< AppointmentSlotDTO> data;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<AppointmentSlotDTO> getData() {
		return data;
	}

	public void setData(List<AppointmentSlotDTO> data) {
		this.data = data;
	}
			
}
