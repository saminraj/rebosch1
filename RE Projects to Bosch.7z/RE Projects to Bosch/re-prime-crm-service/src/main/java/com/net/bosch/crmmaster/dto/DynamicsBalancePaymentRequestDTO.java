package com.net.bosch.crmmaster.dto;

import static com.net.bosch.constants.Constants.DMS_EXCELLON_PAYMENT_SOURCE;

import java.io.Serializable;

public class DynamicsBalancePaymentRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1786712639182986455L;

	private String bookingNo;
	private String paybleAmount;
	private String paymentDoneDateTime;
	private String paymentReference;
	private String paymentSource;
	private String paymentStatus;

	public DynamicsBalancePaymentRequestDTO() {
	}

	/**
	 * @param bookingNo
	 * @param paybleAmount
	 * @param paymentDoneDateTime
	 * @param paymentReference
	 * @param paymentSource
	 * @param paymentStatus
	 */
	public DynamicsBalancePaymentRequestDTO(String bookingNo, Double paybleAmount) {
		super();
		this.bookingNo = bookingNo;
		this.paybleAmount = String.valueOf(paybleAmount);
		this.paymentSource = DMS_EXCELLON_PAYMENT_SOURCE;
	}

	/**
	 * @return the bookingNo
	 */
	public String getBookingNo() {
		return bookingNo;
	}

	/**
	 * @param bookingNo the bookingNo to set
	 */
	public void setBookingNo(String bookingNo) {
		this.bookingNo = bookingNo;
	}

	/**
	 * @return the paybleAmount
	 */
	public String getPaybleAmount() {
		return paybleAmount;
	}

	/**
	 * @param paybleAmount the paybleAmount to set
	 */
	public void setPaybleAmount(String paybleAmount) {
		this.paybleAmount = paybleAmount;
	}

	/**
	 * @return the paymentDoneDateTime
	 */
	public String getPaymentDoneDateTime() {
		return paymentDoneDateTime;
	}

	/**
	 * @param paymentDoneDateTime the paymentDoneDateTime to set
	 */
	public void setPaymentDoneDateTime(String paymentDoneDateTime) {
		this.paymentDoneDateTime = paymentDoneDateTime;
	}

	/**
	 * @return the paymentReference
	 */
	public String getPaymentReference() {
		return paymentReference;
	}

	/**
	 * @param paymentReference the paymentReference to set
	 */
	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}

	/**
	 * @return the paymentSource
	 */
	public String getPaymentSource() {
		return paymentSource;
	}

	/**
	 * @param paymentSource the paymentSource to set
	 */
	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DynamicsBalancePaymentRequestDTO [bookingNo=");
		builder.append(bookingNo);
		builder.append(", paybleAmount=");
		builder.append(paybleAmount);
		builder.append(", paymentDoneDateTime=");
		builder.append(paymentDoneDateTime);
		builder.append(", paymentReference=");
		builder.append(paymentReference);
		builder.append(", paymentSource=");
		builder.append(paymentSource);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append("]");
		return builder.toString();
	}

}
