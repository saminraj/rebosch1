
package com.net.bosch.crmmaster.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "preview_url",
    "shorten_url",
    "title",
    "value",
    "data",
    "type"
})
public class Content {

    @JsonProperty("preview_url")
    private Boolean previewUrl=Boolean.FALSE;
    @JsonProperty("shorten_url")
    private Boolean shortenUrl=Boolean.FALSE;
    @JsonProperty("title")
    private String title;
    @JsonProperty("value")
    private String value;
    @JsonProperty("data")
    private Data data;
    @JsonProperty("type")
    private String type;

    @JsonProperty("preview_url")
    public Boolean getPreviewUrl() {
        return previewUrl;
    }

    @JsonProperty("preview_url")
    public void setPreviewUrl(Boolean previewUrl) {
        this.previewUrl = previewUrl;
    }

    @JsonProperty("shorten_url")
    public Boolean getShortenUrl() {
        return shortenUrl;
    }

    @JsonProperty("shorten_url")
    public void setShortenUrl(Boolean shortenUrl) {
        this.shortenUrl = shortenUrl;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("value")
    public String getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(String value) {
        this.value = value;
    }

    @JsonProperty("data")
    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(Data data) {
        this.data = data;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

}
