package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

/**
 * @author pushkarkhosla
 *
 */
public class NewRegistrationGuidUpdateDTO {

	@NotBlank
	@NotEmpty
	private String guid;

	@NotBlank
	@NotEmpty
	private String mobileNo;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("NewRegistrationGuidUpdateDTO [guid=");
		builder.append(guid);
		builder.append(", mobileNo=");
		builder.append(mobileNo);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
