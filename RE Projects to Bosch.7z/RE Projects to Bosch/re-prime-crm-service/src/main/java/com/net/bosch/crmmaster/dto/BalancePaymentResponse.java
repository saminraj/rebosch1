package com.net.bosch.crmmaster.dto;

import com.net.bosch.constants.PaymentStage;

/**
 * @author pushkarkhosla
 *
 */
public class BalancePaymentResponse {

	private String dealerSource;
	private String dmsExcellonBookingId;
	private String bookingCaseId;

	private String paymentCaseId;
	private String paymentStatus;
	private PaymentStage paymentStage;

	public BalancePaymentResponse() {
	}

	/**
	 * @param bookingCaseId
	 * @param dmsExcellonBookingId
	 * @param paymentCaseId
	 * @param paymentStatus
	 * @param paymentStage
	 */
	public BalancePaymentResponse(String dealerSource, String bookingCaseId, String dmsExcellonBookingId,
			String paymentCaseId, String paymentStatus, PaymentStage paymentStage) {
		super();
		this.dealerSource = dealerSource;
		this.bookingCaseId = bookingCaseId;
		this.dmsExcellonBookingId = dmsExcellonBookingId;
		this.paymentCaseId = paymentCaseId;
		this.paymentStatus = paymentStatus;
		this.paymentStage = paymentStage;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the dmsExcellonBookingId
	 */
	public String getDmsExcellonBookingId() {
		return dmsExcellonBookingId;
	}

	/**
	 * @param dmsExcellonBookingId the dmsExcellonBookingId to set
	 */
	public void setDmsExcellonBookingId(String dmsExcellonBookingId) {
		this.dmsExcellonBookingId = dmsExcellonBookingId;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the paymentStage
	 */
	public PaymentStage getPaymentStage() {
		return paymentStage;
	}

	/**
	 * @param paymentStage the paymentStage to set
	 */
	public void setPaymentStage(PaymentStage paymentStage) {
		this.paymentStage = paymentStage;
	}

}
