package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NearByDealerDTO{	

	private String id;	
	
	private String dealerId;
	
	private String state;
	
	private String pincode;
	
	private String phone;
	
	private String longitude;
	
	private String latitude;
	
	private String emailId;
	
	private String dealerName;
	
	private String city_id;
	
	private String city;
	
	private String branchName;
	
	private String addressLine2;
	
	private String addressLine1;		

	private String Locality;
	
	private String dealerType;
	
	private String dealerStatus;
	
	private String dealerSource;
	
	private String branchCode;
	
	private String distance;
	
	private String pickUpServiceAvailable;
	
	private String doorStepServiceAvailable;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getCity_id() {
		return city_id;
	}

	public void setCity_id(String city_id) {
		this.city_id = city_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getLocality() {
		return Locality;
	}

	public void setLocality(String locality) {
		Locality = locality;
	}

	public String getDealerType() {
		return dealerType;
	}

	public void setDealerType(String dealerType) {
		this.dealerType = dealerType;
	}

	public String getDealerStatus() {
		return dealerStatus;
	}

	public void setDealerStatus(String dealerStatus) {
		this.dealerStatus = dealerStatus;
	}

	public String getDealerSource() {
		return dealerSource;
	}

	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}	

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getPickUpServiceAvailable() {
		return pickUpServiceAvailable;
	}

	public void setPickUpServiceAvailable(String pickUpServiceAvailable) {
		this.pickUpServiceAvailable = pickUpServiceAvailable;
	}

	public String getDoorStepServiceAvailable() {
		return doorStepServiceAvailable;
	}

	public void setDoorStepServiceAvailable(String doorStepServiceAvailable) {
		this.doorStepServiceAvailable = doorStepServiceAvailable;
	}
			
}
