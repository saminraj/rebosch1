
package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class Locality implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8360261029582908719L;

	private String country;
	private String language;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Locality [country=");
		builder.append(country);
		builder.append(", language=");
		builder.append(language);
		builder.append("]");
		return builder.toString();
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

}
