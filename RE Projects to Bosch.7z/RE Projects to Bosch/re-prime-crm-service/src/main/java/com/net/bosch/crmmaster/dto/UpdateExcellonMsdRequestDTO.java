package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.net.bosch.constants.BookingStatus;

/**
 * @author pushkarkhosla
 *
 */
public class UpdateExcellonMsdRequestDTO {

	@NotNull
	@NotBlank
	private String bookingCaseId;

	@NotNull
	@NotBlank
	private String paymentCaseId;

	private String guid;

	private String billDeskAuthStatus;

	/**
	 * DMS - MSD Api Response
	 */
	private DynamicsBookingResponse dynamicsResponse;

	/**
	 * Excellon Api Response
	 */
	private ExcellonBookingPaymentResponse excellonResponse;

	private BookingStatus bookingStatus;
	private String paymentStatus;
	private String billDeskTransactionId;

	private String transactionType;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateExcellonMsdRequestDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", guid=");
		builder.append(guid);
		builder.append(", billDeskAuthStatus=");
		builder.append(billDeskAuthStatus);
		builder.append(", dynamicsResponse=");
		builder.append(dynamicsResponse);
		builder.append(", excellonResponse=");
		builder.append(excellonResponse);
		builder.append(", bookingStatus=");
		builder.append(bookingStatus);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", billDeskTransactionId=");
		builder.append(billDeskTransactionId);
		builder.append(", transactionType=");
		builder.append(transactionType);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the billDeskAuthStatus
	 */
	public String getBillDeskAuthStatus() {
		return billDeskAuthStatus;
	}

	/**
	 * @param billDeskAuthStatus the billDeskAuthStatus to set
	 */
	public void setBillDeskAuthStatus(String billDeskAuthStatus) {
		this.billDeskAuthStatus = billDeskAuthStatus;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the billDeskTransactionId
	 */
	public String getBillDeskTransactionId() {
		return billDeskTransactionId;
	}

	/**
	 * @param billDeskTransactionId the billDeskTransactionId to set
	 */
	public void setBillDeskTransactionId(String billDeskTransactionId) {
		this.billDeskTransactionId = billDeskTransactionId;
	}

	/**
	 * @return the bookingStatus
	 */
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the excellonResponse
	 */
	public ExcellonBookingPaymentResponse getExcellonResponse() {
		return excellonResponse;
	}

	/**
	 * @param excellonResponse the excellonResponse to set
	 */
	public void setExcellonResponse(ExcellonBookingPaymentResponse excellonResponse) {
		this.excellonResponse = excellonResponse;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the dynamicsResponse
	 */
	public DynamicsBookingResponse getDynamicsResponse() {
		return dynamicsResponse;
	}

	/**
	 * @param dynamicsResponse the dynamicsResponse to set
	 */
	public void setDynamicsResponse(DynamicsBookingResponse dynamicsResponse) {
		this.dynamicsResponse = dynamicsResponse;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

}
