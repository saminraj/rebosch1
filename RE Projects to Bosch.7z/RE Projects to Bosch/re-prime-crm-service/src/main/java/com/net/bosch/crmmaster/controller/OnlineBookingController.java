package com.net.bosch.crmmaster.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.crmmaster.dto.BalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.FinanceBookingDetailsDTO;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyRequestDTO;
import com.net.bosch.crmmaster.dto.NewRegistrationGuidUpdateDTO;
import com.net.bosch.crmmaster.dto.OnlineBookingRequestDTO;
import com.net.bosch.crmmaster.dto.OnlinePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.SearchBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.SearchOnlineBookingRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdRequestDTO;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyRequestDTO;
import com.net.bosch.crmmaster.service.BalancePaymentService;
import com.net.bosch.crmmaster.service.InStoreBookingService;
import com.net.bosch.crmmaster.service.OnlineBookingService;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/booking/")
public class OnlineBookingController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OnlineBookingService onlineBookingService;
	@Autowired
	private BalancePaymentService balancePaymentService;
	@Autowired
	private InStoreBookingService inStoreBookingService;

	@PostMapping(value = "save")
	public REBaseResponse saveBikeBookingDetails(@RequestBody @Valid OnlineBookingRequestDTO dto) {

		logger.info("Calling /booking/save/ api ,Input Params {{}}", dto);

		return onlineBookingService.saveBikeBookingDetails(dto);
	}

	@PostMapping(value = "updateExcellonMsdResponse")
	public REBaseResponse updateExcellonMsdResponse(@RequestBody @Valid UpdateExcellonMsdRequestDTO dto) {

		logger.info("Calling /booking/updateExcellonMsdResponse/ api ,Input Params {{}}", dto);

		return onlineBookingService.updateExcellonMsdResponse(dto);
	}

	@PostMapping(value = "search")
	public REBaseResponse searchBikeBookingDetails(@RequestBody @Valid SearchOnlineBookingRequestDTO dto) {

		logger.info("Calling /booking/search/ api ,Input Params {{}}", dto);

		return onlineBookingService.searchBikeBookingDetails(dto);
	}

	@PostMapping(value = "savePayment")
	public REBaseResponse saveOnlinePaymentDetails(@RequestBody @Valid OnlinePaymentRequestDTO dto) {

		logger.info("Calling /booking/savePayment/ api ,Input Params {{}}", dto);

		return onlineBookingService.saveOnlinePaymentDetails(dto);
	}

	@GetMapping(value = "getBookingTransactions", produces = "application/json")
	public REBaseResponse getOnlineBookingTransactions(
			@RequestParam(value = "transactionType", required = true) String transactionType) {

		logger.info("Calling /booking/getBookingTransactions/ api. Transaction Type {{}}", transactionType);

		return onlineBookingService.getBookingTransactions(transactionType);
	}

	@PostMapping(value = "balancePayment/generatePaymentKey")
	public REBaseResponse generatePaymentKey(@RequestBody @Valid GeneratePaymentKeyRequestDTO dto) {

		logger.info("Calling booking/balancePayment/generatePaymentKey/ api ,Input Params {{}}", dto);

		return balancePaymentService.generatePaymentKey(dto);
	}

	@PostMapping(value = "balancePayment/validatePaymentKey")
	public REBaseResponse validatePaymentKey(@RequestBody @Valid ValidatePaymentKeyRequestDTO dto) {

		logger.info("Calling booking/balancePayment/validatePaymentKey/ api ,Input Params {{}}", dto);

		return balancePaymentService.validatePaymentKey(dto);
	}

	@PostMapping(value = "balancePayment/save")
	public REBaseResponse saveBalancePayment(@RequestBody @Valid BalancePaymentRequestDTO dto) {

		logger.info("Calling booking/balancePayment/save/ api ,Input Params {{}}", dto);

		return balancePaymentService.saveBalancePayment(dto);
	}

	@PostMapping(value = "balancePayment/update")
	public REBaseResponse updateBalancePayment(@RequestBody @Valid UpdateBalancePaymentRequestDTO dto) {

		logger.info("Calling booking/balancePayment/update/ api ,Input Params {{}}", dto);

		return balancePaymentService.updateBalancePayment(dto);
	}

	@PostMapping(value = "balancePayment/search")
	public REBaseResponse searchBalancePayment(@RequestBody @Valid SearchBalancePaymentRequestDTO dto) {

		logger.info("Calling booking/balancePayment/search/ api ,Input Params {{}}", dto);

		return balancePaymentService.searchBalancePayment(dto);
	}

	@PostMapping(value = "balancePayment/updateExcellonMsdBalancePaymentResponse")
	public REBaseResponse updateExcellonMsdBalancePaymentResponse(
			@RequestBody @Valid UpdateExcellonMsdBalancePaymentRequestDTO dto) {

		logger.info("Calling /booking/balancePayment/updateExcellonMsdBalancePaymentResponse/ api ,Input Params {{}}",
				dto);

		return balancePaymentService.updateExcellonMsdBalancePaymentResponse(dto);
	}

	@PostMapping(value = "instore/save")
	public REBaseResponse createInstoreBooking(
			@RequestParam(value = "bookingCaseId", required = false, defaultValue = "") String bookingCaseId,
			@RequestParam(value = "configId", required = false, defaultValue = "") String configId,
			@RequestBody @Valid OnlineBookingRequestDTO dto) {

		logger.info("Calling /booking/instore/save api ,Input Params BookingCaseId {{}},Config Id {{}} And DTO {{}}",
				bookingCaseId, configId, dto);

		return inStoreBookingService.createInstoreBooking(dto, bookingCaseId, configId);
	}

	@PostMapping(value = "instore/updateGuid")
	public REBaseResponse updateGuidForInstoreBookings(@RequestBody @Valid List<NewRegistrationGuidUpdateDTO> dtoList) {

		logger.info("Calling /booking/instore/updateGuid api ,Input Params DTO {{}}", dtoList);

		return inStoreBookingService.updateGuidForInstoreBookings(dtoList);
	}

	@PostMapping(value = "syncBookingsToFireBase")
	public REBaseResponse syncBookingsToFireBase(
			@RequestParam(value = "updateRecords", required = true) boolean updateRecords,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "guid", required = false) String guid,
			@RequestParam(value = "transactionType", required = true) String transactionType) {

		logger.info(
				"Calling /booking/syncBookingsToFireBase api ,Input Params {Update Records :{{}} ,From: {} ,To: {} ,Guid {}, Transaction Type {}}",
				updateRecords, fromDate, toDate, guid, transactionType);

		return onlineBookingService.syncBookingsToFireBase(updateRecords, fromDate, toDate, guid, transactionType);
	}

	@PostMapping(value = "syncFinanceDetailsToFireBase")
	public REBaseResponse syncFinanceDetailsToFireBase(@RequestBody @Valid FinanceBookingDetailsDTO dto) {

		logger.info("Calling /booking/syncFinanceDetailsToFireBase api ,Input Params {{}}", dto);

		return onlineBookingService.syncFinanceDetailsToFireBase(dto);
	}

}
