package com.net.bosch.crmmaster.service;

import java.lang.reflect.InvocationTargetException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.net.bosch.constants.Constants;
import com.net.bosch.crmmaster.dao.AppointmentBookQueueRepository;
import com.net.bosch.crmmaster.dao.AppointmentFullSlotsRepository;
import com.net.bosch.crmmaster.dao.AppointmentSlotRepository;
import com.net.bosch.crmmaster.dao.BookedAppointmentSlotRepository;
import com.net.bosch.crmmaster.dao.DealerServiceRedisRepository;
import com.net.bosch.crmmaster.dao.DealerServiceSlotsRepository;
import com.net.bosch.crmmaster.domain.AppointmentBookQueue;
import com.net.bosch.crmmaster.domain.AppointmentFullSlots;
import com.net.bosch.crmmaster.domain.AppointmentSlot;
import com.net.bosch.crmmaster.domain.BookedAppointmentSlot;
import com.net.bosch.crmmaster.domain.DealerServiceRedis;
import com.net.bosch.crmmaster.domain.DealerServiceSlots;
import com.net.bosch.crmmaster.dto.AppointmentBookDTO;
import com.net.bosch.crmmaster.dto.AppointmentCancelDTO;
import com.net.bosch.crmmaster.dto.AppointmentFeedbackRequestDTO;
import com.net.bosch.crmmaster.dto.AppointmentFeedbackResponseDTO;
import com.net.bosch.crmmaster.dto.AppointmentRescheduleDTO;
import com.net.bosch.crmmaster.dto.AppointmentSearchDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotListDTO;
import com.net.bosch.crmmaster.dto.DeviceResponseDTO;
import com.net.bosch.crmmaster.dto.NearByDealerDTO;
import com.net.bosch.crmmaster.dto.PickupDoorStepSlotDTO;
import com.net.bosch.crmmaster.dto.ScheduledAppointmentDTO;
import com.net.bosch.crmmaster.dto.ServiceInProgressDTO;
import com.net.bosch.crmmaster.dto.VehicleRequestDTO;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;
import com.net.bosch.utils.DateHelper;
import com.net.bosch.utils.HttpClientUtil;


@Service
public class AppointmentService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AppointmentSlotRepository appointmentSlotRepository;
	
	@Autowired
	private AppointmentFullSlotsRepository appointmentFullSlotsRepository;
	
	@Autowired
	private BookedAppointmentSlotRepository bookedAppointmentSlotRepository;
	
	@Autowired
	private AppointmentBookQueueRepository appointmentBookQueueRepository;
	
	@Autowired
	private DealerServiceRedisRepository dealerServiceRedisRepository;
	
	@Autowired
	private DealerServiceSlotsRepository dealerServiceSlotsRepository;
	
	@Autowired
	StoredProcedureService storedProcedureService;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
		
	ObjectMapper mapper = new ObjectMapper();
	
	private static final String BOOKED_STATUS = "Booked";
	private static final String CANCELED_STATUS = "Canceled";
	
	private static final Integer SERVICE_TYPE_WALKIN = 1;
	private static final Integer SERVICE_TYPE_DOORSTEP = 2;
	private static final Integer SERVICE_TYPE_PICKUP = 3;
	
	private static final Integer SERVICE_OP_INCREASE = 1;
	private static final Integer SERVICE_OP_DECREASE = 2;
	
	
	/**
	 * 
	 * @param PaymentRecordsDTO
	 * @return
	 * @throws AppException
	 */
	
	@Transactional
	public AppointmentSlotDTO create(AppointmentSlotDTO appointmentSlotDTO) throws AppException {
		AppointmentSlot appointmentSlot;		
		appointmentSlot = new AppointmentSlot();
		convertToEntity(appointmentSlotDTO, appointmentSlot);		
		return convertToDTO(appointmentSlot);		
	}
	
	

	@Transactional
	public void createAppointmentSlots(HashMap<String, List<AppointmentSlotDTO>> appointmentSlotDTOMap) throws AppException {		 
		logger.debug("AppointmentService.createAppointmentSlots() in ");
		Iterator<String> iterator = appointmentSlotDTOMap.keySet().iterator();
		int count =0;
		while (iterator.hasNext()){
		    String key = iterator.next();
		    List<AppointmentSlotDTO> value = appointmentSlotDTOMap.get(key);
		    AppointmentSlotListDTO appointmentSlotListDTO = new AppointmentSlotListDTO();
		    appointmentSlotListDTO.setData(value);
		    AppointmentFullSlots appointmentFullSlots = new AppointmentFullSlots();
		    appointmentFullSlots.setId(key);
		    appointmentFullSlots.setSlots(appointmentSlotListDTO);
			appointmentFullSlotsRepository.save(appointmentFullSlots);
		    logger.debug("AppointmentService.createAppointmentSlots() inserted"+(++count)+" -- key "+key);
		}
				
	}
		
	
	/*
	 * Check the Active AppointmentSlot 
	 * throw exception
	 * 
	 * Try to get the smartPole from the ElasticSearch
	 * If not got from the elastic search try to get from the DB and add it to elastic search
	 * 
	 */	
	@Transactional
	public AppointmentSlot get(String id) throws AppException {
		AppointmentSlot appointmentSlot = appointmentSlotRepository.findById(id).get();
		if (appointmentSlot==null)
			throw new AppException(AppExceptionErrorCode.USER_DOES_NOT_EXIST, messageSource.getMessage("error.smartPole.smartPole_does_not_exist", null, null));
		return appointmentSlot;
	}
	
	@Transactional
	public AppointmentFullSlots getFullSlots(String id) throws AppException {
		AppointmentFullSlots appointmentSlot = null;
		try {
			appointmentSlot = appointmentFullSlotsRepository.findById(id).get();
		} catch (Exception e) {	}
		if(appointmentSlot==null) {
			appointmentSlot= new AppointmentFullSlots();
		}
		return appointmentSlot;
	}
	
	/*public AppointmentSlotListDTO getAllAppointmentSlots(AppointmentSearchDTO appointmentSearchDTO) throws AppException {
		logger.info("BranchID "+appointmentSearchDTO.getBranchID()+"  Appointmentdate "+appointmentSearchDTO.getAppointmentdate());
		List<AppointmentSlot> slots = (List<AppointmentSlot>) appointmentSlotRepository.findByDate(appointmentSearchDTO.getBranchID()+":"+appointmentSearchDTO.getAppointmentdate());
		logger.info("getAllAppointmentSlots size "+slots.size());
		List<AppointmentSlotDTO> appointmentSlotDTOs = new ArrayList<>();		
		for (AppointmentSlot appointmentSlot : slots) {
			appointmentSlotDTOs.add(convertToDTO(appointmentSlot));
		}
		AppointmentSlotListDTO responseListDTO = new AppointmentSlotListDTO();
		responseListDTO.setData(appointmentSlotDTOs);
		return responseListDTO;
	}*/
	
	public AppointmentSlotListDTO getAllAppointmentSlots(AppointmentSearchDTO appointmentSearchDTO) throws AppException, ParseException {		
		String key = appointmentSearchDTO.getBranchID()+":"+appointmentSearchDTO.getAppointmentdate();
		logger.info("getAllAppointmentSlots key "+key);	
		AppointmentSlotListDTO appointmentSlotListDTO = new AppointmentSlotListDTO();
		if(!appointmentSearchDTO.getIsDummySlots()){
			AppointmentFullSlots appointmentSlot = null;
			try {
				appointmentSlot = appointmentFullSlotsRepository.findById(key).get();
			} catch (Exception e) {	e.printStackTrace();}		
			if(appointmentSlot != null){
				appointmentSlotListDTO.setData(minimizeAppointmentSlot(appointmentSlot.slots,appointmentSearchDTO.getBranchID(), appointmentSearchDTO.getAppointmentdate()));
			}else{
				appointmentSlotListDTO.setData(new ArrayList<AppointmentSlotDTO>());
			}
		}else{
			logger.info("getAllAppointmentSlots dummy slots required ");
			List<AppointmentSlotDTO> appointmentSlots = new ArrayList<AppointmentSlotDTO>();
			Date startDate = DateUtils.parseDate(appointmentSearchDTO.getAppointmentdate(), "yyyy-MM-dd");
			logger.info("getAllAppointmentSlots dummy slots startDate "+startDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(startDate);
			cal.set(Calendar.HOUR_OF_DAY, 9);
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.RE_PRIME_PATTERN);
			do{
				AppointmentSlotDTO appointmentSlotDTO = new AppointmentSlotDTO();
				appointmentSlotDTO.setResourceId("00000000-0000-0000-0000-000000000000");
				appointmentSlotDTO.setBranchId(appointmentSearchDTO.getBranchID());									
				appointmentSlotDTO.setStartTimeSlot(sdf.format(cal.getTime()));
				//logger.info("getAllAppointmentSlots dummy slots starttime "+cal.getTime()+" appointmentSlotDTO.getStartTimeSlot "+appointmentSlotDTO.getStartTimeSlot());
				cal.add(Calendar.MINUTE, 15);				
				appointmentSlotDTO.setEndTimeSlot(sdf.format(cal.getTime()));
				//logger.info("getAllAppointmentSlots dummy slots endtime "+cal.getTime()+" appointmentSlotDTO.getEndTimeSlot "+appointmentSlotDTO.getEndTimeSlot());
				appointmentSlotDTO.setAvailability(true);					
				appointmentSlotDTO.setDate(appointmentSearchDTO.getAppointmentdate());				
				appointmentSlots.add(appointmentSlotDTO);
				//logger.info("getAllAppointmentSlots dummy slots cal.get(Calendar.HOUR) "+cal.get(Calendar.HOUR));
			}while(cal.get(Calendar.HOUR_OF_DAY)< 18);
			appointmentSlotListDTO.setData(appointmentSlots);
		}
		return appointmentSlotListDTO;
	}
	
	
	
	public DataResponseDTO bookAppointment(AppointmentBookDTO appointmentBookDTO)throws AppException, ParseException {
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		
		/*if(appointmentBookDTO.getServiceBookingType()  != SERVICE_TYPE_WALKIN){
			checkTheServiceSlotAvailability(appointmentBookDTO.getAppointmentDate(), appointmentBookDTO.getBranchID(),appointmentBookDTO.getServiceBookingType());			
		}*/
		
		String authToken = HttpClientUtil.getAuthenticationToken(env.getProperty("spring.dms.token.url"), env.getProperty("spring.dms.token.grant_type"), env.getProperty("spring.dms.token.client_id"), env.getProperty("spring.dms.token.client_secret"), env.getProperty("spring.dms.token.resource"));
		logger.info("spring.dms.token: "+env.getProperty("spring.dms.token.url")+ " | "+ env.getProperty("spring.dms.token.grant_type")+ " | "+env.getProperty("spring.dms.token.client_id")+ " | "+ env.getProperty("spring.dms.token.client_secret")+ " | "+ env.getProperty("spring.dms.token.resource"));
				
		//String url = "https://re-d365-apims.azure-api.net/reapi/ServiceAppointmentBooking";
		//String url = "https://dmsapi.royalenfield.com/reprimeappapi/ServiceAppointmentBooking";
		String url = env.getProperty("spring.dms.api.appointment_booking");
		logger.info("spring.dms.api.appointment_booking: "+url);
		//String params= "[{\"Mobile\":\"9417337083\",\"AppointmentDate\":\"2018-01-10T10:00:00\",\"AttachmentKey\":\"\",\"BranchID\":\"7711\",\"CityName\":\"Bangalore\",\"CompanyID\":\"7711\",\"CustomerRemarks\":\"Customer Remarks\",\"DropAddress\":\"Test1\",\"HomeAddress\":\"Test2\",\"Email\":\"test@test.com\",\"EntityType\":\"\",\"FirstName\":\"GURDEEP\",\"Engine\":\"U3S5C0FE794400\",\"LastName\":\"SINGH\",\"IsPickUpDrop\":\"Yes\",\"RegNo\":\"U3S5C0FE794400\",\"ServiceType\":\"2\",\"Source\":\"2\",\"StateName\":\"Gurgaon\",\"UserID\":\"\",\"Chassis\":\"ME3U3S5C1FE223135\",\"UserName\":\"\",\"services\":\"Service today\",\"PickUpAddress\":\"TEst3\",\"OfficeAddress\":\"\",\"ResourceIdentifier\":\"\",\"SlotID\":\"f537175a-70c5-e811-a970-000d3af29e21\",\"Gender\":\"M\",\"PickUpTime\":\"\"}] ";
		if(!appointmentBookDTO.getIsDummySlots()){
			String resourceId =  getResourceIdForBooking(appointmentBookDTO.getBranchID(), appointmentBookDTO.getAppointmentDate());
			if(resourceId == null)throw new AppException(AppExceptionErrorCode.PARAMETER_MISSING, "Slot for the requested time not found");
			appointmentBookDTO.setSlotID(resourceId);
		}
		String params= "";
		try {
			logger.info("appointmentBookDTO.getSlotID()  ->"+appointmentBookDTO.getSlotID());
			List inputJson = new ArrayList<>();
			inputJson.add(appointmentBookDTO);
			params = new ObjectMapper().writeValueAsString(inputJson);
			logger.info("appointmentBookDTO : "+params);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonNode response = HttpClientUtil.postRequestWithJsonBody(url, params,authToken, env.getProperty("spring.dms.token.subscriber_id"));
		
		//JsonNode appointmentResponse = HttpClientUtil.postRequestWithJsonBody(url, params,authToken, env.getProperty("spring.dms.token.subscriber_id"));
		String appointmentResponseCode = null;
		try {
			appointmentResponseCode = response.get(0).get("code").asText();
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
		if(appointmentResponseCode.equals("200")) {
			logger.info("book appointment success = "+appointmentResponseCode);
			try {
				if(!appointmentBookDTO.getIsDummySlots()){
					createBookedAppointmentSlot(appointmentBookDTO.getAppointmentDate(),appointmentBookDTO.getBranchID(), appointmentBookDTO.getSlotID(), response);
				}
				 
				JsonNode bookingNumberNode = response.findValue("bookingno");
				String bookingNumber = bookingNumberNode.asText();
				logger.info("createBookedAppointmentSlot bookingNumber -> "+bookingNumber);		
				//if(bookingNumber == null || bookingNumber.isEmpty()){bookingNumber = "CAS-705596-R6Z4D7";}
				if(bookingNumber != null && !bookingNumber.isEmpty()){
					logger.info("appointmentBookDTO.getSlotID()  -> bookingNumber"+bookingNumber+" appointmentBookDTO.getChassisNo() ->"+appointmentBookDTO.getChassisNo());
					// New requirement 10 OCT 2019 Add to redis cache book information
					appointmentBookDTO.setBookingStatus(BOOKED_STATUS);
					AppointmentBookQueue appointmentBookQueue = new AppointmentBookQueue();
					appointmentBookQueue.setAppointmentBookDTO(appointmentBookDTO);
					appointmentBookQueue.setId(appointmentBookDTO.getMobile());
					appointmentBookQueue.setCaseId(bookingNumber);
					appointmentBookQueue.setDate(""+new Date());
					appointmentBookQueueRepository.save(appointmentBookQueue);
					AppointmentBookQueue appointmentBookQueue1 = new AppointmentBookQueue();
					appointmentBookQueue1.setAppointmentBookDTO(appointmentBookDTO);
					appointmentBookQueue1.setId(appointmentBookDTO.getChassisNo());
					appointmentBookQueue1.setCaseId(bookingNumber);
					appointmentBookQueue1.setDate(""+new Date());
					appointmentBookQueueRepository.save(appointmentBookQueue1);					
				}
				/*if(appointmentBookDTO.getServiceBookingType()  != SERVICE_TYPE_WALKIN){
					updateServiceSlotAvailability(appointmentBookDTO.getAppointmentDate(), appointmentBookDTO.getBranchID(),appointmentBookDTO.getServiceBookingType(),SERVICE_OP_INCREASE);// 1:Operation add
				}*/
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			logger.info("book appointment failure = "+appointmentResponseCode);	
			if(appointmentResponseCode.equals("400"))updateDMSResponseWithGenericMessage(response.get(0));
		}	
		
		dataResponseDTO.setStatus(Integer.parseInt(appointmentResponseCode));
		dataResponseDTO.setResponse(response);
		return dataResponseDTO;
				
	}
	
	private void updateDMSResponseWithGenericMessage(JsonNode response){
		try {
			ObjectNode jsonNode = (ObjectNode)response;
			JsonNode newNode = new TextNode("Sorry. Something went wrong, please try again later");
			jsonNode.set("message", newNode);
		} catch (Exception e) {	
			logger.error("updateDMSResponseWithGenericMessage -> "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	public DataResponseDTO rescheduleAppointment(AppointmentRescheduleDTO rescheduleDTO)throws AppException, ParseException {
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		String authToken = HttpClientUtil.getAuthenticationToken(env.getProperty("spring.dms.token.url"), env.getProperty("spring.dms.token.grant_type"), env.getProperty("spring.dms.token.client_id"), env.getProperty("spring.dms.token.client_secret"), env.getProperty("spring.dms.token.resource"));
		//String url = "https://re-d365-apims.azure-api.net/reapi/RescheduleServiceAppointmentBooking";
		//String url = "https://dmsapi.royalenfield.com/reprimeappapi/RescheduleServiceAppointmentBooking";
		String url = env.getProperty("spring.dms.api.reschedule_appointment");
		logger.info("spring.dms.api.reschedule_appointment: "+url);
		if(!rescheduleDTO.getIsDummySlots()){
			String resourceId =  getResourceIdForBooking(rescheduleDTO.getBranchID(), rescheduleDTO.getAppointmentDate());
			if(resourceId == null)throw new AppException(AppExceptionErrorCode.PARAMETER_MISSING, "Slot for the requested time not found");
			rescheduleDTO.setSlotID(resourceId);
		}
		
		AppointmentBookDTO oldAppointmentBookDTO = storedProcedureService.getServiceStatus(rescheduleDTO.getAppointmentId());
		if(oldAppointmentBookDTO.getAppointmentDate() == null || oldAppointmentBookDTO.getAppointmentDate().isEmpty()){
			try {
				AppointmentBookQueue appointment = appointmentBookQueueRepository.findById(rescheduleDTO.getMobile()).get();
				oldAppointmentBookDTO = appointment.getAppointmentBookDTO();
			} catch (Exception e) {	e.printStackTrace();}
		}
/*		if(oldAppointmentBookDTO.getServiceBookingType()  != SERVICE_TYPE_WALKIN){
			checkTheServiceSlotAvailability(rescheduleDTO.getAppointmentDate(), oldAppointmentBookDTO.getBranchID(),oldAppointmentBookDTO.getServiceBookingType());			
		}*/
		
		String params= "";
		try {
			logger.info("rescheduleDTO.getSlotID()  ->"+rescheduleDTO.getSlotID());
			List inputJson = new ArrayList<>();
			inputJson.add(rescheduleDTO);
			params = new ObjectMapper().writeValueAsString(inputJson);
			logger.info("rescheduleDTO : "+params);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//New cache implementation remove it from the Cache
			appointmentBookQueueRepository.deleteById(rescheduleDTO.getAppointmentId());
		} catch (Exception e) {	e.printStackTrace();}
		
		JsonNode response = HttpClientUtil.postRequestWithJsonBody(url, params,authToken, env.getProperty("spring.dms.token.subscriber_id"));
		String appointmentResponseCode = null;
		try {
			appointmentResponseCode = response.get(0).get("code").asText();
		} catch (Exception e) {			
			e.printStackTrace();
		}
//		String appointmentResponseCode = response.get("code").asText();
		if(appointmentResponseCode.equals("200")) {
			logger.info("reschedule appointment success = "+appointmentResponseCode);
			try {
				if(!rescheduleDTO.getIsDummySlots()){
					createBookedAppointmentSlot(rescheduleDTO.getAppointmentDate(),rescheduleDTO.getBranchID(), rescheduleDTO.getSlotID(), response);
				}			
				
				JsonNode bookingNumberNode = response.findValue("bookingno");
				String bookingNumber = bookingNumberNode.asText();
				if(bookingNumber != null && !bookingNumber.isEmpty()){
					// New requirement 10 OCT 2019 Add to redis cache book information
					AppointmentBookQueue appointmentBookQueue = new AppointmentBookQueue();
					AppointmentBookDTO appointmentBookDTO = new AppointmentBookDTO();
					try {
						PropertyUtils.copyProperties(appointmentBookDTO, rescheduleDTO);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					appointmentBookDTO.setBookingStatus(BOOKED_STATUS);
					appointmentBookDTO.setServiceBookingType(oldAppointmentBookDTO.getServiceBookingType());
					appointmentBookQueue.setAppointmentBookDTO(appointmentBookDTO);
					appointmentBookQueue.setId(rescheduleDTO.getMobile());
					appointmentBookQueue.setCaseId(bookingNumber);
					appointmentBookQueue.setDate(""+new Date());
					appointmentBookQueueRepository.save(appointmentBookQueue);
					if(rescheduleDTO.getChassisNo() != null && !rescheduleDTO.getChassisNo().isEmpty()){
						logger.info("reschedule appointment save to redis  = "+rescheduleDTO.getChassisNo() );
						AppointmentBookQueue appointmentBookQueue1 = new AppointmentBookQueue();
						appointmentBookQueue1.setAppointmentBookDTO(appointmentBookDTO);
						appointmentBookQueue1.setId(rescheduleDTO.getChassisNo());
						appointmentBookQueue1.setCaseId(bookingNumber);
						appointmentBookQueue1.setDate(""+new Date());
						appointmentBookQueueRepository.save(appointmentBookQueue1);
					}
					
					/*if(oldAppointmentBookDTO.getServiceBookingType()  != SERVICE_TYPE_WALKIN){
						updateServiceSlotAvailability(oldAppointmentBookDTO.getAppointmentDate(), oldAppointmentBookDTO.getBranchID(),oldAppointmentBookDTO.getServiceBookingType(),SERVICE_OP_DECREASE);
						updateServiceSlotAvailability(rescheduleDTO.getAppointmentDate(), rescheduleDTO.getBranchID(),oldAppointmentBookDTO.getServiceBookingType(),SERVICE_OP_INCREASE);
					}*/
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			logger.info("reschedule appointment failure = "+appointmentResponseCode);
			if(appointmentResponseCode.equals("400"))updateDMSResponseWithGenericMessage(response.get(0));
		}
		dataResponseDTO.setStatus(Integer.parseInt(appointmentResponseCode));
		dataResponseDTO.setResponse(response);
		return dataResponseDTO;				
	}
	
	public DataResponseDTO cancelAppointment(AppointmentCancelDTO cancelDTO)throws AppException {
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		String authToken = HttpClientUtil.getAuthenticationToken(env.getProperty("spring.dms.token.url"), env.getProperty("spring.dms.token.grant_type"), env.getProperty("spring.dms.token.client_id"), env.getProperty("spring.dms.token.client_secret"), env.getProperty("spring.dms.token.resource"));
//		String url = "https://re-d365-apims.azure-api.net/reapi/CancelServiceAppointment";
//		String url = "https://dmsapi.royalenfield.com/reprimeappapi/CancelServiceAppointment";
		String url = env.getProperty("spring.dms.api.cancel_booking");
		logger.info("spring.dms.api.cancel_booking: "+url);
		String params= "";
		try {
			logger.info("cancelDTO  ->"+cancelDTO.getCaseNo());
			params = new ObjectMapper().writeValueAsString(cancelDTO);
			logger.info("cancelDTO : "+params);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		AppointmentBookDTO oldAppointmentBookDTO = storedProcedureService.getServiceStatus(cancelDTO.getCaseNo());
		logger.info("cancel appointment success oldAppointmentBookDTO 1 = "+oldAppointmentBookDTO.getAppointmentDate());
		if(oldAppointmentBookDTO.getAppointmentDate() == null || oldAppointmentBookDTO.getAppointmentDate().isEmpty()){
			logger.info("cancel appointment success oldAppointmentBookDTO 2 = "+cancelDTO.getMobile());
			try {
				AppointmentBookQueue appointment = appointmentBookQueueRepository.findById(cancelDTO.getMobile()).get();
				oldAppointmentBookDTO = appointment.getAppointmentBookDTO();
			} catch (Exception e) {	e.printStackTrace();}
		}
		logger.info("cancel appointment success oldAppointmentBookDTO 3 = "+oldAppointmentBookDTO.getAppointmentDate());
		
		JsonNode appointmentResponse = HttpClientUtil.postRequestWithJsonBody(url, params,authToken, env.getProperty("spring.dms.token.subscriber_id"));
		String appointmentResponseCode = appointmentResponse.get("code").asText();
		if(appointmentResponseCode.equals("200")) {
			logger.info("cancel appointment success = "+appointmentResponseCode);
			try {
				// New requirement 12 NOV 2019 Add to redis cache cancel information
				AppointmentBookQueue appointmentBookQueue = new AppointmentBookQueue();
				AppointmentBookDTO appointmentBookDTO = new AppointmentBookDTO();
				appointmentBookDTO.setBookingStatus(CANCELED_STATUS);
				appointmentBookQueue.setAppointmentBookDTO(appointmentBookDTO);
				appointmentBookQueue.setId(cancelDTO.getMobile());
				appointmentBookQueue.setCaseId(cancelDTO.getCaseNo());
				appointmentBookQueue.setDate(""+new Date());
				appointmentBookQueueRepository.save(appointmentBookQueue);
				if(cancelDTO.getChassisNo() != null && !cancelDTO.getChassisNo().isEmpty()){
					logger.info("cancel appointment saving chasis to redis = "+cancelDTO.getChassisNo());
					AppointmentBookQueue appointmentBookQueue1 = new AppointmentBookQueue();
					appointmentBookQueue1.setAppointmentBookDTO(appointmentBookDTO);
					appointmentBookQueue1.setId(cancelDTO.getChassisNo());
					appointmentBookQueue1.setCaseId(cancelDTO.getCaseNo());
					appointmentBookQueue1.setDate(""+new Date());
					appointmentBookQueueRepository.save(appointmentBookQueue1);
				}
				
				/*if(oldAppointmentBookDTO.getServiceBookingType()  != SERVICE_TYPE_WALKIN){
					updateServiceSlotAvailability(oldAppointmentBookDTO.getAppointmentDate(), oldAppointmentBookDTO.getBranchID(),oldAppointmentBookDTO.getServiceBookingType(),SERVICE_OP_DECREASE);					
				}*/
			} catch (Exception e) {	e.printStackTrace();}
		} else {
			logger.info("cancel appointment failure = "+appointmentResponseCode);
			if(appointmentResponseCode.equals("400"))updateDMSResponseWithGenericMessage(appointmentResponse);
		}
		
		dataResponseDTO.setResponse(appointmentResponse);
//		dataResponseDTO.setResponse(HttpClientUtil.postRequestWithJsonBody(url, params,authToken, env.getProperty("spring.dms.token.subscriber_id")));
		dataResponseDTO.setStatus(Integer.parseInt(appointmentResponseCode));
		return dataResponseDTO;				
	}
	
	private String createBookedAppointmentSlot(String appointmentDate, String branchId, String resourceId, JsonNode response){
		String bookingNumber = null;
		try{
			String dateKey = appointmentDate.substring(0,10);
			JsonNode bookingNumberNode = response.findValue("bookingno");
			bookingNumber = bookingNumberNode.asText();
			logger.info("createBookedAppointmentSlot bookingNumber -> "+bookingNumber);
			if(bookingNumber != null && !bookingNumber.isEmpty()){
				BookedAppointmentSlot bookedAppointmentSlot  = null;
				try{
					bookedAppointmentSlot  = bookedAppointmentSlotRepository.findById(branchId+":"+dateKey).get();
				}catch(Exception e){e.printStackTrace();}
				if(bookedAppointmentSlot == null){
					bookedAppointmentSlot = new BookedAppointmentSlot();
					bookedAppointmentSlot.setId(branchId+":"+dateKey);
				}
				List< AppointmentSlotDTO> bookedSlots = bookedAppointmentSlot.getData();
				if(bookedSlots == null){
					bookedSlots =  new ArrayList<AppointmentSlotDTO>();
				}
				
				AppointmentSlotDTO appointmentSlotDTO = new AppointmentSlotDTO();
				appointmentSlotDTO.setBranchId(branchId);
				appointmentSlotDTO.setStartTimeSlot(appointmentDate);
				appointmentSlotDTO.setResourceId(resourceId);
				bookedSlots.add(appointmentSlotDTO);
				bookedAppointmentSlot.setData(bookedSlots);
				bookedAppointmentSlotRepository.save(bookedAppointmentSlot);			
				
			}
		}catch(Exception e){e.printStackTrace();}
		
		return bookingNumber;
	}
	
	@Transactional
	public AppointmentSlotDTO getDTO(String id) throws AppException {		
		return convertToDTO(get(id));
	}
	
	@Transactional
	public AppointmentSlotListDTO getFullSlotsDTO(String id) throws AppException {		
		AppointmentFullSlots appointmentSlots =  getFullSlots(id);
		if(appointmentSlots != null) return appointmentSlots.slots;
		return new AppointmentSlotListDTO();
	}
	
	private AppointmentSlot convertToEntity(AppointmentSlotDTO appointmentSlotDTO, AppointmentSlot appointmentSlot) {
		try {
			appointmentSlot.setAvailability(appointmentSlotDTO.getAvailability());
			appointmentSlot.setBranchId(appointmentSlotDTO.getBranchId());
			appointmentSlot.setEndTimeSlot(DateUtils.parseDate(appointmentSlotDTO.getEndTimeSlot(), "yyyy-MM-dd hh:mm:ss.SSS"));
			appointmentSlot.setId(appointmentSlotDTO.getResourceId()+":"+appointmentSlotDTO.getBranchId()+":"+appointmentSlotDTO.getDate());
			appointmentSlot.setStartTimeSlot(DateUtils.parseDate(appointmentSlotDTO.getStartTimeSlot(), "yyyy-MM-dd hh:mm:ss.SSS"));
			appointmentSlot.setDate(appointmentSlotDTO.getBranchId()+":"+appointmentSlotDTO.getDate());
		} catch (Exception e) {
			logger.error("Appoinment convertToEntity"+e);
		}
		appointmentSlot =  appointmentSlotRepository.save(appointmentSlot);		
	    return appointmentSlot;
	}
	
	public AppointmentSlotDTO convertToDTO(AppointmentSlot appointmentSlot) {
		AppointmentSlotDTO appointmentSlotDTO = new AppointmentSlotDTO();
		try {
			appointmentSlotDTO.setAvailability(appointmentSlot.getAvailability());
			appointmentSlotDTO.setBranchId(appointmentSlot.getBranchId());
			appointmentSlotDTO.setEndTimeSlot(org.apache.http.client.utils.DateUtils.formatDate(appointmentSlot.getEndTimeSlot(), "yyyy-MM-dd'T'HH:mm:ss"));
			appointmentSlotDTO.setStartTimeSlot(org.apache.http.client.utils.DateUtils.formatDate(appointmentSlot.getStartTimeSlot(), "yyyy-MM-dd'T'HH:mm:ss"));
			appointmentSlotDTO.setResourceId(appointmentSlot.getId().substring(0, appointmentSlot.getId().indexOf(':')));
			appointmentSlotDTO.setDate(appointmentSlot.getDate());
		} catch (Exception e) {
			e.printStackTrace();
		}				
	    return appointmentSlotDTO;
	}	
	
	private List<AppointmentSlotDTO> minimizeAppointmentSlot(AppointmentSlotListDTO appointmentSlotListDTO, String branchId, String appointmentDate){
		HashMap<String, AppointmentSlotDTO> minimumSlotsMap = new HashMap<String, AppointmentSlotDTO>();
		if(appointmentSlotListDTO != null){
			List<AppointmentSlotDTO> totalSlots = appointmentSlotListDTO.getData();
			List<AppointmentSlotDTO> bookedSlots = getBookedSlots(branchId, appointmentDate);
			if(totalSlots != null){
				for (AppointmentSlotDTO appointmentSlotDTO : totalSlots) {					
					if(!isBlockedSlot(bookedSlots, appointmentSlotDTO)){
						minimumSlotsMap.put(appointmentSlotDTO.getStartTimeSlot(), appointmentSlotDTO);					
					}
				}				
			}			
		}
		Collection collection = minimumSlotsMap.values();
		List list;
		if (collection instanceof List)
		  list = (List)collection;
		else
		  list = new ArrayList(collection);
		return (list);
	}
	
	private List<AppointmentSlotDTO> getBookedSlots(String branchId, String appointmentDate){
		List<AppointmentSlotDTO> bookedSlots = null;
		try{
			BookedAppointmentSlot bookedSlot = bookedAppointmentSlotRepository.findById(branchId+":"+appointmentDate).get();				
			if(bookedSlot != null){
				bookedSlots = bookedSlot.getData();
				logger.info("minimizeAppointmentSlot bookedSlots size"+bookedSlots.size());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return bookedSlots;
	}
	
	private Boolean isBlockedSlot(List<AppointmentSlotDTO> bookedSlots, AppointmentSlotDTO appointmentSlotDTO){
		//avoid the blocked slots
		Boolean isBlockedSlot = false;
		if(bookedSlots != null){
			for (AppointmentSlotDTO blockedSlot : bookedSlots) {
				if(blockedSlot.getResourceId().equals(appointmentSlotDTO.getResourceId()) 
						&& blockedSlot.getStartTimeSlot().equals(appointmentSlotDTO.getStartTimeSlot())){
					isBlockedSlot = true;
					break;
				}
			}
		}
		return isBlockedSlot;
	}
	
	public String getResourceIdForBooking(String branchId, String appointmentDateTime){
		String resourceId = null;
		String appointmentDate = appointmentDateTime.substring(0,10);
		String key = branchId+":"+appointmentDate;
		logger.info("getResourceIdForBooking key "+key);	
		AppointmentFullSlots appointmentSlot = null;
		try {
			appointmentSlot = appointmentFullSlotsRepository.findById(key).get();
		} catch (Exception e) {	e.printStackTrace();}
		if(appointmentSlot != null && appointmentSlot.getSlots() != null){
			List<AppointmentSlotDTO> totalSlots = appointmentSlot.getSlots().getData();			
			if(totalSlots != null && totalSlots.size() > 0){
				logger.info("getResourceIdForBooking totalSlots "+totalSlots.size());	
				/*List<AppointmentSlotDTO> slotsForTime = totalSlots.stream()                // convert list to stream
		                .filter(slotDTO -> "appointmentDateTime".equals(slotDTO.getStartTimeSlot()))     // 
		                .collect(Collectors.toList());              // collect the output and convert streams to a List*/
				List<AppointmentSlotDTO> slotsForTime = new ArrayList<AppointmentSlotDTO>();		
				for (AppointmentSlotDTO appointmentSlotDTO : totalSlots) {
					if(appointmentDateTime.equals(appointmentSlotDTO.getStartTimeSlot())){
						slotsForTime.add(appointmentSlotDTO);
					}
				}				
				List<AppointmentSlotDTO> bookedSlots = getBookedSlots(branchId, appointmentDate);
				if(slotsForTime != null){
					logger.info("getResourceIdForBooking slotsForTime "+slotsForTime.size());	
					for (AppointmentSlotDTO appointmentSlotDTO : slotsForTime) {					
						if(!isBlockedSlot(bookedSlots, appointmentSlotDTO)){
							return appointmentSlotDTO.getResourceId();					
						}
					}				
				} 
			}
		}		 
		return resourceId;
	}
	
	public DataResponseDTO getServiceStatus(AppointmentCancelDTO cancelDTO) {
		DataResponseDTO responseDTO = new DataResponseDTO();		
		logger.info("getServiceStatus  mobile "+ cancelDTO.getMobile());	
		AppointmentBookQueue appointment = null;
		try {
			appointment = appointmentBookQueueRepository.findById(cancelDTO.getMobile()).get();
		} catch (Exception e) {	e.printStackTrace();}
		if(appointment != null){
			logger.info("getServiceStatus  got from the local database ");
			responseDTO.setResponse(appointment.getAppointmentBookDTO());
		}else{
			logger.info("getServiceStatus  not available in the local database "+ cancelDTO.getCaseNo());
			responseDTO.setResponse(storedProcedureService.getServiceStatus(cancelDTO.getCaseNo()));
		}
		return responseDTO;
	}
	
	public Map<String, ServiceInProgressDTO> getVehicleServiceInProgressList(VehicleRequestDTO vehicleRequestDTO) {
		Map<String,ServiceInProgressDTO> serviceInProgressDTOList = new HashMap<String, ServiceInProgressDTO>();
		if(vehicleRequestDTO.getChassisNo()!= null){
			String[] chassisNumbers = vehicleRequestDTO.getChassisNo().split(",");
			for (String chassisNo : chassisNumbers) {
				AppointmentBookQueue appointment = null;
				try {
					appointment = appointmentBookQueueRepository.findById(chassisNo).get();			
				} catch (Exception e) {	
					logger.info("getVehicleServiceInProgressList  not available in the local database using mobie number "+ chassisNo);
				}
				if(appointment != null){
					logger.info("getVehicleServiceInProgressList  got from the local database ");
					ServiceInProgressDTO serviceInProgressDTO =  new ServiceInProgressDTO();
					AppointmentBookDTO appointmentBookDTO = appointment.getAppointmentBookDTO();
					if(appointmentBookDTO.getBookingStatus().equals(BOOKED_STATUS)){
						serviceInProgressDTO.setIsServiceInProgress("Yes");
						serviceInProgressDTO.setCustomerRemarks(appointmentBookDTO.getCustomerRemarks());
						serviceInProgressDTO.setDealerInfo(appointmentBookDTO.getBranchID());				
						serviceInProgressDTO.setPickupAddres(appointmentBookDTO.getPickUpAddress());	
						serviceInProgressDTO.setAppointmentNumber(appointment.getCaseId());
						serviceInProgressDTO.setAppointmentDate(appointmentBookDTO.getAppointmentDate());
						serviceInProgressDTO.setRegistrationNumber(appointmentBookDTO.getRegNo());
						serviceInProgressDTO.setServiceBookingType(appointmentBookDTO.getServiceBookingType());
						serviceInProgressDTO.setAppointmentCategory(appointmentBookDTO.getAppointmentCategory());
						serviceInProgressDTO.setSlotId(appointmentBookDTO.getSlotID());
					}else{
						serviceInProgressDTO.setIsServiceInProgress("No");
					}			
					serviceInProgressDTOList.put(chassisNo,serviceInProgressDTO);
				}else{
					logger.info("getVehicleServiceInProgressList  not available in the local database "+ chassisNo);
					serviceInProgressDTOList.put(chassisNo,storedProcedureService.getVehicleServiceInProgressList(chassisNo));			
				}
			}			
		}		
		return serviceInProgressDTOList;
	}
	
	public void deleteAllAppointmentSlots(){
		logger.info("DeleteAll called");
		/*Iterable<AppointmentSlot> appointmentSlots = appointmentSlotRepository.findAll();
		logger.info("deleteAllAppointmentSlots "+appointmentSlots.iterator().hasNext());
		AppointmentSlot appointmentSlot;
		while (appointmentSlots.iterator().hasNext()) {
			appointmentSlot = appointmentSlots.iterator().next();
            logger.info("deleteAllAppointmentSlots appointmentSlot -> "+appointmentSlot.getBranchId()); 
            appointmentSlotRepository.delete(appointmentSlot);
		}*/	
		appointmentSlotRepository.deleteAll();
	}
	
	public List<PickupDoorStepSlotDTO> getPickupAndDoorstepServiceSlots(NearByDealerDTO dealerDTO) throws AppException, ParseException {		
		List<PickupDoorStepSlotDTO> pickupDoorStepSlotDTOs = new ArrayList<PickupDoorStepSlotDTO>();
		String key = dealerDTO.getDealerId();
		logger.info("getPickupAndDoorstepServiceSlots key "+key);
		DealerServiceRedis dealerServiceRedis = null;
		try {
			dealerServiceRedis = dealerServiceRedisRepository.findById(key).get();
		} catch (Exception e1) {
			logger.info("pickupDoorStepSlotDTOs error "+e1.getMessage());
			return pickupDoorStepSlotDTOs;
		}	
		logger.info("pickupDoorStepSlotDTOs dealerServiceRedis vehicle "+dealerServiceRedis.getDoorStepVehiclesCount());
		logger.info("pickupDoorStepSlotDTOs dealerServiceRedis door enabled "+dealerServiceRedis.getDoorStepServiceEnabled());
		logger.info("pickupDoorStepSlotDTOs dealerServiceRedis technician "+dealerServiceRedis.getPickupTechnicianCount());
		logger.info("pickupDoorStepSlotDTOs dealerServiceRedis pickup enabled "+dealerServiceRedis.getPickupServiceEnabled());
		Calendar cal = Calendar.getInstance();
		logger.info("getPickupAndDoorstepServiceSlots slots startDate "+cal.getTime());
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.SHORT_DATE_FORMAT);
		PickupDoorStepSlotDTO pickupDoorStepSlotDTO = null;		
		for (int i = 0; i < 11; i++) {//Can advance book for 11 days
			cal.add(Calendar.DATE, 1);
			DealerServiceSlots dealerServiceSlots = null;
			String date = sdf.format(cal.getTime());
			try{
				dealerServiceSlots  = dealerServiceSlotsRepository.findById(key+":"+date).get();
			}catch(Exception e){}
			if(dealerServiceSlots == null){
				dealerServiceSlots = new DealerServiceSlots();
				dealerServiceSlots.setId(key+":"+date);
				dealerServiceSlots.setCurrentDoorStepCount(0);
				dealerServiceSlots.setCurrentPickupCount(0);
				if(dealerServiceRedis.getDoorStepServiceEnabled().equalsIgnoreCase("Y") && dealerServiceRedis.getDoorStepVehiclesCount() > 0){
					dealerServiceSlots.setTotalDoorStepCount(dealerServiceRedis.getDoorStepVehiclesCount()*env.getProperty("re.service.doorstepmaxcount",Integer.class));
				}
				if(dealerServiceRedis.getPickupServiceEnabled().equalsIgnoreCase("Y") && dealerServiceRedis.getPickupTechnicianCount() > 0){
					dealerServiceSlots.setTotalPickupCount(dealerServiceRedis.getPickupTechnicianCount()*env.getProperty("re.service.pickupmaxcount",Integer.class));
				}
				dealerServiceSlotsRepository.save(dealerServiceSlots);				
			}
			pickupDoorStepSlotDTO = new PickupDoorStepSlotDTO();
			pickupDoorStepSlotDTO.setDate(date);
			pickupDoorStepSlotDTO.setDoorStepAvailability(dealerServiceSlots.getTotalDoorStepCount()>dealerServiceSlots.getCurrentDoorStepCount());
			pickupDoorStepSlotDTO.setPickupAvailability(dealerServiceSlots.getTotalPickupCount()>dealerServiceSlots.getCurrentPickupCount());
			pickupDoorStepSlotDTOs.add(pickupDoorStepSlotDTO);
		}	
		
		return pickupDoorStepSlotDTOs;
	}
	
	public void checkTheServiceSlotAvailability(String appointmentDateString, String branchId, Integer serviceType) throws ParseException{
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constants.RE_PRIME_PATTERN);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constants.SHORT_DATE_FORMAT);
		
		Date appointmentDate = sdf1.parse(appointmentDateString);
		String shortDate = sdf2.format(appointmentDate);
		DealerServiceSlots dealerServiceSlots = null;
		try {
			logger.info("service slot get key "+branchId+":"+shortDate);
			dealerServiceSlots = dealerServiceSlotsRepository.findById(branchId+":"+shortDate).get();
		} catch (Exception e) {	
			logger.info("service slot not available: "+e.getMessage());
			if(serviceType  == SERVICE_TYPE_DOORSTEP){
				throw new AppException("All Doorstep service slots are full for the chosen date. Please choose a different date.");
			}else if(serviceType  == SERVICE_TYPE_PICKUP){
				throw new AppException("All pick-up and drop slots are full for the chosen date. Please choose a different date.");
			}
		}
		if(dealerServiceSlots == null){
			if(serviceType  == SERVICE_TYPE_DOORSTEP){
				throw new AppException("All Doorstep service slots are full for the chosen date. Please choose a different date.");
			}else if(serviceType  == SERVICE_TYPE_PICKUP){
				throw new AppException("All pick-up and drop slots are full for the chosen date. Please choose a different date.");
			}
		}
		if(serviceType  == SERVICE_TYPE_DOORSTEP){
			if(dealerServiceSlots.getTotalDoorStepCount() <= dealerServiceSlots.getCurrentDoorStepCount()){
				throw new AppException("All Doorstep service slots are full for the chosen date. Please choose a different date.");
			}
		}else if(serviceType  == SERVICE_TYPE_PICKUP){
			if(dealerServiceSlots.getTotalPickupCount() <= dealerServiceSlots.getCurrentPickupCount()){
				throw new AppException("All pick-up and drop slots are full for the chosen date. Please choose a different date.");
			}
		}
	}
	
	// Operation 1: increase 2: decrease
	public void updateServiceSlotAvailability(String appointmentDateString, String branchId, Integer serviceType, Integer operation) throws ParseException{
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constants.RE_PRIME_PATTERN);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constants.SHORT_DATE_FORMAT);
		SimpleDateFormat sdf3 = new SimpleDateFormat(Constants.RE_PRIME_PURCHASE_DATE);
		
		Date appointmentDate = null;
		try {
			appointmentDate = sdf1.parse(appointmentDateString);
		} catch (Exception e1) {
			logger.info("date parsing error"+e1.getMessage());
			appointmentDate = sdf3.parse(appointmentDateString);
		}
		String shortDate = sdf2.format(appointmentDate);
		DealerServiceSlots dealerServiceSlots = null;
		try {
			logger.info("service slot get key "+branchId+":"+shortDate);
			dealerServiceSlots = dealerServiceSlotsRepository.findById(branchId+":"+shortDate).get();
		} catch (Exception e) {	
			logger.info("service slot not available: "+e.getMessage());
			if(serviceType  == SERVICE_TYPE_DOORSTEP){
				throw new AppException("All Doorstep service slots are full for the chosen date. Please choose a different date.");
			}else if(serviceType  == SERVICE_TYPE_PICKUP){
				throw new AppException("All pick-up and drop slots are full for the chosen date. Please choose a different date.");
			}
		}
		if(dealerServiceSlots == null){
			if(serviceType  == SERVICE_TYPE_DOORSTEP){
				throw new AppException("All Doorstep service slots are full for the chosen date. Please choose a different date.");
			}else if(serviceType  == SERVICE_TYPE_PICKUP){
				throw new AppException("All pick-up and drop slots are full for the chosen date. Please choose a different date.");
			}
		}
		if(serviceType  == SERVICE_TYPE_DOORSTEP){
			if(operation == 1 && dealerServiceSlots.getTotalDoorStepCount() > dealerServiceSlots.getCurrentDoorStepCount()){
				dealerServiceSlots.setCurrentDoorStepCount(dealerServiceSlots.getCurrentDoorStepCount()+1);				
			}
			if(operation == 2 && dealerServiceSlots.getCurrentDoorStepCount() > 0){
				dealerServiceSlots.setCurrentDoorStepCount(dealerServiceSlots.getCurrentDoorStepCount()-1);				
			}
		}else if(serviceType  == SERVICE_TYPE_PICKUP){
			if(operation == 1 && dealerServiceSlots.getTotalPickupCount() > dealerServiceSlots.getCurrentPickupCount()){
				dealerServiceSlots.setCurrentPickupCount(dealerServiceSlots.getCurrentPickupCount()+1);				
			}
			if(operation == 2 && dealerServiceSlots.getCurrentPickupCount() > 0){
				dealerServiceSlots.setCurrentPickupCount(dealerServiceSlots.getCurrentPickupCount()-1);				
			}
		}
		dealerServiceSlotsRepository.save(dealerServiceSlots);
	}
	
	public DataResponseDTO getScheduledService(AppointmentCancelDTO cancelDTO) {
		DataResponseDTO responseDTO = new DataResponseDTO();		
		logger.info("getScheduledService  ChassisNo "+ cancelDTO.getChassisNo());
		Map<String,ScheduledAppointmentDTO> scheduledAppointmentDTOList = new HashMap<String, ScheduledAppointmentDTO>();
		if(cancelDTO.getChassisNo()!= null){
			String[] chassisNumbers = cancelDTO.getChassisNo().split(",");
			for (String chassisNo : chassisNumbers) {
				scheduledAppointmentDTOList.put(chassisNo,storedProcedureService.getScheduledService(chassisNo));	
			}
		}
		responseDTO.setResponse(scheduledAppointmentDTOList);
		return responseDTO;
	}
	
	public DataResponseDTO getFeedbackLink(AppointmentFeedbackRequestDTO feedbackDTO) {
		DataResponseDTO responseDTO = new DataResponseDTO();		
		logger.info("getFeedbackLink  JobCardNo "+ feedbackDTO.getJobCardNumber());
		Map<String,AppointmentFeedbackResponseDTO> feedBackLinkList = new HashMap<String, AppointmentFeedbackResponseDTO>();
		if(feedbackDTO.getJobCardNumber()!= null){
			String[] jobcardNumbers = feedbackDTO.getJobCardNumber().split(",");
			for (String jobCardNumber : jobcardNumbers) {
				feedBackLinkList.put(jobCardNumber,storedProcedureService.getFeedBackLInk(jobCardNumber));	
			}
		}
		responseDTO.setResponse(feedBackLinkList);
		return responseDTO;
	}
	
	public Boolean isValidUser(String chassisNo, String phoneNumber, String guid){
		logger.debug("checking isValidUser -> chassisNo-> "+chassisNo+" phoneNumber-> "+phoneNumber+" guid-> "+guid);
		RestTemplate restTemplate = new RestTemplate();	 
		DeviceResponseDTO device = null;
		if(chassisNo != null && !chassisNo.isEmpty()){
			device = restTemplate.getForObject(env.getProperty("spring.getdevice.webapi.url")+"chassisNo="+chassisNo, DeviceResponseDTO.class);
		}else{
			device = restTemplate.getForObject(env.getProperty("spring.getdevice.webapi.url")+"phone_number="+chassisNo, DeviceResponseDTO.class);
		}
		try {
			logger.debug("getDeviceTokenUsingGuid response - > "+mapper.writeValueAsString(device));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(device == null || !device.getCode().equals("200") || !device.getSuccess().equals("true")){
			logger.debug("no User found for the provided details-> ");			
			return false;
		}else{
			logger.debug("device.getData().getGuid() -> "+device.getData().getGuid());
			if(!device.getData().getGuid().equals(guid)){
				return false;
			}
		}
		return true;
	}
}