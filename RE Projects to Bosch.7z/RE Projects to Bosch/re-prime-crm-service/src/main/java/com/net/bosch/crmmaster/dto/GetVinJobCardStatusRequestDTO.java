package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class GetVinJobCardStatusRequestDTO implements Serializable {

	private static final long serialVersionUID = -3541122859222308326L;

	@NotBlank
	@NotNull
	private String chassisNo;

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GetVinJobCardStatusRequestDTO [chassisNo=").append(chassisNo).append("]");
		return builder.toString();
	}

}
