package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class BalancePaymentRequestDTO {

	@NotNull
	@NotBlank
	private String dealerSource;

	@NotNull
	@NotBlank
	private String dmsExcellonBookingId;

	private String modelId;
	private String bookingDate;
	private String customerAccount;

	private String dealerCode;
	private String dealerName;

	private String customerName;
	private String customerPhone;
	private String customerEmail;
	private String vehicleDescription;

	private String totalOnlineAmount; // Total Amount Return By DMS/Excellon
	private Double totalOnlinePaidAmount; // Total Amount Paid By Customer
	private String dealerAddress;

	private String excellonResponseKey;

	private String appId;

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BalancePaymentRequestDTO [dealerSource=");
		builder.append(dealerSource);
		builder.append(", dmsExcellonBookingId=");
		builder.append(dmsExcellonBookingId);
		builder.append(", modelId=");
		builder.append(modelId);
		builder.append(", bookingDate=");
		builder.append(bookingDate);
		builder.append(", customerAccount=");
		builder.append(customerAccount);
		builder.append(", dealerCode=");
		builder.append(dealerCode);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", customerPhone=");
		builder.append(customerPhone);
		builder.append(", customerEmail=");
		builder.append(customerEmail);
		builder.append(", vehicleDescription=");
		builder.append(vehicleDescription);
		builder.append(", totalOnlineAmount=");
		builder.append(totalOnlineAmount);
		builder.append(", totalOnlinePaidAmount=");
		builder.append(totalOnlinePaidAmount);
		builder.append(", dealerAddress=");
		builder.append(dealerAddress);
		builder.append(", excellonResponseKey=");
		builder.append(excellonResponseKey);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the excellonResponseKey
	 */
	public String getExcellonResponseKey() {
		return excellonResponseKey;
	}

	/**
	 * @param excellonResponseKey the excellonResponseKey to set
	 */
	public void setExcellonResponseKey(String excellonResponseKey) {
		this.excellonResponseKey = excellonResponseKey;
	}

	/**
	 * @return the dealerSource
	 */
	public String getDealerSource() {
		return dealerSource;
	}

	/**
	 * @param dealerSource the dealerSource to set
	 */
	public void setDealerSource(String dealerSource) {
		this.dealerSource = dealerSource;
	}

	/**
	 * @return the dmsExcellonBookingId
	 */
	public String getDmsExcellonBookingId() {
		return dmsExcellonBookingId;
	}

	/**
	 * @param dmsExcellonBookingId the dmsExcellonBookingId to set
	 */
	public void setDmsExcellonBookingId(String dmsExcellonBookingId) {
		this.dmsExcellonBookingId = dmsExcellonBookingId;
	}

	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}

	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	/**
	 * @return the bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * @param bookingDate the bookingDate to set
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * @return the customerAccount
	 */
	public String getCustomerAccount() {
		return customerAccount;
	}

	/**
	 * @param customerAccount the customerAccount to set
	 */
	public void setCustomerAccount(String customerAccount) {
		this.customerAccount = customerAccount;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the dealerName
	 */
	public String getDealerName() {
		return dealerName;
	}

	/**
	 * @param dealerName the dealerName to set
	 */
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerPhone
	 */
	public String getCustomerPhone() {
		return customerPhone;
	}

	/**
	 * @param customerPhone the customerPhone to set
	 */
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	/**
	 * @return the customerEmail
	 */
	public String getCustomerEmail() {
		return customerEmail;
	}

	/**
	 * @param customerEmail the customerEmail to set
	 */
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	/**
	 * @return the vehicleDescription
	 */
	public String getVehicleDescription() {
		return vehicleDescription;
	}

	/**
	 * @param vehicleDescription the vehicleDescription to set
	 */
	public void setVehicleDescription(String vehicleDescription) {
		this.vehicleDescription = vehicleDescription;
	}

	/**
	 * @return the totalOnlineAmount
	 */
	public String getTotalOnlineAmount() {
		return totalOnlineAmount;
	}

	/**
	 * @param totalOnlineAmount the totalOnlineAmount to set
	 */
	public void setTotalOnlineAmount(String totalOnlineAmount) {
		this.totalOnlineAmount = totalOnlineAmount;
	}

	/**
	 * @return the totalOnlinePaidAmount
	 */
	public Double getTotalOnlinePaidAmount() {
		return totalOnlinePaidAmount;
	}

	/**
	 * @param totalOnlinePaidAmount the totalOnlinePaidAmount to set
	 */
	public void setTotalOnlinePaidAmount(Double totalOnlinePaidAmount) {
		this.totalOnlinePaidAmount = totalOnlinePaidAmount;
	}

	/**
	 * @return the dealerAddress
	 */
	public String getDealerAddress() {
		return dealerAddress;
	}

	/**
	 * @param dealerAddress the dealerAddress to set
	 */
	public void setDealerAddress(String dealerAddress) {
		this.dealerAddress = dealerAddress;
	}

}
