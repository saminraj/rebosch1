package com.net.bosch.domain;

import java.io.Serializable;

public interface DomainObject extends Serializable{
	
}
