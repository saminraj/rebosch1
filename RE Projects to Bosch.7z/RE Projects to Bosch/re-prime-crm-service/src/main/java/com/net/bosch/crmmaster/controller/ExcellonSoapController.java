package com.net.bosch.crmmaster.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.net.bosch.crmmaster.service.ExcellonSoapService;

import https.royalenfield_com.generatepaymentkey.GeneratePaymentKeyRequest;
import https.royalenfield_com.generatepaymentkey.ReBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Endpoint
public class ExcellonSoapController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ExcellonSoapService excellonSoapService;

	private static final String NAME_SPACE = "https://royalenfield.com/generatePaymentKey";

	@PayloadRoot(namespace = NAME_SPACE, localPart = "generatePaymentKeyRequest")
	@ResponsePayload
	public ReBaseResponse generatePaymentKey(@RequestPayload GeneratePaymentKeyRequest payload) {

		logger.info("In ExcellonSoapController generatePaymentKey(), Input Params {{}}-", payload);

		return excellonSoapService.generatePaymentKey(payload);
	}

}
