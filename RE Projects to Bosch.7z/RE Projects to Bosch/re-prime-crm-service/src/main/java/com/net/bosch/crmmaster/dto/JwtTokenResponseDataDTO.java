package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class JwtTokenResponseDataDTO implements Serializable{
	
	private static final long serialVersionUID = -362848265077399549L;
	
	private String _id;

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}
	
}
