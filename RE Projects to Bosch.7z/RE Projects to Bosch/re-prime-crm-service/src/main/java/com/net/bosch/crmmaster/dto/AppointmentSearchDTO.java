package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class AppointmentSearchDTO{
	
	private String appointmentdate;
	
	private String branchID;
	
	private Boolean isDummySlots;

	public String getAppointmentdate() {
		return appointmentdate;
	}

	public void setAppointmentdate(String appointmentdate) {
		this.appointmentdate = appointmentdate;
	}

	public String getBranchID() {
		return branchID;
	}

	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}

	public Boolean getIsDummySlots() {
		return isDummySlots;
	}

	public void setIsDummySlots(Boolean isDummySlots) {
		this.isDummySlots = isDummySlots;
	}
		
}
