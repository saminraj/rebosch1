package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ScheduledAppointmentDTO{	
	
    private String appointmentDate;
    
    private String appointmentStatus;
    
    private String appointmentNum;
	
    private String branchID;
	
    private String registrationNumber;
	
    private String serviceType;
	
    private String chasssisNumber;
	
    private String appointmentDueDate;
    
    private String appointmentLastDate;

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public String getAppointmentNum() {
		return appointmentNum;
	}

	public void setAppointmentNum(String appointmentNum) {
		this.appointmentNum = appointmentNum;
	}

	public String getBranchID() {
		return branchID;
	}

	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getChasssisNumber() {
		return chasssisNumber;
	}

	public void setChasssisNumber(String chasssisNumber) {
		this.chasssisNumber = chasssisNumber;
	}

	public String getAppointmentDueDate() {
		return appointmentDueDate;
	}

	public void setAppointmentDueDate(String appointmentDueDate) {
		this.appointmentDueDate = appointmentDueDate;
	}

	public String getAppointmentLastDate() {
		return appointmentLastDate;
	}

	public void setAppointmentLastDate(String appointmentLastDate) {
		this.appointmentLastDate = appointmentLastDate;
	}
}
