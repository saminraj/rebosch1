package com.net.bosch.crmmaster.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.net.bosch.crmmaster.dto.ServiceHistoryRequestDTO;
import com.net.bosch.crmmaster.dto.VehicleRequestDTO;
import com.net.bosch.crmmaster.service.FirebaseService;
import com.net.bosch.crmmaster.service.StoredProcedureService;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;

@RestController
@CrossOrigin
@RequestMapping("/vehicle")
public class VehicleController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	StoredProcedureService storedProcedureService;
	
	@Autowired
	FirebaseService firebaseService;
	
	
	/**
	 * GET method to get a Dealer
	 */
	@RequestMapping(value="/GetVehicleDetails", method = RequestMethod.POST)
	public ResponseDTO getVehicle(@RequestBody @Valid VehicleRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getVehicle() called");
		
		storedProcedureService.fetchVehiclesByPhoneNo(requestDTO.getMobileNo());
		//storedProcedureService.asynFetchVehiclesByPhoneNo(requestDTO.getMobileNo());
//		new CrmAsyncThread(storedProcedureService).asyncFetchVehiclesByPhoneNo(requestDTO.getMobileNo());
		
		logger.debug("[getVehicle]: elapsed time: "+(System.currentTimeMillis()-startTime));
		
		return new ResponseDTO();
	}	

	/**
	 * POST method to pull service history from SP and dump in firestore.
	 */
	@RequestMapping(value="/fetchallservicehistory", method = RequestMethod.POST)
	public ResponseDTO fetchAllServiceHistory(@RequestBody @Valid ServiceHistoryRequestDTO serviceHistoryRequestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("fetchAllServiceHistory() called");
		logger.debug("serviceHistoryRequestDTO.getGuid() "+serviceHistoryRequestDTO.getGuid());
		storedProcedureService.fetchAllServiceHistory(serviceHistoryRequestDTO);
		
		
		logger.debug("[getVehicle]: elapsed time: "+(System.currentTimeMillis()-startTime));
		
		return new ResponseDTO();
	}
	
	@RequestMapping(value="/testVehicleDetails", method = RequestMethod.POST)
	public ResponseDTO testVehicleDetails(@RequestBody @Valid VehicleRequestDTO requestDTO) throws AppException {
		logger.debug("testVehicleDetails() in");
		//storedProcedureService.testVehicleDetails(requestDTO.getMobileNo());
		return new ResponseDTO();
	}		
	
	@RequestMapping(value="/{collection}", method = RequestMethod.GET)
	public String getCollection(@PathVariable String collection) throws AppException {
		
		logger.debug("getCollection() called");
		
		try {
			return firebaseService.getCollection(collection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "failed .. ";
	}		

	@RequestMapping(value="/deleteFirestore/{collectionId}/{docId}", method = RequestMethod.GET)
	public Boolean deleteFirestore(@PathVariable String collectionId,@PathVariable String docId) throws Exception {

		logger.debug("deleteFirestore() In "+ collectionId + " "+ docId);
		
//		collectionId = "9786641810";
//		docId = "Vehicle";
		
		return storedProcedureService.deleteFirbaseDoc(collectionId, docId);

	}	
	
	
	
	
}
