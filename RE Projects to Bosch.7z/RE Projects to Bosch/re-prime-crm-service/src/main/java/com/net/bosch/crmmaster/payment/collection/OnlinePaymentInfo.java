package com.net.bosch.crmmaster.payment.collection;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.net.bosch.constants.PaymentStage;
import com.net.bosch.crmmaster.dto.DynamicsBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.DynamicsBalancePaymentResponse;
import com.net.bosch.crmmaster.dto.DynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingResponse;
import com.net.bosch.crmmaster.dto.ExcellonBalancePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.ExcellonBalancePaymentResponse;
import com.net.bosch.crmmaster.dto.ExcellonBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.ExcellonBookingPaymentResponse;
import com.net.bosch.crmmaster.dto.InStoreDynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.PaymentRawResponse;


public class OnlinePaymentInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4454408431479813747L;

	private String appId;

	@CreatedDate
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date paymentTimeStamp;

	private Double amountPaid;

	private String paymentCaseId;

	private String billDeskTrnsactionId;

	private String paymentStatus;

	private Integer retryCount = 0;

	private PaymentStage paymentStage;

	/**
	 * Added for Instore Booking & Finance.
	 */
	private String transactionStage;

	/**
	 * Bill-Desk-Payment Response Params.
	 */
	private PaymentRawResponse paymentRawRespObj;

	/**
	 * Dms/Excellon Initial Payment Request & Response.
	 */
	private DynamicsBookingPaymentRequestDTO dynamicsRequest;
	/**
	 * In-Store Dms Response.
	 */
	private InStoreDynamicsBookingPaymentRequestDTO inStoreDynamicsRequest;

	private DynamicsBookingResponse dynamicsResponse;
	private ExcellonBookingPaymentRequestDTO excellonRequest;
	private ExcellonBookingPaymentResponse excellonResponse;

	/**
	 * Dms/Excellon Balance Payment Request & Response.
	 */
	private ExcellonBalancePaymentRequestDTO excellonBalancePaymentRequestDTO;
	private DynamicsBalancePaymentRequestDTO dynamicsBalancePaymentRequestDTO;
	private ExcellonBalancePaymentResponse excellonBalancePaymentResponse;
	private DynamicsBalancePaymentResponse dynamicsBalancePaymentResponse;


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OnlinePaymentInfo [appId=");
		builder.append(appId);
		builder.append(", paymentTimeStamp=");
		builder.append(paymentTimeStamp);
		builder.append(", amountPaid=");
		builder.append(amountPaid);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", billDeskTrnsactionId=");
		builder.append(billDeskTrnsactionId);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", retryCount=");
		builder.append(retryCount);
		builder.append(", paymentStage=");
		builder.append(paymentStage);
		builder.append(", paymentRawRespObj=");
		builder.append(paymentRawRespObj);
		builder.append(", dynamicsRequest=");
		builder.append(dynamicsRequest);
		builder.append(", dynamicsResponse=");
		builder.append(dynamicsResponse);
		builder.append(", excellonRequest=");
		builder.append(excellonRequest);
		builder.append(", excellonResponse=");
		builder.append(excellonResponse);
		builder.append(", excellonBalancePaymentRequestDTO=");
		builder.append(excellonBalancePaymentRequestDTO);
		builder.append(", dynamicsBalancePaymentRequestDTO=");
		builder.append(dynamicsBalancePaymentRequestDTO);
		builder.append(", excellonBalancePaymentResponse=");
		builder.append(excellonBalancePaymentResponse);
		builder.append(", dynamicsBalancePaymentResponse=");
		builder.append(dynamicsBalancePaymentResponse);
		builder.append(", transactionStage=");
		builder.append(transactionStage);
		builder.append(", inStoreDynamicsRequest=");
		builder.append(inStoreDynamicsRequest);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the excellonBalancePaymentRequestDTO
	 */
	public ExcellonBalancePaymentRequestDTO getExcellonBalancePaymentRequestDTO() {
		return excellonBalancePaymentRequestDTO;
	}

	/**
	 * @param excellonBalancePaymentRequestDTO the excellonBalancePaymentRequestDTO
	 *                                         to set
	 */
	public void setExcellonBalancePaymentRequestDTO(ExcellonBalancePaymentRequestDTO excellonBalancePaymentRequestDTO) {
		this.excellonBalancePaymentRequestDTO = excellonBalancePaymentRequestDTO;
	}

	/**
	 * @return the dynamicsBalancePaymentRequestDTO
	 */
	public DynamicsBalancePaymentRequestDTO getDynamicsBalancePaymentRequestDTO() {
		return dynamicsBalancePaymentRequestDTO;
	}

	/**
	 * @param dynamicsBalancePaymentRequestDTO the dynamicsBalancePaymentRequestDTO
	 *                                         to set
	 */
	public void setDynamicsBalancePaymentRequestDTO(DynamicsBalancePaymentRequestDTO dynamicsBalancePaymentRequestDTO) {
		this.dynamicsBalancePaymentRequestDTO = dynamicsBalancePaymentRequestDTO;
	}

	/**
	 * @return the excellonBalancePaymentResponse
	 */
	public ExcellonBalancePaymentResponse getExcellonBalancePaymentResponse() {
		return excellonBalancePaymentResponse;
	}

	/**
	 * @param excellonBalancePaymentResponse the excellonBalancePaymentResponse to
	 *                                       set
	 */
	public void setExcellonBalancePaymentResponse(ExcellonBalancePaymentResponse excellonBalancePaymentResponse) {
		this.excellonBalancePaymentResponse = excellonBalancePaymentResponse;
	}

	/**
	 * @return the dynamicsBalancePaymentResponse
	 */
	public DynamicsBalancePaymentResponse getDynamicsBalancePaymentResponse() {
		return dynamicsBalancePaymentResponse;
	}

	/**
	 * @param dynamicsBalancePaymentResponse the dynamicsBalancePaymentResponse to
	 *                                       set
	 */
	public void setDynamicsBalancePaymentResponse(DynamicsBalancePaymentResponse dynamicsBalancePaymentResponse) {
		this.dynamicsBalancePaymentResponse = dynamicsBalancePaymentResponse;
	}

	/**
	 * @return the paymentStage
	 */
	public PaymentStage getPaymentStage() {
		return paymentStage;
	}

	/**
	 * @param paymentStage the paymentStage to set
	 */
	public void setPaymentStage(PaymentStage paymentStage) {
		this.paymentStage = paymentStage;
	}

	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the dynamicsRequest
	 */
	public DynamicsBookingPaymentRequestDTO getDynamicsRequest() {
		return dynamicsRequest;
	}

	/**
	 * @param dynamicsRequest the dynamicsRequest to set
	 */
	public void setDynamicsRequest(DynamicsBookingPaymentRequestDTO dynamicsRequest) {
		this.dynamicsRequest = dynamicsRequest;
	}

	/**
	 * @return the excellonRequest
	 */
	public ExcellonBookingPaymentRequestDTO getExcellonRequest() {
		return excellonRequest;
	}

	/**
	 * @param excellonRequest the excellonRequest to set
	 */
	public void setExcellonRequest(ExcellonBookingPaymentRequestDTO excellonRequest) {
		this.excellonRequest = excellonRequest;
	}

	/**
	 * @return the excellonResponse
	 */
	public ExcellonBookingPaymentResponse getExcellonResponse() {
		return excellonResponse;
	}

	/**
	 * @param excellonResponse the excellonResponse to set
	 */
	public void setExcellonResponse(ExcellonBookingPaymentResponse excellonResponse) {
		this.excellonResponse = excellonResponse;
	}

	/**
	 * @return the paymentRawRespObj
	 */
	public PaymentRawResponse getPaymentRawRespObj() {
		return paymentRawRespObj;
	}

	/**
	 * @param paymentRawRespObj the paymentRawRespObj to set
	 */
	public void setPaymentRawRespObj(PaymentRawResponse paymentRawRespObj) {
		this.paymentRawRespObj = paymentRawRespObj;
	}

	/**
	 * @return the dynamicsResponse
	 */
	public DynamicsBookingResponse getDynamicsResponse() {
		return dynamicsResponse;
	}

	/**
	 * @param dynamicsResponse the dynamicsResponse to set
	 */
	public void setDynamicsResponse(DynamicsBookingResponse dynamicsResponse) {
		this.dynamicsResponse = dynamicsResponse;
	}

	/**
	 * @return the paymentTimeStamp
	 */
	public Date getPaymentTimeStamp() {
		return paymentTimeStamp;
	}

	/**
	 * @param paymentTimeStamp the paymentTimeStamp to set
	 */
	public void setPaymentTimeStamp(Date paymentTimeStamp) {
		this.paymentTimeStamp = paymentTimeStamp;
	}

	/**
	 * @return the amountPaid
	 */
	public Double getAmountPaid() {
		return amountPaid;
	}

	/**
	 * @param amountPaid the amountPaid to set
	 */
	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the billDeskTrnsactionId
	 */
	public String getBillDeskTrnsactionId() {
		return billDeskTrnsactionId;
	}

	/**
	 * @param billDeskTrnsactionId the billDeskTrnsactionId to set
	 */
	public void setBillDeskTrnsactionId(String billDeskTrnsactionId) {
		this.billDeskTrnsactionId = billDeskTrnsactionId;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the transactionStage
	 */
	public String getTransactionStage() {
		return transactionStage;
	}

	/**
	 * @param transactionStage the transactionStage to set
	 */
	public void setTransactionStage(String transactionStage) {
		this.transactionStage = transactionStage;
	}


	/**
	 * @return the inStoreDynamicsRequest
	 */
	public InStoreDynamicsBookingPaymentRequestDTO getInStoreDynamicsRequest() {
		return inStoreDynamicsRequest;
	}

	/**
	 * @param inStoreDynamicsRequest the inStoreDynamicsRequest to set
	 */
	public void setInStoreDynamicsRequest(InStoreDynamicsBookingPaymentRequestDTO inStoreDynamicsRequest) {
		this.inStoreDynamicsRequest = inStoreDynamicsRequest;
	}

}
