package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.List;

public class SelectedProducts implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String defaultPrice;
	private String category;
	private String price;
	private String productId;
	private String productName;
	private String subCategory;
	private String thumbnailImage;
	private boolean visibility;
	private String color;
	private String isHelperProduct;
	private List<String> collisionProduct;
	private List<String> productToAdd;
	private List<String> productToRemove;

	/**
	 * @return the isHelperProduct
	 */
	public String getIsHelperProduct() {
		return isHelperProduct;
	}

	/**
	 * @param isHelperProduct the isHelperProduct to set
	 */
	public void setIsHelperProduct(String isHelperProduct) {
		this.isHelperProduct = isHelperProduct;
	}

	public String getDefaultPrice() {
		return defaultPrice;
	}

	public void setDefaultPrice(String defaultPrice) {
		this.defaultPrice = defaultPrice;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getThumbnailImage() {
		return thumbnailImage;
	}

	public void setThumbnailImage(String thumbnailImage) {
		this.thumbnailImage = thumbnailImage;
	}

	public boolean isVisibility() {
		return visibility;
	}

	public void setVisibility(boolean visibility) {
		this.visibility = visibility;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public List<String> getCollisionProduct() {
		return collisionProduct;
	}

	public void setCollisionProduct(List<String> collisionProduct) {
		this.collisionProduct = collisionProduct;
	}

	public List<String> getProductToAdd() {
		return productToAdd;
	}

	public void setProductToAdd(List<String> productToAdd) {
		this.productToAdd = productToAdd;
	}

	public List<String> getProductToRemove() {
		return productToRemove;
	}

	public void setProductToRemove(List<String> productToRemove) {
		this.productToRemove = productToRemove;
	}

	@Override
	public String toString() {
		return "SelectedProducts [defaultPrice=" + defaultPrice + ", category=" + category + ", price=" + price
				+ ", productId=" + productId + ", productName=" + productName + ", subCategory=" + subCategory
				+ ", thumbnailImage=" + thumbnailImage + ", visibility=" + visibility + ", color=" + color
				+ ", collisionProduct=" + collisionProduct + ", productToAdd=" + productToAdd + ", productToRemove="
				+ productToRemove + "]";
	}

}
