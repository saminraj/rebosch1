package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum VehicleStatus {
	VERIFIED("V"), PENDING("P"), FAILED("F"), REJECTED("R"), REGISTRATION_NO_UPDATE_PENDING("RNUP"),
	REMOVE_BIKE_PENDING("RBP");

	private String value;

	private VehicleStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}