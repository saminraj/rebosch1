
package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class VariantDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1229850607539461163L;
	private String variantMailerImage;
	private String bookingAmount;
	private String colorCodeName;
	private String summaryImage;
	private String price;
	private String colorCode;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VariantDetails [variantMailerImage=");
		builder.append(variantMailerImage);
		builder.append(", bookingAmount=");
		builder.append(bookingAmount);
		builder.append(", colorCodeName=");
		builder.append(colorCodeName);
		builder.append(", summaryImage=");
		builder.append(summaryImage);
		builder.append(", price=");
		builder.append(price);
		builder.append(", colorCode=");
		builder.append(colorCode);
		builder.append("]");
		return builder.toString();
	}

	public String getVariantMailerImage() {
		return variantMailerImage;
	}

	public void setVariantMailerImage(String variantMailerImage) {
		this.variantMailerImage = variantMailerImage;
	}

	public String getBookingAmount() {
		return bookingAmount;
	}

	public void setBookingAmount(String bookingAmount) {
		this.bookingAmount = bookingAmount;
	}

	public String getColorCodeName() {
		return colorCodeName;
	}

	public void setColorCodeName(String colorCodeName) {
		this.colorCodeName = colorCodeName;
	}

	public String getSummaryImage() {
		return summaryImage;
	}

	public void setSummaryImage(String summaryImage) {
		this.summaryImage = summaryImage;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

}
