package com.net.bosch.filter;

import static com.net.bosch.utils.SoapResponseHelper.getSoapXMLResponse;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.net.bosch.utils.TokenValidatorUtil;

@Component
public class AppFilter implements Filter {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * This app id is used for re-prime-master-service Batch Job, to skip JWT token
	 * validation.
	 */

	private static String APP_ID_VALUE = "999";
	private static String DMS_BY_PASS_APP_ID_VALUE = "100";
	private static String EXCELLON_BY_PASS_APP_ID_VALUE = "101";
	private static String DMS_BY_PASS_URL = "/booking/balancePayment/generatePaymentKey";
	private static String EXCELLON_BY_PASS_URL = "/ws/balancePayment/generatePaymentKey";

	private static String[] jwtByPassUrls = { "/user/vehicle/getDetails", "/user/vehicle/updateVehicleStatus",
			"/user/vehicle/getVin", "/booking/getBookingTransactions", "/booking/updateExcellonMsdResponse",
			"/booking/search", "/booking/balancePayment/generatePaymentKey",
			"/booking/balancePayment/validatePaymentKey", "/booking/balancePayment/save",
			"/booking/balancePayment/update", "/booking/balancePayment/search",
			"/booking/balancePayment/updateExcellonMsdBalancePaymentResponse",
			"/booking/balancePayment/generatePaymentKey", "/ws/balancePayment/generatePaymentKey",
			"/booking/balancePayment/updateExcellonMsdBalancePaymentResponse", "/vehicle/fetchallservicehistory",
			"/user/vehicle/getFullDetails", "/user/vehicle/getVinJobCardStatus", "/booking/syncBookingsToFireBase",
			"/user/vehicle/verifyAndUpdateServiceHistory", "/booking/syncFinanceDetailsToFireBase",
			"/booking/instore/save", "/booking/fetchUserBookings", "/booking/instore/updateGuid",
			"/booking/syncBookingsToFireBase", "/user/vehicle/verifyAndUpdateServiceHistory",
			"/user/vehicle/getFullDetails", "/user/vehicle/fetchProfileVehicles",
			"/user/vehicle/updateConnectedFlag" };

	@Autowired
	private Environment env;

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;
		domainHandler(chain, request, response);
	}

	private boolean domainHandler(FilterChain chain, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String path = (request).getRequestURI();

		logger.debug("Inside the App Filter getRequestURI ---------------->" + path);

		String languageHeader = StringUtils.trimToNull(request.getHeader("x-custom-language"));
		String countryHeader = StringUtils.trimToNull(request.getHeader("x-custom-country"));
		logger.info("Headers Language {{}} ,Country {{}}", languageHeader, countryHeader);

		if (path.startsWith("/js/") || path.startsWith("/dataTables/") || path.startsWith("/css/")
				|| path.startsWith("/images/") || path.contains("/v2/") || path.contains("wsdl")) {
			// Skip DomainCheck
			logger.debug("Skip DomainCheck ---------------->");
		} else {
			String jwtToken = StringUtils.trimToNull(request.getHeader("Authorization"));
			String appId = StringUtils.trimToNull(request.getHeader("app_id"));
			logger.info("App Id {{}} ,JWT Token {{}}", appId, jwtToken);

			if (StringUtils.isEmpty(appId)) {
				logger.debug("App Id is Required.");

				returnResponse(response, path, "App Id is Required.");
				return false;
			}
			if (validateJWTByPassUrls(appId, path)) {
				logger.info("JWT token authentication by-pass successfully for URL {{}}", path);
				chain.doFilter(request, response);
				return false;
			}
			if (StringUtils.isEmpty(jwtToken)) {
				logger.debug("Authorization Token is Required.");

				returnResponse(response, path, "Authorization Token is Required.");
				return false;
			}
			String guid = TokenValidatorUtil.validateAuthenticationToken(jwtToken,
					env.getProperty("spring.jwt.url"));

			if (guid == null) {
				logger.debug("Invalid authentication token ---------------->");
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "jwt token is invalid or incorrect");
				return false;
			}
			request.setAttribute("guid", guid);
			request.setAttribute("app_id", appId);
		}
		chain.doFilter(request, response);
		return false;
	}

	/**
	 * @param app_id
	 * @param path
	 * @return
	 */
	private boolean validateJWTByPassUrls(final String app_id, final String path) {
		logger.info("Verifying URL's with app id to skip JWT token authentication.");

		if ((StringUtils.equals(app_id, DMS_BY_PASS_APP_ID_VALUE) && StringUtils.equals(path, DMS_BY_PASS_URL))
				|| (StringUtils.equals(app_id, EXCELLON_BY_PASS_APP_ID_VALUE)
						&& StringUtils.equals(path, EXCELLON_BY_PASS_URL))) {
			return true;
		}
		if ((StringUtils.equals(app_id, APP_ID_VALUE)) && (StringUtils.equals(path, "/user/vehicle/verifyPurchaseDates")
				|| StringUtils.equals(path, "/user/vehicle/updatePurchaseDates")
				|| StringUtils.equals(path, "/user/vehicle/updateDatesAndServiceHistory")
				|| StringUtils.equals(path, "/user/vehicle/isServiceHistoryExistInDms")
				|| StringUtils.equals(path, "/user/vehicle/updateServiceHistoryWithDates")
				|| StringUtils.equals(path, "/user/vehicle/updateServiceHistoryWithChassisNo")
				|| StringUtils.equals(path, "/user/vehicle/updateExcellonServiceHistoryWithDates")
				|| StringUtils.equals(path, "/user/vehicle/updateExcellonServiceHistoryWithChassisNo"))) {
			return true;
		}
		return (StringUtils.equals(app_id, APP_ID_VALUE) && Arrays.asList(jwtByPassUrls).contains(path));
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// Do nothing
	}

	@Override
	public void destroy() {
		// Do nothing
	}

	/**
	 * @param response
	 * @param path
	 * @param errorMessage
	 * @return
	 * @throws IOException
	 */
	private HttpServletResponse returnResponse(HttpServletResponse response, String path, String errorMessage)
			throws IOException {
		if (path.contains("/ws/")) {
			response = getSoapXMLResponse(response, errorMessage);
			return response;
		}
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, errorMessage);
		return response;
	}
}
