package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author pushkarkhosla
 *
 */
public class DynamicsBookingPaymentRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -920079437409714818L;
	private String configid;
	private String configdescription;
	private String typeofnquiry;
	private String mobileno;
	private String enquirycategory;
	private String salutation;
	private String firstname;
	private String lastname;
	private String email;
	private String purchasetimeframe;
	private String dealer;
	private String primarysource;
	private String secondarySource;
	private String city;
	private String state;
	private String ownerstatus;
	private String testridetaken;
	private String testridedenialreason;

	private List<DynamicsBookingPaymentPartsDTO> parts;

	private String stageoflife;
	private String usage;
	private String ridetaken;
	private String existingcar;
	private String possiblepersona;
	private String actualpersona;
	private String fourWOwned;
	private String purposeOfUse;
	private String pincode;
	private String date_of_birth;
	private String gender;
	private String paymentId;
	private String creationsource;
	private String pannumber;
	private String alternatemobilenumber;
	private String bookingmodel;
	private String financerequired;
	private String preferredfinancer;
	private String interestinexchange;
	private String beeninanyrides;
	private String street1;
	private String street2;
	private String country;
	private String district;
	private String occupation;
	private String tentativedeliverydays;
	private String modeofregistration;
	private String referencenumber;
	private String bookingdate;
	private String paymentmode;
	private String fathername;
	private String badgename;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DynamicsBookingPaymentRequestDTO [configid=");
		builder.append(configid);
		builder.append(", configdescription=");
		builder.append(configdescription);
		builder.append(", typeofnquiry=");
		builder.append(typeofnquiry);
		builder.append(", mobileno=");
		builder.append(mobileno);
		builder.append(", enquirycategory=");
		builder.append(enquirycategory);
		builder.append(", salutation=");
		builder.append(salutation);
		builder.append(", firstname=");
		builder.append(firstname);
		builder.append(", lastname=");
		builder.append(lastname);
		builder.append(", email=");
		builder.append(email);
		builder.append(", purchasetimeframe=");
		builder.append(purchasetimeframe);
		builder.append(", dealer=");
		builder.append(dealer);
		builder.append(", primarysource=");
		builder.append(primarysource);
		builder.append(", secondarysource=");
		builder.append(secondarySource);
		builder.append(", city=");
		builder.append(city);
		builder.append(", state=");
		builder.append(state);
		builder.append(", ownerstatus=");
		builder.append(ownerstatus);
		builder.append(", testridetaken=");
		builder.append(testridetaken);
		builder.append(", testridedenialreason=");
		builder.append(testridedenialreason);
		builder.append(", parts=");
		builder.append(parts);
		builder.append(", stageoflife=");
		builder.append(stageoflife);
		builder.append(", usage=");
		builder.append(usage);
		builder.append(", ridetaken=");
		builder.append(ridetaken);
		builder.append(", existingcar=");
		builder.append(existingcar);
		builder.append(", possiblepersona=");
		builder.append(possiblepersona);
		builder.append(", actualpersona=");
		builder.append(actualpersona);
		builder.append(", fourWOwned=");
		builder.append(fourWOwned);
		builder.append(", purposeOfUse=");
		builder.append(purposeOfUse);
		builder.append(", pincode=");
		builder.append(pincode);
		builder.append(", date_of_birth=");
		builder.append(date_of_birth);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", paymentId=");
		builder.append(paymentId);
		builder.append(", creationsource=");
		builder.append(creationsource);
		builder.append(", pannumber=");
		builder.append(pannumber);
		builder.append(", alternatemobilenumber=");
		builder.append(alternatemobilenumber);
		builder.append(", bookingmodel=");
		builder.append(bookingmodel);
		builder.append(", financerequired=");
		builder.append(financerequired);
		builder.append(", preferredfinancer=");
		builder.append(preferredfinancer);
		builder.append(", interestinexchange=");
		builder.append(interestinexchange);
		builder.append(", beeninanyrides=");
		builder.append(beeninanyrides);
		builder.append(", street1=");
		builder.append(street1);
		builder.append(", street2=");
		builder.append(street2);
		builder.append(", country=");
		builder.append(country);
		builder.append(", district=");
		builder.append(district);
		builder.append(", occupation=");
		builder.append(occupation);
		builder.append(", tentativedeliverydays=");
		builder.append(tentativedeliverydays);
		builder.append(", modeofregistration=");
		builder.append(modeofregistration);
		builder.append(", referencenumber=");
		builder.append(referencenumber);
		builder.append(", bookingdate=");
		builder.append(bookingdate);
		builder.append(", paymentmode=");
		builder.append(paymentmode);
		builder.append(", fathername=");
		builder.append(fathername);
		builder.append(", badgename=");
		builder.append(badgename);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the secondarySource
	 */
	public String getSecondarySource() {
		return secondarySource;
	}

	/**
	 * @param secondarySource the secondarySource to set
	 */
	public void setSecondarySource(String secondarySource) {
		this.secondarySource = secondarySource;
	}

	/**
	 * @return the configid
	 */
	public String getConfigid() {
		return configid;
	}

	/**
	 * @param configid the configid to set
	 */
	public void setConfigid(String configid) {
		this.configid = configid;
	}

	/**
	 * @return the configdescription
	 */
	public String getConfigdescription() {
		return configdescription;
	}

	/**
	 * @param configdescription the configdescription to set
	 */
	public void setConfigdescription(String configdescription) {
		this.configdescription = configdescription;
	}

	/**
	 * @return the typeofnquiry
	 */
	public String getTypeofnquiry() {
		return typeofnquiry;
	}

	/**
	 * @param typeofnquiry the typeofnquiry to set
	 */
	public void setTypeofnquiry(String typeofnquiry) {
		this.typeofnquiry = typeofnquiry;
	}

	/**
	 * @return the mobileno
	 */
	public String getMobileno() {
		return mobileno;
	}

	/**
	 * @param mobileno the mobileno to set
	 */
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	/**
	 * @return the enquirycategory
	 */
	public String getEnquirycategory() {
		return enquirycategory;
	}

	/**
	 * @param enquirycategory the enquirycategory to set
	 */
	public void setEnquirycategory(String enquirycategory) {
		this.enquirycategory = enquirycategory;
	}

	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * @param salutation the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the purchasetimeframe
	 */
	public String getPurchasetimeframe() {
		return purchasetimeframe;
	}

	/**
	 * @param purchasetimeframe the purchasetimeframe to set
	 */
	public void setPurchasetimeframe(String purchasetimeframe) {
		this.purchasetimeframe = purchasetimeframe;
	}

	/**
	 * @return the dealer
	 */
	public String getDealer() {
		return dealer;
	}

	/**
	 * @param dealer the dealer to set
	 */
	public void setDealer(String dealer) {
		this.dealer = dealer;
	}

	/**
	 * @return the primarysource
	 */
	public String getPrimarysource() {
		return primarysource;
	}

	/**
	 * @param primarysource the primarysource to set
	 */
	public void setPrimarysource(String primarysource) {
		this.primarysource = primarysource;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the ownerstatus
	 */
	public String getOwnerstatus() {
		return ownerstatus;
	}

	/**
	 * @param ownerstatus the ownerstatus to set
	 */
	public void setOwnerstatus(String ownerstatus) {
		this.ownerstatus = ownerstatus;
	}

	/**
	 * @return the testridetaken
	 */
	public String getTestridetaken() {
		return testridetaken;
	}

	/**
	 * @param testridetaken the testridetaken to set
	 */
	public void setTestridetaken(String testridetaken) {
		this.testridetaken = testridetaken;
	}

	/**
	 * @return the testridedenialreason
	 */
	public String getTestridedenialreason() {
		return testridedenialreason;
	}

	/**
	 * @param testridedenialreason the testridedenialreason to set
	 */
	public void setTestridedenialreason(String testridedenialreason) {
		this.testridedenialreason = testridedenialreason;
	}

	/**
	 * @return the parts
	 */
	public List<DynamicsBookingPaymentPartsDTO> getParts() {
		return parts;
	}

	/**
	 * @param parts the parts to set
	 */
	public void setParts(List<DynamicsBookingPaymentPartsDTO> parts) {
		this.parts = parts;
	}

	/**
	 * @return the stageoflife
	 */
	public String getStageoflife() {
		return stageoflife;
	}

	/**
	 * @param stageoflife the stageoflife to set
	 */
	public void setStageoflife(String stageoflife) {
		this.stageoflife = stageoflife;
	}

	/**
	 * @return the usage
	 */
	public String getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}

	/**
	 * @return the ridetaken
	 */
	public String getRidetaken() {
		return ridetaken;
	}

	/**
	 * @param ridetaken the ridetaken to set
	 */
	public void setRidetaken(String ridetaken) {
		this.ridetaken = ridetaken;
	}

	/**
	 * @return the existingcar
	 */
	public String getExistingcar() {
		return existingcar;
	}

	/**
	 * @param existingcar the existingcar to set
	 */
	public void setExistingcar(String existingcar) {
		this.existingcar = existingcar;
	}

	/**
	 * @return the possiblepersona
	 */
	public String getPossiblepersona() {
		return possiblepersona;
	}

	/**
	 * @param possiblepersona the possiblepersona to set
	 */
	public void setPossiblepersona(String possiblepersona) {
		this.possiblepersona = possiblepersona;
	}

	/**
	 * @return the actualpersona
	 */
	public String getActualpersona() {
		return actualpersona;
	}

	/**
	 * @param actualpersona the actualpersona to set
	 */
	public void setActualpersona(String actualpersona) {
		this.actualpersona = actualpersona;
	}

	/**
	 * @return the fourWOwned
	 */
	public String getFourWOwned() {
		return fourWOwned;
	}

	/**
	 * @param fourWOwned the fourWOwned to set
	 */
	public void setFourWOwned(String fourWOwned) {
		this.fourWOwned = fourWOwned;
	}

	/**
	 * @return the purposeOfUse
	 */
	public String getPurposeOfUse() {
		return purposeOfUse;
	}

	/**
	 * @param purposeOfUse the purposeOfUse to set
	 */
	public void setPurposeOfUse(String purposeOfUse) {
		this.purposeOfUse = purposeOfUse;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the date_of_birth
	 */
	public String getDate_of_birth() {
		return date_of_birth;
	}

	/**
	 * @param date_of_birth the date_of_birth to set
	 */
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the paymentId
	 */
	public String getPaymentId() {
		return paymentId;
	}

	/**
	 * @param paymentId the paymentId to set
	 */
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	/**
	 * @return the creationsource
	 */
	public String getCreationsource() {
		return creationsource;
	}

	/**
	 * @param creationsource the creationsource to set
	 */
	public void setCreationsource(String creationsource) {
		this.creationsource = creationsource;
	}

	/**
	 * @return the pannumber
	 */
	public String getPannumber() {
		return pannumber;
	}

	/**
	 * @param pannumber the pannumber to set
	 */
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}

	/**
	 * @return the alternatemobilenumber
	 */
	public String getAlternatemobilenumber() {
		return alternatemobilenumber;
	}

	/**
	 * @param alternatemobilenumber the alternatemobilenumber to set
	 */
	public void setAlternatemobilenumber(String alternatemobilenumber) {
		this.alternatemobilenumber = alternatemobilenumber;
	}

	/**
	 * @return the bookingmodel
	 */
	public String getBookingmodel() {
		return bookingmodel;
	}

	/**
	 * @param bookingmodel the bookingmodel to set
	 */
	public void setBookingmodel(String bookingmodel) {
		this.bookingmodel = bookingmodel;
	}

	/**
	 * @return the financerequired
	 */
	public String getFinancerequired() {
		return financerequired;
	}

	/**
	 * @param financerequired the financerequired to set
	 */
	public void setFinancerequired(String financerequired) {
		this.financerequired = financerequired;
	}

	/**
	 * @return the preferredfinancer
	 */
	public String getPreferredfinancer() {
		return preferredfinancer;
	}

	/**
	 * @param preferredfinancer the preferredfinancer to set
	 */
	public void setPreferredfinancer(String preferredfinancer) {
		this.preferredfinancer = preferredfinancer;
	}

	/**
	 * @return the interestinexchange
	 */
	public String getInterestinexchange() {
		return interestinexchange;
	}

	/**
	 * @param interestinexchange the interestinexchange to set
	 */
	public void setInterestinexchange(String interestinexchange) {
		this.interestinexchange = interestinexchange;
	}

	/**
	 * @return the beeninanyrides
	 */
	public String getBeeninanyrides() {
		return beeninanyrides;
	}

	/**
	 * @param beeninanyrides the beeninanyrides to set
	 */
	public void setBeeninanyrides(String beeninanyrides) {
		this.beeninanyrides = beeninanyrides;
	}

	/**
	 * @return the street1
	 */
	public String getStreet1() {
		return street1;
	}

	/**
	 * @param street1 the street1 to set
	 */
	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	/**
	 * @return the street2
	 */
	public String getStreet2() {
		return street2;
	}

	/**
	 * @param street2 the street2 to set
	 */
	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the occupation
	 */
	public String getOccupation() {
		return occupation;
	}

	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * @return the tentativedeliverydays
	 */
	public String getTentativedeliverydays() {
		return tentativedeliverydays;
	}

	/**
	 * @param tentativedeliverydays the tentativedeliverydays to set
	 */
	public void setTentativedeliverydays(String tentativedeliverydays) {
		this.tentativedeliverydays = tentativedeliverydays;
	}

	/**
	 * @return the modeofregistration
	 */
	public String getModeofregistration() {
		return modeofregistration;
	}

	/**
	 * @param modeofregistration the modeofregistration to set
	 */
	public void setModeofregistration(String modeofregistration) {
		this.modeofregistration = modeofregistration;
	}

	/**
	 * @return the referencenumber
	 */
	public String getReferencenumber() {
		return referencenumber;
	}

	/**
	 * @param referencenumber the referencenumber to set
	 */
	public void setReferencenumber(String referencenumber) {
		this.referencenumber = referencenumber;
	}

	/**
	 * @return the bookingdate
	 */
	public String getBookingdate() {
		return bookingdate;
	}

	/**
	 * @param bookingdate the bookingdate to set
	 */
	public void setBookingdate(String bookingdate) {
		this.bookingdate = bookingdate;
	}

	/**
	 * @return the paymentmode
	 */
	public String getPaymentmode() {
		return paymentmode;
	}

	/**
	 * @param paymentmode the paymentmode to set
	 */
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}

	/**
	 * @return the fathername
	 */
	public String getFathername() {
		return fathername;
	}

	/**
	 * @param fathername the fathername to set
	 */
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	/**
	 * @return the badgename
	 */
	public String getBadgename() {
		return badgename;
	}

	/**
	 * @param badgename the badgename to set
	 */
	public void setBadgename(String badgename) {
		this.badgename = badgename;
	}

}
