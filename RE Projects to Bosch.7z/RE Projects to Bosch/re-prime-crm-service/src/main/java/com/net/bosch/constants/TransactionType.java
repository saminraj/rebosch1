package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum TransactionType {

	INSTORE_DMS_POSTED("INSTORE_DMS_POSTED"),
	/**
	 * In Store-Bookings Transaction Stage after booking direct posting is failed.
	 * And this transaction will picked by batch job.
	 */
	INSTORE_DMS_FAILED("INSTORE_DMS_FAILED");

	private String value;

	private TransactionType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
