package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.ACCESS_TOKEN;
import static com.net.bosch.constants.Constants.APP_ID_VALUE_FOR_PUSH_NOTIFICATION;
import static com.net.bosch.constants.Constants.CLIENT_ID;
import static com.net.bosch.constants.Constants.CLIENT_SECRET;
import static com.net.bosch.constants.Constants.DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SIG;
import static com.net.bosch.constants.Constants.DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SP;
import static com.net.bosch.constants.Constants.DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SV;
import static com.net.bosch.constants.Constants.DMS_BOOKING_DETAILS_API_QUERY_PARAMS_VERSION;
import static com.net.bosch.constants.Constants.FETCH_CONFIG_STATUS_ID_PARAM;
import static com.net.bosch.constants.Constants.GRANT_TYPE;
import static com.net.bosch.constants.Constants.RESOURCE;
import static com.net.bosch.constants.Constants.SUCCESS_CODE;
import static com.net.bosch.constants.Constants.VEHICLE_ONBOARDING;
import static com.net.bosch.constants.Constants.WEB_USER_NAME_KEY;
import static com.net.bosch.utils.ApplicationHelper.convertObjectToJson;
import static com.net.bosch.utils.ApplicationHelper.getHttpEntity;
import static com.net.bosch.utils.ApplicationHelper.getInstoreBookingDMSHttpEntity;
import static com.net.bosch.utils.ApplicationHelper.validateShowAuthorizeApiResponse;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.net.URI;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.crmmaster.dto.AzureLoggerEmailDTO;
import com.net.bosch.crmmaster.dto.AzureLoggerEmailDataDTO;
import com.net.bosch.crmmaster.dto.CustomerConfiguratorResponseDTO;
import com.net.bosch.crmmaster.dto.DMSBookingDetailsDTO;
import com.net.bosch.crmmaster.dto.DMSBookingDetailsResponse;
import com.net.bosch.crmmaster.dto.EmailDTO;
import com.net.bosch.crmmaster.dto.ExcellonServiceHistoryResponse;
import com.net.bosch.crmmaster.dto.FirestoreUpdateRequestDTO;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyRequestDTO;
import com.net.bosch.crmmaster.dto.InStoreDynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.InstoreBookingDMSResponseDTO;
import com.net.bosch.crmmaster.dto.SavePaymentKeyRequest;
import com.net.bosch.crmmaster.dto.ShowAuthorizeRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateConfigStatusRequestDTO;
import com.net.bosch.crmmaster.dto.UserProfileResponseDTO;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyExpiryDTO;
import com.net.bosch.crmmaster.dto.ValidatePaymentKeyExpiryResponse;
import com.net.bosch.crmmaster.dto.notification.Content;
import com.net.bosch.crmmaster.dto.notification.Data;
import com.net.bosch.crmmaster.dto.notification.Message;
import com.net.bosch.crmmaster.dto.notification.MetaData;
import com.net.bosch.crmmaster.dto.notification.Params;
import com.net.bosch.crmmaster.dto.notification.Preferences;
import com.net.bosch.crmmaster.dto.notification.Recipient;
import com.net.bosch.crmmaster.dto.notification.SendNotificationRequestDTO;
import com.net.bosch.crmmaster.dto.notification.SendNotificationResponse;
import com.net.bosch.crmmaster.dto.notification.Sender;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class RestTemplateService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${re.payment.service.save.payment.key.api.url}")
	private String savePaymentKeyUrl;

	@Value("${re.payment.service.validate.payment.key.api.url}")
	private String validatePaymentKeyUrl;

	@Value("${re.dms.booking.details.api.url}")
	private String dmsBookingDetailsUrl;

	@Value("${re.dms.booking.details.api.queryParams.api-version}")
	private String dmsBookingDetailsApiQueryParamApiVersion;

	@Value("${re.dms.booking.details.api.queryParams.sp}")
	private String dmsBookingDetailsApiQueryParamSp;

	@Value("${re.dms.booking.details.api.queryParams.sv}")
	private String dmsBookingDetailsApiQueryParamSv;

	@Value("${re.dms.booking.details.api.queryParams.sig}")
	private String dmsBookingDetailsApiQueryParamSig;

//	@Value("${re.utility.payment.save.email.url}")
//	private String utilitySaveEmailApiUrl;

	@Value("${re.excellon.service.history.url}")
	private String excellonServiceHistoryApiUrl;

	@Value("${re.excellon.service.history.header.authentication.key}")
	private String excellonServiceHistoryHeaderAuthentication;

	@Value("${re.configurator.update.config.api.url}")
	private String configuratorUpdateConfigApiUrl;

	@Value("${re.configurator.fetch.configuration.url}")
	private String fetchConfiguratorApiUrl;

	@Value("${re.firestore.update.api.url}")
	private String RE_FIRESTORE_UPDATE_API_URL;

	@Value("${re.push.notification.url}")
	private String pushNotificationUrl;

	@Value("${re.vehicle.update.push.notification.title}")
	private String pushNotificationTitle;

	@Value("${re.vehicle.update.push.notification.value}")
	private String pushNotificationValue;

	@Value("${re.prime.user.details.api.url}")
	private String USER_DETAILS_URL;

	@Value("${re.instore.bike.booking.api.url}")
	private String INSTORE_DMS_PAYMENT_URL;

	@Value("${re.instore.booking.dms.token.url}")
	private String INSTORE_DMS_TOKEN_URL;

	@Value("${re.instore.booking.dms.token.grant_type}")
	private String INSTORE_BOOKING_DMS_GRANT_TYPE;

	@Value("${re.instore.booking.dms.token.client_id}")
	private String INSTORE_BOOKING_DMS_CLIENT_ID;

	@Value("${re.instore.booking.dms.token.client_secret}")
	private String INSTORE_BOOKING_DMS_CLIENT_SECRET;

	@Value("${re.instore.booking.dms.token.resource}")
	private String INSTORE_BOOKING_DMS_RESOURCE;

	@Value("${re.utility.azure.logger.email.url}")
	private String azureLoggerEmailURL;

	@Value("${re.connected.show.authorize.api.url}")
	private String RE_CONNECTED_SHOW_AUTHORIZE_URL;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * @param dto
	 * @param paymentKey
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> callPaymentServiceAPIToSavePaymentKey(@Valid GeneratePaymentKeyRequestDTO dto,
			String paymentKey) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Payment-Service-Save-Payment-Key API {{}}.", savePaymentKeyUrl);

			SavePaymentKeyRequest payload = new SavePaymentKeyRequest(dto, paymentKey);
			if (logger.isDebugEnabled()) {
				logger.debug("Payment-Service-Save-Payment-Key API Request Json Payload : {}",
						convertObjectToJson(payload));
			}
			Map<String, Object> response = restTemplate.postForObject(savePaymentKeyUrl, getHttpEntity(payload),
					Map.class);

			logger.info("Payment-Service-Save-Payment-Key Api Called in {{}}ms. API Response {{}}",
					System.currentTimeMillis() - startTime, response);
			return response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Payment-Service-Save-Payment-Key API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param paymentKey
	 * @return
	 */
	public ValidatePaymentKeyExpiryResponse callPaymentServiceAPItoValidatePaymentKey(final String paymentKey) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Payment-Service-Validate-Payment-Key API {{}}.", validatePaymentKeyUrl);

			ValidatePaymentKeyExpiryDTO payload = new ValidatePaymentKeyExpiryDTO(paymentKey);
			if (logger.isDebugEnabled()) {
				logger.debug("Payment-Service-Validate-Payment-Key API Request Json Payload : {}",
						convertObjectToJson(payload));
			}
			ValidatePaymentKeyExpiryResponse response = restTemplate.postForObject(validatePaymentKeyUrl,
					getHttpEntity(payload), ValidatePaymentKeyExpiryResponse.class);

			if (logger.isDebugEnabled()) {
				logger.debug("Payment-Service-Validate-Payment-Key API Called in {{}}ms. API Response {}",
						System.currentTimeMillis() - startTime, convertObjectToJson(response));
			}
			if (ObjectUtils.isEmpty(response)) {
				return null;
			}
			return response.getValid() ? response : null;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Payment-Service-Validate-Payment-Key API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param bookingId
	 */
	public DMSBookingDetailsResponse callDMSAPIToGetBookingDetails(final String bookingId) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling DMS-Booking-Details API.");

			URI uri = createURIForDMSBookingDetailsAPI();
			logger.info("DMS-Booking-Details API URL {{}}", uri);

			ResponseEntity<DMSBookingDetailsResponse> responseEntity = restTemplate.exchange(uri, HttpMethod.POST,
					getHttpEntity(new DMSBookingDetailsDTO(bookingId)), DMSBookingDetailsResponse.class);

			DMSBookingDetailsResponse response = responseEntity.getBody();
			logger.info("DMS-Booking-Details API Called in {{}}ms. API Response {{}}",
					System.currentTimeMillis() - startTime, response);

			if (ObjectUtils.isEmpty(response)) {
				return null;
			}
			return !ObjectUtils.isEmpty(response.getError()) ? null : response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling DMS-Booking-Details API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @return
	 */
	@SuppressWarnings("deprecation")
	private URI createURIForDMSBookingDetailsAPI() {

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(dmsBookingDetailsUrl)
				.queryParam(DMS_BOOKING_DETAILS_API_QUERY_PARAMS_VERSION, dmsBookingDetailsApiQueryParamApiVersion)
				.queryParam(DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SP,
						URLEncoder.encode(dmsBookingDetailsApiQueryParamSp))
				.queryParam(DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SV, dmsBookingDetailsApiQueryParamSv)
				.queryParam(DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SIG, dmsBookingDetailsApiQueryParamSig);

		return builder.build(true).toUri();
	}

	/**
	 * Calling Utility Service /utility/saveEmailForBatch API
	 * 
	 * @param payload
	 * @return
	 */
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> callUtilitySaveEmailApi(final EmailNotificationRequestDTO payload) {
//		try {
//			long startTime = System.currentTimeMillis();
//			logger.info("Calling Utility Save Email API {{}}", utilitySaveEmailApiUrl);
//			if (logger.isDebugEnabled()) {
//				logger.debug("Utility Save Email API Request Json Payload : {}", convertObjectToJson(payload));
//			}
//			Map<String, Object> response = restTemplate.postForObject(utilitySaveEmailApiUrl, getHttpEntity(payload),
//					Map.class);
//
//			logger.info("Utility Save Email API Called In {{}}ms. API Response {{}}",
//					System.currentTimeMillis() - startTime, response);
//			return response;
//		} catch (Exception e) {
//			logger.error(
//					"Exception Occured While Calling Utility-Save-Email API. Exception Message {{}},Exception Details {{}}",
//					e.getMessage(), e);
//			return null;
//		}
//	}

	/**
	 * 
	 * @param templateId
	 * @param recipientEmail
	 * @param deliveryStatus
	 * @param emailSubject
	 * @param sourceData
	 * @param attachments
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public void callLoggingServiceToSaveEmailToAzure(String templateId, String receipientEmail, String deliveryStatus,
			String emailSubject, EmailDTO sourceData, String comments, List<String> attachments) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Logging Service To Save Email To Azure {{}}", azureLoggerEmailURL);

			AzureLoggerEmailDataDTO data = new AzureLoggerEmailDataDTO(receipientEmail, deliveryStatus, emailSubject,
					new ObjectMapper().writeValueAsString(sourceData), templateId);
			AzureLoggerEmailDTO payload = new AzureLoggerEmailDTO(VEHICLE_ONBOARDING, sourceData.getAppId(), data,
					attachments, comments);

			if (logger.isDebugEnabled()) {
				logger.debug("Logging Service To Save Email To Azure Request Json Payload : {}",
						convertObjectToJson(payload));
			}

			Map<String, Object> response = restTemplate.postForObject(azureLoggerEmailURL, getHttpEntity(payload),
					Map.class);

			logger.info("Logging Service To Save Email To Azure Called In {{}}ms. API Response {{}}",
					System.currentTimeMillis() - startTime, response);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Logging-Service-To-Save-Email-To-Azure API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
	}

	/**
	 * Calling Configurator Update Config Status API.
	 * 
	 * @param configId
	 * @param configStatus
	 */
	@SuppressWarnings("unchecked")
	public void callConfiguratorUpdateConfigIdApi(final String configId, final String configStatus) {
		try {
			long startTime = System.currentTimeMillis();

			logger.info("Calling Configurator-Update-Config-API {{}}", configuratorUpdateConfigApiUrl);

			UpdateConfigStatusRequestDTO payload = new UpdateConfigStatusRequestDTO(configId, configStatus);
			if (logger.isDebugEnabled()) {
				logger.debug("Utility Configurator-Update-Config-API Json Payload : {}", convertObjectToJson(payload));
			}
			Map<String, Object> response = restTemplate.postForObject(configuratorUpdateConfigApiUrl,
					getHttpEntity(payload), Map.class);

			logger.info("Configurator-Update-Config-Status-API Called In {{}}ms. API Response {{}}",
					System.currentTimeMillis() - startTime, response);

		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Configurator-Update-Config-Status-API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
	}

	/**
	 * Calling Configurator Get Configuration By Config Id.
	 * 
	 * @param configId
	 * @param configStatus
	 */
	public CustomerConfiguratorResponseDTO fetchConfigurationById(final String configId) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Configurator-Get-Config-By-Id API {{}}", fetchConfiguratorApiUrl);

			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fetchConfiguratorApiUrl)
					.queryParam(FETCH_CONFIG_STATUS_ID_PARAM, configId);

			if (logger.isDebugEnabled()) {
				logger.debug("Configurator-Get-Config-By-Id API URL {{}}", builder.toUriString());
			}
			ResponseEntity<CustomerConfiguratorResponseDTO> response = restTemplate
					.exchange(builder.build(true).toUri(), HttpMethod.GET, null, CustomerConfiguratorResponseDTO.class);

			CustomerConfiguratorResponseDTO configResponse = response.getBody();
			logger.info("Configurator-Get-Config-By-Id API Called In {{}}ms. API Response {{}}",
					System.currentTimeMillis() - startTime, configResponse);

			if (ObjectUtils.isEmpty(configResponse)
					|| !StringUtils.equals(String.valueOf(configResponse.getCode()), SUCCESS_CODE)) {
				logger.error("Error Occured While Calling Configurator-Get-Config-By-Id {{}} API.", configId);
				return null;
			}
			return configResponse;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Configurator-Get-Config-By-Id API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * Calling Excellon Service History API.
	 * 
	 * @param payload
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ExcellonServiceHistoryResponse> callExcellonServiceHistoryApi(final String chassisNo) {
		try {
			long startTime = System.currentTimeMillis();
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(excellonServiceHistoryApiUrl)
					.queryParam("vehiclechassis", chassisNo);

			URI uri = builder.build(true).toUri();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authentication", excellonServiceHistoryHeaderAuthentication);
			HttpEntity<?> entity = new HttpEntity<>(headers);

			logger.info("Calling Excellon-Service-History API {{}}", uri);
			ResponseEntity<List> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, List.class);

			List<ExcellonServiceHistoryResponse> response = responseEntity.getBody();

			if (logger.isDebugEnabled()) {
				logger.info("Excellon-Service-History API Called In {{}}ms. API Response {}",
						System.currentTimeMillis() - startTime, convertObjectToJson(response));
			}
			return response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Excellon-Service-History API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return Collections.emptyList();
		}
	}

	/**
	 * @param guid
	 * @param paymentCaseId
	 * @param bookingCaseId
	 * @param bookingStaus
	 * @param billdeskPaymentStatus
	 * @param txnId
	 * @param txnAmount
	 * @param modelDetail
	 * @param totalAmount
	 *//*
		 * @SuppressWarnings("unchecked") public void
		 * callFirestoreUpdatePaymentStatusApi(final OnlinePaymentRequestDTO dto, final
		 * String guid, final String modelDetail, final String totalAmount) { try { long
		 * startTime = System.currentTimeMillis();
		 * logger.info("Calling Firestore-Update-Bike-Payment-Status API {{}}",
		 * reFirestoreUpdateApiUrl);
		 * 
		 * FirestoreUpdateRequestDTO payload = new FirestoreUpdateRequestDTO(dto, guid,
		 * modelDetail, totalAmount); if (logger.isDebugEnabled()) { logger.
		 * debug("Firestore-Update-Bike-Payment-Status API Request Json Payload : {}",
		 * convertObjectToJson(payload)); } Map<String, Object> response =
		 * restTemplate.postForObject(reFirestoreUpdateApiUrl, getHttpEntity(payload),
		 * Map.class);
		 * 
		 * logger.
		 * info("Firestore-Update-Bike-Payment-Status API called in {{}}ms. API Response {}"
		 * , System.currentTimeMillis() - startTime, response); } catch (Exception e) {
		 * logger.error(
		 * "Exception Occured While Calling Firestore-Update-Bike-Payment-Status API. Exception Message {{}},Exception Details {{}}"
		 * , e.getMessage(), e); } }
		 */

	/**
	 * @param dto
	 * @param guid
	 * @param paymentCaseId
	 * @param bookingCaseId
	 * @param bookingStaus
	 * @param billdeskPaymentStatus
	 * @param txnId
	 * @param txnAmount
	 * @param modelDetail
	 * @param totalAmount
	 */
	@SuppressWarnings("unchecked")
	public void callFirestoreUpdatePaymentStatusApi(final String guid, final String paymentCaseId,
			final String bookingCaseId, final String bookingStaus, final String billdeskPaymentStatus,
			final String txnId, final String txnAmount, final String modelDetail, final String totalAmount) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Firestore-Update-Bike-Payment-Status API {{}}", RE_FIRESTORE_UPDATE_API_URL);

			FirestoreUpdateRequestDTO payload = new FirestoreUpdateRequestDTO(guid, paymentCaseId, bookingCaseId,
					bookingStaus, billdeskPaymentStatus, txnId, txnAmount, modelDetail, totalAmount);
			logger.info("Firestore-Update-Bike-Payment-Status API Request Json Payload : {}",
					convertObjectToJson(payload));

			Map<String, Object> response = restTemplate.postForObject(RE_FIRESTORE_UPDATE_API_URL,
					getHttpEntity(payload), Map.class);

			logger.info("Firestore-Update-Bike-Payment-Status API called in {{}}ms. API Response {}",
					System.currentTimeMillis() - startTime, response);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Firestore-Update-Bike-Payment-Status API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
	}

	public UserProfileResponseDTO callWebAPItoGetBasicDetails(String mobileNo) {
		long startTime = System.currentTimeMillis();
		try {
			logger.info("Calling USER Basic Details API ,Input Params {{}}", mobileNo);
			mobileNo = trimToNull(mobileNo);
			if (isEmpty(mobileNo)) {
				logger.error("For USER Basic Details API Required Input Param {Mobile No.{}} is blank/null.", mobileNo);
				return null;
			}
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(USER_DETAILS_URL)
					.queryParam(WEB_USER_NAME_KEY, mobileNo);

			logger.info("USER Basic Deatils API URL {{}}", builder.build(true).toUri());

			ResponseEntity<UserProfileResponseDTO> response = restTemplate.exchange(builder.build(true).toUri(),
					HttpMethod.GET, null, UserProfileResponseDTO.class);

			logger.info("USER Basic Details API called in {{}}ms. Response {{}}",
					System.currentTimeMillis() - startTime, response.getBody());
			UserProfileResponseDTO userDetailsResponse = response.getBody();

			if (ObjectUtils.isEmpty(userDetailsResponse)
					|| !StringUtils.equals(String.valueOf(userDetailsResponse.getCode()), SUCCESS_CODE)) {
				logger.error("Error Occured / User not found while Calling User Basic Details API. Code is {{}} ",
						userDetailsResponse.getCode());
				return null;
			}
			return userDetailsResponse;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling User Basic Details API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param payload
	 * @return
	 */
	public InstoreBookingDMSResponseDTO postInstoreTransactionToDMS(InStoreDynamicsBookingPaymentRequestDTO payload) {
		try {
			long startTime = System.currentTimeMillis();
			String authToken = trimToNull(generateDMSAuthToken());
			if (isEmpty(authToken)) {
				logger.error("Generated DMS Auth token is Blank/Null.");
				return null;
			}
			logger.info("Calling DMS-Instore-Booking API {{}}.", INSTORE_DMS_PAYMENT_URL);
			if (logger.isDebugEnabled()) {
				logger.info("For Mobile No {{}} DMS-Instore-Booking API Request Json Payload: {}",
						payload.getMobileno(), convertObjectToJson(payload));
			}
			InstoreBookingDMSResponseDTO response = restTemplate.postForObject(INSTORE_DMS_PAYMENT_URL,
					getInstoreBookingDMSHttpEntity(authToken, payload), InstoreBookingDMSResponseDTO.class);

			logger.info("For Mobile No {{}} DMS-Instore-Booking API Called in {{}}ms. API Response {{}}",
					payload.getMobileno(), System.currentTimeMillis() - startTime, response);
			return response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling DMS-Instore-Booking API for Mobile no {{}}. Exception Message {{}}, Exception Details {{}}",
					payload.getMobileno(), e.getMessage(), e);
			return new InstoreBookingDMSResponseDTO(null, e.getMessage());
		}
	}

	/**
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private String generateDMSAuthToken() {
		long startTime = System.currentTimeMillis();
		logger.info("Generating DMS-Auth-Token.");

		ResponseEntity<Map> response = restTemplate.postForEntity(INSTORE_DMS_TOKEN_URL,
				getInstoreBookingDMSTokenHttpEntity(), Map.class);
		Map responseMap = response.getBody();

		logger.info("DMS-Auth-Token Generated in {{}}ms. API Response {{}}", System.currentTimeMillis() - startTime,
				responseMap);

		return (String) responseMap.get(ACCESS_TOKEN);
	}

	/**
	 * @return
	 */
	private HttpEntity<MultiValueMap<String, String>> getInstoreBookingDMSTokenHttpEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add(GRANT_TYPE, INSTORE_BOOKING_DMS_GRANT_TYPE);
		map.add(CLIENT_ID, INSTORE_BOOKING_DMS_CLIENT_ID);
		map.add(CLIENT_SECRET, INSTORE_BOOKING_DMS_CLIENT_SECRET);
		map.add(RESOURCE, INSTORE_BOOKING_DMS_RESOURCE);
		return new HttpEntity<>(map, headers);

	}

	/**
	 *
	 * @param appId
	 * @param guid
	 * @param loggedInUserMobileNo
	 */
	@Async
	public void callSendNotificationApi(final String loggedInUserMobileNo, final String chassisNumber,
			final String guid) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("For Mobile No {{}} Calling Send Notification API {{}}", loggedInUserMobileNo,
					pushNotificationUrl);

			SendNotificationRequestDTO payload = new SendNotificationRequestDTO();
			Message message = new Message();
			message.setAppId(APP_ID_VALUE_FOR_PUSH_NOTIFICATION);

			Content content = new Content();
			content.setTitle(pushNotificationTitle);
			content.setValue(pushNotificationValue);
			Data data = new Data();
			Params params = new Params();
			params.setChassisNumber(chassisNumber);
			data.setParams(params);
			content.setData(data);
			content.setType("NON_TEMPLATE");
			message.setContent(content);

			Recipient recipient = new Recipient();
			recipient.setTo(loggedInUserMobileNo);
			recipient.setGuid(guid);
			message.setRecipient(recipient);

			Sender sender = new Sender();
			message.setSender(sender);
			message.setPreferences(new Preferences());

			payload.setMessage(message);
			payload.setMetaData(new MetaData());

			if (logger.isDebugEnabled()) {
				logger.debug("send notification API Request Json Payload : {}", convertObjectToJson(payload));
			}

			SendNotificationResponse response = restTemplate.postForObject(pushNotificationUrl, getHttpEntity(payload),
					SendNotificationResponse.class);

			logger.info("send notification API called in {{}}ms. API Response {}",
					System.currentTimeMillis() - startTime, response);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling send notification API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}

	}

	public boolean callShowAuthorizeApi(final String chassisNo) {
		try {
			long startTime = System.currentTimeMillis();
			logger.info("Calling Show-Authorize API. {{}}", RE_CONNECTED_SHOW_AUTHORIZE_URL);

			ShowAuthorizeRequestDTO payload = new ShowAuthorizeRequestDTO(chassisNo);
			if (logger.isDebugEnabled()) {
				logger.info("Show-Authorize API Request Json Payload : {}", convertObjectToJson(payload));
			}
			REBaseResponse response = restTemplate.postForObject(RE_CONNECTED_SHOW_AUTHORIZE_URL,
					getHttpEntity(payload), REBaseResponse.class);

			if (logger.isDebugEnabled()) {
				logger.info("Show-Authorize API Called in {{}}ms. API Response {}",
						System.currentTimeMillis() - startTime, convertObjectToJson(response));
			}
			return validateShowAuthorizeApiResponse(response);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Calling Show Authorize API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return false;
		}
	}

}
