package com.net.bosch.utils;

import static com.net.bosch.constants.Constants.KYC_FILE_NAME;
import static com.net.bosch.constants.Constants.OWNER_SHIP_FILE_NAME;
import static com.net.bosch.constants.Constants.USER_NAME_KEY;
import static com.net.bosch.constants.Constants.UTF_8;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.tidy.Tidy;

/**
 * @author pushkarkhosla
 *
 */
@Component
public class EmailHelper {

	public static final Logger logger = LoggerFactory.getLogger(EmailHelper.class);

	private EmailHelper() {

	}

	/**
	 * @param fileType
	 * @param originalFileName
	 * @return
	 */
	public static String getFileName(String fileType, String originalFileName) {
		return (StringUtils.equals(fileType, "kycDoc") ? KYC_FILE_NAME : OWNER_SHIP_FILE_NAME).concat(".")
				.concat(com.google.common.io.Files.getFileExtension(originalFileName));
	}

	/**
	 * Below methods are used to place dynamic data in email-template subjects &
	 * body.
	 * 
	 * @param subject
	 * @param userName
	 * @return
	 */
	public static String formatUserAddvehicleEmailSubject(String subject, String userName) {
		return subject.replaceAll(USER_NAME_KEY, userName);
	}

	/**
	 * @param subject
	 * @param userName
	 * @return
	 */
	public static String formatRegisNumUpdateEmailSubject(String subject, String userName) {
		return subject.replaceAll(USER_NAME_KEY, userName);
	}

	/**
	 * @param fileSize
	 * @return
	 */
	public static double getFileSizeInMB(long fileSize) {
		double kilobytes = fileSize / 1024d; // kilobytes
		return (kilobytes / 1024); // megabytes
	}

	/**
	 * @param html
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String convertToXhtml(String html) throws UnsupportedEncodingException {
		Tidy tidy = new Tidy();
		tidy.setInputEncoding(UTF_8);
		tidy.setOutputEncoding(UTF_8);
		tidy.setXHTML(true);
		ByteArrayInputStream inputStream = new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8));
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		tidy.parseDOM(inputStream, outputStream);
		return outputStream.toString(UTF_8);
	}

	/**
	 * @param values
	 * @return
	 */
	public static List<String> convertCommaSeparatedEmailsToList(String values) {
		values = trimToNull(values);
		if (isEmpty(values)) {
			logger.info("No CC Emails Found.");
			return Collections.emptyList();
		}
		List<String> outPut = new ArrayList<>();
		if (!values.contains(",")) {
			outPut.add(values);
			return outPut;
		}
		Collections.addAll(outPut, values.split(","));
		return outPut;
	}
}
