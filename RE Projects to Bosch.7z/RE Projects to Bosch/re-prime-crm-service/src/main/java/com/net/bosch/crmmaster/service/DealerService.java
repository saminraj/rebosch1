package com.net.bosch.crmmaster.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.net.bosch.crmmaster.dao.DealerRepository;
import com.net.bosch.crmmaster.dao.DealerServiceRedisRepository;
import com.net.bosch.crmmaster.domain.Dealer;
import com.net.bosch.crmmaster.domain.DealerServiceRedis;
import com.net.bosch.crmmaster.dto.DealerDTO;
import com.net.bosch.crmmaster.dto.DealerListDTO;
import com.net.bosch.crmmaster.dto.DealerSearchDTO;
import com.net.bosch.crmmaster.dto.FullDealerDTO;
import com.net.bosch.crmmaster.dto.NearByDealerDTO;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;


@Service
public class DealerService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private DealerRepository dealerRepository;
	
	@Autowired
	private DealerServiceRedisRepository dealerServiceRedisRepository;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
		
	ObjectMapper mapper = new ObjectMapper();
	
	
	/**
	 * 
	 * @param dealerDTO
	 * @return
	 * @throws AppException
	 */
	
	@Transactional
	public DealerDTO create(FullDealerDTO fullDealerDTO) throws AppException {
		Dealer dealer;		
		dealer = new Dealer();
		convertToEntity(fullDealerDTO, dealer);		
		return convertToDTO(dealer);		
	}
	
	
	@Transactional
	public Dealer get(String id) throws AppException {
		Dealer dealer = dealerRepository.findById(id).get();
		if (dealer==null)
			throw new AppException(AppExceptionErrorCode.USER_DOES_NOT_EXIST, messageSource.getMessage("error.smartPole.smartPole_does_not_exist", null, null));
		return dealer;
	}
	
	public DealerListDTO getAllDealers() throws AppException {
		List<Dealer> dealerList = dealerRepository.findAll();
		List<DealerDTO> dealerDTOs = new ArrayList<>();		
		for (Dealer dealer : dealerList) {
			dealerDTOs.add(convertToDTO(dealer));
		}
		DealerListDTO responseListDTO = new DealerListDTO();
		responseListDTO.setData(dealerDTOs);
		return responseListDTO;
	}
	
	/*public DealerListDTO searchNearByDealers(DealerSearchDTO dealerSearchDTO) throws AppException {
		List<DealerDTO> dealerDTOs = storedProcedureService.fetchDealerList();
		DealerListDTO responseListDTO = new DealerListDTO();
		responseListDTO.setData(dealerDTOs);
		return responseListDTO;
	}*/
	
	public DataResponseDTO searchNearByDealers(DealerSearchDTO dealerSearchDTO) throws AppException {
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		RestTemplate restTemplate = new RestTemplate();
	     
	    try {
			final String baseUrl = env.getProperty("re.prime.web.nearbydealers")+"?longitude="+dealerSearchDTO.getLongitude()
					+"&latitude="+dealerSearchDTO.getLatitude()+"&distance="+env.getProperty("re.prime.nearbydealers.distance")+"&searchType=service";
			logger.info("searchNearByDealers url = "+baseUrl);
			URI uri = new URI(baseUrl);
 
			ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
			int responseStatus =  result.getStatusCodeValue();
			dataResponseDTO.setStatus(responseStatus);
			if(responseStatus == 200){
				String dealerBody = result.getBody();
            	//logger.info("searchNearByDealers dealerBody = "+dealerBody);
            	
            	ObjectMapper mapper = new ObjectMapper();
            	JsonObject dealerJsonObject = new JsonParser().parse(dealerBody).getAsJsonObject();
            	//logger.info("searchNearByDealers json = " + dealerJsonObject.get("data"));
            	Gson gson = new Gson();
            	String dealerData = gson.toJson(dealerJsonObject.get("data"));
            	//logger.info("searchNearByDealers dealerData" + dealerData);

				List<NearByDealerDTO> myObjects = mapper.readValue(dealerData, new TypeReference<List<NearByDealerDTO>>(){});
				if(myObjects != null){
					List<NearByDealerDTO> myObjectsSubset = null;
					if(!dealerSearchDTO.getIncludeAllDealers() && myObjects.size() > 10){
						myObjectsSubset = myObjects.subList(0, 10);
					}else{
						myObjectsSubset = myObjects;
					}
					
					for (NearByDealerDTO nearByDealerDTO : myObjectsSubset) {
						DealerServiceRedis dealerServiceRedis = null;
						try {
							dealerServiceRedis = dealerServiceRedisRepository.findById(nearByDealerDTO.getBranchCode()).get();
						} catch (Exception e1) {
							//logger.info("pickupDoorStepSlotDTOs error "+e1.getMessage());							
						}
						if(dealerServiceRedis != null) {
							nearByDealerDTO.setPickUpServiceAvailable(dealerServiceRedis.getPickupServiceEnabled());
							nearByDealerDTO.setDoorStepServiceAvailable(dealerServiceRedis.getDoorStepServiceEnabled());
						}else{
							nearByDealerDTO.setPickUpServiceAvailable("N");
							nearByDealerDTO.setDoorStepServiceAvailable("N");
						}
					}
					dataResponseDTO.setResponse(myObjectsSubset);
				}			

			}			
		} catch (Exception e ) {
			logger.error("Exception in searchNearByDealers "+e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		return dataResponseDTO;
	}
	
	

	//Method to get DealerDTO
	@Transactional
	public DealerDTO getDTO(String id) throws AppException {		
		return convertToDTO(get(id));
	}
	
	private Dealer convertToEntity(FullDealerDTO fullDealerDTO, Dealer dealer) {
		try {
			PropertyUtils.copyProperties(dealer, fullDealerDTO);			
		} catch (IllegalAccessException | InvocationTargetException	| NoSuchMethodException e) {
			e.printStackTrace();
		}
		dealer =  dealerRepository.save(dealer);		
	    return dealer;
	}
	
	public DealerDTO convertToDTO(Dealer dealer) {
		DealerDTO dealerDTO = new DealerDTO();
		try {
			PropertyUtils.copyProperties(dealerDTO, dealer);			
		} catch (IllegalAccessException | InvocationTargetException	| NoSuchMethodException e) {
			e.printStackTrace();
		}				
	    return dealerDTO;
	}
}
