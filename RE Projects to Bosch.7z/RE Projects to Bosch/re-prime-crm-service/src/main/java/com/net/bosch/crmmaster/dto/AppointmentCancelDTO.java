package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppointmentCancelDTO{	
	@JsonProperty("CaseNo")
	private String caseNo;
	
	@JsonProperty("Mobile")
	private String mobile;
	
	@JsonProperty("Cancel Appointment")
	private String cancelAppointment;
	
	private Boolean isDummySlots;
	
	@JsonProperty("ChassisNo")
    private String chassisNo;
	
	@JsonProperty("CancellationReason")
	private String cancellationReason;
	
	@JsonProperty("ChassisNoSow")
    private String chassisNoSow;
	
	@JsonProperty("SlotID")
	private String slotID;
	
	@JsonProperty("Remarks")
	private String remarks;
	
	public String getCaseNo() {
		return caseNo;
	}

	public String getCancelAppointment() {
		return cancelAppointment;
	}

	public void setCancelAppointment(String cancelAppointment) {
		this.cancelAppointment = cancelAppointment;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Boolean getIsDummySlots() {
		return isDummySlots;
	}

	public void setIsDummySlots(Boolean isDummySlots) {
		this.isDummySlots = isDummySlots;
	}

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public String getChassisNoSow() {
		return chassisNoSow;
	}

	public void setChassisNoSow(String chassisNoSow) {
		this.chassisNoSow = chassisNoSow;
	}

	public String getSlotID() {
		return slotID;
	}

	public void setSlotID(String slotID) {
		this.slotID = slotID;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
