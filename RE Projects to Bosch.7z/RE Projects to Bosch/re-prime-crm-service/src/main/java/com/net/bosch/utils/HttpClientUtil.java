package com.net.bosch.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class HttpClientUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);
	
	public static String getAuthenticationToken(String tokenUrl, String grantType, String clientId, String clientSecret, String resource){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
//    	params.add(new BasicNameValuePair("grant_type", "client_credentials"));
//    	params.add(new BasicNameValuePair("client_id", "7a23a10e-7f1a-42ce-a103-3591e668e5fd"));
//    	params.add(new BasicNameValuePair("client_secret", "EE6N7ntVecJhfhbiEMW4NBy8jHwu3uPq5z27FacgdZg="));
//    	params.add(new BasicNameValuePair("resource", "acc97858-30ab-41c5-aac5-47d036e08947"));
//      System.out.println("params value :: " +params.toString());
//		String authResult = requestByPost("https://login.microsoftonline.com/624a95d9-8c90-4097-95cc-1f953608f9c4/oauth2/token", params, "application/x-www-form-urlencoded");
//    	params.add(new BasicNameValuePair("grant_type", "client_credentials"));
//    	params.add(new BasicNameValuePair("client_id", "a54c2a3a-5886-4c6d-aabf-c46f087d4f8b"));
//    	params.add(new BasicNameValuePair("client_secret", "OaPP7Vbm7TU1+m3P6A1To+BgsX6HI1aDTH5WBrJbSfU="));
//    	params.add(new BasicNameValuePair("resource", "acc97858-30ab-41c5-aac5-47d036e08947"));
//      System.out.println("params value :: " +params.toString());
//		String authResult = requestByPost("https://login.microsoftonline.com/624a95d9-8c90-4097-95cc-1f953608f9c4/oauth2/token", params, "application/x-www-form-urlencoded");
		
		params.add(new BasicNameValuePair("grant_type",grantType));
    	params.add(new BasicNameValuePair("client_id", clientId));
    	params.add(new BasicNameValuePair("client_secret", clientSecret));
    	params.add(new BasicNameValuePair("resource", resource));
    	System.out.println("params value :: " +params.toString());
		String authResult = requestByPost(tokenUrl, params, "application/x-www-form-urlencoded");
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode authResultJson = null;
		try {
			authResultJson = mapper.readTree(authResult);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    JsonNode accessToken = authResultJson.findValue("access_token");
	    logger.info("auth bearer "+accessToken.asText());

		return accessToken.asText();
	}

	public static String requestByPost(String url, List<NameValuePair> params, String contentType)	{
		DefaultHttpClient httpClient = null;
		String responseString = null;
		HttpResponse response = null;
		try {
			System.out.println("requestByPost 1 " );
			UrlEncodedFormEntity data = new UrlEncodedFormEntity(params, "UTF-8");
			httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(url);
			//data.setContentType(contentType);
			postRequest.setEntity(data);
			//postRequest.setHeader("accept",contentType);
			response = httpClient.execute(postRequest);
			
			System.out.println("requestByPost 2 "+response.getStatusLine().getReasonPhrase() );

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent())));
			
			String responseLine=null;
			StringBuilder sb = new StringBuilder();
			
			while ((responseLine = br.readLine()) != null) {
				sb.append(responseLine);
			}

			responseString = sb.toString();
			
			System.out.println("requestByPost 4 responseString "+responseString);

		} catch (Exception e) {
			System.out.println("Failed executing rest POST service: HTTP error code : "
					+ response.getStatusLine().getStatusCode());
			System.out.println("Failed executing rest service: " + e.toString());
		}finally {
			httpClient.getConnectionManager().shutdown();
		}
		
		return responseString;

	}
	
	public static JsonNode postRequestWithJsonBody(String url, String content, String token, String subscriberId)	{
		DefaultHttpClient httpClient = null;
		String responseString = null;
		HttpResponse response = null;
		try {
			StringEntity data = new StringEntity(content,"UTF-8");
			httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(url);			
			data.setContentType("application/json");
			postRequest.setEntity(data);
			postRequest.setHeader("Content-Type","application/json");
//			postRequest.setHeader("Ocp-Apim-Subscription-Key","ca4f0e9ca2224514926b6dde386cb58b");
//			postRequest.setHeader("Ocp-Apim-Subscription-Key","cbb03578e29a435a9f03ad75e6e61aeb");
			postRequest.setHeader("Ocp-Apim-Subscription-Key",subscriberId);
			postRequest.setHeader("Authorization","Bearer "+token);
			logger.info("postRequestWithJsonBody -- 1a"+content);
			response = httpClient.execute(postRequest);
			logger.info("postRequestWithJsonBody -- 2a"+response);

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent())));

			String responseLine=null;
			StringBuilder sb = new StringBuilder();
			
			while ((responseLine = br.readLine()) != null) {
				sb.append(responseLine);
			}

			responseString = sb.toString();
			logger.info("requestByPost 4 responseString "+responseString);

		} catch (Exception e) {
			if(response != null && response.getStatusLine() != null){
				logger.error("Failed executing rest POST service: HTTP error code : "+ response.getStatusLine().getStatusCode());
			}
			logger.error("Failed executing rest service: " + e.toString());
		}finally {
			httpClient.getConnectionManager().shutdown();
		}
		
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode authResultJson = null;
		try {
			authResultJson = mapper.readTree(responseString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return authResultJson;

	}
}
