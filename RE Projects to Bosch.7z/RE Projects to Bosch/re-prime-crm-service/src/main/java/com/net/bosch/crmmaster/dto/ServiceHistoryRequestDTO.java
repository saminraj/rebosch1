package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.constants.ServiceHistoryOperationEnum;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;

@JsonInclude(Include.NON_NULL)
public class ServiceHistoryRequestDTO {

	String guid;
	
	private ServiceHistoryOperationEnum operationEnum;

	List<VehicleDetailsVO> vehicles;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public List<VehicleDetailsVO> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<VehicleDetailsVO> vehicles) {
		this.vehicles = vehicles;
	}
	
	/**
	 * @return the operationEnum
	 */
	public ServiceHistoryOperationEnum getOperationEnum() {
		return operationEnum;
	}

	/**
	 * @param operationEnum the operationEnum to set
	 */
	public void setOperationEnum(ServiceHistoryOperationEnum operationEnum) {
		this.operationEnum = operationEnum;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ServiceHistoryRequestDTO [guid=");
		builder.append(guid);
		builder.append(", vehicles=");
		builder.append(vehicles);
		builder.append("]");
		return builder.toString();
	}

}
