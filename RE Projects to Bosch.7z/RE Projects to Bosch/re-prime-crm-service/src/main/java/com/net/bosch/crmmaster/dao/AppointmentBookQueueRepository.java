package com.net.bosch.crmmaster.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.domain.AppointmentBookQueue;

@Repository
public interface AppointmentBookQueueRepository extends CrudRepository<AppointmentBookQueue, String> {
	
		List<AppointmentBookQueue> findAllByCaseId( String caseId);
		AppointmentBookQueue findByCaseId( String caseId);
		

}