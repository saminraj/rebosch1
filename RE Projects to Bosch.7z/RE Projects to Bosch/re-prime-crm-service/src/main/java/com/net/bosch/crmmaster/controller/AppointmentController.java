package com.net.bosch.crmmaster.controller;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.auth.AuthenticationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.net.bosch.crmmaster.dto.AppointmentBookDTO;
import com.net.bosch.crmmaster.dto.AppointmentCancelDTO;
import com.net.bosch.crmmaster.dto.AppointmentFeedbackRequestDTO;
import com.net.bosch.crmmaster.dto.AppointmentRescheduleDTO;
import com.net.bosch.crmmaster.dto.AppointmentSearchDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotListDTO;
import com.net.bosch.crmmaster.dto.DealerDTO;
import com.net.bosch.crmmaster.dto.DealerListDTO;
import com.net.bosch.crmmaster.dto.DealerSearchDTO;
import com.net.bosch.crmmaster.dto.JwtTokenResponseDTO;
import com.net.bosch.crmmaster.dto.NearByDealerDTO;
import com.net.bosch.crmmaster.dto.PickupDoorStepSlotDTO;
import com.net.bosch.crmmaster.dto.ServiceInProgressListDTO;
import com.net.bosch.crmmaster.dto.VehicleRequestDTO;
import com.net.bosch.crmmaster.service.AppointmentService;
import com.net.bosch.crmmaster.service.DealerService;
import com.net.bosch.crmmaster.service.StoredProcedureService;
import com.net.bosch.crmmaster.service.UserVehicleService;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;

@RestController
@CrossOrigin
@RequestMapping("/appointment")
public class AppointmentController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	AppointmentService appointmentService;	
	
	@Autowired
	StoredProcedureService storedProcedureService;
	
	@Autowired
	DealerService dealerService;
	
	@Autowired
	UserVehicleService userVehicleService;	
	
	@Autowired
	private Environment env;
	
	private static String APP_ID_VALUE = "999";
	
	
	@RequestMapping(method = RequestMethod.POST)
	public AppointmentSlotDTO createAppointmentSlot(@RequestBody @Valid AppointmentSlotDTO appointmentSlotDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("Create AppointmentSlot called");
		AppointmentSlotDTO newAppointmentSlotDTO = appointmentService.create(appointmentSlotDTO);
		logger.debug("[createAppointmentSlot]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return newAppointmentSlotDTO;
	}	
	
	/**
	 * GET method to get a AppointmentSlot
	 */
	@RequestMapping(value="/{id}", method = RequestMethod.GET)
	public AppointmentSlotDTO getAppointmentSlot(@PathVariable String id) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("Get AppointmentSlot called");
		AppointmentSlotDTO responseDTO = appointmentService.getDTO(id);
		logger.debug("[getAppointmentSlot]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}	
	
	/**
	 * GET method to get a AppointmentSlot
	 */
	@RequestMapping(value="/fullslots/{id}", method = RequestMethod.GET)
	public AppointmentSlotListDTO getAppointmentFullSlots(@PathVariable String id) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("Get AppointmentSlot called");
		AppointmentSlotListDTO responseDTO = appointmentService.getFullSlotsDTO(id);
		logger.debug("[getAppointmentSlot]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	/**
	 * GET method to get a AppointmentSlot
	 * @throws ParseException 
	 */
	@RequestMapping(value="/searchSlotAppointment", method = RequestMethod.POST)
	public AppointmentSlotListDTO getAllLiveAppointmentSlots(@RequestBody @Valid AppointmentSearchDTO appointmentSearchDTO) throws AppException, ParseException {
		
		System.out.println("AppointmentController.getAllLiveAppointmentSlots() =================== 11111111111111 ");
		Long startTime = System.currentTimeMillis();
		logger.debug("getAllLiveAppointmentSlots called");
		AppointmentSlotListDTO responseListDTO = appointmentService.getAllAppointmentSlots(appointmentSearchDTO);
		logger.debug("[getAllLiveAppointmentSlots]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}	
	
	/**
	 * GET method to get a AppointmentSlot
	 * @throws ParseException 
	 */
	@RequestMapping(value="/serviceappointmentbooking", method = RequestMethod.POST)
	public DataResponseDTO serviceAppointmentBooking(@RequestAttribute String guid, @RequestAttribute String app_id,@RequestBody @Valid AppointmentBookDTO appointmentBookDTO) throws AppException, ParseException {
		Long startTime = System.currentTimeMillis();
		logger.debug("serviceAppointmentBooking called");
		if(!StringUtils.equals(app_id, APP_ID_VALUE)){
			if(!userVehicleService.isChassisMappedtoUser(appointmentBookDTO.getChassisNo(),guid))throw new AppException(AppExceptionErrorCode.NOT_AUTHORIZED,"Not a valid user");
		}
		DataResponseDTO responseListDTO = appointmentService.bookAppointment(appointmentBookDTO);
		logger.debug("[serviceAppointmentBooking]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}
	
	/**
	 * GET method to get a AppointmentSlot
	 * @throws ParseException 
	 */
	@RequestMapping(value="/rescheduleserviceappointment", method = RequestMethod.POST)
	public DataResponseDTO rescheduleserviceappointment(@RequestAttribute String guid, @RequestAttribute String app_id,@RequestBody @Valid AppointmentRescheduleDTO appointmentRescheduleDTO) throws AppException, ParseException {
		Long startTime = System.currentTimeMillis();
		logger.debug("rescheduleserviceappointment called");
		if(!StringUtils.equals(app_id, APP_ID_VALUE)){
			if(!userVehicleService.isChassisMappedtoUser(appointmentRescheduleDTO.getChassisNo(),guid))throw new AppException(AppExceptionErrorCode.NOT_AUTHORIZED,"Not a valid user");
		}
		DataResponseDTO responseListDTO = appointmentService.rescheduleAppointment(appointmentRescheduleDTO);
		logger.debug("[rescheduleserviceappointment]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}
	
	@RequestMapping(value="/cancelServiceAppointment", method = RequestMethod.POST)
	public DataResponseDTO cancelServiceAppointment(@RequestAttribute String guid, @RequestAttribute String app_id,@RequestBody @Valid AppointmentCancelDTO appointmentCancelDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("cancelServiceAppointment called");
		if(!StringUtils.equals(app_id, APP_ID_VALUE)){
			if(!userVehicleService.isChassisMappedtoUser(appointmentCancelDTO.getChassisNo(),guid))throw new AppException(AppExceptionErrorCode.NOT_AUTHORIZED,"Not a valid user");
		}
		DataResponseDTO responseListDTO = appointmentService.cancelAppointment(appointmentCancelDTO);
		logger.debug("[cancelServiceAppointment]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}
	
//	@RequestMapping(value="/getServiceHistory", method = RequestMethod.POST)
//	public ResponseDTO getServiceHistory(@RequestBody @Valid VehicleRequestDTO requestDTO) throws AppException {
//		Long startTime = System.currentTimeMillis();
//		logger.debug("getServiceHistory() called");
//		
//		storedProcedureService.fetchServiceHistory(requestDTO);
//		
//		logger.debug("[getServiceHistory]: elapsed time: "+(System.currentTimeMillis()-startTime));
//		
//		return new ResponseDTO();
//	}
	
	@RequestMapping(value="/getVehicleServiceInProgressList", method = RequestMethod.POST)
	public ServiceInProgressListDTO getVehicleServiceInProgressList(@RequestAttribute String guid,
			@RequestAttribute String app_id, @RequestBody @Valid VehicleRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getVehicleServiceInProgressList() called");
		if(!StringUtils.equals(app_id, APP_ID_VALUE)){
			String[] chassisNumbers = requestDTO.getChassisNo().split(",");
			for (String chassisNo : chassisNumbers) {
				if(!userVehicleService.isChassisMappedtoUser(chassisNo, guid))throw new AppException(AppExceptionErrorCode.NOT_AUTHORIZED,"Not a valid user");
			}	
		}
		ServiceInProgressListDTO serviceInProgressListDTO = new ServiceInProgressListDTO();
		serviceInProgressListDTO.setData(appointmentService.getVehicleServiceInProgressList(requestDTO));
		logger.debug("[getVehicleServiceInProgressList]: elapsed time: "+(System.currentTimeMillis()-startTime));		
		return serviceInProgressListDTO;
	}	
	
	/*@RequestMapping(value="/serviceEstimate", method = RequestMethod.POST)
	public Object getServiceEstimate(@RequestBody @Valid VehicleRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getServiceEstiamte called");
		Object responseDTO;
		if(requestDTO.getChassisNo()!= null && !requestDTO.getChassisNo().isEmpty()){
			responseDTO = storedProcedureService.getVehicleServiceInProgressList(requestDTO.getMobileNo());
		}else{
			responseDTO = storedProcedureService.getServiceEstimate(requestDTO);
		}
		logger.debug("[getServiceEstiamte]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/serviceStatus", method = RequestMethod.POST)
	public ResponseDTO getServiceStatus(@RequestBody @Valid AppointmentCancelDTO appointmentCancelDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getServiceStatus called");
		ResponseDTO responseDTO = appointmentService.getServiceStatus(appointmentCancelDTO);
		logger.debug("[getServiceStatus]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	*//**
	 * Post method to get near by dealers
	 *//*
	@RequestMapping(value="/searchNearByDealers", method = RequestMethod.POST)
	public DataResponseDTO searchNearByDealers(@RequestBody @Valid DealerSearchDTO dealerSearchDTO) throws AppException {
		
		System.out.println("AppointmentController.searchNearByDealers() =================== 11111111111111 ");
		Long startTime = System.currentTimeMillis();
		logger.debug("searchNearByDealers called");
		DataResponseDTO responseListDTO = dealerService.searchNearByDealers(dealerSearchDTO);
		logger.debug("[searchNearByDealers]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}
	
	*//**
	 * GET method to get a AppointmentSlotList<PickupDoorStepSlotDTO>
	 * @throws ParseException 
	 *//*
	@RequestMapping(value="/getPickupAndDoorstepServiceSlots", method = RequestMethod.POST)
	public List<PickupDoorStepSlotDTO> getPickupAndDoorstepServiceSlots(@RequestBody NearByDealerDTO dealerDTO) throws AppException, ParseException {
		
		System.out.println("AppointmentController.getPickupAndDoorstepServiceSlots() ");
		Long startTime = System.currentTimeMillis();
		logger.debug("getAllLiveAppointmentSlots called");
		List<PickupDoorStepSlotDTO> responseListDTO = appointmentService.getPickupAndDoorstepServiceSlots(dealerDTO);
		logger.debug("[getPickupAndDoorstepServiceSlots]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseListDTO;
	}*/
	
	@RequestMapping(value="/getScheduledService", method = RequestMethod.POST)
	public ResponseDTO getScheduledServiceStatus(@RequestAttribute String guid, @RequestAttribute String app_id,
			@RequestBody @Valid AppointmentCancelDTO appointmentCancelDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getScheduledService called");
		if(!StringUtils.equals(app_id, APP_ID_VALUE)){
			String[] chassisNumbers = appointmentCancelDTO.getChassisNo().split(",");
			for (String chassisNo : chassisNumbers) {
				if(!userVehicleService.isChassisMappedtoUser(chassisNo, guid))throw new AppException(AppExceptionErrorCode.NOT_AUTHORIZED,"Not a valid user");
			}
		}
		ResponseDTO responseDTO = appointmentService.getScheduledService(appointmentCancelDTO);
		logger.debug("[getScheduledService]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/getFeedbackLink", method = RequestMethod.POST)
	public ResponseDTO getFeedbackLink(@RequestAttribute String guid, @RequestAttribute String app_id,
			@RequestBody @Valid AppointmentFeedbackRequestDTO appointmentFeedbackDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getFeedbackLink called");
		ResponseDTO responseDTO = appointmentService.getFeedbackLink(appointmentFeedbackDTO);
		logger.debug("[getFeedbackLink]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/verifyToken", method = RequestMethod.POST)
	public String verifyToken(@RequestHeader("Authorization") String jwtToken) throws AppException {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		logger.info("jwtToken from the Header -- > "+jwtToken);
		map.add("authorization","JWT "+jwtToken);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(map, headers);
		//ResponseEntity<JwtTokenResponseDTO> response =  restTemplate.exchange("http://13.71.26.22:3001/node/api/auth/verify-token",HttpMethod.POST,entity,JwtTokenResponseDTO.class);
		/* 22 feet **/
		String jwtURL = env.getProperty("spring.jwt.url");
		ResponseEntity<JwtTokenResponseDTO> response =  restTemplate.exchange(jwtURL,HttpMethod.POST,entity,JwtTokenResponseDTO.class);
		 
		return response.getBody().getMessage();
	}
	
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String getTest() throws AppException {
		return "Success CRM 1.1.1";
	}
	
	@RequestMapping(value="/deleteAll", method = RequestMethod.GET)
	public String deleteAll() throws AppException {
		appointmentService.deleteAllAppointmentSlots();
		return "Deleted All";
	}
	

}
