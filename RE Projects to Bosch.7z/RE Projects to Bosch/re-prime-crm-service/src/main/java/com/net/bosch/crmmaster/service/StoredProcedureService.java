package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.CHASSIS_NO;
import static com.net.bosch.constants.Constants.SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.Constants.VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT;
import static com.net.bosch.constants.REResponse.CALL_CUSTOMER_SUPPORT;
import static com.net.bosch.constants.REResponse.PLEASE_TRY_ADDING_VEHICLE_WITH_CHASSIS_NO;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.lang.reflect.InvocationTargetException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.validation.Valid;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.DateUtils;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutureCallback;
import com.google.api.core.ApiFutures;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.cloud.FirestoreClient;
import com.net.bosch.constants.Constants;
import com.net.bosch.crmmaster.dto.AppointmentBookDTO;
import com.net.bosch.crmmaster.dto.AppointmentFeedbackResponseDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotDTO;
import com.net.bosch.crmmaster.dto.DealerDTO;
import com.net.bosch.crmmaster.dto.FullDealerDTO;
import com.net.bosch.crmmaster.dto.GetVehicleVinRequestDTO;
import com.net.bosch.crmmaster.dto.GetVinJobCardStatusRequestDTO;
import com.net.bosch.crmmaster.dto.ScheduledAppointmentDTO;
import com.net.bosch.crmmaster.dto.ServiceEstimateDTO;
import com.net.bosch.crmmaster.dto.ServiceHistoryRequestDTO;
import com.net.bosch.crmmaster.dto.ServiceInProgressDTO;
import com.net.bosch.crmmaster.dto.VehicleDTO;
import com.net.bosch.crmmaster.dto.VehicleRequestDTO;
import com.net.bosch.crmmaster.dto.VehicleVerifyRequestDTO;
import com.net.bosch.crmmaster.dto.firebase.ServiceHistoryInfoVO;
import com.net.bosch.crmmaster.dto.firebase.VehicleInfoVO;
import com.net.bosch.crmmaster.dto.firebase.VehicleVO;
import com.net.bosch.crmmaster.dto.resultset.VehicleDetailsVO;
import com.net.bosch.crmmaster.dto.resultset.VehicleJobCardStatusResponseObject;
import com.net.bosch.crmmaster.dto.resultset.VehicleVinResponseObject;
import com.net.bosch.utils.DateHelper;

@Service
public class StoredProcedureService {

	private static final String USER_MOBILE_NUMBER = "User_MobileNumber";

	private static final String USER_ID = "UserID";

	private static final String REG_NO = "RegNo";

	private static final String SERVICE_INVOICE_NUM = "ServiceInvoiceNum";

	private static final String BILL_AMOUNT = "BillAmount";

	private static final String INVOICE_DATE = "InvoiceDate";

	private static final String BRANCH_ID = "BranchId";

	private static final String CALL = "{call ";

	private static final Logger logger = LoggerFactory.getLogger(StoredProcedureService.class);

	@Value("${spring.sqlserver.sp_prefix}")
	private String spPrefix;

	@Autowired
	DealerService dealerService;

	private static final String BRANCH_TYPE_SERVICE = "Service";
	private static final String BRANCH_TYPE_SPARE_SERVICE = "Spare & Service";

	@Autowired
	private DataSource dataSource;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public HashMap<String, List<AppointmentSlotDTO>> fetchAppointmentsFromSP() {
		HashMap<String, List<AppointmentSlotDTO>> appointmentSlotDTOMap = new HashMap<>();
		List<AppointmentSlotDTO> appointmentSlotDTOList = null;
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			String searchDate = DateHelper.convertDateToStringYYYYMMDD(System.currentTimeMillis());
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_searchSlotAppointment('");
			stringBuilder.append(searchDate);
			stringBuilder.append("', ' ','10')}");
			String spQuery = stringBuilder.toString();

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					AppointmentSlotDTO appointmentSlotDTO = new AppointmentSlotDTO();
					appointmentSlotDTO.setResourceId(resultSet.getString("bookableresourceid"));
					appointmentSlotDTO.setBranchId(resultSet.getString("Branch_ID"));
					String startDate = resultSet.getString("StartTimeSlot");
					appointmentSlotDTO.setStartTimeSlot(DateHelper.convertAppointmentDateToNewPattern(startDate));
					appointmentSlotDTO.setEndTimeSlot(
							DateHelper.convertAppointmentDateToNewPattern(resultSet.getString("EndTimeSlot")));
					appointmentSlotDTO.setAvailability(resultSet.getBoolean("SlotAvailability"));
					appointmentSlotDTO.setDate(startDate.substring(0, 10));
					String key = resultSet.getString("Branch_ID") + ":" + appointmentSlotDTO.getDate();
					appointmentSlotDTOList = appointmentSlotDTOMap.get(key);
					if (appointmentSlotDTOList == null) {
						appointmentSlotDTOList = new ArrayList<>();
					}
					appointmentSlotDTOList.add(appointmentSlotDTO);
					appointmentSlotDTOMap.put(key, appointmentSlotDTOList);
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchAppointmentsFromSP Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return appointmentSlotDTOMap;
	}

	public List<DealerDTO> fetchDealerList() {
		List<DealerDTO> dealerDTOList = new ArrayList<>();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getDealers(' ', ' ', ' ')}");
			String spQuery = stringBuilder.toString();

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("StoredProcedureService.fetchDealerList() BranchID: {{}}",
							resultSet.getString("BranchID"));

					FullDealerDTO fullDealerDTO = new FullDealerDTO();
					fullDealerDTO.setActive(resultSet.getString("IsActive"));
					// fullDealerDTO.setAddress(resultSet.getString("Address"));
					if (resultSet.getString("Address") == null || resultSet.getString("Address").isEmpty()) {
						fullDealerDTO.setAddress(" ");
					} else {
						fullDealerDTO.setAddress(resultSet.getString("Address"));
					}
					fullDealerDTO.setBranch_type(resultSet.getString("Branch_Type"));
					fullDealerDTO.setBranchid(resultSet.getString("BranchID"));
					fullDealerDTO.setBranchname(resultSet.getString("BranchName"));
					fullDealerDTO.setCity(resultSet.getString("City"));
					// fullDealerDTO.setContactnumber(resultSet.getString("ContactNumber"));
					if (resultSet.getString("ContactNumber") == null
							|| resultSet.getString("ContactNumber").isEmpty()) {
						fullDealerDTO.setContactnumber(" ");
					} else {
						fullDealerDTO.setContactnumber(resultSet.getString("ContactNumber"));
					}

					fullDealerDTO.setCountry(resultSet.getString("Country"));
					fullDealerDTO.setDealerid(resultSet.getString("DealerID"));
					fullDealerDTO.setDealername(resultSet.getString("DealerName"));
					fullDealerDTO.setIs_pick_and_drop_available(resultSet.getString("IsPickandDropAvailable"));
					// fullDealerDTO.setLanlong(resultSet.getString("LatLong"));
					if (resultSet.getString("LatLong") == null || resultSet.getString("LatLong").isEmpty()) {
						fullDealerDTO.setLanlong(" ");
					} else {
						fullDealerDTO.setLanlong(resultSet.getString("LatLong"));
					}
//					fullDealerDTO.setLanlong("25.75038,82.70086000000001");
					fullDealerDTO.setPincode(resultSet.getString("PinCode"));
					fullDealerDTO.setState(resultSet.getString("State"));
					fullDealerDTO.setId(resultSet.getString("DealerID"));
					fullDealerDTO.setManagerName(resultSet.getString("ManagerName"));
					fullDealerDTO.setIsServiceApplicable(resultSet.getString("IsServiceApplicable"));
					fullDealerDTO.setIsSalesApplicable(resultSet.getString("IsSalesApplicable"));
					fullDealerDTO.setStartTime(resultSet.getString("StartTime"));
					fullDealerDTO.setEndTime(resultSet.getString("EndTime"));
					fullDealerDTO.setWeekOff(resultSet.getString("Week_Off"));
					fullDealerDTO.setTeflonCoating(resultSet.getString("TeflonCoating"));
					fullDealerDTO.setBaseCurrency(resultSet.getString("BaseCurrency"));
					fullDealerDTO.setSlotBufferWSApp(resultSet.getString("SlotBufferWSApp"));
					fullDealerDTO.setAsmContactNum(resultSet.getString("ASMContactNum"));
					fullDealerDTO.setTsmContactNum(resultSet.getString("TSMContactNum"));
					fullDealerDTO.setRmContactNum(resultSet.getString("RMContactNum"));
					fullDealerDTO.setZmContactNum(resultSet.getString("ZMContactNum"));
					fullDealerDTO.setRsmContactNum(resultSet.getString("RSMContactNum"));
					fullDealerDTO.setTpmContactNum(resultSet.getString("TPMContactNum"));
					fullDealerDTO.setDealerSource(resultSet.getString("Dealer_Source"));

					dealerService.create(fullDealerDTO);

					if (BRANCH_TYPE_SERVICE.equals(fullDealerDTO.getBranch_type())
							|| BRANCH_TYPE_SPARE_SERVICE.equals(fullDealerDTO.getBranch_type())) {
						DealerDTO dealerDTO = new DealerDTO();
						try {
							PropertyUtils.copyProperties(dealerDTO, fullDealerDTO);
							dealerDTOList.add(dealerDTO);
						} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
							logger.error(
									"Exception Occured While copying properties Exception Message {{}},Exception Details {{}}",
									e.getMessage(), e);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchDealerList Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return dealerDTOList;
	}

	public List<VehicleDTO> fetchVehicleList() {
		List<VehicleDTO> vehicleDTOList = new ArrayList<>();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {

			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getVehicles(' ', ' ', ' ')}");
			String spQuery = stringBuilder.toString();

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("StoredProcedureService.fetchVehicleList() vehicleName: {{}}",
							resultSet.getString("vehicleName"));

					VehicleDTO vehicleDTO = new VehicleDTO();
					vehicleDTO.setVehicleId(resultSet.getString("vehicleId"));
					vehicleDTO.setVehicleName(resultSet.getString("vehicleName"));
					// vehicleService.create(vehicleDTO);
					vehicleDTOList.add(vehicleDTO);
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchVehicleList Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return vehicleDTOList;
	}

//	==============================================================================================================

	public boolean deleteFirbaseDoc(String collectionName, String docName) {

		try {
			Firestore db = FirestoreClient.getFirestore();

			CollectionReference cr = db.collection(collectionName);
			cr.document(docName).delete();
			ApiFuture<WriteResult> writeResult = cr.document().delete();

			logger.debug("StoredProcedureService.deleteFirbaseDoc() .......... ");

		} catch (Exception e) {
			return false;
		}
		return true;

	}

	public void asynFetchVehiclesByPhoneNo(String phoneNo) {
		ExecutorService executorService = Executors.newSingleThreadExecutor();

		executorService.execute(new Runnable() {
			public void run() {
				logger.info("Asynchronous task");
				fetchVehiclesByPhoneNo(phoneNo);
			}
		});
		logger.info("Asynchronous END");

		executorService.shutdown();

	}

	public void fetchAllServiceHistory(ServiceHistoryRequestDTO serviceHistoryRequestDTO) {

		for (VehicleDetailsVO vehicleDetailsVO : serviceHistoryRequestDTO.getVehicles()) {
			/**
			 * logger.info("StoredProcedureService.fetchAllServiceHistory() getChassisNo
			 * {{}}", vehicleDetailsVO.getChassisNo());
			 */
			fetchServiceHistoryForVehicle(vehicleDetailsVO.getChassisNo(), serviceHistoryRequestDTO.getGuid(),
					serviceHistoryRequestDTO.getOperationEnum().getValue());
		}

	}

	public void fetchVehiclesByPhoneNo(String phoneNo) {

		logger.info("StoredProcedureService.fetchVehiclesByPhoneNo() {{}}", phoneNo);
		Firestore firestore = FirestoreClient.getFirestore();

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getVehicleDetails(' ',' ',' ','");
			stringBuilder.append(phoneNo);
			stringBuilder.append("' , ' ')}");
			String spQuery = stringBuilder.toString();

			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				logger.info("resultSet length {{}}", resultSet.getFetchSize());
				DocumentReference docRef = firestore.collection(phoneNo).document("Vehicle");

				VehicleVO vehicleVO = new VehicleVO();
				while (resultSet.next()) {
					logger.info("StoredProcedureService.fetchVehiclesByPhoneNo() vehicleName: {{}}",
							resultSet.getString("ActiveCustomerName"));
					VehicleInfoVO vehicleInfoVO = vehicleDetailsSPtoDTO(resultSet);
					vehicleVO.addVehicleInfoVO(vehicleInfoVO);
					fetchServiceHistoryFromSP(vehicleInfoVO);
				}
				// docRef.set(vehicleVO);
				/** add listener to get callback from firestore **/
				// asynchronously write data
				ApiFuture<WriteResult> result = docRef.set(vehicleVO);
				// ...
				// result.get() blocks on response
				logger.debug("Update time : {{}}", result.get().getUpdateTime());

				logger.info("Update time of adding vehicle details: {{}}", result.get().getUpdateTime());

				ApiFutures.addCallback(result, new ApiFutureCallback<WriteResult>() {
					@Override
					public void onFailure(Throwable t) {
						logger.debug("failure");
						logger.info("fail to add vehicle details into firestore");
					}

					@Override
					public void onSuccess(WriteResult result) {
						logger.debug("success");
						logger.info("  vehicle details add successfully into firestore");
					}
				});
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchVehiclesByPhoneNo Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	public VehicleInfoVO fetchServiceHistoryFromSP(VehicleInfoVO vehicleInfoVO) {

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_GetServiceHistory(' ','");
			stringBuilder.append(vehicleInfoVO.getChaissisNo());
			stringBuilder.append("',' ',' ',' ')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("StoredProcedureService.fetchServiceHistoryFromSP() InvoiceDate: {{}}",
							resultSet.getString(INVOICE_DATE));
					String billAmount = resultSet.getString(BILL_AMOUNT);
					String invoiceDate = resultSet.getString(INVOICE_DATE);
					if (billAmount != null && !billAmount.isEmpty() && invoiceDate != null && !invoiceDate.isEmpty()) {
						ServiceHistoryInfoVO serviceHistoryInfoVO = serviceHistorySPtoDTO(resultSet);
						vehicleInfoVO.addServiceHistoryInfoVO(serviceHistoryInfoVO);
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchServiceHistoryFromSP Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}

		return vehicleInfoVO;
	}

	public void fetchServiceHistory(VehicleRequestDTO dto) {

		Firestore firestore = FirestoreClient.getFirestore();

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_GetServiceHistory('");
			stringBuilder.append(dto.getRegistrationNo());
			stringBuilder.append("','");
			stringBuilder.append(dto.getChassisNo());
			stringBuilder.append("','");
			stringBuilder.append(dto.getEngineNo());
			stringBuilder.append("','");
			stringBuilder.append(dto.getMobileNo());
			stringBuilder.append("')}");
			String spQuery = stringBuilder.toString();

			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();

				DocumentReference docRef = firestore.collection(dto.getMobileNo()).document("Vehicle");
				while (resultSet.next()) {
					logger.info("StoredProcedureService.fetchServiceHistory() ServiceInvoiceNum: {{}}",
							resultSet.getString(SERVICE_INVOICE_NUM));
					docRef = docRef.collection(resultSet.getString(REG_NO)).document("Service History");
					String serviceInvoiceNum = resultSet.getString(SERVICE_INVOICE_NUM);
					if (serviceInvoiceNum == null) {
						serviceInvoiceNum = SERVICE_INVOICE_NUM;
					}
					docRef = docRef.collection(serviceInvoiceNum).document("History Details");
					Map<String, Object> data = new HashMap<>();
					data.put(BRANCH_ID, resultSet.getString(BRANCH_ID));
					data.put(INVOICE_DATE, resultSet.getString(INVOICE_DATE));
					data.put(BILL_AMOUNT, resultSet.getString(BILL_AMOUNT));
					data.put(SERVICE_INVOICE_NUM, resultSet.getString(SERVICE_INVOICE_NUM));
					data.put(USER_ID, resultSet.getString(USER_ID));
//	 				 DocumentReference docRef = firestore.collection("ServiceHistory").document(dto.getMobileNo()+"_"+resultSet.getString("ServiceInvoiceNum"));
					docRef.set(data);
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing fetchServiceHistory Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	public void fetchServiceHistoryForVehicle(String chaissisNo, String guid, String opNum) {

		logger.info("Processing Service Details For Guid {{}} and Chassis No {{}}.", guid, chaissisNo);
		Firestore firestore = FirestoreClient.getFirestore();

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_GetServiceHistory(' ','");
			stringBuilder.append(chaissisNo);
			stringBuilder.append("',' ',' ',' ')}");
			String spQuery = stringBuilder.toString();

			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();

			if (hadResults) {
				resultSet = statement.getResultSet();
				logger.info("opNum {{}} ", opNum);

				switch (opNum) {
				case "ONLY DELETE":
					logger.info("ONLY DELETE {{}} ", opNum);
					try {
						ApiFuture<QuerySnapshot> future = firestore.collection(guid)
								.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
								.collection(SERVICE_HISTORY_FIREBASE_CONSTANT).get();
						int deleted = 0;
						List<QueryDocumentSnapshot> documents = future.get().getDocuments();
						for (QueryDocumentSnapshot document : documents) {
							document.getReference().delete();
							++deleted;
						}
						logger.info("Total Deleted Documents are {{}}", deleted);
					} catch (Exception e) {
						logger.info("Error deleting collection {{}} ", e.getMessage());
					}
					break;
				case "ONLY INSERT":
					logger.info("ONLY INSERT {{}} ", opNum);
					CollectionReference collectionRef1 = firestore.collection(guid)
							.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
							.collection(SERVICE_HISTORY_FIREBASE_CONSTANT);

					while (resultSet.next()) {
						String branchId = resultSet.getString(BRANCH_ID);
						String invoiceDate = resultSet.getString(INVOICE_DATE);
						String billAmount = resultSet.getString(BILL_AMOUNT);
						String serviceInvoiceNum = resultSet.getString(SERVICE_INVOICE_NUM);
						String chassisNo = resultSet.getString(CHASSIS_NO);
						String regNo = resultSet.getString(REG_NO);
						String userID = resultSet.getString(USER_ID);
						String userMobileNumber = resultSet.getString(USER_MOBILE_NUMBER);

						if (isNotEmpty(invoiceDate) && isNotEmpty(billAmount) && isNotEmpty(serviceInvoiceNum)) {
							DocumentReference documentRef = collectionRef1.document(serviceInvoiceNum);

							Map<String, Object> data = new HashMap<>();
							data.put(BRANCH_ID, branchId);
							data.put(INVOICE_DATE, invoiceDate);
							data.put(BILL_AMOUNT, billAmount);
							data.put(SERVICE_INVOICE_NUM, serviceInvoiceNum);
							data.put(CHASSIS_NO, chassisNo);
							data.put(REG_NO, regNo);
							data.put(USER_ID, userID);
							data.put("UserMobileNumber", userMobileNumber);
							logger.info("Service Details {{}}", data);
							documentRef.set(data);
						} else {
							logger.error(
									"Due to Some Missing Details Service History for chassis no {{}} can not be written in Firebase ",
									chassisNo);
						}
					}
					break;
				case "DELETE AND INSERT":

					logger.info("DELETE AND INSERT {{}} ", opNum);
					try {
						ApiFuture<QuerySnapshot> future = firestore.collection(guid)
								.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
								.collection(SERVICE_HISTORY_FIREBASE_CONSTANT).get();
						int deleted = 0;
						List<QueryDocumentSnapshot> documents = future.get().getDocuments();
						for (QueryDocumentSnapshot document : documents) {
							document.getReference().delete();
							++deleted;
						}
						logger.info("Total Deleted Documents are {{}}", deleted);
					} catch (Exception e) {
						logger.info("Error deleting collection {{}} ", e.getMessage());
					}
					CollectionReference collectionRefNew1 = firestore.collection(guid)
							.document(VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT)
							.collection(SERVICE_HISTORY_FIREBASE_CONSTANT);

					while (resultSet.next()) {
						String branchId = resultSet.getString(BRANCH_ID);
						String invoiceDate = resultSet.getString(INVOICE_DATE);
						String billAmount = resultSet.getString(BILL_AMOUNT);
						String serviceInvoiceNum = resultSet.getString(SERVICE_INVOICE_NUM);
						String chassisNo = resultSet.getString(CHASSIS_NO);
						String regNo = resultSet.getString(REG_NO);
						String userID = resultSet.getString(USER_ID);
						String userMobileNumber = resultSet.getString(USER_MOBILE_NUMBER);

						if (isNotEmpty(invoiceDate) && isNotEmpty(billAmount) && isNotEmpty(serviceInvoiceNum)) {
							DocumentReference documentRef = collectionRefNew1.document(serviceInvoiceNum);

							Map<String, Object> data = new HashMap<>();
							data.put(BRANCH_ID, branchId);
							data.put(INVOICE_DATE, invoiceDate);
							data.put(BILL_AMOUNT, billAmount);
							data.put(SERVICE_INVOICE_NUM, serviceInvoiceNum);
							data.put(CHASSIS_NO, chassisNo);
							data.put(REG_NO, regNo);
							data.put(USER_ID, userID);
							data.put("UserMobileNumber", userMobileNumber);
							logger.info("Service Details {{}}", data);
							documentRef.set(data);
						} else {
							logger.error(
									"Due to Some Missing Details Service History for chassis no {{}} can not be written in Firebase ",
									chassisNo);
						}
					}
					break;
				default:
					logger.error("Unhandled Case found for Service History");
					break;
				}

			} else {
				logger.error("No Service History Available for Guid {{}} and Chassis No {{}}", guid, chaissisNo);
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Processing Service History For Guid {{}} and Chassis No {{}}. Exception Message {{}} ,Exception Details {{}}",
					guid, chaissisNo, e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	private VehicleInfoVO vehicleDetailsSPtoDTO(ResultSet resultSet) throws SQLException {

		VehicleInfoVO vehicleInfo = new VehicleInfoVO("Ram Narayan", "03-11-2016", "981234576", "KL-02 BA 9067");

		vehicleInfo.setActiveCustomerName(resultSet.getString("ActiveCustomerName"));
		vehicleInfo.setChaissisNo(resultSet.getString("ChassisNo"));
		vehicleInfo.setEngineNo(resultSet.getString("EngineNo"));
		vehicleInfo.setId(resultSet.getString("ID"));
		vehicleInfo.setMobileNo(resultSet.getString("MobileNo"));
		vehicleInfo.setModelCode(resultSet.getString("ModelCode"));
		vehicleInfo.setModelName(resultSet.getString("Modelname"));
		vehicleInfo.setRegistrationNo(resultSet.getString("RegistrationNo"));
		vehicleInfo.setInvoiceNo(resultSet.getString("InvoiceNo"));

//       date format must be yyyy-mm-ddThh:mm:ss
		logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  DateOfMfg: {{}}",
				resultSet.getString("DateOfMfg"));
		try {
			String dateOfMfgStr = resultSet.getString("DateOfMfg");
			logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  dateOfMfgStr1: {{}}", dateOfMfgStr);
			if (dateOfMfgStr != null && dateOfMfgStr.length() > 0) {
				dateOfMfgStr = dateOfMfgStr.trim();
				SimpleDateFormat format = new SimpleDateFormat("MMM dd yyyy hh:mma");
				Date mfgDate = format.parse(dateOfMfgStr);
				dateOfMfgStr = org.apache.http.client.utils.DateUtils.formatDate(mfgDate, Constants.RE_PRIME_PATTERN);
				vehicleInfo.setDateOfMfg(dateOfMfgStr);
			}
			logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  dateOfMfgStr2: {{}}", dateOfMfgStr);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing vehicleDetailsSPtoDTO Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			vehicleInfo.setDateOfMfg(resultSet.getString("DateOfMfg"));
		}
		logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  getDateOfMfg: {{}}", vehicleInfo.getDateOfMfg());

//       date format must be yyyy-mm-ddThh:mm:ss
		logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  PurchaseDate: {{}}",
				resultSet.getString("PurchaseDate"));
		try {
			Date dateOfPurchase = resultSet.getDate("PurchaseDate");
			String dateOfPurchaseStr = DateUtils.formatDate(dateOfPurchase, Constants.RE_PRIME_PATTERN);
			vehicleInfo.setPurchaseDate(dateOfPurchaseStr);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While processing dateOfPurchase under vehicleDetailsSPtoDTO Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			vehicleInfo.setPurchaseDate(resultSet.getString("PurchaseDate"));
		}
		logger.info("StoredProcedureService.vehicleDetailsSPtoDTO()  getPurchaseDate: {{}}",
				vehicleInfo.getPurchaseDate());

		return vehicleInfo;

	}

	private ServiceHistoryInfoVO serviceHistorySPtoDTO(ResultSet resultSet) throws SQLException {
		ServiceHistoryInfoVO serviceHistory = new ServiceHistoryInfoVO();
		serviceHistory.setServiceInvoicenum(resultSet.getString(SERVICE_INVOICE_NUM));
		serviceHistory.setInvoiceDate(resultSet.getString(INVOICE_DATE));
		serviceHistory.setBillAmount(resultSet.getString(BILL_AMOUNT));
		serviceHistory.setDealerId(resultSet.getString(BRANCH_ID));
		serviceHistory.setUserId(resultSet.getString(USER_ID));
//			serviceHistory.setPaymentMethod(paymentMethod);
		serviceHistory.setLastUpdatedOn(resultSet.getString("LastUpdatedOn"));
		return serviceHistory;
	}

//	-------------------------

	public ServiceInProgressDTO getVehicleServiceInProgressList(String chassisNo) {
		ServiceInProgressDTO serviceInProgressDTO = new ServiceInProgressDTO();

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			if (chassisNo != null && !chassisNo.isEmpty()) {
				stringBuilder.append("_sp_getserviceinprogress('");
				stringBuilder.append(chassisNo);
				stringBuilder.append("',' ')}");
			} 

			String spQuery = stringBuilder.toString();

			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			logger.info("hadResults --------------------{{}}", hadResults);
			if (hadResults) {
				resultSet = statement.getResultSet();				
				serviceInProgressDTO.setIsServiceInProgress("No");
				while (resultSet.next()) {
					serviceInProgressDTO.setCustomerRemarks(resultSet.getString("CustomerRemarks"));
					serviceInProgressDTO.setDealerInfo(resultSet.getString("BranchID"));
					try {
						String jcOpeningDealer = resultSet.getString("JCOpeningDealer");
						if (jcOpeningDealer != null && !jcOpeningDealer.isEmpty()) {
							serviceInProgressDTO.setDealerInfo(jcOpeningDealer);
						}
						logger.info("jcOpeningDealer --------------------> " + jcOpeningDealer);
						logger.info("BranchID  --------------------> " + resultSet.getString("BranchID"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					serviceInProgressDTO.setModelName(resultSet.getString("ModelName"));
					serviceInProgressDTO.setPaybleamount(resultSet.getString("PayableAmount"));
					serviceInProgressDTO.setPickupAddres(resultSet.getString("PickupAddress"));
					serviceInProgressDTO.setAppointmentNumber(resultSet.getString("AppointmentNum"));
					serviceInProgressDTO.setAppointmentStatus(resultSet.getString("AppointmentStatus"));
					serviceInProgressDTO.setAppointmentDate(resultSet.getString("AppointmentDate"));
					serviceInProgressDTO.setModelCode(resultSet.getString("ModelCode"));
					serviceInProgressDTO.setRegistrationNumber(resultSet.getString("RegistrationNumber"));
					serviceInProgressDTO.setServiceBookingType(resultSet.getInt("ServiceBookingType"));
					serviceInProgressDTO.setIsServiceInProgress("Yes");
					serviceInProgressDTO.setJobcardStatus(resultSet.getString("JobCardStatus"));
					serviceInProgressDTO.setJobCardNumber(resultSet.getString("JobCardNo"));
					serviceInProgressDTO.setAppointmentCategory(resultSet.getString("AppointmentCategory"));
					serviceInProgressDTO.setTechnicianName(resultSet.getString("TechnicianName"));					
					serviceInProgressDTO.setTechnicianMobile(resultSet.getString("TechnicianMobile"));
					serviceInProgressDTO.setSlotId(resultSet.getString("SLOTID"));
					serviceInProgressDTO.setConfirmVisitFlag(resultSet.getString("ConfirmVisitFlag"));		
					
				}				
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing getVehicleServiceInProgressList Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return serviceInProgressDTO;
	}

	public ServiceEstimateDTO getServiceEstimate(VehicleRequestDTO dto) {
		ServiceEstimateDTO serviceEstimateDTO = new ServiceEstimateDTO();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getServiceAppointmentList(' ','");
			stringBuilder.append(dto.getRegistrationNo());
			stringBuilder.append("',' ', ' ', ' ')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);
			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					// Changed as per mail "Sync on Handling Service Booking Statuses in RE Prime
					// App" on 16 OCT 19
					// Change Open (D) status not consider for this as per the discussion with RE on
					// 12 MAR 2020
					String appointmentStatus = resultSet.getString("AppointmentStatus");
					String jobCardStatus = resultSet.getString("JobCardStatus");
					String jobCardStatusReason = resultSet.getString("JobCardStatusReason");

					if (appointmentStatus != null && (appointmentStatus.equalsIgnoreCase("Scheduled")
							|| appointmentStatus.equalsIgnoreCase("Converted to JC (JC Opened)")
							|| appointmentStatus.equalsIgnoreCase("Converted to JC (Invoiced)")
							|| appointmentStatus.equalsIgnoreCase("Converted to JC(JC Opened)")
							|| appointmentStatus.equalsIgnoreCase("Converted to JC(Invoiced)"))) {
						// New Requirement 12 AUG 2020
						// https://royalenfielddna.atlassian.net/browse/REAPPINC-14
						if (jobCardStatus == null && (appointmentStatus.equalsIgnoreCase("Converted to JC (JC Opened)")
								|| appointmentStatus.equalsIgnoreCase("Converted to JC (Invoiced)")
								|| appointmentStatus.equalsIgnoreCase("Converted to JC(JC Opened)")
								|| appointmentStatus.equalsIgnoreCase("Converted to JC(Invoiced)"))) {
							logger.info("jobCardStatus == null &&  JC breaking --------------------{{}}");
							continue;
							// break;
						}
						if (jobCardStatus == null || (!jobCardStatus.equalsIgnoreCase("Closed")
								&& !jobCardStatus.equalsIgnoreCase("Cancelled")
								&& !jobCardStatus.equalsIgnoreCase("On Hold")
								&& !jobCardStatus.equalsIgnoreCase("Rejected"))) {

							serviceEstimateDTO.setTotalEstimate(resultSet.getString("PaybleAmount"));

							if (jobCardStatusReason != null && jobCardStatusReason.equals("Delivered")) {
							} else {
								break;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing getServiceEstimate Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return serviceEstimateDTO;
	}

	public ServiceEstimateDTO getServiceEstimateUsingChassisNo(VehicleRequestDTO vehicleRequestDTO) {
		logger.debug("getServiceEstimateUsingChassisNo called");
		ServiceEstimateDTO serviceEstimateDTO = new ServiceEstimateDTO();

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getserviceinprogress('");
			stringBuilder.append(vehicleRequestDTO.getChassisNo());
			stringBuilder.append("',' ')}");

			String spQuery = stringBuilder.toString();

			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			logger.info("hadResults --------------------{{}}", hadResults);
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					serviceEstimateDTO.setTotalEstimate(resultSet.getString("PaybleAmount"));
				}
			}
		} catch (Exception e) {
			logger.error("Exception Occured getServiceEstimateUsingChassisNo Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return serviceEstimateDTO;
	}

	public AppointmentBookDTO getServiceStatus(String caseId) {
		Connection connection = null;
		CallableStatement statement = null;
		AppointmentBookDTO appointmentBookDTO = new AppointmentBookDTO();
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getServiceAppointmentList(' ',' ','");
			stringBuilder.append(caseId);
			stringBuilder.append("', ' ', ' ')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);
			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("AppointmentDate - > {{}}", resultSet.getString("AppointmentDate"));
					logger.info("AppointmentDate - >" + resultSet.getString("AppointmentDate"));
					String jcOpeningDealer = resultSet.getString("JCOpeningDealer");
					appointmentBookDTO.setAppointmentDate(resultSet.getString("AppointmentDate"));
					appointmentBookDTO.setPickUpAddress(resultSet.getString("PickupAddress"));
					appointmentBookDTO.setRegNo(resultSet.getString("RegistrationNumber"));
					if (jcOpeningDealer != null && !jcOpeningDealer.isEmpty()) {
						appointmentBookDTO.setBranchID(jcOpeningDealer);
					} else {
						appointmentBookDTO.setBranchID(resultSet.getString("BranchID"));
					}
					appointmentBookDTO.setCustomerRemarks(resultSet.getString("CustomerRemarks"));
					appointmentBookDTO.setServiceBookingType(resultSet.getInt("ServiceBookingType"));
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing getServiceStatus Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return appointmentBookDTO;
	}

	public ScheduledAppointmentDTO getScheduledService(String chassisNo) {
		Connection connection = null;
		CallableStatement statement = null;
		ScheduledAppointmentDTO appointmentDTO = new ScheduledAppointmentDTO();
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_FreePaidservicedue('");
			stringBuilder.append(chassisNo);
			stringBuilder.append("')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);
			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("AppointmentDate - > {{}}", resultSet.getString("AppointmentDate"));
					logger.info("AppointmentStatus - >" + resultSet.getString("AppointmentStatus"));
					logger.info("setAppointmentDueDate - >" + resultSet.getString("AppointmentDueDate"));
					logger.info("AppointmentNum - >" + resultSet.getString("AppointmentNum"));
					logger.info("AppointmentLastDate - >" + resultSet.getString("AppointmentLastDate"));
					appointmentDTO.setAppointmentDate(resultSet.getString("AppointmentDate"));
					appointmentDTO.setAppointmentDueDate(resultSet.getString("AppointmentDueDate"));
					appointmentDTO.setAppointmentStatus(resultSet.getString("AppointmentStatus"));
					appointmentDTO.setAppointmentNum(resultSet.getString("AppointmentNum"));
					appointmentDTO.setRegistrationNumber(resultSet.getString("RegistrationNumber"));
					appointmentDTO.setBranchID(resultSet.getString("BranchID"));
					appointmentDTO.setChasssisNumber(resultSet.getString("ChasssisNumber"));
					appointmentDTO.setServiceType(resultSet.getString("ServiceType"));
					appointmentDTO.setAppointmentLastDate(resultSet.getString("AppointmentLastDate"));
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing getServiceStatus Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return appointmentDTO;
	}
	
	public AppointmentFeedbackResponseDTO getFeedBackLInk(String jobCardNumber) {
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		AppointmentFeedbackResponseDTO appointmentFeedbackResponseDTO = new AppointmentFeedbackResponseDTO();
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getsurveylink('");
			stringBuilder.append(jobCardNumber);
			stringBuilder.append("')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);
			statement = connection.prepareCall(spQuery);
			boolean hadResults = statement.execute();
			if (hadResults) {
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					logger.info("SurveyInviteLINK - > {{}}", resultSet.getString("SurveyInviteLINK"));
					appointmentFeedbackResponseDTO.setSurveyInviteLink(resultSet.getString("SurveyInviteLINK")); 
					appointmentFeedbackResponseDTO.setStatus(resultSet.getString("Status"));
				}
			}
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing getServiceStatus Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		} finally {
			closeConnections(connection, statement, resultSet);
		}
		return appointmentFeedbackResponseDTO;
	}

	private void closeConnections(Connection connection, CallableStatement statement, ResultSet resultSet) {
		try {
			if (null != resultSet)
				resultSet.close();
			if (null != statement)
				statement.close();
			if (null != connection)
				connection.close();
		} catch (SQLException e) {
			logger.error(
					"Exception Occured While closing connection object.Input Params {Result Set{}},{Statement{}} & {Connection{}} Exception Message {{}},Exception Details {{}}",
					resultSet, statement, connection, e.getMessage(), e);
		}

	}

	/**
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	public List<VehicleDetailsVO> callGetVehicleDetailsProcedure(final String mobileNo) {
		logger.info("Calling callGetVehicleDetailsProcedure({}) ", mobileNo);

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getVehicleDetails(' ',' ',' ', ? ,' ')}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			statement.setString(1, mobileNo);
			if (statement.execute()) {
				List<VehicleDetailsVO> userVehicleDetailsList = new ArrayList<>();
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					VehicleDetailsVO object = new VehicleDetailsVO(resultSet);

					userVehicleDetailsList.add(object);
				}
				return userVehicleDetailsList;
			}
			return Collections.emptyList();
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While executing getVehicleDetails({}) procudure Exception Message {{}},Exception Details {{}}",
					mobileNo, e.getMessage(), e);
			return Collections.emptyList();
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	public Object[][] callVerifyUserVehicleDetailsProcedure(VehicleVerifyRequestDTO dto) {
		Object[][] objectArr = new Object[1][2];
		String spQuery = "";
		if ((StringUtils.isNotEmpty(dto.getRegistrationNumber()) && StringUtils.isNotEmpty(dto.getChassisNumber()))
				|| StringUtils.isNotEmpty(dto.getChassisNumber())) {

			logger.info(
					"Found Registration Number Or Chassis Number. So calling DMS SP. Input Params {Regis No:{}}{Chassis No:{}}",
					dto.getRegistrationNumber(), dto.getChassisNumber());

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append(spPrefix);
			stringBuilder.append("_sp_getVehicleDetails(' ', ? ,' ',' ',' ')}");
			spQuery = stringBuilder.toString();
			objectArr[0][0] = callVerifyUserVehicleDetailsProcedure(spQuery, dto.getChassisNumber());
			objectArr[0][1] = CALL_CUSTOMER_SUPPORT;
			return objectArr;
		}
		logger.info(
				"Found Registration Number Only. So calling DMS SP with Registration number. Input Params {Regis No:{}}",
				dto.getRegistrationNumber());

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(CALL);
		stringBuilder.append(spPrefix);
		stringBuilder.append("_sp_getVehicleDetails(?,' ',' ',' ',' ')}");
		spQuery = stringBuilder.toString();
		objectArr[0][0] = callVerifyUserVehicleDetailsProcedure(spQuery, dto.getRegistrationNumber());
		objectArr[0][1] = PLEASE_TRY_ADDING_VEHICLE_WITH_CHASSIS_NO;
		return objectArr;
	}

	/**
	 * @param spQuery
	 * @param inputParam
	 * @return
	 * @throws Exception
	 */
	private VehicleDetailsVO callVerifyUserVehicleDetailsProcedure(final String spQuery, final String inputParam) {
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			statement.setString(1, inputParam);
			if (statement.execute()) {
				resultSet = statement.getResultSet();
				if (resultSet.next()) {
					return new VehicleDetailsVO(resultSet);
				}
				return null;
			}
			return null;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While executing {}_sp_getVehicleDetails() stored procedure. Exception Message {{}},Exception Details {{}}",
					spPrefix, e.getMessage(), e);
			return null;
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	/**
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	public List<VehicleVinResponseObject> getVehicleVin(GetVehicleVinRequestDTO dto) {
		logger.info("Calling callGetVehicleDetailsProcedure to get Vehicle Vin({}) ", dto);

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			statement = connection.prepareCall(prepareVehicleStoredProcedureQueryWithAllParams());
			statement.setString(1, dto.getRegistrationNo());
			statement.setString(2, dto.getChassisNo());
			statement.setString(3, dto.getEngineNo());
			statement.setString(4, dto.getMobileNo());
			statement.setString(5, dto.getLastPullDate());

			if (statement.execute()) {
				List<VehicleVinResponseObject> userVehicleDetailsList = new ArrayList<>();
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					VehicleVinResponseObject vehicleObject = new VehicleVinResponseObject();
					vehicleObject.setChassisNo(resultSet.getString("ChassisNo"));
					userVehicleDetailsList.add(vehicleObject);
				}
				return userVehicleDetailsList;
			}
			return Collections.emptyList();
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While executing getVehicleDetails SP procudure Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return Collections.emptyList();
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	public List<VehicleJobCardStatusResponseObject> getVinJobCardStatus(@Valid GetVinJobCardStatusRequestDTO dto) {
		logger.info("Calling callGetVehicleDetailsProcedure to get Vehicle Vin({}) ", dto);

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(CALL);
			stringBuilder.append("REMechanic_OpenJC(?)}");
			String spQuery = stringBuilder.toString();
			logger.info(spQuery);

			statement = connection.prepareCall(spQuery);
			statement.setString(1, dto.getChassisNo());

			if (statement.execute()) {
				List<VehicleJobCardStatusResponseObject> vehicleJobCardStatusList = new ArrayList<>();
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					VehicleJobCardStatusResponseObject object = new VehicleJobCardStatusResponseObject(resultSet);
					vehicleJobCardStatusList.add(object);
				}
				return vehicleJobCardStatusList;
			}
			return Collections.emptyList();
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While executing REMechanic_OpenJC SP. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return Collections.emptyList();
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public List<VehicleDetailsVO> getFullVehicleDetails(GetVehicleVinRequestDTO dto) {
		logger.info("Calling callGetVehicleDetailsProcedure to get Vehicle details.");

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();

			statement = connection.prepareCall(prepareVehicleStoredProcedureQueryWithAllParams());
			statement.setString(1, dto.getRegistrationNo());
			statement.setString(2, dto.getChassisNo());
			statement.setString(3, dto.getEngineNo());
			statement.setString(4, dto.getMobileNo());
			statement.setString(5, dto.getLastPullDate());

			if (statement.execute()) {
				List<VehicleDetailsVO> userVehicleDetailsList = new ArrayList<>();
				resultSet = statement.getResultSet();
				while (resultSet.next()) {
					userVehicleDetailsList.add(new VehicleDetailsVO(resultSet));
				}
				return userVehicleDetailsList;
			}
			return Collections.emptyList();
		} catch (final Exception e) {
			logger.error(
					"Exception Occured While executing getVehicleDetails SP procudure Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return Collections.emptyList();
		} finally {
			closeConnections(connection, statement, resultSet);
		}
	}

	private String prepareVehicleStoredProcedureQueryWithAllParams() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(CALL);
		stringBuilder.append(spPrefix);
		stringBuilder.append("_sp_getVehicleDetails(?,?,?,?,?)}");
		String spQuery = stringBuilder.toString();
		logger.info(spQuery);

		return spQuery;
	}

}
