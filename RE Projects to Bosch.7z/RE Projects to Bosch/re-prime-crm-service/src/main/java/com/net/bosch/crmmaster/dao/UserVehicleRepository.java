package com.net.bosch.crmmaster.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.vehicle.collection.UserVehicle;

/**
 * @author pushkarkhosla
 *
 */
@Repository
public interface UserVehicleRepository extends MongoRepository<UserVehicle, String> {

	/**
	 * This method fetch user vehicle details by mobile no from MOngo DB.
	 */
	Optional<UserVehicle> findByPhoneNo(final String mobileNo);

	// Optional<UserVehicle> findByUserVehiclesChassisNo(@Param(value = "chassisNo")
	// String chassisNo);

	Optional<UserVehicle> findByGuid(final String guid);

	List<UserVehicle> findAllByGuid(final String guid);

	List<UserVehicle> findByCreatedOnBetween(@Param(value = "createdOnFrom") Date createdOnFrom,
			@Param(value = "createdOnTo") Date createdOnTo);

	List<UserVehicle> findByUserVehiclesChassisNoIn(@Param(value = "chassisNumbers") List<String> chassisNumbers);

	List<UserVehicle> findByUserVehiclesChassisNo(@Param(value = "chassisNo") String chassisNo);
}
