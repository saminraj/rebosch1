package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DMSServiceHistoryResponse {

	private String branchId;
	private String invoiceDate;
	private String billAmount;
	private String serviceInvoiceNum;
	private String chassisNo;
	private String regNo;
	private String userID;
	private String userMobileNumber;
	private String status;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DMSServiceHistoryResponse [branchId=");
		builder.append(branchId);
		builder.append(", invoiceDate=");
		builder.append(invoiceDate);
		builder.append(", billAmount=");
		builder.append(billAmount);
		builder.append(", serviceInvoiceNum=");
		builder.append(serviceInvoiceNum);
		builder.append(", chassisNo=");
		builder.append(chassisNo);
		builder.append(", regNo=");
		builder.append(regNo);
		builder.append(", userID=");
		builder.append(userID);
		builder.append(", userMobileNumber=");
		builder.append(userMobileNumber);
		builder.append(", status=");
		builder.append(status);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the branchId
	 */
	public String getBranchId() {
		return branchId;
	}

	/**
	 * @param branchId the branchId to set
	 */
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	/**
	 * @return the invoiceDate
	 */
	public String getInvoiceDate() {
		return invoiceDate;
	}

	/**
	 * @param invoiceDate the invoiceDate to set
	 */
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	/**
	 * @return the billAmount
	 */
	public String getBillAmount() {
		return billAmount;
	}

	/**
	 * @param billAmount the billAmount to set
	 */
	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	/**
	 * @return the serviceInvoiceNum
	 */
	public String getServiceInvoiceNum() {
		return serviceInvoiceNum;
	}

	/**
	 * @param serviceInvoiceNum the serviceInvoiceNum to set
	 */
	public void setServiceInvoiceNum(String serviceInvoiceNum) {
		this.serviceInvoiceNum = serviceInvoiceNum;
	}

	/**
	 * @return the chassisNo
	 */
	public String getChassisNo() {
		return chassisNo;
	}

	/**
	 * @param chassisNo the chassisNo to set
	 */
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	/**
	 * @return the regNo
	 */
	public String getRegNo() {
		return regNo;
	}

	/**
	 * @param regNo the regNo to set
	 */
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * @return the userMobileNumber
	 */
	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	/**
	 * @param userMobileNumber the userMobileNumber to set
	 */
	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
