package com.net.bosch.crmmaster.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.domain.Dealer;

@Repository
public interface DealerRepository extends CrudRepository<Dealer, String> {

	List<Dealer> findAll();

}