/**
 * 
 */
package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum EmailTable {

	VEHICLE_ON_BOARDING("VEHICLE_ON_BOARDING"),CONFIGURATOR("CONFIGURATOR");

	private String value;

	/**
	 * @param value
	 */
	private EmailTable(String value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

}
