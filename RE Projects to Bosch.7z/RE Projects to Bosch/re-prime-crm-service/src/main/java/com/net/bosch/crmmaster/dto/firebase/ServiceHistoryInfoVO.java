package com.net.bosch.crmmaster.dto.firebase;

public class ServiceHistoryInfoVO {

	String billAmount;
	String dealerId;
	String invoiceDate;
	String paymentMethod;
	String serviceInvoicenum;
	String userId;
	String lastUpdatedOn;
	

	public ServiceHistoryInfoVO() {

	}

	public ServiceHistoryInfoVO(String serviceInvoicenum, String invoiceDate,
			String billAmount, String dealerId) {

		this.serviceInvoicenum = serviceInvoicenum;
		this.invoiceDate = invoiceDate;
		this.billAmount = billAmount;
		this.dealerId = dealerId;
	}

	public String getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getServiceInvoicenum() {
		return serviceInvoicenum;
	}

	public void setServiceInvoicenum(String serviceInvoicenum) {
		this.serviceInvoicenum = serviceInvoicenum;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}
	
}
