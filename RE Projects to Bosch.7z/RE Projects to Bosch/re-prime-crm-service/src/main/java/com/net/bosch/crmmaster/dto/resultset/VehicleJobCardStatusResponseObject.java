package com.net.bosch.crmmaster.dto.resultset;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author pushkarkhosla
 *
 */
public class VehicleJobCardStatusResponseObject {

	
	private String jobCardStatus;

	/**
	 * @return the jobCardStatus
	 */
	public String getJobCardStatus() {
		return jobCardStatus;
	}

	/**
	 * @param jobCardStatus the jobCardStatus to set
	 */
	public void setJobCardStatus(String jobCardStatus) {
		this.jobCardStatus = jobCardStatus;
	}

	public VehicleJobCardStatusResponseObject(ResultSet resultSet) throws SQLException {
			this.jobCardStatus = resultSet.getString("JobcardNumber");
		
	}
	
	

}
