package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pushkarkhosla
 *
 */
public class DMSBookingDetailsResponse {

	@JsonProperty("BookingDate")
	private String bookingDate;

	@JsonProperty("CustAccount")
	private String custAccount;

	@JsonProperty("DealerCode")
	private String dealerCode;

	@JsonProperty("DisplayCustEmail")
	private String displayCustEmail;

	@JsonProperty("DisplayCustName")
	private String displayCustName;

	@JsonProperty("DisplayCustPhone")
	private String displayCustPhone;

	@JsonProperty("DisplayDealerName")
	private String displayDealerName;

	@JsonProperty("DisplayVehicleDescription")
	private String displayVehicleDescription;

	@JsonProperty("ModelId")
	private String modelId;

	@JsonProperty("PendingAmount")
	private String pendingAmount;

	private DMSBookingDetailsResponseError error;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DMSBookingDetailsResponse [bookingDate=");
		builder.append(bookingDate);
		builder.append(", custAccount=");
		builder.append(custAccount);
		builder.append(", dealerCode=");
		builder.append(dealerCode);
		builder.append(", displayCustEmail=");
		builder.append(displayCustEmail);
		builder.append(", displayCustName=");
		builder.append(displayCustName);
		builder.append(", displayCustPhone=");
		builder.append(displayCustPhone);
		builder.append(", displayDealerName=");
		builder.append(displayDealerName);
		builder.append(", displayVehicleDescription=");
		builder.append(displayVehicleDescription);
		builder.append(", modelId=");
		builder.append(modelId);
		builder.append(", pendingAmount=");
		builder.append(pendingAmount);
		builder.append(", error=");
		builder.append(error);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the error
	 */
	public DMSBookingDetailsResponseError getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(DMSBookingDetailsResponseError error) {
		this.error = error;
	}

	/**
	 * @return the bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * @param bookingDate the bookingDate to set
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * @return the custAccount
	 */
	public String getCustAccount() {
		return custAccount;
	}

	/**
	 * @param custAccount the custAccount to set
	 */
	public void setCustAccount(String custAccount) {
		this.custAccount = custAccount;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the displayCustEmail
	 */
	public String getDisplayCustEmail() {
		return displayCustEmail;
	}

	/**
	 * @param displayCustEmail the displayCustEmail to set
	 */
	public void setDisplayCustEmail(String displayCustEmail) {
		this.displayCustEmail = displayCustEmail;
	}

	/**
	 * @return the displayCustName
	 */
	public String getDisplayCustName() {
		return displayCustName;
	}

	/**
	 * @param displayCustName the displayCustName to set
	 */
	public void setDisplayCustName(String displayCustName) {
		this.displayCustName = displayCustName;
	}

	/**
	 * @return the displayCustPhone
	 */
	public String getDisplayCustPhone() {
		return displayCustPhone;
	}

	/**
	 * @param displayCustPhone the displayCustPhone to set
	 */
	public void setDisplayCustPhone(String displayCustPhone) {
		this.displayCustPhone = displayCustPhone;
	}

	/**
	 * @return the displayDealerName
	 */
	public String getDisplayDealerName() {
		return displayDealerName;
	}

	/**
	 * @param displayDealerName the displayDealerName to set
	 */
	public void setDisplayDealerName(String displayDealerName) {
		this.displayDealerName = displayDealerName;
	}

	/**
	 * @return the displayVehicleDescription
	 */
	public String getDisplayVehicleDescription() {
		return displayVehicleDescription;
	}

	/**
	 * @param displayVehicleDescription the displayVehicleDescription to set
	 */
	public void setDisplayVehicleDescription(String displayVehicleDescription) {
		this.displayVehicleDescription = displayVehicleDescription;
	}

	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}

	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	/**
	 * @return the pendingAmount
	 */
	public String getPendingAmount() {
		return pendingAmount;
	}

	/**
	 * @param pendingAmount the pendingAmount to set
	 */
	public void setPendingAmount(String pendingAmount) {
		this.pendingAmount = pendingAmount;
	}

}
