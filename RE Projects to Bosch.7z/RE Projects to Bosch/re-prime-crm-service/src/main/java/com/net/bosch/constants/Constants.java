package com.net.bosch.constants;

import java.util.regex.Pattern;

import com.net.bosch.crmmaster.service.BalancePaymentService;
import com.net.bosch.crmmaster.service.DMSDirectPostingService;
import com.net.bosch.crmmaster.service.OnlineBookingService;
import com.net.bosch.crmmaster.service.RestTemplateService;
import com.net.bosch.utils.ApplicationHelper;

public class Constants {

	private Constants() {

	}

	public static final String LONG_DATE_FORMAT = "hh:mm a MMM dd yyyy";
	public static final String SHORT_DATE_FORMAT = "dd-MMM-yyyy";
	public static final String RE_PRIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String BOOKING_HISTORY_PATTERN = "yyyy-MM-dd HH:mm:ss";
	public static final String RE_PRIME_MANUFACTURE_DATE = "MMM dd yyyy hh:mma";
	public static final String RE_PRIME_PURCHASE_DATE = "MMM dd yyyy hh:mma";

	public static final String SUCCESS_CODE = "200";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILED = "FAILED";
	public static final int MINIMUM_REGIS_NUM_LEN = 8;
	public static final int MAXIMUM_REGIS_NUM_LEN = 10;
	public static final int CHASSIS_NUMBER_LEN = 50;

	/**
	 * Used In UserVehicleService.
	 */
	public static final String KYC_DOC_KEY = "kycDoc";
	public static final String RC_DOC_KEY = "RCDoc";
	public static final String CUSTOMER_REGIS_KEY = "customerRegis";
	public static final String INITIATED_PAYMENT_STATUS = "INITIATED";
	public static final String INITIAL_PAYMENT_STAGE = "INITIAL_PAYMENT";
	public static final String BALANCE_PAYMENT_STAGE = "BALANCE_PAYMENT";
	public static final String CUSTOMER_ADD_VEHICLE_KEY = "customerAddVehicle";
	public static final String REGISTRATION_NO_UPDATE_TRANSACTION_TYPE = "Reg No Update";
	public static final String VEHICLE_VERIFIED_TRANSACTION_TYPE = "Vehicle Verified";

	/**
	 * Used In EmailService.
	 */
	public static final double MAX_FILE_SIZE = 3;
	public static final Pattern FILE_EXTN_PATTERN = Pattern.compile("([^\\s]+(\\.(?i)(jpg|jpeg|pdf))$)");

	/**
	 * Used In ThymeleafConfig.
	 */
	public static final String UTF_8 = "UTF-8";

	/**
	 * Used In EmailHelper.
	 */
	public static final String NEXT_LINE = "\n\n";
	public static final String USER_NAME_KEY = "##userName##";
	public static final String OWNER_SHIP_FILE_NAME = "RC Document";
	public static final String KYC_FILE_NAME = "KYC Document";

	/**
	 * Used In {@link OnlineBookingService} {@link BalancePaymentService} .
	 */
	public static final String HYPHEN = "-";
	public static final String BOOKING_SEQUENCE_PREFIX = "OBB".concat(HYPHEN);
	public static final String BOOKING_DIGITS_FORMATTER = "%020d";
	public static final int RETRY_COUNT = 5;
	/**
	 * Used In {@link BalancePaymentService}.
	 */
	public static final String DMS_DEALER_SOURCE = "D";
	public static final String EXCELLON_DEALER_SOURCE = "E";

	public static final String ONLINE_BALANCE_PAYMENT_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss.S";
	public static final String DMS_EXCELLON_PAYMENT_SOURCE = "Online";
	public static final String SUCCESSFUL_TRANSACTION = "Successful Transaction";
	public static final String CANCEL_TRANSACTION = "Cancel Transaction";
	public static final String PENDING_RESOLUTION_TRANSACTION_STATUS = "Pending Resolution";
	public static final String BILL_DESK_AUTH_STATUS_NA = "NA";
	public static final String BILL_DESK_AUTH_STATUS_PENDING = "0002";
	public static final String CONFIG_STATUS_OPEN = "OPEN";
	public static final String CONFIG_STATUS_BOOKED = "BOOKED";
	public static final String FETCH_CONFIG_STATUS_ID_PARAM = "id";

	/**
	 * Used In {@link ApplicationHelper}.
	 */
	public static final String DDMMYYYY_SLASH = "dd/MM/yyyy HH:mm:ss a";
	public static final String FIRST_PAYMENT = "-01";
	public static final String BALANCE_PAYMENT = "-02";
	public static final String APP_ID_KEY = "app_id";
	public static final String APP_ID_VALUE_FOR_PAYMENT_SERVICE = "2";
	public static final String APP_ID_VALUE_FOR_RE_UTILITY_SAVE_EMAIL = "4";
	public static final String APP_ID_VALUE_FOR_PUSH_NOTIFICATION = "8";

	/**
	 * Used In {@link RestTemplateService}.
	 */
	public static final String DMS_BOOKING_DETAILS_API_QUERY_PARAMS_VERSION = "api-version";
	public static final String DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SP = "sp";
	public static final String DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SV = "sv";
	public static final String DMS_BOOKING_DETAILS_API_QUERY_PARAMS_SIG = "sig";
	public static final String USER_DETAILS_API_USERNAME_PARAM_KEY = "sig";

	/**
	 * Used In {@link DMSDirectPostingService}.
	 */
	public static final String GRANT_TYPE = "grant_type";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String RESOURCE = "resource";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer ";
	public static final String ACCESS_TOKEN = "access_token";

	public static final String VEHICLE_SERVICE_HISTORY_FIREBASE_CONSTANT = "VehicleServiceHistory";
	public static final String SERVICE_HISTORY_FIREBASE_CONSTANT = "serviceHistory";
	public static final String CHASSIS_NO = "ChassisNo";

	public static final String SP_NO_DATA_FOUND = "No Result Found From Stored Procedure.";

	public static final String DMS_DO_NOT_RETRY_MESSAGE = "501 Not Implemented";

	public static final String DMS_PROCESSING_TRANSACTION_STAGE = "PROCESSING";
	public static final String DMS_DIRECT_POSTED_TRANSACTION_STAGE = "DIRECT_POSTED";
	public static final String MIY_BOOKINGS = "MIY_BOOKINGS";
	public static final String INSTORE_BOOKINGS = "INSTORE_BOOKINGS";

	public static final String MIY_WEB_APP_ID = "5";
	public static final String MIY_REAPP_APP_ID = "2";
	public static final String INSTORE_APP_ID = "6";

	public static final String WEB_USER_NAME_KEY = "username";

	public static final String FIRESTORE_KEY_MY_BOOKING = "myBooking";
	public static final String FIRESTORE_KEY_BIKE_BOOKING = "bikeBooking";

	public static final String PIPE_SEPARATOR = "|";

	public static final String VALID_SERVICE_HISTORY = "Valid Service History, This will Update In Firebase.";
	public static final String INVALID_SERVICE_HISTORY = "Invalid Service History as Invoice Date, Bill Amount or Invoice Number is Blank. This will Not Update In Firebase";
	public static final String DMS_SUCCESS_MESSAGE = "Booking created successfully";
	
	public static final String VEHICLE_ONBOARDING = "VEHICLE_ONBOARDING";
	public static final String REGISTRATION_NUMBER_UPDATE_OR_REMOVE_BIKE = "REGISTRATION_NUMBER_UPDATE_OR_REMOVE_BIKE ";
	
}
