package com.net.bosch.crmmaster.domain;

import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;
import org.springframework.data.redis.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.crmmaster.dto.AppointmentBookDTO;
import com.net.bosch.crmmaster.dto.AppointmentSlotListDTO;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash(value = "AppointmentBookQueue", timeToLive = 900)
public class AppointmentBookQueue implements DomainObject{

	private static final long serialVersionUID = -646307326078491498L;

	@Id
	public String id;
	
	@Indexed
	public String caseId;
	
	@Indexed
	public String date;
	
	/*@TimeToLive 
	Long timeout;*/
	
	public AppointmentBookDTO appointmentBookDTO;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public AppointmentBookDTO getAppointmentBookDTO() {
		return appointmentBookDTO;
	}

	public void setAppointmentBookDTO(AppointmentBookDTO appointmentBookDTO) {
		this.appointmentBookDTO = appointmentBookDTO;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
			
}
