package com.net.bosch.crmmaster.dto;

public class ShowAuthorizeRequestDTO {

	private String chassisNumber;
	private String engineNumber;

	public ShowAuthorizeRequestDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param chassisNumber
	 * @param engineNumber
	 */
	public ShowAuthorizeRequestDTO(String chassisNumber) {
		super();
		this.chassisNumber = chassisNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ShowAuthorizeRequestDTO [chassisNumber=");
		builder.append(chassisNumber);
		builder.append(", engineNumber=");
		builder.append(engineNumber);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the chassisNumber
	 */
	public String getChassisNumber() {
		return chassisNumber;
	}

	/**
	 * @param chassisNumber the chassisNumber to set
	 */
	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	/**
	 * @return the engineNumber
	 */
	public String getEngineNumber() {
		return engineNumber;
	}

	/**
	 * @param engineNumber the engineNumber to set
	 */
	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

}
