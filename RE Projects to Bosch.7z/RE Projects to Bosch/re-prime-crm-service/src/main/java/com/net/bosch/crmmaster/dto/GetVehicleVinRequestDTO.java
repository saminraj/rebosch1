package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class GetVehicleVinRequestDTO implements Serializable {

	private static final long serialVersionUID = -3541122859222308326L;

	private String registrationNo;

	private String chassisNo;

	private String engineNo;

	private String mobileNo;

	private String lastPullDate;

	/**
	 * @return the lastPullDate
	 */
	public String getLastPullDate() {
		return lastPullDate;
	}

	/**
	 * @param lastPullDate the lastPullDate to set
	 */
	public void setLastPullDate(String lastPullDate) {
		this.lastPullDate = lastPullDate;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GetVehicleVinRequestDTO [registrationNo=").append(registrationNo).append(", chassisNo=")
				.append(chassisNo).append(", engineNo=").append(engineNo).append(", mobileNo=").append(mobileNo)
				.append(", lastPullDate=").append(lastPullDate).append("]");
		return builder.toString();
	}

}
