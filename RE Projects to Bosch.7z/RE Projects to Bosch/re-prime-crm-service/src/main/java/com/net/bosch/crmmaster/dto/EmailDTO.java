package com.net.bosch.crmmaster.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class EmailDTO {

	/**
	 * User Profile Details parameters starts
	 */
	private String userName;

	private String primaryPhoneNumber;

	private String toEmailId;

	private String chassisNo;

	private boolean isKycDocPresent;

	private String appId;

	// Update Registration Number & Remove Vehicle E-Mail Parameters
	private List<RegistrationNumberRequest> removeBikes;
	private List<RegistrationNumberRequest> updateRegisNo;

	public EmailDTO() {

	}

	/**
	 * Below Constructor is Used for Add Vehicle
	 * 
	 * @param userName
	 * @param primaryPhoneNumber
	 * @param toEmailId
	 */
	public EmailDTO(String userName, @NotNull @NotEmpty String primaryPhoneNumber, @NotNull @NotEmpty String toEmailId,
			String chassisNo, boolean isKycDocPresent, String appId) {
		this.userName = userName;
		this.primaryPhoneNumber = primaryPhoneNumber;
		this.toEmailId = toEmailId;
		this.chassisNo = chassisNo;
		this.isKycDocPresent = isKycDocPresent;
		this.appId = appId;
	}

	/**
	 * Below Constructor is Used for Update Registration Number & Remove Bike
	 * 
	 * @param userName
	 * @param primaryPhoneNumber
	 * @param toEmailId
	 * @param removeBikes
	 * @param updateRegisNo
	 */
	public EmailDTO(String userName, String primaryPhoneNumber, @NotNull @NotEmpty String toEmailId,
			List<RegistrationNumberRequest> updateRegisNo, List<RegistrationNumberRequest> removeBikes, String appId) {
		this.userName = userName;
		this.primaryPhoneNumber = primaryPhoneNumber;
		this.toEmailId = toEmailId;
		this.removeBikes = removeBikes;
		this.updateRegisNo = updateRegisNo;
		this.appId = appId;
	}

	/**
	 * @return the chassisNo
	 */
	public String getChassisNo() {
		return chassisNo;
	}

	/**
	 * @param chassisNo the chassisNo to set
	 */
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the primaryPhoneNumber
	 */
	public String getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}

	/**
	 * @param primaryPhoneNumber the primaryPhoneNumber to set
	 */
	public void setPrimaryPhoneNumber(String primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}

	/**
	 * @return the toEmailId
	 */
	public String getToEmailId() {
		return toEmailId;
	}

	/**
	 * @param toEmailId the toEmailId to set
	 */
	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}

	/**
	 * @return the removeBikes
	 */
	public List<RegistrationNumberRequest> getRemoveBikes() {
		return removeBikes;
	}

	/**
	 * @param removeBikes the removeBikes to set
	 */
	public void setRemoveBikes(List<RegistrationNumberRequest> removeBikes) {
		this.removeBikes = removeBikes;
	}

	/**
	 * @return the updateRegisNo
	 */
	public List<RegistrationNumberRequest> getUpdateRegisNo() {
		return updateRegisNo;
	}

	/**
	 * @param updateRegisNo the updateRegisNo to set
	 */
	public void setUpdateRegisNo(List<RegistrationNumberRequest> updateRegisNo) {
		this.updateRegisNo = updateRegisNo;
	}

	public boolean getIsKycDocPresent() {
		return isKycDocPresent;
	}

	public void setIsKycDocPresent(boolean isKycDocPresent) {
		this.isKycDocPresent = isKycDocPresent;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Override
	public String toString() {
		return "EmailDTO [userName=" + userName + ", primaryPhoneNumber=" + primaryPhoneNumber + ", toEmailId="
				+ toEmailId + ", chassisNo=" + chassisNo + ", isKycDocPresent=" + isKycDocPresent + ", removeBikes="
				+ removeBikes + ", updateRegisNo=" + updateRegisNo + ", appId=" + appId + "]";
	}

}
