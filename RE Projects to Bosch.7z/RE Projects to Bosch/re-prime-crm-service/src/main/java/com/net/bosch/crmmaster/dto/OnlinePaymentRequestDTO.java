package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.net.bosch.constants.BookingStatus;
import com.net.bosch.dto.base.RequestDTO;

/**
 * @author pushkarkhosla
 *
 */
public class OnlinePaymentRequestDTO extends RequestDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5993147403976469989L;

	@NotNull
	@NotBlank
	private String bookingCaseId;

	private Double amountPaid;

	@NotNull
	@NotBlank
	private String paymentCaseId;

	private String billDeskTrnsactionId;

	private String paymentStatus;

	private BookingStatus bookingStatus;

	/**
	 * Bill-Desk-Payment Response Params
	 */
	private PaymentRawResponse paymentRawResponse;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OnlinePaymentRequestDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", amountPaid=");
		builder.append(amountPaid);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", billDeskTrnsactionId=");
		builder.append(billDeskTrnsactionId);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", bookingStatus=");
		builder.append(bookingStatus);
		builder.append(", paymentRawResponse=");
		builder.append(paymentRawResponse);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingStatus
	 */
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the paymentRawResponse
	 */
	public PaymentRawResponse getPaymentRawResponse() {
		return paymentRawResponse;
	}

	/**
	 * @param paymentRawResponse the paymentRawResponse to set
	 */
	public void setPaymentRawResponse(PaymentRawResponse paymentRawResponse) {
		this.paymentRawResponse = paymentRawResponse;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the amountPaid
	 */
	public Double getAmountPaid() {
		return amountPaid;
	}

	/**
	 * @param amountPaid the amountPaid to set
	 */
	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the billDeskTrnsactionId
	 */
	public String getBillDeskTrnsactionId() {
		return billDeskTrnsactionId;
	}

	/**
	 * @param billDeskTrnsactionId the billDeskTrnsactionId to set
	 */
	public void setBillDeskTrnsactionId(String billDeskTrnsactionId) {
		this.billDeskTrnsactionId = billDeskTrnsactionId;
	}

}
