package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.RequestDTO;

/**
 * @author pushkarkhosla
 *
 */
@JsonInclude(Include.NON_NULL)
public class VehicleVerifyRequestDTO extends RequestDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -604005480503211548L;

	private String chassisNumber;
	private String registrationNumber;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VehicleVerifyRequestDTO [chassisNumber=");
		builder.append(chassisNumber);
		builder.append(", registrationNumber=");
		builder.append(registrationNumber);
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the chassisNumber
	 */
	public String getChassisNumber() {
		return chassisNumber;
	}

	/**
	 * @param chassisNumber the chassisNumber to set
	 */
	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	/**
	 * @return the registrationNumber
	 */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	/**
	 * @param registrationNumber the registrationNumber to set
	 */
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

}
