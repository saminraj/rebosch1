package com.net.bosch.crmmaster.dto;

import java.util.ArrayList;

public class ListRegNoRequestDTO {

	ArrayList<String> regnos = new ArrayList<>();

	String guid;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public ArrayList<String> getRegnos() {
		return regnos;
	}

	public void setRegnos(ArrayList<String> regnos) {
		this.regnos = regnos;
	}

}
