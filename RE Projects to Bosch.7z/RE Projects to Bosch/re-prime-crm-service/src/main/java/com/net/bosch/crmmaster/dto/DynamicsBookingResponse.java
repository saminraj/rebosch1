
package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class DynamicsBookingResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5231959735928140729L;
	private String message;
	private String bookingid;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date postedTimestamp;

	public DynamicsBookingResponse() {
	}

	/**
	 * @param message
	 * @param bookingid
	 */
	public DynamicsBookingResponse(String message, String bookingid) {
		super();
		this.message = message;
		this.bookingid = bookingid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DynamicsBookingResponse [message=");
		builder.append(message);
		builder.append(", bookingid=");
		builder.append(bookingid);
		builder.append(", postedTimestamp=");
		builder.append(postedTimestamp);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the postedTimestamp
	 */
	public Date getPostedTimestamp() {
		return postedTimestamp;
	}

	/**
	 * @param postedTimestamp the postedTimestamp to set
	 */
	public void setPostedTimestamp(Date postedTimestamp) {
		this.postedTimestamp = postedTimestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getBookingid() {
		return bookingid;
	}

	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}

}
