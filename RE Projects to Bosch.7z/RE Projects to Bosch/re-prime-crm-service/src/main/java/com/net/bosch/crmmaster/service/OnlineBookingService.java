package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.BILL_DESK_AUTH_STATUS_PENDING;
import static com.net.bosch.constants.Constants.BOOKING_DIGITS_FORMATTER;
import static com.net.bosch.constants.Constants.BOOKING_SEQUENCE_PREFIX;
import static com.net.bosch.constants.Constants.CANCEL_TRANSACTION;
import static com.net.bosch.constants.Constants.CONFIG_STATUS_BOOKED;
import static com.net.bosch.constants.Constants.CONFIG_STATUS_OPEN;
import static com.net.bosch.constants.Constants.DMS_DEALER_SOURCE;
import static com.net.bosch.constants.Constants.DMS_DIRECT_POSTED_TRANSACTION_STAGE;
import static com.net.bosch.constants.Constants.DMS_DO_NOT_RETRY_MESSAGE;
import static com.net.bosch.constants.Constants.DMS_PROCESSING_TRANSACTION_STAGE;
import static com.net.bosch.constants.Constants.DMS_SUCCESS_MESSAGE;
import static com.net.bosch.constants.Constants.EXCELLON_DEALER_SOURCE;
import static com.net.bosch.constants.Constants.HYPHEN;
import static com.net.bosch.constants.Constants.INITIATED_PAYMENT_STATUS;
import static com.net.bosch.constants.Constants.INSTORE_APP_ID;
import static com.net.bosch.constants.Constants.INSTORE_BOOKINGS;
import static com.net.bosch.constants.Constants.MIY_BOOKINGS;
import static com.net.bosch.constants.Constants.MIY_REAPP_APP_ID;
import static com.net.bosch.constants.Constants.MIY_WEB_APP_ID;
import static com.net.bosch.constants.Constants.PENDING_RESOLUTION_TRANSACTION_STATUS;
import static com.net.bosch.constants.Constants.RETRY_COUNT;
import static com.net.bosch.constants.Constants.SUCCESSFUL_TRANSACTION;
import static com.net.bosch.constants.REResponse.DMS_POSTING_FAILS;
import static com.net.bosch.constants.REResponse.GENERIC_OR_UNKNOWN_ERROR;
import static com.net.bosch.constants.REResponse.INVALID_GUID_OR_BOOKING_CASE_ID;
import static com.net.bosch.constants.REResponse.INVALID_TRANSACTION_TYPE;
import static com.net.bosch.constants.REResponse.NO_BOOKING_DETAILS_FOUND;
import static com.net.bosch.constants.REResponse.NO_RECORDS_FOUND;
import static com.net.bosch.constants.REResponse.ONLINE_PAYMENT_DETAILS_SAVED_SUCCESSFULLY;
import static com.net.bosch.utils.APIResponseHelper.getErrorResponse;
import static com.net.bosch.utils.APIResponseHelper.getSuccessResponse;
import static com.net.bosch.utils.ApplicationHelper.checkOnlineBookingOptional;
import static com.net.bosch.utils.ApplicationHelper.checkOnlinePaymentOptional;
import static com.net.bosch.utils.ApplicationHelper.getDMSPartsListForFirebase;
import static com.net.bosch.utils.ApplicationHelper.getExcellonPartsListForFirebase;
import static com.net.bosch.utils.ApplicationHelper.populateFromTimeInQuery;
import static com.net.bosch.utils.ApplicationHelper.validateAndGetBookingStatusForFirebase;
import static com.net.bosch.utils.DateHelper.formatStrToDates;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.constants.BookingStatus;
import com.net.bosch.constants.PaymentStage;
import com.net.bosch.constants.REResponse;
import com.net.bosch.constants.TransactionType;
import com.net.bosch.crmmaster.dao.OnlineBookingRepository;
import com.net.bosch.crmmaster.dao.OnlinePaymentDetailsRepository;
import com.net.bosch.crmmaster.dto.DMSResponseDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.FinanceBookingDetailsDTO;
import com.net.bosch.crmmaster.dto.InStoreDynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.OnlineBookingRequestDTO;
import com.net.bosch.crmmaster.dto.OnlineBookingResponseDTO;
import com.net.bosch.crmmaster.dto.OnlineBookingSearchResponseDTO;
import com.net.bosch.crmmaster.dto.OnlinePaymentDetailsResponseDTO;
import com.net.bosch.crmmaster.dto.OnlinePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.SearchOnlineBookingRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdRequestDTO;
import com.net.bosch.crmmaster.dto.UserBookingFinanceResponseDTO;
import com.net.bosch.crmmaster.dto.UserBookingsGuidResponseDTO;
import com.net.bosch.crmmaster.dto.UserBookingsResponseDTO;
import com.net.bosch.crmmaster.payment.collection.OnlineBooking;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentInfo;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.exceptions.InvalidBookingCaseIdException;
import com.net.bosch.utils.ApplicationHelper;
import com.net.bosch.utils.DateHelper;

/**
 * @author pushkarkhosla
 */
@Service
public class OnlineBookingService {

	private static final String TEST = "-TEST";
	private static final String PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_TIMESTAMP = "Processing Started for Syncing Bookings to Firestore for Timestamp {{}} {{}} ";
	private static final String PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_GUID = "Processing Started for Syncing Bookings to Firestore for GUID {{}}";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OnlineBookingRepository onlineBookingRepository;
	@Autowired
	private OnlinePaymentDetailsRepository onlinePaymentDetailsRepository;
	@Autowired
	private RestTemplateService restTemplateService;
	@Autowired
	private DMSDirectPostingService dmsDirectPostingService;
	@Autowired
	private InStoreBookingService inStoreBookingService;

	@Value("${re.azure.color.code.mapping.url}")
	private String azurePathForColorCodeMapping;

	@Autowired
	private FirebaseService firebaseService;

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse saveBikeBookingDetails(OnlineBookingRequestDTO dto) {
		logger.info("In saveBikeBookingDetails() >>>");
		try {
			long startTime = System.currentTimeMillis();

			OnlineBooking bookingResponse = saveUserOnlineBikeBookingDetails(dto);

			logger.info("User Data Saved For Online-Bike-Booking successfully in {{}}ms.",
					System.currentTimeMillis() - startTime);

			OnlinePaymentDetails paymentResponse = saveInitialOnlineBookingPayment(bookingResponse,
					bookingResponse.getDynamicsRequest(), null, null);

			return getSuccessResponse(getOnlineBikeBookingResponse(bookingResponse, paymentResponse, startTime));
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Saving User Online Bike Booking Details. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse updateExcellonMsdResponse(@Valid UpdateExcellonMsdRequestDTO dto) {
		logger.info("In updateExcellonMsdResponse() --");
		try {
			long startTime = System.currentTimeMillis();

			if (StringUtils.equals(dto.getTransactionType(), INSTORE_BOOKINGS)) {
				return inStoreBookingService.updateDMSResponseForInstoreBookings(dto);
			}
			OnlineBooking onlineBooking = checkOnlineBookingOptional(
					onlineBookingRepository.findByBookingCaseIdAndGuid(dto.getBookingCaseId(), dto.getGuid()));

			OnlinePaymentDetails paymentDetails = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findById(onlineBooking.getPaymentObjectId()));

			return updateExcellonMsdResponse(dto, onlineBooking, paymentDetails);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User DMS-Excellon-Response. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @param onlineBooking
	 * @param paymentDetails
	 * @return
	 */
	public REBaseResponse updateExcellonMsdResponse(@Valid UpdateExcellonMsdRequestDTO dto, OnlineBooking onlineBooking,
			OnlinePaymentDetails paymentDetails) {
		logger.info("In updateExcellonMsdResponse() Internal --");
		try {
			long startTime = System.currentTimeMillis();
			if (null == onlineBooking) {
				logger.error("No Bike Booking details found with this Booking Id {{}} & Guid {{}}",
						dto.getBookingCaseId(), dto.getGuid());
				return getErrorResponse(REResponse.INVALID_GUID_OR_BOOKING_CASE_ID);
			}
			if (null == paymentDetails) {
				logger.error("Payment Response is Blank/Null for Booking-Cash-Id {{}} & Guid {{}}",
						dto.getBookingCaseId(), dto.getGuid());
				return getErrorResponse(REResponse.INVALID_GUID_OR_BOOKING_CASE_ID);
			}

			if (!ObjectUtils.isEmpty(dto.getDynamicsResponse())) {
				paymentDetails.setDmsBookingId(dto.getDynamicsResponse().getBookingid());
			}
			if (!ObjectUtils.isEmpty(dto.getExcellonResponse())) {
				paymentDetails.setExcellonResponseKey(dto.getExcellonResponse().getResponseKey());
			}

			List<OnlinePaymentInfo> paymentInfoList = paymentDetails.getPaymentInfo();
			if (CollectionUtils.isEmpty(paymentInfoList)) {
				logger.error("Unable to get Initiated Payment Details.");
				return getErrorResponse(INVALID_GUID_OR_BOOKING_CASE_ID);
			}

			for (int i = 0; i < paymentInfoList.size(); i++) {
				OnlinePaymentInfo paymentInfo = paymentInfoList.get(i);

				if (StringUtils.equals(paymentInfoList.get(i).getPaymentCaseId(), dto.getPaymentCaseId())
						&& dto.getPaymentCaseId().endsWith("-01")) {

					logger.info(
							"Payment-Cash-Id Matched Successfully For First Payment Updating DMS/Excellon Response.");
					String configId;
					onlineBooking.setBookingStatus(dto.getBookingStatus());
					onlineBooking.setDynamicsResponse(dto.getDynamicsResponse());
					onlineBooking.setExcellonResponse(dto.getExcellonResponse());

					paymentInfo.setDynamicsResponse(dto.getDynamicsResponse());
					paymentInfo.setExcellonResponse(dto.getExcellonResponse());
					paymentInfo.setPaymentStatus(dto.getPaymentStatus());
					paymentInfo.setBillDeskTrnsactionId(dto.getBillDeskTransactionId());
					if (isNotEmpty(onlineBooking.getBookingAmt()) && null == paymentInfo.getAmountPaid()) {
						paymentInfo.setAmountPaid(Double.valueOf(onlineBooking.getBookingAmt()));
					}

					String configStatus = CONFIG_STATUS_OPEN;
					if (!ObjectUtils.isEmpty(onlineBooking.getDynamicsRequest())) {
						onlineBooking.getDynamicsRequest().setPaymentId(dto.getBillDeskTransactionId());
						onlineBooking.getDynamicsRequest().setReferencenumber(dto.getPaymentCaseId());

						paymentInfo.getDynamicsRequest().setPaymentId(dto.getBillDeskTransactionId());
						paymentInfo.getDynamicsRequest().setReferencenumber(dto.getPaymentCaseId());
						configId = paymentInfo.getDynamicsRequest().getConfigid();

						if (!ObjectUtils.isEmpty(dto.getDynamicsResponse())) {
							if (isNotEmpty(dto.getDynamicsResponse().getBookingid())) {
								Date dmsPostedDate = new Date();
								onlineBooking.getDynamicsResponse().setPostedTimestamp(dmsPostedDate);
								paymentInfo.getDynamicsResponse().setPostedTimestamp(dmsPostedDate);
							} else {
								String dmsResponseMessage = dto.getDynamicsResponse().getMessage();
								if (isNotEmpty(dmsResponseMessage)
										&& (dmsResponseMessage.contains(DMS_DO_NOT_RETRY_MESSAGE) || dmsResponseMessage
												.toLowerCase().contains(DMS_SUCCESS_MESSAGE.toLowerCase()))) {

									logger.info("Dms Duplicate Error Message {{}} Found so Setting Retry Count to {{}}",
											dto.getDynamicsResponse().getMessage(), RETRY_COUNT);
									paymentInfo.setRetryCount(RETRY_COUNT);
									configStatus = CONFIG_STATUS_BOOKED;
								}
							}
						}
					} else {
						onlineBooking.getExcellonRequest().setPaymentRefNo(dto.getBillDeskTransactionId());
						paymentInfo.getExcellonRequest().setPaymentRefNo(dto.getBillDeskTransactionId());
						configId = paymentInfo.getExcellonRequest().getConfigid();
						if (!ObjectUtils.isEmpty(dto.getExcellonResponse())
								&& dto.getExcellonResponse().isRequestSuccessful()) {
							Date excellonPostedDate = new Date();
							onlineBooking.getExcellonResponse().setPostedTimestamp(excellonPostedDate);
							paymentInfo.getExcellonResponse().setPostedTimestamp(excellonPostedDate);
						}
					}
					if (!ApplicationHelper.isRecordToBeProcessed(paymentInfo)) {
						// saveBookingDetailsInMySqlConfiguratorForAzurePdf(configId);
						updateConfigurationStatusInMongo(configId, CONFIG_STATUS_BOOKED);
					}
					if (!StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), SUCCESSFUL_TRANSACTION)
							|| ApplicationHelper.isRecordToBeProcessed(paymentInfo)) {

						paymentInfo.setRetryCount(
								(paymentInfo.getRetryCount() < RETRY_COUNT) ? (paymentInfo.getRetryCount() + 1)
										: paymentInfo.getRetryCount());

						if (paymentInfo.getRetryCount() == RETRY_COUNT) {

							if ((StringUtils.equalsIgnoreCase(dto.getBillDeskAuthStatus(),
									BILL_DESK_AUTH_STATUS_PENDING)
							/*
							 * || StringUtils.equalsIgnoreCase(dto.getBillDeskAuthStatus(),
							 * BILL_DESK_AUTH_STATUS_NA)
							 */)) {
								logger.info(
										"Retry Count is 5 and Status is {{}} . Setting Status to Pending Resolution",
										dto.getPaymentStatus());
								paymentInfo.setPaymentStatus(PENDING_RESOLUTION_TRANSACTION_STATUS);
							} else {
								updateConfigurationStatusInMongo(configId, configStatus);
							}
						}
					}
					// paymentInfoList.set(i, paymentInfo);
					// onlineBookingRepository.save(onlineBooking);

					/**
					 * Below Condition Will Only used for Cancel Transaction,& Setting The MAX Retry
					 * Count so that it can not Picked By Batch-Job Again & Again.
					 */
					if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), CANCEL_TRANSACTION)) {
						logger.info(
								"Payment Status is cancel For {{}}, Setting retry count to {{}} and unlocking configuration for {{}} ",
								dto.getPaymentCaseId(), RETRY_COUNT, configId);
						paymentInfo.setRetryCount(RETRY_COUNT);
						updateConfigurationStatusInMongo(configId, CONFIG_STATUS_OPEN);
					}

					paymentInfoList.set(i, paymentInfo);
					onlineBookingRepository.save(onlineBooking);
					break;
				}
			}
			paymentDetails.setPaymentInfo(paymentInfoList);
			paymentDetails = onlinePaymentDetailsRepository.save(paymentDetails);

			updateUserBookingsToFireBase(paymentDetails.getPaymentInfo().get(0), dto.getGuid(), dto.getBookingCaseId(),
					null);

			logger.info("User DMS-Excellon-Response Updated successfully in {{}}ms.",
					System.currentTimeMillis() - startTime);

			return getSuccessResponse(REResponse.DMS_EXCELLON_RESPONSE_UPDATED_SUCCESSFULLY);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Updating User DMS-Excellon-Response. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse searchBikeBookingDetails(@Valid SearchOnlineBookingRequestDTO dto) {
		logger.info("In searchBikeBookingDetails() --");
		try {
			List<OnlineBooking> searchResponseList = searchUserBikeBookingDetails(dto.getGuid(),
					dto.getBookingCaseId());
			if (CollectionUtils.isEmpty(searchResponseList)) {
				return getErrorResponse(NO_BOOKING_DETAILS_FOUND);
			}
			return getSuccessResponse(copyBookingDetailsToBookingResponse(searchResponseList));
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Searching User Online Bike Booking Details. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	public REBaseResponse saveOnlinePaymentDetails(@Valid OnlinePaymentRequestDTO dto) {
		logger.info("In saveOnlinePaymentDetails() >>>");
		try {
			long startTime = System.currentTimeMillis();

			OnlinePaymentDetails initiatedPaymentResponse = searchUserPaymentDetails(dto.getGuid(),
					dto.getBookingCaseId());
			if (null == initiatedPaymentResponse) {
				logger.error("No Payment Response Found with given details.");
				return getErrorResponse(INVALID_GUID_OR_BOOKING_CASE_ID);
			}

			List<OnlinePaymentInfo> paymentInfoList = initiatedPaymentResponse.getPaymentInfo();
			if (CollectionUtils.isEmpty(paymentInfoList)) {
				logger.error("Unable to get Initiated Payment Details.");
				return getErrorResponse(INVALID_GUID_OR_BOOKING_CASE_ID);
			}
			logger.info("Previous Initiated Payment Response Found.");
			OnlineBooking onlineBookingObj = null;
			boolean isCancelTransaction = false;
			String configId = StringUtils.EMPTY;

			for (int i = 0; i < paymentInfoList.size(); i++) {
				if (StringUtils.equals(paymentInfoList.get(i).getPaymentCaseId(), dto.getPaymentCaseId())) {

					OnlinePaymentInfo paymentInfo = getOnlinePaymentInfoObject(paymentInfoList.get(i), dto);
					logger.info("Updating Payment Status For Payment Cash Id {{}}", paymentInfo.getPaymentCaseId());

					if (dto.getPaymentCaseId().endsWith("-01")) {
						onlineBookingObj = saveFirstBillDeskPaymentResponseInOnlineBooking(dto);
					}
					if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), CANCEL_TRANSACTION)) {
						logger.info("Payment Status is cancel For {{}}, Setting retry count to {{}}.",
								dto.getPaymentCaseId(), RETRY_COUNT);
						paymentInfo.setRetryCount(RETRY_COUNT);
						isCancelTransaction = true;

						if (!ObjectUtils.isEmpty(paymentInfo.getDynamicsRequest())) {
							paymentInfo.getDynamicsRequest().setPaymentId(dto.getBillDeskTrnsactionId());
							paymentInfo.getDynamicsRequest().setReferencenumber(dto.getPaymentCaseId());
							configId = paymentInfo.getDynamicsRequest().getConfigid();
						} else {
							paymentInfo.getExcellonRequest().setPaymentRefNo(dto.getBillDeskTrnsactionId());
							configId = paymentInfo.getExcellonRequest().getConfigid();
						}
					}
					if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), SUCCESSFUL_TRANSACTION)) {
						logger.info("For Payment Cash Id {{}} Setting Transaction Stage as {{}}",
								dto.getPaymentCaseId(), DMS_PROCESSING_TRANSACTION_STAGE);
						paymentInfo.setTransactionStage(DMS_PROCESSING_TRANSACTION_STAGE);
					}
					paymentInfoList.set(i, paymentInfo);
				}
			}
			initiatedPaymentResponse.setPaymentInfo(paymentInfoList);
			initiatedPaymentResponse = onlinePaymentDetailsRepository.save(initiatedPaymentResponse);

			if (isCancelTransaction) {
				updateConfigurationStatusInMongo(configId, CONFIG_STATUS_OPEN);
				updateFirestoreAfterBookingPayment(onlineBookingObj, dto, dto.getBookingStatus());

				String colorCode = ObjectUtils.isEmpty(onlineBookingObj.getVariantDetails()) ? null
						: onlineBookingObj.getVariantDetails().getColorCode();
				String price = ObjectUtils.isEmpty(onlineBookingObj.getVariantDetails()) ? null
						: onlineBookingObj.getVariantDetails().getPrice();

				/*
				 * restTemplateService.callFirestoreUpdatePaymentStatusApi(dto,
				 * initiatedPaymentResponse.getGuid(), colorCode, price);
				 */

				restTemplateService.callFirestoreUpdatePaymentStatusApi(onlineBookingObj.getGuid(),
						dto.getPaymentCaseId(), dto.getBookingCaseId(), String.valueOf(BookingStatus.CANCELLED),
						dto.getPaymentStatus(), dto.getBillDeskTrnsactionId(), String.valueOf(dto.getAmountPaid()),
						colorCode, price);
			}
			// DMS Direct Posting.
			REBaseResponse response = postSuccessfullBookingToDms(onlineBookingObj, initiatedPaymentResponse, dto,
					configId);

			logger.info("User Online-Payment-Details Updated successfully in {{}}ms. ",
					System.currentTimeMillis() - startTime);

			logger.info("<<< Out saveOnlinePaymentDetails() in {{}}ms. ", System.currentTimeMillis() - startTime);

			return response;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Saving User Online payment Details. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	/**
	 * @return
	 */
//	public REBaseResponse getBookingTransactions(String transactionType) {
//		logger.info("Executing getBookingTransactions for batch Job.");
//		List<OnlineBookingSearchResponseDTO> responseObjList = new ArrayList<>();
//		try {
//			List<OnlinePaymentDetails> onlinePaymentDetails = onlinePaymentDetailsRepository
//					.findByPaymentInfoPaymentTimeStampBeforeAndPaymentInfoAppIdAndPaymentInfoRetryCountIsLessThanOrPaymentInfoPaymentStatusEquals(
//							populateFromTimeInQuery(), "2", RETRY_COUNT, SUCCESSFUL_TRANSACTION);
//			if (CollectionUtils.isEmpty(onlinePaymentDetails)) {
//				logger.error("No Online-Bike-Booking-Transaction Found.");
//				return getErrorResponse(NO_BOOKING_DETAILS_FOUND);
//			}
//			logger.info("Found {{}} bookings details from Online booking Payment details collection.",
//					onlinePaymentDetails.size());
//
//			for (OnlinePaymentDetails paymentDetail : onlinePaymentDetails) {
//
//				List<OnlinePaymentInfo> paymentInfoList = new ArrayList<>();
//				Set<PaymentStage> stage = new HashSet<PaymentStage>();
//				for (OnlinePaymentInfo paymentInfoLoopObject : paymentDetail.getPaymentInfo()) {
//
//					boolean retryCountStatus = paymentInfoLoopObject.getRetryCount() < RETRY_COUNT ? true : false;
//					boolean timecheckstatus = checkBalancePaymentTimeStamp(paymentInfoLoopObject.getPaymentTimeStamp());
//					boolean isRecordProcessstatus = ApplicationHelper.isRecordToBeProcessed(paymentInfoLoopObject);
//					boolean isPaymentSuccessRecord = StringUtils.equals(paymentInfoLoopObject.getPaymentStatus(),
//							SUCCESSFUL_TRANSACTION);
//
//					/*
//					 * logger.
//					 * info("For Payment-Case-Id {{}} ,Time Status {{}}, Record Proccessed Status {{}}, Retry Count {{}}, Is Success Record {{}}"
//					 * , paymentInfoLoopObject.getPaymentCaseId(), timecheckstatus,
//					 * isRecordProcessstatus, retryCountStatus, isPaymentSuccessRecord);
//					 */
//
//					if (retryCountStatus && (timecheckstatus || isPaymentSuccessRecord) && isRecordProcessstatus) {
//						stage.add(paymentInfoLoopObject.getPaymentStage());
//						paymentInfoList.add(paymentInfoLoopObject);
//					}
//				}
//				if (CollectionUtils.isEmpty(paymentInfoList)) {
//					continue;
//				}
//				paymentDetail.setPaymentInfo(paymentInfoList);
//				OnlineBookingSearchResponseDTO obj = new OnlineBookingSearchResponseDTO();
//				if (stage.contains(PaymentStage.INITIAL_PAYMENT)) {
//					OnlineBooking resultObject = checkOnlineBookingOptional(onlineBookingRepository
//							.findByBookingCaseIdAndGuid(paymentDetail.getBookingCaseId(), paymentDetail.getGuid()));
//					if (null != resultObject) {
//						BeanUtils.copyProperties(resultObject, obj);
//					} else {
//						logger.error("No Booking Details Found in Parent Table for Booking-Cash-Id {{}} & Guid {{}}",
//								paymentDetail.getBookingCaseId(), paymentDetail.getGuid());
//					}
//				}
//				OnlinePaymentDetailsResponseDTO paymentDetails = new OnlinePaymentDetailsResponseDTO();
//				paymentDetails.setGuid(paymentDetail.getGuid());
//				paymentDetails.setPaymentInfo(paymentDetail.getPaymentInfo());
//				paymentDetails.setDealerSource(paymentDetail.getDealerSource());
//				paymentDetails.setDmsBookingId(paymentDetail.getDmsBookingId());
//				paymentDetails.setExcellonBookingId(paymentDetail.getExcellonBookingId());
//				paymentDetails.setExcellonResponseKey(paymentDetail.getExcellonResponseKey());
//				paymentDetails.setBookingCaseId(paymentDetail.getBookingCaseId());
//				obj.setPaymentDetails(paymentDetails);
//				responseObjList.add(obj);
//			}
//			logger.info("Found {{}} Bookings for Processing.", responseObjList.size());
//			return getSuccessResponse(responseObjList);
//		} catch (Exception e) {
//			logger.error(
//					"Exception Occured While Getting Online-Bike-Booking-Transaction. Exception Message {{}},Exception Details {{}}",
//					e.getMessage(), e);
//			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
//		}
//	}

	public REBaseResponse getBookingTransactions(String transactionType) {
		logger.info("Executing getBookingTransactions for batch Job.");
		try {
			List<OnlinePaymentDetails> onlinePaymentDetails = null;
			switch (transactionType) {
			case INSTORE_BOOKINGS:
				onlinePaymentDetails = onlinePaymentDetailsRepository
						.findByPaymentInfoAppIdAndPaymentInfoRetryCountIsLessThanAndPaymentInfoTransactionStageEquals(
								INSTORE_APP_ID, RETRY_COUNT, TransactionType.INSTORE_DMS_FAILED.getValue());
				break;
			case MIY_BOOKINGS:
				List<String> appIdsList = new ArrayList<>();
				appIdsList.add(MIY_WEB_APP_ID);
				appIdsList.add(MIY_REAPP_APP_ID);
				onlinePaymentDetails = onlinePaymentDetailsRepository
						.findByPaymentInfoAppIdInAndPaymentInfoPaymentTimeStampBeforeAndPaymentInfoRetryCountIsLessThanOrPaymentInfoPaymentStatusEquals(
								appIdsList, populateFromTimeInQuery(), RETRY_COUNT, SUCCESSFUL_TRANSACTION);
				break;
			default:
				return getErrorResponse(INVALID_TRANSACTION_TYPE);
			}
			if (CollectionUtils.isEmpty(onlinePaymentDetails)) {
				logger.error("No Online-Bike-Booking-Transaction Found in Online booking Payment details collection.");
				return getErrorResponse(NO_BOOKING_DETAILS_FOUND);
			}
			logger.info("Found {{}} bookings details from Online booking Payment details collection.",
					onlinePaymentDetails.size());
			List<OnlineBookingSearchResponseDTO> responseObjList = getBookingsForBatchJobProcessing(
					onlinePaymentDetails, transactionType);
			return getSuccessResponse(responseObjList);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Getting Online-Bike-Booking-Transaction. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

	private List<OnlineBookingSearchResponseDTO> getBookingsForBatchJobProcessing(
			List<OnlinePaymentDetails> onlinePaymentDetails, String transactionType) throws ParseException {
		List<OnlineBookingSearchResponseDTO> responseObjList = new ArrayList<>();

		for (OnlinePaymentDetails paymentDetail : onlinePaymentDetails) {
			List<OnlinePaymentInfo> paymentInfoList = new ArrayList<>();
			Set<PaymentStage> stage = new HashSet<>();
			for (OnlinePaymentInfo paymentInfoLoopObject : paymentDetail.getPaymentInfo()) {

				boolean retryCountStatus = paymentInfoLoopObject.getRetryCount() < RETRY_COUNT;
				boolean timecheckstatus = checkBalancePaymentTimeStamp(paymentInfoLoopObject.getPaymentTimeStamp());
				boolean isPaymentSuccessRecord = StringUtils.equals(paymentInfoLoopObject.getPaymentStatus(),
						SUCCESSFUL_TRANSACTION);
				boolean isValidAppId = false;
				boolean isRecordProcessstatus = false;
				boolean isTransactionStageValid = true;
				switch (transactionType) {

				case INSTORE_BOOKINGS:
					isValidAppId = StringUtils.equals(INSTORE_APP_ID, paymentInfoLoopObject.getAppId());
					isTransactionStageValid = StringUtils.equals(paymentInfoLoopObject.getTransactionStage(),
							TransactionType.INSTORE_DMS_FAILED.getValue());
					isRecordProcessstatus = ApplicationHelper.isInStoreRecordToBeProcessed(paymentInfoLoopObject);
					break;
				case MIY_BOOKINGS:
					isValidAppId = StringUtils.equals(MIY_WEB_APP_ID, paymentInfoLoopObject.getAppId())
							|| StringUtils.equals(MIY_REAPP_APP_ID, paymentInfoLoopObject.getAppId());

					// Now For App-id 2 For direct DMS Posting we put Transaction Stage as
					// (PROCESSING & DIRECT_POSTED) If it is empty then only this will pick by Batch
					// Job.
					isTransactionStageValid = isEmpty(paymentInfoLoopObject.getTransactionStage());
					isRecordProcessstatus = ApplicationHelper.isRecordToBeProcessed(paymentInfoLoopObject);
					break;
				default:
					break;
				}
				if (isValidAppId && isTransactionStageValid && retryCountStatus
						&& (timecheckstatus || isPaymentSuccessRecord) && isRecordProcessstatus) {
					stage.add(paymentInfoLoopObject.getPaymentStage());
					paymentInfoList.add(paymentInfoLoopObject);
				}
			}
			if (CollectionUtils.isEmpty(paymentInfoList)) {
				continue;
			}
			paymentDetail.setPaymentInfo(paymentInfoList);
			OnlineBookingSearchResponseDTO obj = new OnlineBookingSearchResponseDTO();
			if (stage.contains(PaymentStage.INITIAL_PAYMENT)) {
				OnlineBooking resultObject = checkOnlineBookingOptional(
						onlineBookingRepository.findByBookingCaseId(paymentDetail.getBookingCaseId()));
				if (null != resultObject) {
					BeanUtils.copyProperties(resultObject, obj);
				} else {
					logger.error("No Booking Details Found in Parent Table for Booking-Cash-Id {{}} ",
							paymentDetail.getBookingCaseId());
				}
			}
			OnlinePaymentDetailsResponseDTO paymentDetails = new OnlinePaymentDetailsResponseDTO();
			paymentDetails.setGuid(paymentDetail.getGuid());
			paymentDetails.setPaymentInfo(paymentDetail.getPaymentInfo());
			paymentDetails.setDealerSource(paymentDetail.getDealerSource());
			paymentDetails.setDmsBookingId(paymentDetail.getDmsBookingId());
			paymentDetails.setExcellonBookingId(paymentDetail.getExcellonBookingId());
			paymentDetails.setExcellonResponseKey(paymentDetail.getExcellonResponseKey());
			paymentDetails.setBookingCaseId(paymentDetail.getBookingCaseId());
			obj.setPaymentDetails(paymentDetails);
			responseObjList.add(obj);
		}
		
		logger.info("Found {{}} Bookings for Processing.", responseObjList.size());
		return responseObjList;
	}

	private boolean checkBalancePaymentTimeStamp(Date date) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date currentTime = sdf.parse(sdf.format(new Date()));
		Date recordCreatedTime = sdf.parse(sdf.format(date));

		int diffmin = (int) ((currentTime.getTime() - recordCreatedTime.getTime()) / (60 * 1000));

		/**
		 * logger.info("Current Time {{}} ,DB Time {{}} ,Diff Minutes {{}}",
		 * sdf.format(new Date()), sdf.format(date), diffmin);
		 */
		return (diffmin > 30);
	}

	public OnlineBooking saveUserOnlineBikeBookingDetails(OnlineBookingRequestDTO dto) {
		logger.info("Copying all DTO param to Entity Params for saving.");

		OnlineBooking entity = new OnlineBooking();
		BeanUtils.copyProperties(dto, entity);
		entity.setBookingStatus(BookingStatus.INITIATED);
		entity.setBookingCaseId(generateBookingId());

		return onlineBookingRepository.save(entity);
	}

	/**
	 * @param response
	 * @return
	 */
	public OnlinePaymentDetails saveInitialOnlineBookingPayment(OnlineBooking response,
			DynamicsBookingPaymentRequestDTO dynamicsRequest,
			InStoreDynamicsBookingPaymentRequestDTO inStoreDynamicsRequest, TransactionType inStoreTrnxType) {
		long startTime = System.currentTimeMillis();
		logger.info("In saveInitialOnlineBookingPayment() >>>");

		OnlinePaymentDetails entity = new OnlinePaymentDetails();
		List<OnlinePaymentInfo> paymentInfoList = new ArrayList<>();

		entity.setBookingCaseId(response.getBookingCaseId());
		entity.setGuid(response.getGuid());
		entity.setDealerSource(response.getDealerObj().getDealersource());
		OnlinePaymentInfo paymentInfo = new OnlinePaymentInfo();
		paymentInfo.setPaymentCaseId(ApplicationHelper.generatePaymentCashId(response.getBookingCaseId()));
		paymentInfo.setDynamicsRequest(dynamicsRequest);
		paymentInfo.setInStoreDynamicsRequest(inStoreDynamicsRequest);
		paymentInfo.setExcellonRequest(response.getExcellonRequest());
		paymentInfo.setPaymentStatus(INITIATED_PAYMENT_STATUS);

		if (null != inStoreDynamicsRequest) {
			paymentInfo.setPaymentStatus(SUCCESSFUL_TRANSACTION);
			paymentInfo.setAmountPaid(Double.valueOf(response.getBookingAmt()));
			paymentInfo.setTransactionStage(inStoreTrnxType.getValue());
		}
		paymentInfo.setPaymentStage(PaymentStage.INITIAL_PAYMENT);
		paymentInfo.setPaymentTimeStamp(new Date());
		paymentInfo.setAppId(response.getAppId());
		paymentInfoList.add(paymentInfo);
		entity.setPaymentInfo(paymentInfoList);

		OnlinePaymentDetails paymentResponse = onlinePaymentDetailsRepository.save(entity);

		response.setPaymentObjectId(paymentResponse.getId());
		onlineBookingRepository.save(response);

		logger.info("<<< Out saveInitialOnlineBookingPayment() In {{}}ms.", System.currentTimeMillis() - startTime);
		return paymentResponse;
	}

	/**
	 * @param entity
	 * @return
	 */
	private OnlineBookingResponseDTO getOnlineBikeBookingResponse(OnlineBooking entity,
			OnlinePaymentDetails paymentResponse, long startTime) {

		OnlineBookingResponseDTO response = new OnlineBookingResponseDTO();
		BeanUtils.copyProperties(entity, response);
		response.setPaymentCaseId(paymentResponse.getPaymentInfo().get(0).getPaymentCaseId());
		response.setPaymentStatus(paymentResponse.getPaymentInfo().get(0).getPaymentStatus());

		logger.info("<<< Out saveBikeBookingDetails() In {{}}ms.", System.currentTimeMillis() - startTime);
		return response;
	}

	/**
	 * @param guid
	 * @param bookingId
	 * @return
	 */
	private List<OnlineBooking> searchUserBikeBookingDetails(String guid, String bookingId) {
		guid = trimToNull(guid);
		bookingId = trimToNull(bookingId);
		List<OnlineBooking> outputList = new ArrayList<>();

		if (isNotEmpty(guid) && isNotEmpty(bookingId)) {
			logger.info("Found Guid {{}} & Booking Id {{}} both. So searching With both Parameters.", guid, bookingId);

			OnlineBooking res = checkOnlineBookingOptional(
					onlineBookingRepository.findByBookingCaseIdAndGuid(bookingId, guid));
			if (null != res) {
				outputList.add(res);
			}
			return outputList;
		}
		if (isNotEmpty(guid)) {
			logger.info("Found Guid {{}}. So searching With Guid Parameter.", guid);

			return onlineBookingRepository.findByGuid(guid);
		}
		if (isNotEmpty(bookingId)) {
			logger.info("Found Booking Case id {{}}. So searching With Booking Case id Parameter.", bookingId);

			OnlineBooking res = checkOnlineBookingOptional(onlineBookingRepository.findByBookingCaseId(bookingId));
			if (null != res) {
				outputList.add(res);
			}
			return outputList;
		}
		return Collections.emptyList();
	}

	/**
	 * @param guid
	 * @param bookingId
	 * @return
	 */
	private OnlinePaymentDetails searchUserPaymentDetails(String guid, String bookingId) {
		guid = trimToNull(guid);
		bookingId = trimToNull(bookingId);

		if (isNotEmpty(guid) && isNotEmpty(bookingId)) {
			logger.info("Found Guid {{}} & Booking Id {{}} both. So searching With both Parameters.", guid, bookingId);

			return checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseIdAndGuid(bookingId, guid));
		}
		return null;
	}

	/**
	 * @param searchResponse
	 * @return
	 */
	private List<OnlineBookingSearchResponseDTO> copyBookingDetailsToBookingResponse(
			List<OnlineBooking> searchResponse) {
		long startTime = System.currentTimeMillis();

		logger.info("User Total Online-Bike-Booking Details Found is {{}}.", searchResponse.size());
		List<OnlineBookingSearchResponseDTO> responseObjList = new ArrayList<>();

		searchResponse.forEach(bean -> {
			OnlinePaymentDetails paymentResponse = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseId(bean.getBookingCaseId()));
			if (null == paymentResponse) {
				logger.error("Invalid Payment Booking Case Id Found {{}}", bean.getBookingCaseId());
				OnlineBookingSearchResponseDTO responseObj = new OnlineBookingSearchResponseDTO();
				BeanUtils.copyProperties(bean, responseObj);
				responseObjList.add(responseObj);
			} else {
				OnlineBookingSearchResponseDTO responseObj = new OnlineBookingSearchResponseDTO();
				BeanUtils.copyProperties(bean, responseObj);
				OnlinePaymentDetailsResponseDTO paymentDetails = new OnlinePaymentDetailsResponseDTO();
				paymentDetails.setBookingCaseId(paymentResponse.getBookingCaseId());
				paymentDetails.setGuid(paymentResponse.getGuid());
				paymentDetails.setDealerSource(paymentResponse.getDealerSource());
				paymentDetails.setDmsBookingId(paymentResponse.getDmsBookingId());
				paymentDetails.setExcellonBookingId(paymentResponse.getExcellonBookingId());
				paymentDetails.setExcellonResponseKey(paymentResponse.getExcellonResponseKey());
				paymentDetails.setPaymentInfo(paymentResponse.getPaymentInfo());
				responseObj.setPaymentDetails(paymentDetails);
				responseObjList.add(responseObj);
			}
		});
		logger.info("Returning Response For Search User Online-Bike-Booking Details in {{}}ms.",
				System.currentTimeMillis() - startTime);
		return responseObjList;
	}

	/**
	 * @param bookingCashId
	 * @param guid
	 * @param dto
	 * @throws Exception
	 */
	private OnlineBooking saveFirstBillDeskPaymentResponseInOnlineBooking(OnlinePaymentRequestDTO dto) {

		logger.info("Updating User Bill-Desk-First-Payment Response for Mobile no {{}}, Booking Id {{}}, Guid {{}}",
				dto.getLoggedInUserMobileNo(), dto.getBookingCaseId(), dto.getGuid());

		OnlineBooking onlineBookingObj = checkOnlineBookingOptional(
				onlineBookingRepository.findByBookingCaseIdAndGuid(dto.getBookingCaseId(), dto.getGuid()));

		if (null == onlineBookingObj) {
			logger.error("Invalid Booking-Cash-Id {{}} or Guid {{}}", dto.getBookingCaseId(), dto.getGuid());
			throw new InvalidBookingCaseIdException();
		}
		onlineBookingObj.setPaymentRawRespObj(dto.getPaymentRawResponse());
		onlineBookingObj.setBookingStatus(dto.getBookingStatus());

		if (StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), CANCEL_TRANSACTION)) {
			logger.info("For {{}} Updating DMS/Excellon Parent Object in Online-Booking With Bill-Desk Response.",
					dto.getPaymentStatus());

			if (!ObjectUtils.isEmpty(onlineBookingObj.getDynamicsRequest())) {
				onlineBookingObj.getDynamicsRequest().setPaymentId(dto.getBillDeskTrnsactionId());
				onlineBookingObj.getDynamicsRequest().setReferencenumber(dto.getPaymentCaseId());
			} else {
				onlineBookingObj.getExcellonRequest().setPaymentRefNo(dto.getBillDeskTrnsactionId());
			}
		}
		onlineBookingObj = onlineBookingRepository.save(onlineBookingObj);

		logger.info("Bill-Desk-First-Payment Response Successfully Updated in Online-Booking.");
		return onlineBookingObj;
	}

	/**
	 * @param previousPaymentInfo
	 * @param dto
	 * @return
	 */
	private OnlinePaymentInfo getOnlinePaymentInfoObject(OnlinePaymentInfo previousPaymentInfo,
			OnlinePaymentRequestDTO dto) {
		if (null == previousPaymentInfo) {
			previousPaymentInfo = new OnlinePaymentInfo();
			previousPaymentInfo.setPaymentCaseId(dto.getPaymentCaseId());
			previousPaymentInfo.setPaymentTimeStamp(new Date());
		}
		previousPaymentInfo.setAmountPaid(dto.getAmountPaid());
		previousPaymentInfo.setPaymentStatus(dto.getPaymentStatus());
		previousPaymentInfo.setBillDeskTrnsactionId(dto.getBillDeskTrnsactionId());
		previousPaymentInfo.setPaymentRawRespObj(dto.getPaymentRawResponse());
		return previousPaymentInfo;
	}

	/**
	 * @param updateRecords
	 * @param fromDate
	 * @param toDate
	 * @param guid
	 * @param inputTransactionType
	 * @return
	 */
	public REBaseResponse syncBookingsToFireBase(boolean updateRecords, String fromDate, String toDate, String guid,
			String inputTransactionType) {
		long startTime = System.currentTimeMillis();
		logger.info("In syncBookingsToFireBase() --");
		try {
			List<OnlinePaymentDetails> paymentDetails = getPaymentDetailsForFireBaseSync(fromDate, toDate, guid,
					inputTransactionType);

			if (CollectionUtils.isEmpty(paymentDetails)) {
				return getErrorResponse(NO_RECORDS_FOUND);
			}
			logger.info("Found {{}} total Bookings.", paymentDetails.size());
			List<UserBookingsGuidResponseDTO> userBookingsResultList = putUserBookingsToFireStore(paymentDetails,
					updateRecords, inputTransactionType);

			logger.info("Out syncBookingsToFireBase -- {{}}ms. Returning {{}} records.",
					System.currentTimeMillis() - startTime, userBookingsResultList.size());

			return getSuccessResponse(userBookingsResultList);
		} catch (Exception ex) {
			logger.error(
					"Exception Occured While Fetching User Bookings History. Exception Message {{}},Exception Details {{}}",
					ex.getMessage(), ex);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, ex.getMessage());
		}

	}

	/**
	 *
	 * @param guid
	 * @param guid
	 */
	public List<UserBookingsGuidResponseDTO> putUserBookingsToFireStore(List<OnlinePaymentDetails> paymentDetails,
			boolean firebasePushStatus, String inputTransactionType) {
		long startTime = System.currentTimeMillis();
		logger.info("In putUserBookingsToFireStore --");
		try {
			Map<String, String> colorCodeMapping = fetchColorCodeMapping();
			List<UserBookingsGuidResponseDTO> userBookingsResultList = new ArrayList<>();

			int counter = 1;
			for (OnlinePaymentDetails paymentObject : paymentDetails) {
				if (paymentObject.getBookingCaseId().toUpperCase().contains(TEST)) {
					logger.error("Remove Migration Booking-Cash-Id {{}}", paymentObject.getBookingCaseId());
					continue;
				}
				for (OnlinePaymentInfo paymentInfo : paymentObject.getPaymentInfo()) {

					/***
					 * logger.info("{{}} Processing Started for Guid {{}} & Booking Case Id {{}} &
					 * App Id {{}}", counter, paymentObject.getGuid(),
					 * paymentObject.getBookingCaseId(), paymentInfo.getAppId());
					 */

					if (ObjectUtils.isEmpty(paymentInfo)
							|| paymentInfo.getPaymentCaseId().toUpperCase().contains(TEST)) {
						logger.error(
								"Payment Info List is Blank for Guid {{}} or Migration Case {{}} so not putting in firebase.",
								paymentObject.getGuid(), paymentInfo.getPaymentCaseId());
					} else {
//						if (paymentInfo.getPaymentStage() == PaymentStage.BALANCE_PAYMENT) {
//
//							logger.error("For Guid {{}} Removing Balance Payment From User Bookings {{}}",
//									paymentObject.getGuid(), paymentInfo.getPaymentCaseId());
//						} else {
//							populateResponseObject(paymentInfo, userBookingsResultList, paymentObject.getGuid(),
//									paymentObject.getBookingCaseId(), colorCodeMapping, firebasePushStatus);
//						}
						if (paymentInfo.getPaymentCaseId().endsWith("-01")) {
							populateResponseObject(paymentInfo, userBookingsResultList, paymentObject.getGuid(),
									paymentObject.getBookingCaseId(), colorCodeMapping, firebasePushStatus, null);
						} else {
							logger.error("For Guid {{}} Removing Balance Payment From User Bookings {{}}",
									paymentObject.getGuid(), paymentInfo.getPaymentCaseId());
						}
					}
				}
				counter++;
			}
			logger.info("Found {{}} {{}} Booking Details for Firebase.", userBookingsResultList.size(),
					inputTransactionType);
			if (firebasePushStatus) {
				logger.debug("Firebase Writting Started....");

				for (UserBookingsGuidResponseDTO bean : userBookingsResultList) {
					firebaseService.myBookingToFireStore(bean.getFireBaseObj(), bean.getGuid());
				}
				logger.info("Data Successfully Written to firebase .");
			}
			logger.info("Out putUserBookingsToFireStore finished in -- {{}}ms.",
					System.currentTimeMillis() - startTime);
			return userBookingsResultList;
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Writing User Bookings History in Firebase. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return Collections.emptyList();
		}
	}

	/**
	 * @param paymentInfo
	 * @param userBookingsResultList
	 * @param guid
	 * @param bookingCaseId
	 * @param colorCodeMapping
	 */
	private void populateResponseObject(OnlinePaymentInfo paymentInfo,
			List<UserBookingsGuidResponseDTO> userBookingsResultList, String guid, String bookingCaseId,
			Map<String, String> colorCodeMapping, boolean firebasePushStatus, FinanceBookingDetailsDTO financeDetails) {

		UserBookingsResponseDTO userBookings = new UserBookingsResponseDTO();
		try {
			userBookings.setBillDeskTrnsactionId(paymentInfo.getBillDeskTrnsactionId());
			userBookings.setPaymentCaseId(paymentInfo.getPaymentCaseId());
			userBookings.setPaymentStatus(paymentInfo.getPaymentStatus());
			userBookings.setBookingDate(
					DateHelper.convertDateToString(paymentInfo.getPaymentTimeStamp(), DateHelper.DDMMYYYY_HYPHEN));

			OnlineBooking onlineBookingObj = populateModelCode(bookingCaseId, colorCodeMapping, firebasePushStatus);
			if (null != onlineBookingObj) {
				userBookings.setModelCode(onlineBookingObj.getVariantDetails().getColorCode());
				userBookings.setModelName(onlineBookingObj.getVariantDetails().getColorCodeName());
			}

			if (!ObjectUtils.isEmpty(paymentInfo.getDynamicsRequest())) {
				userBookings.setDealerSource(DMS_DEALER_SOURCE);
				userBookings.setPartsData(getDMSPartsListForFirebase(paymentInfo.getDynamicsRequest()));

				userBookings.setTentativeDeliveryDays(paymentInfo.getDynamicsRequest().getTentativedeliverydays());
				if (null != paymentInfo.getDynamicsResponse()
						&& StringUtils.isNotBlank(paymentInfo.getDynamicsResponse().getBookingid())) {
					userBookings.setBookingId(paymentInfo.getDynamicsResponse().getBookingid());
					userBookings.setBookingPostedDate(DateHelper.convertDateToString(
							paymentInfo.getDynamicsResponse().getPostedTimestamp(), DateHelper.DDMMYYYY_HYPHEN));
				} else {
					userBookings.setBookingId("NA");
				}
			}
			if (!ObjectUtils.isEmpty(paymentInfo.getExcellonRequest())) {
				userBookings.setDealerSource(EXCELLON_DEALER_SOURCE);
				userBookings.setPartsData(
						getExcellonPartsListForFirebase(paymentInfo.getExcellonRequest(), onlineBookingObj));

				if (null != paymentInfo.getExcellonResponse()
						&& StringUtils.isNotBlank(paymentInfo.getExcellonResponse().getResponseKey())) {
					userBookings.setBookingId(paymentInfo.getExcellonResponse().getResponseKey());
					userBookings.setModelCode(paymentInfo.getExcellonRequest().getBookingmodel());
					userBookings.setBookingPostedDate(DateHelper.convertDateToString(
							paymentInfo.getExcellonResponse().getPostedTimestamp(), DateHelper.DDMMYYYY_HYPHEN));
				} else {
					userBookings.setBookingId("NA");
				}
			}
			userBookings = validateAndGetBookingStatusForFirebase(onlineBookingObj, paymentInfo, userBookings);

			if (null != financeDetails && isNotEmpty(financeDetails.getFinancerName())
					&& isNotEmpty(financeDetails.getFinancerStatus())) {
				userBookings.setFinancerDetails(new UserBookingFinanceResponseDTO(financeDetails));
			}
			/***
			 * logger.info("Booking Cash Id {{}} Successfully Added in Result List.",
			 * bookingCaseId);
			 */
		} catch (Exception ex) {
			logger.error(
					"Exception Occured While Setting User Bookings History Details for Guid {{}} PaymentInfo {{}}, Exception Message {{}},Exception Details {{}}",
					guid, paymentInfo, ex.getMessage(), ex);
		} finally {
			userBookingsResultList.add(new UserBookingsGuidResponseDTO(userBookings, guid));
		}
	}

	/**
	 * @param bookingCaseId
	 * @param colorCodeMapping
	 * @return
	 */
	private OnlineBooking populateModelCode(String bookingCaseId, Map<String, String> colorCodeMapping,
			boolean firebasePushStatus) {
		OnlineBooking onlineBookingObj = checkOnlineBookingOptional(
				onlineBookingRepository.findByBookingCaseId(bookingCaseId));

		/**
		 * logger.debug("Verifying Vehicle Model Code & Model Name for Booking-Cash-Id
		 * {{}} in Online Booking Collection.", bookingCaseId);
		 */
		if (null == onlineBookingObj) {
			logger.error("For Booking Case Id {{}} No Details found in OnlineBooking Collection.", bookingCaseId);
			return null;
		}
		if (ObjectUtils.isEmpty(onlineBookingObj.getVariantDetails())
				|| isEmpty(onlineBookingObj.getVariantDetails().getColorCode())) {
			logger.error("For Booking Case Id {{}} No Varient Details/colorCodeName found in OnlineBooking Collection.",
					bookingCaseId);
			return null;
		}
//		if (onlineBookingObj.getVariantDetails().getColorCodeName().contains("-")) {
//
//			/**
//			 * logger.info("Vehicle Model Code & Model Name Found Successfully for
//			 * Booking-Cash-Id {{}}", bookingCaseId);
//			 */
//			return onlineBookingObj;
//		}

		String bikeNameAndColor = colorCodeMapping.get(onlineBookingObj.getVariantDetails().getColorCode());

		if (!MapUtils.isEmpty(colorCodeMapping) && isNotEmpty(bikeNameAndColor)) {

			onlineBookingObj.getVariantDetails().setColorCodeName(bikeNameAndColor);
			if (firebasePushStatus) {
//				if (onlineBookingObj.getVariantDetails().getColorCodeName().contains("-")) {
//					String bikeName = onlineBookingObj.getVariantDetails().getColorCodeName().split("-")[0];
//
//					onlineBookingObj.getVariantDetails()
//							.setColorCodeName(bikeName.trim().concat(" - ").concat(bikeColour));
//				} else {
//					onlineBookingObj.getVariantDetails().setColorCodeName(
//							onlineBookingObj.getVariantDetails().getColorCodeName().concat(" - ").concat(bikeColour));
//				}
				onlineBookingObj = onlineBookingRepository.save(onlineBookingObj);
				logger.info("Vehicle Colour successfully updated in Mongo for Booking-Cash-Id {{}}", bookingCaseId);
			}
//			else {
//				if (onlineBookingObj.getVariantDetails().getColorCodeName().contains("-")) {
//					String bikeName = onlineBookingObj.getVariantDetails().getColorCodeName().split("-")[0];
//
//					onlineBookingObj.getVariantDetails()
//							.setColorCodeName(bikeName.trim().concat(" - ").concat(bikeColour));
//				} else {
//					onlineBookingObj.getVariantDetails().setColorCodeName(
//							onlineBookingObj.getVariantDetails().getColorCodeName().concat(" - ").concat(bikeColour));
//				}
//			}
			/**
			 * logger.info("Vehicle Model Code & Model Name Found Successfully for
			 * Booking-Cash-Id {{}}", bookingCaseId);
			 */
		} else {
			logger.error("Bike Colour Not found from Azure for Vehicle Model {{}}",
					onlineBookingObj.getVariantDetails().getColorCode());
		}
		return onlineBookingObj;
	}

	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> fetchColorCodeMapping() {
		long startTime = System.currentTimeMillis();
		Map<String, String> dataMap = null;
		logger.debug("Getting Vehicle Colour From Azure {{}}.", azurePathForColorCodeMapping);
		try {
			URL jsonUrl = new URL(azurePathForColorCodeMapping);
			dataMap = new ObjectMapper().readValue(jsonUrl, Map.class);

			logger.debug("Returning Colur Data from Azure in {{}}ms.", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("Unable to fetch JSON from Azure from {{}}, Exception Mesage {{}} ",
					azurePathForColorCodeMapping, e.getMessage());
		}
		return dataMap;
	}

	/**
	 * This method Generates Unique Booking ID for for Online-Bike-Booking.
	 *
	 * @return
	 */
	public synchronized String generateBookingId() {

		Long randomUUID = UUID.randomUUID().getMostSignificantBits();
		randomUUID = String.valueOf(randomUUID).startsWith(HYPHEN)
				? Long.valueOf(String.valueOf(randomUUID).replace(HYPHEN, EMPTY))
				: randomUUID;

		return BOOKING_SEQUENCE_PREFIX.concat(String.format(BOOKING_DIGITS_FORMATTER, randomUUID));
	}

	/**
	 * @param configId
	 */
	public void updateConfigurationStatusInMongo(String configId, String configStatus) {
		logger.info(
				"Updating the Configuration status to OPEN as Payment is Failed/Canceled for Config Id {{}} having config status as {{}}",
				configId, configStatus);
		restTemplateService.callConfiguratorUpdateConfigIdApi(configId, configStatus);
	}

	/**
	 * @param onlineBookingObj
	 * @param dto
	 */
	public REBaseResponse postSuccessfullBookingToDms(final OnlineBooking onlineBookingObj,
			final OnlinePaymentDetails paymentDetailsObj, final OnlinePaymentRequestDTO dto, final String configId) {

		if (!StringUtils.equalsIgnoreCase(dto.getPaymentStatus(), SUCCESSFUL_TRANSACTION)) {
			logger.info("Payment Status is {{}} so Updating Only Payment Details.", dto.getPaymentStatus());

			updateUserBookingsToFireBase(paymentDetailsObj.getPaymentInfo().get(0), dto.getGuid(),
					dto.getBookingCaseId(), null);

			return getSuccessResponse(ONLINE_PAYMENT_DETAILS_SAVED_SUCCESSFULLY);
		}
		logger.info("Found Successfull payment so Posting to DMS for Payment Case Id {{}}.", dto.getPaymentCaseId());

		REBaseResponse response = null;
		DMSResponseDTO dmsResponse = null;
		String dealerSource = onlineBookingObj.getDealerObj().getDealersource();

		if (dealerSource.equals(DMS_DEALER_SOURCE)) {
			dmsResponse = dmsDirectPostingService.callDMSPaymentApi(onlineBookingObj, dto);
			response = dmsDirectPostingService.updateDMSResponseInMongo(dmsResponse, onlineBookingObj,
					paymentDetailsObj, dto);
		} else {
			logger.error("Found Unhandled Dealer Source {{}} While Posting Booking to DMS.", dealerSource);
		}
		if (null == response || isEmpty(dmsResponse.getBookingId())) {
			logger.error("DMS Direct Posting Fails with error Details {{}}", dmsResponse.getMessage());
			updateTransactionStage(paymentDetailsObj, dto, null);

			updateFirestoreAfterBookingPayment(onlineBookingObj, dto, BookingStatus.POST_FAIL);

			return getErrorResponse(DMS_POSTING_FAILS, DMS_POSTING_FAILS.getMessage().concat(dmsResponse.getMessage()));
		}
		logger.info("DMS Direct Posted Successfully.,DMS Booking ID {{}}", dmsResponse.getBookingId());
		updateTransactionStage(paymentDetailsObj, dto, DMS_DIRECT_POSTED_TRANSACTION_STAGE);

		updateFirestoreAfterBookingPayment(onlineBookingObj, dto, BookingStatus.POST_SUCCESS);
		return response;
	}

	/**
	 * @param paymentDetailsObj
	 * @param dto
	 * @param transactionStage
	 */
	private void updateTransactionStage(OnlinePaymentDetails paymentDetailsObj, OnlinePaymentRequestDTO dto,
			String transactionStage) {
		logger.info("For Payment Cash Id {{}} Setting transaction stage to {{}}.", dto.getPaymentCaseId(),
				transactionStage);

		List<OnlinePaymentInfo> paymentInfoList = paymentDetailsObj.getPaymentInfo();
		for (int i = 0; i < paymentInfoList.size(); i++) {
			OnlinePaymentInfo bean = paymentInfoList.get(i);
			if (StringUtils.equals(bean.getPaymentCaseId(), dto.getPaymentCaseId())) {
				bean.setTransactionStage(transactionStage);

				paymentInfoList.set(i, bean);
				break;
			}
		}
		paymentDetailsObj.setPaymentInfo(paymentInfoList);
		onlinePaymentDetailsRepository.save(paymentDetailsObj);
		logger.info("Transaction stage {{}} sets successfully for Payment Cash Id {{}}.", transactionStage,
				dto.getPaymentCaseId());
	}

	/**
	 * @param onlineBookingObj
	 * @param dto
	 * @param configId
	 * @param configStatus
	 * @param bookingStatus
	 */
	private void updateFirestoreAfterBookingPayment(final OnlineBooking onlineBookingObj,
			final OnlinePaymentRequestDTO dto, BookingStatus bookingStatus) {

		String colorCode = ObjectUtils.isEmpty(onlineBookingObj.getVariantDetails()) ? null
				: onlineBookingObj.getVariantDetails().getColorCode();
		String price = ObjectUtils.isEmpty(onlineBookingObj.getVariantDetails()) ? null
				: onlineBookingObj.getVariantDetails().getPrice();

		restTemplateService.callFirestoreUpdatePaymentStatusApi(onlineBookingObj.getGuid(), dto.getPaymentCaseId(),
				dto.getBookingCaseId(), String.valueOf(bookingStatus), dto.getPaymentStatus(),
				dto.getBillDeskTrnsactionId(), String.valueOf(dto.getAmountPaid()), colorCode, price);
	}

	/**
	 * @param paymentInfo
	 * @param guid
	 * @param bookingCaseId
	 */
	private void updateUserBookingsToFireBase(OnlinePaymentInfo paymentInfo, String guid, String bookingCaseId,
			FinanceBookingDetailsDTO financeDetails) {

		if (paymentInfo.getPaymentCaseId().toUpperCase().contains(TEST)) {
			logger.error("Payment Cash Id {{}} with Test Can not be processed in Firebase.",
					paymentInfo.getPaymentCaseId());
			return;
		}
		Map<String, String> colorCodeMapping = fetchColorCodeMapping();
		List<UserBookingsGuidResponseDTO> userBookingsResultList = new ArrayList<>();

		populateResponseObject(paymentInfo, userBookingsResultList, guid, bookingCaseId, colorCodeMapping, true,
				financeDetails);

		logger.debug("Pushing Booking Details to Firebase.");

		for (UserBookingsGuidResponseDTO bean : userBookingsResultList) {
			firebaseService.myBookingToFireStore(bean.getFireBaseObj(), bean.getGuid());
		}
		logger.info("Data Successfully Written to firebase .");
	}

	/**
	 * @param fromDate
	 * @param toDate
	 * @param guid
	 * @param inputTransactionType
	 * @return
	 * @throws ParseException
	 */
	private List<OnlinePaymentDetails> getPaymentDetailsForFireBaseSync(String fromDate, String toDate, String guid,
			String inputTransactionType) throws ParseException {

		List<OnlinePaymentDetails> paymentDetails = null;
		List<String> appIdsList = new ArrayList<>();
		Date from = isEmpty(fromDate) ? new Date() : formatStrToDates(fromDate);
		Date to = isEmpty(toDate) ? new Date() : formatStrToDates(toDate);

		switch (inputTransactionType) {
		case "MIY_BOOKINGS":
			appIdsList.add("2");
			appIdsList.add("5");

			if (isNotEmpty(guid)) {
				logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_GUID, guid);

				paymentDetails = onlinePaymentDetailsRepository.findByGuidAndPaymentInfoAppIdIn(guid, appIdsList);
				break;
			}
			logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_TIMESTAMP, fromDate, toDate);
			paymentDetails = onlinePaymentDetailsRepository.findByCreatedOnBetweenAndPaymentInfoAppIdIn(from, to,
					appIdsList);
			break;
		case "INSTORE_BOOKINGS":
			appIdsList.add("6");

			if (isNotEmpty(guid)) {
				logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_GUID, guid);

				paymentDetails = onlinePaymentDetailsRepository.findByGuidAndPaymentInfoAppIdIn(guid, appIdsList);
				break;
			}
			logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_TIMESTAMP, fromDate, toDate);
			paymentDetails = onlinePaymentDetailsRepository.findByCreatedOnBetweenAndPaymentInfoAppIdIn(from, to,
					appIdsList);
			break;
		case "ALL_BOOKINGS":
			if (isNotEmpty(guid)) {
				logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_GUID, guid);

				paymentDetails = onlinePaymentDetailsRepository.findByGuid(guid);
				break;
			}
			logger.info(PROCESSING_STARTED_FOR_SYNCING_BOOKINGS_TO_FIRESTORE_FOR_TIMESTAMP, fromDate, toDate);
			paymentDetails = onlinePaymentDetailsRepository.findByCreatedOnBetween(from, to);
			break;
		default:
			logger.error("Found Invalid Input Transaction Type {{}}.", inputTransactionType);
			break;
		}
		return paymentDetails;
	}

	public REBaseResponse syncFinanceDetailsToFireBase(@Valid FinanceBookingDetailsDTO dto) {
		long startTime = System.currentTimeMillis();
		logger.info(">> In syncFinanceDetailsToFireBase --");
		try {
			OnlinePaymentDetails paymentDetails = checkOnlinePaymentOptional(
					onlinePaymentDetailsRepository.findByBookingCaseId(dto.getBookingCashId()));

			if (null == paymentDetails) {
				return getErrorResponse(REResponse.INVALID_BOOKING_CASE_ID);
			}
			updateUserBookingsToFireBase(paymentDetails.getPaymentInfo().get(0), paymentDetails.getGuid(),
					dto.getBookingCashId(), dto);

			logger.info("<< Out syncFinanceDetailsToFireBase() in {{}}ms.", System.currentTimeMillis() - startTime);
			return getSuccessResponse(REResponse.FINANCE_DETAILS_SUCCESSFULLY_WRITTEN_TO_FIREBASE);
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Syncing Finance Details to Firebase. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return getErrorResponse(GENERIC_OR_UNKNOWN_ERROR, e.getMessage());
		}
	}

}
