package com.net.bosch.crmmaster.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.domain.DealerServiceRedis;

@Repository
public interface DealerServiceRedisRepository extends CrudRepository<DealerServiceRedis, String> {
	
		

}