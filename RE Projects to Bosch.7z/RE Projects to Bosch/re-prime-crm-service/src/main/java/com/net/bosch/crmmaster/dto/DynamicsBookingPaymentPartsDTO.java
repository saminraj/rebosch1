package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pushkarkhosla
 *
 */
public class DynamicsBookingPaymentPartsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4154833197159830145L;

	private String gmapartnumber;
	@JsonProperty(value = "Partdescription")
	private String partdescription;
	@JsonProperty(value = "Qty")
	private String qty;
	private String price;

	public DynamicsBookingPaymentPartsDTO() {

	}

	/**
	 * @param partdescription
	 */
	public DynamicsBookingPaymentPartsDTO(String partdescription) {
		super();
		this.partdescription = partdescription;
	}

	/**
	 * @param bean
	 */
	public DynamicsBookingPaymentPartsDTO(ExcellonMyoAccessoriesDataRequestDTO bean) {
		super();
		this.gmapartnumber = bean.getAccessoriesCode();
		this.partdescription = bean.getAccessoriesName();
		this.qty = String.valueOf(bean.getAccessoriesQty());
		this.price = String.valueOf(bean.getAccessoreisPrice());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DynamicsBookingPaymentPartsDTO [gmapartnumber=").append(gmapartnumber)
				.append(", partdescription=").append(partdescription).append(", qty=").append(qty).append(", price=")
				.append(price).append("]");
		return builder.toString();
	}

	/**
	 * @return the gmapartnumber
	 */
	public String getGmapartnumber() {
		return gmapartnumber;
	}

	/**
	 * @param gmapartnumber the gmapartnumber to set
	 */
	public void setGmapartnumber(String gmapartnumber) {
		this.gmapartnumber = gmapartnumber;
	}

	/**
	 * @return the partdescription
	 */
	public String getPartdescription() {
		return partdescription;
	}

	/**
	 * @param partdescription the partdescription to set
	 */
	public void setPartdescription(String partdescription) {
		this.partdescription = partdescription;
	}

	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}

	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}

}
