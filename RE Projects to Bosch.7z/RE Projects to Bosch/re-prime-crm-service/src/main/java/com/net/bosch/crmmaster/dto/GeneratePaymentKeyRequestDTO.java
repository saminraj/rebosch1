package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class GeneratePaymentKeyRequestDTO {
	
	@NotNull
	@NotBlank
	private String bookingId;
	private String appId;
	
	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}
	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}
	/**
	 * @return the bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}
	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GeneratePaymentKeyRequestDTO [bookingId=");
		builder.append(bookingId);
		builder.append(", appId=");
		builder.append(appId);
		builder.append("]");
		return builder.toString();
	}
}
