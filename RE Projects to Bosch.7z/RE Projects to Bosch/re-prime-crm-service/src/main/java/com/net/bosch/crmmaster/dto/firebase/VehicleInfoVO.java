package com.net.bosch.crmmaster.dto.firebase;

import java.util.ArrayList;
import java.util.List;

public class VehicleInfoVO {

	String activeCustomerName;
	String chaissisNo;
	String dateOfMfg;
	String engineNo;
	String id;
	String purchaseDate;
	String mobileNo;
	String modelCode;
	String modelName;
	String registrationNo;
	String invoiceNo;

	List<ServiceHistoryInfoVO> serviceHistoryInfo = new ArrayList<>();

	public VehicleInfoVO(String activeCustomerName, String purchaseDate,
			String mobileNo, String registrationNo) {

		this.activeCustomerName = activeCustomerName;
		this.purchaseDate = purchaseDate;
		this.mobileNo = mobileNo;
		this.registrationNo = registrationNo;

	}
	
	public void addServiceHistoryInfoVO(
			ServiceHistoryInfoVO serviceHistoryInfoVO) {
		serviceHistoryInfo.add(serviceHistoryInfoVO);
	}

	public String getActiveCustomerName() {
		return activeCustomerName;
	}

	public void setActiveCustomerName(String activeCustomerName) {
		this.activeCustomerName = activeCustomerName;
	}

	public String getChaissisNo() {
		return chaissisNo;
	}

	public void setChaissisNo(String chaissisNo) {
		this.chaissisNo = chaissisNo;
	}

	public String getDateOfMfg() {
		return dateOfMfg;
	}

	public void setDateOfMfg(String dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getModelCode() {
		return modelCode;
	}

	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public List<ServiceHistoryInfoVO> getServiceHistoryInfo() {
		return serviceHistoryInfo;
	}

	public void setServiceHistoryInfo(
			List<ServiceHistoryInfoVO> serviceHistoryInfo) {
		this.serviceHistoryInfo = serviceHistoryInfo;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	

}
