package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pushkarkhosla
 *
 */
public class SearchOnlineBookingRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4886088369384320087L;

	private String appId;

	private String guid;

	@NotNull
	@NotBlank
	private String loggedInUserMobileNo; // Logged In User Mobile Number.

	@NotNull
	@NotBlank
	private String loggedInUserName; // Logged In User F Name.

	@NotNull
	@NotBlank
	@Email
	private String loggedInUserEmail; // Logged In User E-Mail.

	private String bookingCaseId;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SearchOnlineBookingRequestDTO [appId=");
		builder.append(appId);
		builder.append(", guid=");
		builder.append(guid);
		builder.append(", loggedInUserMobileNo=");
		builder.append(loggedInUserMobileNo);
		builder.append(", loggedInUserName=");
		builder.append(loggedInUserName);
		builder.append(", loggedInUserEmail=");
		builder.append(loggedInUserEmail);
		builder.append(", bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the loggedInUserMobileNo
	 */
	public String getLoggedInUserMobileNo() {
		return loggedInUserMobileNo;
	}

	/**
	 * @param loggedInUserMobileNo the loggedInUserMobileNo to set
	 */
	public void setLoggedInUserMobileNo(String loggedInUserMobileNo) {
		this.loggedInUserMobileNo = loggedInUserMobileNo;
	}

	/**
	 * @return the loggedInUserName
	 */
	public String getLoggedInUserName() {
		return loggedInUserName;
	}

	/**
	 * @param loggedInUserName the loggedInUserName to set
	 */
	public void setLoggedInUserName(String loggedInUserName) {
		this.loggedInUserName = loggedInUserName;
	}

	/**
	 * @return the loggedInUserEmail
	 */
	public String getLoggedInUserEmail() {
		return loggedInUserEmail;
	}

	/**
	 * @param loggedInUserEmail the loggedInUserEmail to set
	 */
	public void setLoggedInUserEmail(String loggedInUserEmail) {
		this.loggedInUserEmail = loggedInUserEmail;
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

}
