package com.net.bosch.crmmaster.dto.resultset;

/**
 * @author pushkarkhosla
 *
 */
public class VehicleVinResponseObject {

	private String chassisNo;

	/**
	 * @return the chassisNo
	 */
	public String getChassisNo() {
		return chassisNo;
	}

	/**
	 * @param chassisNo the chassisNo to set
	 */
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

}
