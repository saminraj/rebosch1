package com.net.bosch.dto.base;

import com.net.bosch.domain.DomainObject;

public class ResponseDTO implements DomainObject {

	private static final long serialVersionUID = -5117614688061102216L;

	public ResponseDTO(String result, Integer status) {
		super();
		this.result = result;
		this.status = status;
	}

	public ResponseDTO() {
	}

	private String result = "OK";

	private Integer status = 200;

	public String getResult() {
		return result;
	}

	public Integer getStatus() {
		return status;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
