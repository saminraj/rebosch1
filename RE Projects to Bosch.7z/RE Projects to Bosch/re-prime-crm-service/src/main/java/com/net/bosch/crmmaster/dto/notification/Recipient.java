
package com.net.bosch.crmmaster.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "guid",
    "deviceid",
    "vin",
    "to",
    "email",
    "recipient_type"
})
public class Recipient {

    @JsonProperty("guid")
    private String guid;
    @JsonProperty("deviceid")
    private String deviceid;
    @JsonProperty("vin")
    private String vin;
    @JsonProperty("to")
    private String to;
    @JsonProperty("email")
    private String email;
    @JsonProperty("recipient_type")
    private String recipientType="individual";

    @JsonProperty("guid")
    public String getGuid() {
        return guid;
    }

    @JsonProperty("guid")
    public void setGuid(String guid) {
        this.guid = guid;
    }

    @JsonProperty("deviceid")
    public String getDeviceid() {
        return deviceid;
    }

    @JsonProperty("deviceid")
    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid;
    }

    @JsonProperty("vin")
    public String getVin() {
        return vin;
    }

    @JsonProperty("vin")
    public void setVin(String vin) {
        this.vin = vin;
    }

    @JsonProperty("to")
    public String getTo() {
        return to;
    }

    @JsonProperty("to")
    public void setTo(String to) {
        this.to = to;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("recipient_type")
    public String getRecipientType() {
        return recipientType;
    }

    @JsonProperty("recipient_type")
    public void setRecipientType(String recipientType) {
        this.recipientType = recipientType;
    }

}
