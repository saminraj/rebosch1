
package com.net.bosch.crmmaster.dto.notification;

public class SendNotificationResponse {

	private String result;
	private Integer status;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SendNotificationResponse [result=");
		builder.append(result);
		builder.append(", status=");
		builder.append(status);
		builder.append("]");
		return builder.toString();
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
