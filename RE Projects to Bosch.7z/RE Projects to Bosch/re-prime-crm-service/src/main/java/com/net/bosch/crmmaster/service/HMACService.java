package com.net.bosch.crmmaster.service;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;

/**
 * calculates PaymentKey
 */

@Service
public class HMACService {

	private static String sha256 = "HmacSHA256";

	/**
	 * @param bookingId
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws Exception
	 */
	public String getPaymentKey(final String bookingId) throws NoSuchAlgorithmException, InvalidKeyException {
		Mac sha256HMAC = Mac.getInstance(sha256);
		SecretKeySpec secretKey = new SecretKeySpec(generatePaymentKeySecret().getBytes(), sha256);
		sha256HMAC.init(secretKey);

		byte[] raw = sha256HMAC.doFinal(bookingId.getBytes());

		StringBuilder lsSb = new StringBuilder();
		for (int i = 0; i < raw.length; i++)
			lsSb.append(char2hex(raw[i]));
		return lsSb.toString(); // step 6
	}

	/**
	 * @param x
	 * @return
	 */
	private static String char2hex(final byte x) {
		char[] arr = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

		char[] c = { arr[(x & 0xF0) >> 4], arr[x & 0x0F] };
		return (new String(c));
	}

	/**
	 * @return
	 */
	private synchronized String generatePaymentKeySecret() {
		return RandomStringUtils.random(12, true, true);
	}
}