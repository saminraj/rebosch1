package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum BookingStatus {

	/**
	 * This is Initial Status updated from back-end only.
	 */
	INITIATED("INITIATED"),

	/**
	 * This Status will be updated from React, if the payment status is Pending.
	 */
	PENDING("PENDING"),

	/**
	 * This Status will be updated from React, if the payment status is Cancelled.
	 */
	CANCELLED("CANCELLED"),

	/**
	 * This Status will be updated from React, if the payment status is Failed.
	 */
	FAILED("FAILED"),

	/**
	 * This Status will be updated from React, if the payment status is Success.
	 */
	READY_TO_POST("READY_TO_POST"),

	/**
	 * This Status will be updated from Batch-Service is DMS/Excellon response is
	 * success.
	 */
	POST_SUCCESS("POST_SUCCESS"),

	/**
	 * This Status will be updated from Batch-Service is DMS/Excellon response is
	 * failed.
	 */
	POST_FAIL("POST_FAIL");

	private String value;

	private BookingStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
