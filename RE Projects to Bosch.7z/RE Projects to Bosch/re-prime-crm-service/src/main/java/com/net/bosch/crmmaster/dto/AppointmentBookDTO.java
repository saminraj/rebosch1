package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppointmentBookDTO {

	@JsonProperty("Mobile")
	private String mobile;
	@JsonProperty("AppointmentDate")
	private String appointmentDate;
	@JsonProperty("AttachmentKey")
	private String attachmentKey;
	@JsonProperty("BranchID")
	private String branchID;
	@JsonProperty("CityName")
	private String cityName;
	@JsonProperty("CompanyID")
	private String companyID;
	@JsonProperty("CustomerRemarks")
	private String customerRemarks;
	@JsonProperty("DropAddress")
	private String dropAddress;
	@JsonProperty("HomeAddress")
	private String homeAddress;
	@JsonProperty("Email")
	private String email;
	@JsonProperty("EntityType")
	private String entityType;
	@JsonProperty("FirstName")
	private String firstName;
	@JsonProperty("Engine")
	private String engine;
	@JsonProperty("LastName")
	private String lastName;
	@JsonProperty("IsPickUpDrop")
	private String isPickUpDrop;
	@JsonProperty("RegNo")
	private String regNo;
	@JsonProperty("ServiceType")
	private String serviceType;
	@JsonProperty("Source")
	private String source;
	@JsonProperty("StateName")
	private String stateName;
	@JsonProperty("UserID")
	private String userID;
	@JsonProperty("ChassisNo")
	private String chassisNo;
	@JsonProperty("UserName")
	private String userName;
	// @JsonProperty("Mobile")
	private String services;
	@JsonProperty("PickUpAddress")
	private String pickUpAddress;
	@JsonProperty("OfficeAddress")
	private String officeAddress;
	@JsonProperty("ResourceIdentifier")
	private String resourceIdentifier;
	@JsonProperty("SlotID")
	private String slotID;
	@JsonProperty("Chassis")
	private String chassis;
	@JsonProperty("Gender")
	private String gender;
	@JsonProperty("PickUpTime")
	private String pickUpTime;

	private String bookingStatus;
	/* new json request string */
	@JsonProperty("Schedule")
	private String schedule;
	@JsonProperty("Schedule Resource")
	private String scheduleResource;

	private Boolean isDummySlots;

	@JsonProperty("ServiceBookingType")
	private Integer serviceBookingType = 1;

	@JsonProperty("CaseNo")
	private String caseNo;

	private String appointmentCategory;
	
	@JsonProperty("chassisNoSow")
    private String chassisNoSow;
	
	public String getScheduleResource() {
		return scheduleResource;
	}

	public void setScheduleResource(String scheduleResource) {
		this.scheduleResource = scheduleResource;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getAttachmentKey() {
		return attachmentKey;
	}

	public void setAttachmentKey(String attachmentKey) {
		this.attachmentKey = attachmentKey;
	}

	public String getBranchID() {
		return branchID;
	}

	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCompanyID() {
		return companyID;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public String getCustomerRemarks() {
		return customerRemarks;
	}

	public void setCustomerRemarks(String customerRemarks) {
		this.customerRemarks = customerRemarks;
	}

	public String getDropAddress() {
		return dropAddress;
	}

	public void setDropAddress(String dropAddress) {
		this.dropAddress = dropAddress;
	}

	public String getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIsPickUpDrop() {
		return isPickUpDrop;
	}

	public void setIsPickUpDrop(String isPickUpDrop) {
		this.isPickUpDrop = isPickUpDrop;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public String getPickUpAddress() {
		return pickUpAddress;
	}

	public void setPickUpAddress(String pickUpAddress) {
		this.pickUpAddress = pickUpAddress;
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}

	public String getResourceIdentifier() {
		return resourceIdentifier;
	}

	public void setResourceIdentifier(String resourceIdentifier) {
		this.resourceIdentifier = resourceIdentifier;
	}

	public String getSlotID() {
		return slotID;
	}

	public void setSlotID(String slotID) {
		this.slotID = slotID;
	}

	public String getChassis() {
		return chassis;
	}

	public void setChassis(String chassis) {
		this.chassis = chassis;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPickUpTime() {
		return pickUpTime;
	}

	public void setPickUpTime(String pickUpTime) {
		this.pickUpTime = pickUpTime;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Boolean getIsDummySlots() {
		return isDummySlots;
	}

	public void setIsDummySlots(Boolean isDummySlots) {
		this.isDummySlots = isDummySlots;
	}

	public Integer getServiceBookingType() {
		return serviceBookingType;
	}

	public void setServiceBookingType(Integer serviceBookingType) {
		this.serviceBookingType = serviceBookingType;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getAppointmentCategory() {
		return appointmentCategory;
	}
	public void setAppointmentCategory(String appointmentCategory) {
		this.appointmentCategory = appointmentCategory;
	}

	public String getChassisNoSow() {
		return chassisNoSow;
	}

	public void setChassisNoSow(String chassisNoSow) {
		this.chassisNoSow = chassisNoSow;
	}    
}
