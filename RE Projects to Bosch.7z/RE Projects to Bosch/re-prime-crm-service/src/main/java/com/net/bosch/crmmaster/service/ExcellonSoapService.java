package com.net.bosch.crmmaster.service;

import static com.net.bosch.utils.SoapResponseHelper.convertResponseForExcellonGenratePaymentKey;
import static com.net.bosch.utils.SoapResponseHelper.getErrorResponse;
import static org.apache.commons.lang3.StringUtils.isEmpty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.net.bosch.constants.REResponse;
import com.net.bosch.crmmaster.dto.GeneratePaymentKeyRequestDTO;
import com.net.bosch.dto.base.REBaseResponse;

import https.royalenfield_com.generatepaymentkey.GeneratePaymentKeyRequest;
import https.royalenfield_com.generatepaymentkey.ReBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class ExcellonSoapService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BalancePaymentService balancePaymentService;

	/**
	 * @param payload
	 * @return
	 */
	public ReBaseResponse generatePaymentKey(GeneratePaymentKeyRequest payload) {
		logger.info("In ExcellonSoapService generatePaymentKey()-");
		if (isEmpty(payload.getBookingId())) {
			return getErrorResponse(REResponse.BOOKING_ID_REQUIRED);
		}
		GeneratePaymentKeyRequestDTO dto = new GeneratePaymentKeyRequestDTO();
		dto.setBookingId(payload.getBookingId());

		REBaseResponse response = balancePaymentService.generatePaymentKey(dto);

		logger.info("Returning Response from ExcellonSoapService generatePaymentKey()-");
		return convertResponseForExcellonGenratePaymentKey(response);
	}

}
