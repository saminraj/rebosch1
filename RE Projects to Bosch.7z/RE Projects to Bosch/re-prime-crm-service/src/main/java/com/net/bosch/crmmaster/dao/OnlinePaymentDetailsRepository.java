package com.net.bosch.crmmaster.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;

@Repository
public interface OnlinePaymentDetailsRepository extends MongoRepository<OnlinePaymentDetails, String> {

	Optional<OnlinePaymentDetails> findByBookingCaseIdAndGuid(@Param(value = "bookingCaseId") String bookingCaseId,
			@Param(value = "guid") String guid);

	Optional<OnlinePaymentDetails> findByBookingCaseId(@Param(value = "bookingCaseId") String bookingCaseId);

	List<OnlinePaymentDetails> findByPaymentInfoPaymentTimeStampBeforeAndPaymentInfoRetryCountIsLessThanOrPaymentInfoPaymentStatusEquals(
			Date from, int retryCount, String paymentStatus);

	/**
	 * This JPA-method will fetch data from Mongo-Db based upon DMS-Booking-Id.
	 */
	Optional<OnlinePaymentDetails> findByDmsBookingId(@Param(value = "dmsBookingId") String dmsBookingId);

	/**
	 * This JPA-method will fetch data from Mongo-Db based upon
	 * Excellon-Response-Key.
	 */
	Optional<OnlinePaymentDetails> findByExcellonResponseKey(
			@Param(value = "excellonResponseKey") String excellonResponseKey);

	/**
	 * This JPA-method will fetch data from Mongo-Db based upon Excellon-Booking-Id.
	 */
	Optional<OnlinePaymentDetails> findByExcellonBookingId(
			@Param(value = "excellonBookingId") String excellonBookingId);

	Optional<OnlinePaymentDetails> findByPaymentInfoPaymentCaseId(@Param(value = "paymentCaseId") String paymentCaseId);

	List<OnlinePaymentDetails> findByGuidAndPaymentInfoPaymentStatusAndPaymentInfoPaymentStage(String guid,
			String paymentStatus, String paymentStage);

	List<OnlinePaymentDetails> findByGuid(String guid);

	List<OnlinePaymentDetails> findByCreatedOnBetweenAndPaymentInfoPaymentStatusEqualsAndPaymentInfoPaymentStageEquals(
			@Param(value = "createdOnFrom") Date createdOnFrom, @Param(value = "createdOnTo") Date createdOnTo,
			@Param(value = "paymentStatus") String paymentStatus, @Param(value = "paymentStage") String paymentStage);

	List<OnlinePaymentDetails> findByCreatedOnBetween(@Param(value = "createdOnFrom") Date createdOnFrom,
			@Param(value = "createdOnTo") Date createdOnTo);

	List<OnlinePaymentDetails> findByGuidAndPaymentInfoAppIdIn(String guid, List<String> appIdsList);

	List<OnlinePaymentDetails> findByCreatedOnBetweenAndPaymentInfoAppIdIn(
			@Param(value = "createdOnFrom") Date createdOnFrom, @Param(value = "createdOnTo") Date createdOnTo,
			List<String> appIdsList);

	Optional<OnlinePaymentDetails> findByPaymentInfoBillDeskTrnsactionId(
			@Param(value = "billDeskTrnsactionId") String billDeskTrnsactionId);
	List<OnlinePaymentDetails> findByPaymentInfoAppIdAndPaymentInfoPaymentTimeStampBeforeAndPaymentInfoRetryCountIsLessThanAndPaymentInfoTransactionStageEquals(
			String appId, Date from, int retryCount, String transactionStage);

	List<OnlinePaymentDetails> findByPaymentInfoAppIdAndPaymentInfoRetryCountIsLessThanAndPaymentInfoTransactionStageEquals(
			String appId, int retryCount, String transactionStage);

	List<OnlinePaymentDetails> findByPaymentInfoAppIdInAndPaymentInfoPaymentTimeStampBeforeAndPaymentInfoRetryCountIsLessThanOrPaymentInfoPaymentStatusEquals(
			List<String> appId, Date from, int retryCount, String paymentStatus);

}
