package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class PickupDoorStepSlotDTO{
	
	private Boolean pickupAvailability;
	
	private Boolean doorStepAvailability;	
	
	private String date;

	public Boolean getPickupAvailability() {
		return pickupAvailability;
	}

	public void setPickupAvailability(Boolean pickupAvailability) {
		this.pickupAvailability = pickupAvailability;
	}

	public Boolean getDoorStepAvailability() {
		return doorStepAvailability;
	}

	public void setDoorStepAvailability(Boolean doorStepAvailability) {
		this.doorStepAvailability = doorStepAvailability;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

		
}
