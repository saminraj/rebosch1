
package com.net.bosch.crmmaster.dto.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Params {

    @JsonProperty("chassisNumber")
    private String chassisNumber;

    //    @JsonProperty("JobCardStatus")
//    private String jobCardStatus;
//    @JsonProperty("RegistrationNumber")
//    private String registrationNumber;
//
//    @JsonProperty("JobCardNo")
//    public String getJobCardNo() {
//        return jobCardNo;
//    }
//
//    @JsonProperty("JobCardNo")
//    public void setJobCardNo(String jobCardNo) {
//        this.jobCardNo = jobCardNo;
//    }
//
//    @JsonProperty("JobCardStatus")
//    public String getJobCardStatus() {
//        return jobCardStatus;
//    }
//
//    @JsonProperty("JobCardStatus")
//    public void setJobCardStatus(String jobCardStatus) {
//        this.jobCardStatus = jobCardStatus;
//    }
//
//    @JsonProperty("RegistrationNumber")
//    public String getRegistrationNumber() {
//        return registrationNumber;
//    }
//
//    @JsonProperty("RegistrationNumber")
//    public void setRegistrationNumber(String registrationNumber) {
//        this.registrationNumber = registrationNumber;
//    }
    @JsonProperty("chassisNumber")
    public String getChassisNumber() {
        return chassisNumber;
    }

    @JsonProperty("chassisNumber")
    public void setChassisNumber(String chassisNumber) {
        this.chassisNumber = chassisNumber;
    }
}
