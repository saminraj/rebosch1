package com.net.bosch.crmmaster.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.net.bosch.crmmaster.dto.GetVehicleVinRequestDTO;
import com.net.bosch.crmmaster.dto.GetVinJobCardStatusRequestDTO;
import com.net.bosch.crmmaster.dto.ListRegistrationNumberRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateDatesAndServiceHistoryRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateMobileInVehicleRecordsDTO;
import com.net.bosch.crmmaster.dto.UpdateRegisNumberStatusDTO;
import com.net.bosch.crmmaster.dto.UservehicleDetailsRequestDTO;
import com.net.bosch.crmmaster.dto.VehicleVerifyRequestDTO;
import com.net.bosch.crmmaster.service.PurchaseDateService;
import com.net.bosch.crmmaster.service.UserVehicleService;
import com.net.bosch.dto.base.REBaseResponse;
import com.net.bosch.dto.base.RequestDTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@CrossOrigin
@RestController
@RequestMapping("/user/vehicle/")
@ApiModel(description = "All Vehicle Details of the User.", value = "User Vehicle Controller")
public class UserVehicleController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserVehicleService userVehicleService;

	@PostMapping(value = "getDetails")
	@ApiOperation(value = "Find User Vehicle Details By Mobile Number.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse getUserVehicleDetails(
			@RequestBody @ApiParam(value = "Get User Vehicle Details DTO.", required = true) @Valid RequestDTO dto) {

		logger.info("Calling /user/vehicle/getDetails api ,Input Params {{}}", dto);

		return userVehicleService.getUserVehicleDetails(dto);
	}

	@PostMapping(value = "verifyDetails")
	@ApiOperation(value = "Verifying User Vehicle Details By Chassis Number & Registration Number.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse verifyVehicleDetails(@RequestBody @Valid VehicleVerifyRequestDTO dto) {

		logger.info("Calling /user/vehicle/verifyDetails api ,Input Params {{}}", dto);

		return userVehicleService.verifyUserVehicleDetails(dto);
	}

	@PostMapping(value = "add")
	@ApiOperation(value = "Add Vehicle Flow / Upload user docuemnts to Azure", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse addVehicle(@RequestParam String json, @RequestParam(required = false) MultipartFile kycDoc,
			@RequestParam(required = false) MultipartFile ownerDoc, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		logger.info("Calling /user/vehicle/add api ,Input Params {{}} , Kyc Doc {{}} , owner Doc {{}}", json, kycDoc,
				ownerDoc);

		return userVehicleService.addVehicle(json, kycDoc, ownerDoc, request);
	}

	@PostMapping(value = "updateRegisNumber")
	@ApiOperation(value = "Updating User Vehicle Registration Number Or Remove Vehicle.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse updateRegisNumberAndRemoveBike(@RequestBody @Valid ListRegistrationNumberRequestDTO dto) {

		logger.info("Calling /user/vehicle/updateRegisNumber api,Input Params {{}}", dto);

		return userVehicleService.updateRegisNumberAndRemoveBike(dto);
	}

	@PostMapping(value = "updateVehicleStatus")
	@ApiOperation(value = "Updating User Vehicle Status", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse updateVehicleStatus(@RequestBody @Valid UpdateRegisNumberStatusDTO dto) {

		logger.info("Calling /user/vehicle/updateVehicleStatus api,Input Params {{}}", dto);

		return userVehicleService.updateVehicleStatus(dto);
	}

	@PostMapping(value = "updateMobileInVehicleRecords")
	@ApiOperation(value = "Updating Mobile In Vehicle Records", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = REBaseResponse.class)
	public REBaseResponse updateMobileInVehicleRecords(@RequestBody @Valid UpdateMobileInVehicleRecordsDTO dto) {

		logger.info("Calling /user/vehicle/updateMobileInVehicleRecords api,Input Params {{}}", dto);

		return userVehicleService.updateMobileInVehicleRecords(dto);
	}

	@PostMapping(value = "getVin")
	public REBaseResponse getVehicleVin(@RequestBody @Valid GetVehicleVinRequestDTO dto) {

		logger.info("Calling /user/vehicle/getVin api ,Input Params {{}}", dto);

		return userVehicleService.getVehicleVin(dto);
	}

	@Autowired
	private PurchaseDateService purchaseDateService;

	@GetMapping(value = "verifyPurchaseDates")
	public REBaseResponse verifyPurchaseDates(@RequestParam(value = "fromDate") String fromDate,
			@RequestParam(value = "toDate") String toDate) {

		logger.info("Calling /user/vehicle/verifyPurchaseDates api ,Input Params {From: {} ,To: {}}", fromDate, toDate);

		return purchaseDateService.verifyPurchaseDates(fromDate, toDate);
	}

	@GetMapping(value = "updatePurchaseDates")
	public REBaseResponse updatePurchaseDateAndManufacturingDatesWithDates(
			@RequestParam(value = "fromDate") String fromDate, @RequestParam(value = "toDate") String toDate) {

		logger.info("Calling /user/vehicle/updatePurchaseDates api ,Input Params {From: {} ,To: {}}", fromDate, toDate);

		return purchaseDateService.updatePurchaseDateAndManufacturingDatesWithDates(fromDate, toDate);
	}

	@PostMapping(value = "updateDatesAndServiceHistory")
	public REBaseResponse updatePurchaseDateAndManufacturingDatesWithChassisNo(
			@RequestBody @Valid UpdateDatesAndServiceHistoryRequestDTO dto) {

		logger.info("Calling /user/vehicle/updateDatesAndServiceHistory api ,Input Params {{}}", dto);

		return purchaseDateService.updatePurchaseDateAndManufacturingDatesWithChassisNo(dto);
	}

	@GetMapping(value = "isServiceHistoryExistInDms")
	public REBaseResponse isServiceHistoryExistInDms(@RequestParam(value = "chassisNo") String chassisNo) {

		logger.info("Calling /user/vehicle/isServiceHistoryExistInDms api ,Input Params {Chassis No: {}}", chassisNo);

		return purchaseDateService.isServiceHistoryExistInDms(chassisNo);
	}

	@GetMapping(value = "updateServiceHistoryWithDates")
	public REBaseResponse updateServiceHistoryWithDates(@RequestParam(value = "updateRecords") boolean updateRecords,
			@RequestParam(value = "fromDate") String fromDate, @RequestParam(value = "toDate") String toDate) {

		logger.info(
				"Calling /user/vehicle/updateServiceHistoryWithDates api ,Input Params {Update Records :{{}} ,From: {} ,To: {}}",
				updateRecords, fromDate, toDate);

		return purchaseDateService.updateServiceHistoryWithDates(updateRecords, fromDate, toDate);
	}

	@PostMapping(value = "updateServiceHistoryWithChassisNo")
	public REBaseResponse updateServiceHistoryWithChassisNo(
			@RequestBody @Valid UpdateDatesAndServiceHistoryRequestDTO dto) {

		logger.info("Calling /user/vehicle/updateServiceHistoryWithChassisNo api ,Input Params {{}}", dto);

		return purchaseDateService.updateServiceHistoryWithChassisNo(dto);
	}

	@GetMapping(value = "updateExcellonServiceHistoryWithDates")
	public REBaseResponse updateExcellonServiceHistoryWithDates(
			@RequestParam(value = "updateRecords") boolean updateRecords,
			@RequestParam(value = "fromDate") String fromDate, @RequestParam(value = "toDate") String toDate) {

		logger.info(
				"Calling /user/vehicle/updateExcellonServiceHistoryWithDates api ,Input Params {Update Records :{{}} ,From: {} ,To: {}}",
				updateRecords, fromDate, toDate);

		return purchaseDateService.updateExcellonServiceHistoryWithDates(updateRecords, fromDate, toDate);
	}

	@PostMapping(value = "updateExcellonServiceHistoryWithChassisNo")
	public REBaseResponse updateExcellonServiceHistoryWithChassisNo(
			@RequestBody @Valid UpdateDatesAndServiceHistoryRequestDTO dto) {

		logger.info("Calling /user/vehicle/updateExcellonServiceHistoryWithChassisNo api ,Input Params {{}}", dto);

		return purchaseDateService.updateExcellonServiceHistoryWithChassisNo(dto);
	}

	@PostMapping(value = "getVinJobCardStatus")
	public REBaseResponse getVinJobCardStatus(@RequestBody @Valid GetVinJobCardStatusRequestDTO dto) {

		logger.info("Calling /user/vehicle/getVinJobCardStatus api ,Input Params {{}}", dto);

		return userVehicleService.getVinJobCardStatus(dto);
	}

	@PostMapping(value = "getFullDetails")
	public REBaseResponse getFullVehicleDetails(@RequestBody @Valid GetVehicleVinRequestDTO dto) {

		logger.info("Calling /user/vehicle/getFullDetails api ,Input Params {{}}", dto);

		return userVehicleService.getFullVehicleDetails(dto);
	}

	@GetMapping(value = "verifyAndUpdateServiceHistory")
	public REBaseResponse verifyAndUpdateServiceHistory(
			@RequestParam(value = "chassisNo", required = true) String chassisNo,
			@RequestParam(value = "guid") String guid, @RequestParam(value = "updateRecords") boolean updateRecords) {

		logger.info(
				"Calling /user/vehicle/verifyAndUpdateServiceHistory api ,Input Params {Chassis No: {}}, {guid: {}} ,{updateRecords: {}}",
				chassisNo, guid, updateRecords);

		return purchaseDateService.verifyAndUpdateServiceHistory(chassisNo, guid, updateRecords);

	}

	@PostMapping(value = "fetchProfileVehicles")
	public REBaseResponse fetchProfileVehicles(@RequestBody @Valid UservehicleDetailsRequestDTO userDetails) {

		logger.info("Calling /user/vehicle/fetchProfileVehicles api ,dto {}.", userDetails);

		return userVehicleService.fetchMongoVehicleDetails(userDetails);
	}

	@PostMapping(value = "updateConnectedFlag")
	public REBaseResponse updateConnectedFlag(@RequestBody @Valid GetVehicleVinRequestDTO dto) {

		logger.info("Calling /user/vehicle/updateConnectedFlag api,Input Params {{}}", dto);

		return userVehicleService.updateConnectedFlag(dto);
	}
}