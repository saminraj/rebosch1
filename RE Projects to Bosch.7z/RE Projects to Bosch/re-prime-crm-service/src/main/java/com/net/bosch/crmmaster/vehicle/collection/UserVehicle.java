package com.net.bosch.crmmaster.vehicle.collection;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author pushkarkhosla
 *
 */
@Document(collection = "uservehicles")
public class UserVehicle extends BaseCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = -233950968198489380L;

	private String guid;
	private String phoneNo;

	private List<UserVehicleDetails> userVehicles;

	/**
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the userVehicles
	 */
	public List<UserVehicleDetails> getUserVehicles() {
		return userVehicles;
	}

	/**
	 * @param userVehicles the userVehicles to set
	 */
	public void setUserVehicles(List<UserVehicleDetails> userVehicles) {
		this.userVehicles = userVehicles;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserVehicle [guid=");
		builder.append(guid);
		builder.append(", phoneNo=");
		builder.append(phoneNo);
		builder.append(", userVehicles=");
		builder.append(userVehicles);
		builder.append(", getId()=");
		builder.append(getId());
		builder.append(", getCreatedOn()=");
		builder.append(getCreatedOn());
		builder.append(", getLastModified()=");
		builder.append(getLastModified());
		builder.append("]");
		return builder.toString();
	}

}
