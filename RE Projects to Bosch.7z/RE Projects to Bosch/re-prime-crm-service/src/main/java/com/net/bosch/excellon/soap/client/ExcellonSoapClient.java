package com.net.bosch.excellon.soap.client;

import static com.net.bosch.utils.ApplicationHelper.convertObjectToJson;
import static com.net.bosch.utils.ApplicationHelper.validateExcellonBookingDetailsAPIResponse;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.net.bosch.excellon.schemas.PushMYOBookingDetailData;
import com.net.bosch.excellon.schemas.PushMYOBookingDetailDataResponse;
import com.net.bosch.excellon.schemas.REPushMYOBookingDetailRequest;

/**
 * @author pushkarkhosla
 *
 */
public class ExcellonSoapClient extends WebServiceGatewaySupport {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Value("${re.excellon.soap.api.url}")
	private String excellonSoapUrl;

	@Value("${re.excellon.soap.booking.details.callback.url}")
	private String excellonBookingDetailsCallBackUrl;

	@Value("${re.excellon.soap.username}")
	private String excellonUsername;

	@Value("${re.excellon.soap.password}")
	private String excellonPassword;

	/**
	 * @param excellonBookingId
	 * @return
	 */
	public PushMYOBookingDetailDataResponse callExcellonBookingDetailsSoapService(final String excellonBookingId) {
		try {
			long startTime = System.currentTimeMillis();
			PushMYOBookingDetailData payload = getExcellonBookingDetailsAPIPayload(excellonBookingId);

			log.info("Calling Excellon-Soap-Booking-Details API {{}}, API-CallBack-URL {{}}.", excellonSoapUrl,
					excellonBookingDetailsCallBackUrl);
			if (log.isDebugEnabled()) {
				log.debug("Excellon-Soap-Booking-Details API Request Json Payload : {}", convertObjectToJson(payload));
			}
			PushMYOBookingDetailDataResponse response = (PushMYOBookingDetailDataResponse) getWebServiceTemplate()
					.marshalSendAndReceive(excellonSoapUrl, payload,
							new SoapActionCallback(excellonBookingDetailsCallBackUrl));

			log.info("Excellon-Soap-Booking-Details API Called in {{}}ms.", System.currentTimeMillis() - startTime);
			if (log.isDebugEnabled()) {
				log.debug("Excellon-Soap-Booking-Details API Json Response : {}", convertObjectToJson(response));
			}
			return validateExcellonBookingDetailsAPIResponse(response);
		} catch (Exception e) {
			log.error(
					"Exception Occured While Calling Excellon-Soap-Booking-Details API. Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param excellonBookingId
	 * @return
	 */
	private PushMYOBookingDetailData getExcellonBookingDetailsAPIPayload(final String excellonBookingId) {
		PushMYOBookingDetailData payload = new PushMYOBookingDetailData();

		REPushMYOBookingDetailRequest request = new REPushMYOBookingDetailRequest();
		request.setAuthenticationToken(null);
		request.setManagerKey("0");
		request.setRequestKey(null);
		request.setClientType(0);
		request.setUserAgent("0");
		request.setEntityType(0);
		request.setMappingID(1);
		request.setEntityDataXml("0");
		request.setUserName(excellonUsername);
		request.setPassword(excellonPassword);
		request.setFromDate(LocalDate.now().toString());
		request.setToDate(LocalDate.now().toString());
		request.setBookingNo(excellonBookingId);

		payload.setRequest(request);
		return payload;
	}

}
