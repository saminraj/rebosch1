
package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

public class DealerDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6149665221185579062L;

	private String dealersource;
	private String salesCodeToBillDesk;
	private String excellonDealerId;
	private String excellonBranchId;
	private String dealerEmail;
	private String branchCode;
	private String dealerPhoneNo;
	private String address;
	private String dealerName;
	private String dealerId;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DealerDetails [dealersource=");
		builder.append(dealersource);
		builder.append(", salesCodeToBillDesk=");
		builder.append(salesCodeToBillDesk);
		builder.append(", excellonDealerId=");
		builder.append(excellonDealerId);
		builder.append(", excellonBranchId=");
		builder.append(excellonBranchId);
		builder.append(", dealerEmail=");
		builder.append(dealerEmail);
		builder.append(", branchCode=");
		builder.append(branchCode);
		builder.append(", dealerPhoneNo=");
		builder.append(dealerPhoneNo);
		builder.append(", address=");
		builder.append(address);
		builder.append(", dealerName=");
		builder.append(dealerName);
		builder.append(", dealerId=");
		builder.append(dealerId);
		builder.append("]");
		return builder.toString();
	}

	public String getDealersource() {
		return dealersource;
	}

	public void setDealersource(String dealersource) {
		this.dealersource = dealersource;
	}

	public String getSalesCodeToBillDesk() {
		return salesCodeToBillDesk;
	}

	public void setSalesCodeToBillDesk(String salesCodeToBillDesk) {
		this.salesCodeToBillDesk = salesCodeToBillDesk;
	}

	public String getExcellonDealerId() {
		return excellonDealerId;
	}

	public void setExcellonDealerId(String excellonDealerId) {
		this.excellonDealerId = excellonDealerId;
	}

	public String getExcellonBranchId() {
		return excellonBranchId;
	}

	public void setExcellonBranchId(String excellonBranchId) {
		this.excellonBranchId = excellonBranchId;
	}

	public String getDealerEmail() {
		return dealerEmail;
	}

	public void setDealerEmail(String dealerEmail) {
		this.dealerEmail = dealerEmail;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getDealerPhoneNo() {
		return dealerPhoneNo;
	}

	public void setDealerPhoneNo(String dealerPhoneNo) {
		this.dealerPhoneNo = dealerPhoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getDealerId() {
		return dealerId;
	}

	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}

}
