package com.net.bosch.crmmaster.service;

import static com.net.bosch.constants.Constants.ACCESS_TOKEN;
import static com.net.bosch.constants.Constants.AUTHORIZATION;
import static com.net.bosch.constants.Constants.BEARER;
import static com.net.bosch.constants.Constants.CLIENT_ID;
import static com.net.bosch.constants.Constants.CLIENT_SECRET;
import static com.net.bosch.constants.Constants.GRANT_TYPE;
import static com.net.bosch.constants.Constants.RESOURCE;
import static com.net.bosch.utils.ApplicationHelper.convertObjectToJson;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.net.bosch.constants.BookingStatus;
import com.net.bosch.crmmaster.dto.DMSResponseDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingPaymentRequestDTO;
import com.net.bosch.crmmaster.dto.DynamicsBookingResponse;
import com.net.bosch.crmmaster.dto.OnlinePaymentRequestDTO;
import com.net.bosch.crmmaster.dto.UpdateExcellonMsdRequestDTO;
import com.net.bosch.crmmaster.payment.collection.OnlineBooking;
import com.net.bosch.crmmaster.payment.collection.OnlinePaymentDetails;
import com.net.bosch.dto.base.REBaseResponse;

/**
 * @author pushkarkhosla
 *
 */
@Service
public class DMSDirectPostingService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${re.dms.token.url}")
	private String DMS_TOKEN_URL;

	@Value("${re.dms.token.grant_type}")
	private String DMS_GRANT_TYPE;

	@Value("${re.dms.token.client_id}")
	private String DMS_CLIENT_ID;

	@Value("${re.dms.token.client_secret}")
	private String DMS_CLIENT_SECRET;

	@Value("${re.dms.token.resource}")
	private String DMS_RESOURCE;

	@Value("${re.dms.payment.api.url}")
	private String DMS_PAYMENT_URL;

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private OnlineBookingService onlineBookingService;

	/**
	 * @param onlineBookingObj
	 * @param dto
	 * @param paymentDetailsObj
	 * @return
	 */
	// @Retryable(value = { Exception.class }, maxAttempts = 3, backoff =
	// @Backoff(delay = 5000))
	public DMSResponseDTO callDMSPaymentApi(final OnlineBooking onlineBookingObj, final OnlinePaymentRequestDTO dto) {
		long startTime = System.currentTimeMillis();
		try {
			String authToken = trimToNull(generateDMSAuthToken());
			if (isEmpty(authToken)) {
				logger.error("Generated DMS Auth token is Blank/Null.");
				return null;
			}
			DynamicsBookingPaymentRequestDTO payload = onlineBookingObj.getDynamicsRequest();
			payload.setReferencenumber(dto.getPaymentCaseId());
			payload.setPaymentId(dto.getBillDeskTrnsactionId());

			logger.info("Calling DMS-Payment-API {{}}.", DMS_PAYMENT_URL);
			logger.info("DMS-Payment-API Request Json Payload : {}", convertObjectToJson(payload));

			DMSResponseDTO response = restTemplate.postForObject(DMS_PAYMENT_URL, getHttpEntity(authToken, payload),
					DMSResponseDTO.class);

			logger.info("DMS-Payment-API Called in {{}}ms. API Response {{}}", System.currentTimeMillis() - startTime,
					response);
			return response;
		} catch (Exception e) {
			logger.error("Exception Occured While Calling DMS-Payment-API. Exception Message {{}}", e.getMessage());
			return new DMSResponseDTO(null, e.getMessage());
		}
	}

	/**
	 * @param e
	 * @return
	 */
//	@Recover
//	public DMSResponseDTO recover(Exception e) {
//		logger.error("All Retries completed for DMS-Posting, so Fallback method called.");
//
//		return new DMSResponseDTO(null, e.getMessage());
//	}

	/**
	 * @param dmsResponse
	 * @param onlineBookingObj
	 * @param updatePaymentBean
	 * @return
	 */
	public REBaseResponse updateDMSResponseInMongo(final DMSResponseDTO dmsResponse,
			final OnlineBooking onlineBookingObj, final OnlinePaymentDetails paymentDetailsObj,
			final OnlinePaymentRequestDTO updatePaymentBean) {
		long startTime = System.currentTimeMillis();
		logger.info("In updateDMSResponseInMongo() >>>");

		UpdateExcellonMsdRequestDTO dto = new UpdateExcellonMsdRequestDTO();
		dto.setBookingCaseId(updatePaymentBean.getBookingCaseId());
		dto.setPaymentCaseId(updatePaymentBean.getPaymentCaseId());
		dto.setGuid(updatePaymentBean.getGuid());
		dto.setBillDeskTransactionId(updatePaymentBean.getBillDeskTrnsactionId());

		dto.setDynamicsResponse(new DynamicsBookingResponse(dmsResponse.getMessage(), dmsResponse.getBookingId()));
		dto.setPaymentStatus(updatePaymentBean.getPaymentStatus());
		dto.setBookingStatus(
				isEmpty(dmsResponse.getBookingId()) ? BookingStatus.POST_FAIL : BookingStatus.POST_SUCCESS);
		// Bill-Desh Auth Status

		REBaseResponse updateResponse = onlineBookingService.updateExcellonMsdResponse(dto, onlineBookingObj,
				paymentDetailsObj);
		updateResponse.setData(dmsResponse);

		logger.info("<<< Out updateDMSResponseInMongo() In {{}}ms.", System.currentTimeMillis() - startTime);
		return updateResponse;
	}

	/**
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private String generateDMSAuthToken() {
		long startTime = System.currentTimeMillis();
		logger.info("Generating DMS-Auth-Token.");

		ResponseEntity<Map> response = restTemplate.postForEntity(DMS_TOKEN_URL, getHttpEntityForDMSToken(), Map.class);
		Map responseMap = response.getBody();

		logger.info("DMS-Auth-Token Generated in {{}}ms. API Response {{}}", System.currentTimeMillis() - startTime,
				responseMap);

		return (String) responseMap.get(ACCESS_TOKEN);
	}

	/**
	 * @param authToken
	 * @param payload
	 * @return
	 */
	private static HttpEntity<Object> getHttpEntity(final String authToken, final Object payload) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		headers.add(AUTHORIZATION, BEARER.concat(authToken));

		return new HttpEntity<>(payload, headers);
	}

	/**
	 * @return
	 */
	private HttpEntity<MultiValueMap<String, String>> getHttpEntityForDMSToken() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add(GRANT_TYPE, DMS_GRANT_TYPE);
		map.add(CLIENT_ID, DMS_CLIENT_ID);
		map.add(CLIENT_SECRET, DMS_CLIENT_SECRET);
		map.add(RESOURCE, DMS_RESOURCE);
		return new HttpEntity<>(map, headers);
	}
}
