package com.net.bosch.crmmaster.dto;

public class AzureLoggerEmailDataDTO {

	private String receipientEmail;

	private String deliveryStatus;

	private String emailSubject;

	private String sourceData;

	private String templateId;

	private int priority;

	public AzureLoggerEmailDataDTO() {
		super();
	}

	public AzureLoggerEmailDataDTO(String receipientEmail, String deliveryStatus, String emailSubject, String sourceData,
			String templateId) {
		super();
		this.receipientEmail = receipientEmail;
		this.deliveryStatus = deliveryStatus;
		this.emailSubject = emailSubject;
		this.sourceData = sourceData;
		this.templateId = templateId;
		this.priority = 1;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AzureLoggerEmailDataDTO [receipientEmail=");
		builder.append(receipientEmail);
		builder.append(", deliveryStatus=");
		builder.append(deliveryStatus);
		builder.append(", emailSubject=");
		builder.append(emailSubject);
		builder.append(", sourceData=");
		builder.append(sourceData);
		builder.append(", templateId=");
		builder.append(templateId);
		builder.append(", priority=");
		builder.append(priority);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the receipientEmail
	 */
	public String getReceipientEmail() {
		return receipientEmail;
	}

	/**
	 * @param receipientEmail the receipientEmail to set
	 */
	public void setReceipientEmail(String receipientEmail) {
		this.receipientEmail = receipientEmail;
	}

	/**
	 * @return the deliveryStatus
	 */
	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	/**
	 * @param deliveryStatus the deliveryStatus to set
	 */
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	/**
	 * @return the emailSubject
	 */
	public String getEmailSubject() {
		return emailSubject;
	}

	/**
	 * @param emailSubject the emailSubject to set
	 */
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	/**
	 * @return the sourceData
	 */
	public String getSourceData() {
		return sourceData;
	}

	/**
	 * @param sourceData the sourceData to set
	 */
	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}

	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

}
