package com.net.bosch.crmmaster.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.crmmaster.domain.AppointmentSlot;

@Repository
public interface AppointmentSlotRepository extends CrudRepository<AppointmentSlot, String> {
	
		List<AppointmentSlot> findAllByBranchId( String dealercode);
		AppointmentSlot findByBranchId( String dealercode);
		List<AppointmentSlot> findAllByStartTimeSlotGreaterThanAndEndTimeSlotLessThan(Date searchDate1, Date searchDate2);
		List<AppointmentSlot> findAllByStartTimeSlot(Date searchDate);
		List<AppointmentSlot> findByBranchIdStartsWith(String dealercode);
		List<AppointmentSlot> findByDate(String date);
		List<AppointmentSlot> findByBranchIdAndDate(String dealercode, String date);
		List<AppointmentSlot> findAll();

}