package com.net.bosch.crmmaster.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AzureLoggerEmailDTO {

	private String workflowName;

	@JsonProperty("app_id")
	private String appId;

	private AzureLoggerEmailDataDTO data;

	private List<String> attachments;

	private String comments;

	public AzureLoggerEmailDTO() {
		super();
	}

	public AzureLoggerEmailDTO(String workflowName, String appId, AzureLoggerEmailDataDTO data,
			List<String> attachments, String comments) {
		super();
		this.workflowName = workflowName;
		this.appId = appId;
		this.data = data;
		this.attachments = attachments;
		this.comments = comments;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AzureLoggerEmailDTO [workflowName=");
		builder.append(workflowName);
		builder.append(", appId=");
		builder.append(appId);
		builder.append(", data=");
		builder.append(data);
		builder.append(", attachments=");
		builder.append(attachments);
		builder.append(", comments=");
		builder.append(comments);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the workflowName
	 */
	public String getWorkflowName() {
		return workflowName;
	}

	/**
	 * @param workflowName the workflowName to set
	 */
	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the data
	 */
	public AzureLoggerEmailDataDTO getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(AzureLoggerEmailDataDTO data) {
		this.data = data;
	}

	/**
	 * @return the attachments
	 */
	public List<String> getAttachments() {
		return attachments;
	}

	/**
	 * @param attachments the attachments to set
	 */
	public void setAttachments(List<String> attachments) {
		this.attachments = attachments;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

}
