
package com.net.bosch.crmmaster.dto;

import java.io.Serializable;

/**
 * Bill Desk Payment Response class.
 *
 */
public class PaymentRawResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 88284255148180129L;

	private String hidOperation;
	private String hidRequestId;
	private String msg;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PaymentRawResponse [hidOperation=");
		builder.append(hidOperation);
		builder.append(", hidRequestId=");
		builder.append(hidRequestId);
		builder.append(", msg=");
		builder.append(msg);
		builder.append("]");
		return builder.toString();
	}

	public String getHidOperation() {
		return hidOperation;
	}

	public void setHidOperation(String hidOperation) {
		this.hidOperation = hidOperation;
	}

	public String getHidRequestId() {
		return hidRequestId;
	}

	public void setHidRequestId(String hidRequestId) {
		this.hidRequestId = hidRequestId;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
