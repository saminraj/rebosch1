package com.net.bosch.crmmaster.vehicle.collection;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.net.bosch.constants.VehicleStatus;

/**
 * @author pushkarkhosla
 *
 */
public class UserVehicleDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8018171853768215979L;

	private String appId;
	private String userName;
	private String chassisNo;
	private String dateOfMfg;
	private String engineNo;
	private String msdynName; // This is ID column as per SP return.
	private String invoiceNo;
	private String alternateNo;
	private String vehicleModelCode;
	private String vehicleModelName;
	private String purchaseDate;
	private String registrationNo;
	private VehicleStatus vehicleStatus;
	private VehicleStatus vehicleUpdateStatus;
	private boolean connectedMotorcycle;

	private String kycFilePath;
	private String ownershipFilePath;

	@CreatedDate
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date createdOn;

	@LastModifiedDate
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date lastModified;

	/**
	 * @return the vehicleUpdateStatus
	 */
	public VehicleStatus getVehicleUpdateStatus() {
		return vehicleUpdateStatus;
	}

	/**
	 * @param vehicleUpdateStatus the vehicleUpdateStatus to set
	 */
	public void setVehicleUpdateStatus(VehicleStatus vehicleUpdateStatus) {
		this.vehicleUpdateStatus = vehicleUpdateStatus;
	}

	public String getKycFilePath() {
		return kycFilePath;
	}

	public void setKycFilePath(String kycFilePath) {
		this.kycFilePath = kycFilePath;
	}

	public String getOwnershipFilePath() {
		return ownershipFilePath;
	}

	public void setOwnershipFilePath(String ownershipFilePath) {
		this.ownershipFilePath = ownershipFilePath;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getChassisNo() {
		return chassisNo;
	}

	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}

	public String getDateOfMfg() {
		return dateOfMfg;
	}

	public void setDateOfMfg(String dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getMsdynName() {
		return msdynName;
	}

	public void setMsdynName(String msdynName) {
		this.msdynName = msdynName;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getAlternateNo() {
		return alternateNo;
	}

	public void setAlternateNo(String alternateNo) {
		this.alternateNo = alternateNo;
	}

	/**
	 * @return the vehicleModelCode
	 */
	public String getVehicleModelCode() {
		return vehicleModelCode;
	}

	/**
	 * @param vehicleModelCode the vehicleModelCode to set
	 */
	public void setVehicleModelCode(String vehicleModelCode) {
		this.vehicleModelCode = vehicleModelCode;
	}

	/**
	 * @return the vehicleModelName
	 */
	public String getVehicleModelName() {
		return vehicleModelName;
	}

	/**
	 * @param vehicleModelName the vehicleModelName to set
	 */
	public void setVehicleModelName(String vehicleModelName) {
		this.vehicleModelName = vehicleModelName;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public VehicleStatus getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(VehicleStatus vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}

	/**
	 * @return the connectedMotorcycle
	 */
	public boolean isConnectedMotorcycle() {
		return connectedMotorcycle;
	}

	/**
	 * @param connectedMotorcycle the connectedMotorcycle to set
	 */
	public void setConnectedMotorcycle(boolean connectedMotorcycle) {
		this.connectedMotorcycle = connectedMotorcycle;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the lastModified
	 */
	public Date getLastModified() {
		return lastModified;
	}

	/**
	 * @param lastModified the lastModified to set
	 */
	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	@Override
	public int hashCode() {
		return Objects.hash(alternateNo, chassisNo, dateOfMfg, engineNo, invoiceNo, kycFilePath, msdynName,
				ownershipFilePath, purchaseDate, registrationNo, userName, vehicleStatus);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof UserVehicleDetails)) {
			return false;
		}
		UserVehicleDetails other = (UserVehicleDetails) obj;
		return Objects.equals(chassisNo, other.chassisNo) && Objects.equals(dateOfMfg, other.dateOfMfg)
				&& Objects.equals(engineNo, other.engineNo) && Objects.equals(invoiceNo, other.invoiceNo)
				&& Objects.equals(msdynName, other.msdynName) && Objects.equals(purchaseDate, other.purchaseDate)
				&& Objects.equals(userName, other.userName);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserVehicleDetails [appId=");
		builder.append(appId);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", chassisNo=");
		builder.append(chassisNo);
		builder.append(", dateOfMfg=");
		builder.append(dateOfMfg);
		builder.append(", engineNo=");
		builder.append(engineNo);
		builder.append(", msdynName=");
		builder.append(msdynName);
		builder.append(", invoiceNo=");
		builder.append(invoiceNo);
		builder.append(", alternateNo=");
		builder.append(alternateNo);
		builder.append(", vehicleModelCode=");
		builder.append(vehicleModelCode);
		builder.append(", vehicleModelName=");
		builder.append(vehicleModelName);
		builder.append(", purchaseDate=");
		builder.append(purchaseDate);
		builder.append(", registrationNo=");
		builder.append(registrationNo);
		builder.append(", vehicleStatus=");
		builder.append(vehicleStatus);
		builder.append(", vehicleUpdateStatus=");
		builder.append(vehicleUpdateStatus);
		builder.append(", connectedMotorcycle=");
		builder.append(connectedMotorcycle);
		builder.append(", kycFilePath=");
		builder.append(kycFilePath);
		builder.append(", ownershipFilePath=");
		builder.append(ownershipFilePath);
		builder.append(", createdOn=");
		builder.append(createdOn);
		builder.append(", lastModified=");
		builder.append(lastModified);
		builder.append("]");
		return builder.toString();
	}

}
