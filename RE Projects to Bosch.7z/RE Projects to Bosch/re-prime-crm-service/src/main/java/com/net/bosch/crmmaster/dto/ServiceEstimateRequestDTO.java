package com.net.bosch.crmmaster.dto;

import com.net.bosch.dto.base.ResponseDTO;



public class ServiceEstimateRequestDTO extends ResponseDTO{	
	
	

	
}
