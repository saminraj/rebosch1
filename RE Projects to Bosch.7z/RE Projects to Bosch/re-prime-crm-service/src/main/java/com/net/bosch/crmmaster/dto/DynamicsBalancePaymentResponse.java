package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author pushkarkhosla
 *
 */
public class DynamicsBalancePaymentResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 342905890737040261L;

	private String result;
	private String error;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date postedTimestamp;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DynamicsBalancePaymentResponse [result=");
		builder.append(result);
		builder.append(", error=");
		builder.append(error);
		builder.append(", postedTimestamp=");
		builder.append(postedTimestamp);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the postedTimestamp
	 */
	public Date getPostedTimestamp() {
		return postedTimestamp;
	}

	/**
	 * @param postedTimestamp the postedTimestamp to set
	 */
	public void setPostedTimestamp(Date postedTimestamp) {
		this.postedTimestamp = postedTimestamp;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}

}
