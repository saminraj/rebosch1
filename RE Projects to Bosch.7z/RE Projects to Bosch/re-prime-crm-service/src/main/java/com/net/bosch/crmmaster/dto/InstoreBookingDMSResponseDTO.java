
package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pushkarkhosla
 *
 */
public class InstoreBookingDMSResponseDTO {

	@JsonProperty(value = "BookingId")
	private String bookingId;

	@JsonProperty(value = "message")
	private String message;

	public InstoreBookingDMSResponseDTO() {
	}

	/**
	 * @param bookingId
	 * @param message
	 */
	public InstoreBookingDMSResponseDTO(String bookingId, String message) {
		super();
		this.bookingId = bookingId;
		this.message = message;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DMSResponseDTO [message=");
		builder.append(message);
		builder.append(", BookingId=");
		builder.append(bookingId);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
