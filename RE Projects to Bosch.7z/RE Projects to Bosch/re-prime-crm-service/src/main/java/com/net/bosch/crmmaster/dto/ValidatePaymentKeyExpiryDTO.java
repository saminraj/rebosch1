package com.net.bosch.crmmaster.dto;

import static com.net.bosch.constants.Constants.ONLINE_BALANCE_PAYMENT_DATE_PATTERN;
import static com.net.bosch.utils.DateHelper.convertCalenderToStringDate;

import java.util.Calendar;

/**
 * @author pushkarkhosla
 *
 */
public class ValidatePaymentKeyExpiryDTO {

	private String paymentKey;
	private String checkDate;

	public ValidatePaymentKeyExpiryDTO() {
	}

	/**
	 * @param paymentKey
	 */
	public ValidatePaymentKeyExpiryDTO(String paymentKey) {
		super();
		this.paymentKey = paymentKey;
		this.checkDate = convertCalenderToStringDate(Calendar.getInstance(), ONLINE_BALANCE_PAYMENT_DATE_PATTERN);
	}

	/**
	 * @return the paymentKey
	 */
	public String getPaymentKey() {
		return paymentKey;
	}

	/**
	 * @param paymentKey the paymentKey to set
	 */
	public void setPaymentKey(String paymentKey) {
		this.paymentKey = paymentKey;
	}

	/**
	 * @return the checkDate
	 */
	public String getCheckDate() {
		return checkDate;
	}

	/**
	 * @param checkDate the checkDate to set
	 */
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}

}
