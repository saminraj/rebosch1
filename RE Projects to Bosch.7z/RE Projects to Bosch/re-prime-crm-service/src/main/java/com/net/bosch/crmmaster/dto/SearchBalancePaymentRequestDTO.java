package com.net.bosch.crmmaster.dto;

/**
 * @author pushkarkhosla
 *
 */
public class SearchBalancePaymentRequestDTO {

	private String bookingCaseId;

	private String dmsBookingId;
	private String excellonBookingId;
	private String excellonResponseKey;

	private String paymentCaseId;

	private String billDeskTransactionId;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SearchBalancePaymentRequestDTO [bookingCaseId=");
		builder.append(bookingCaseId);
		builder.append(", dmsBookingId=");
		builder.append(dmsBookingId);
		builder.append(", excellonBookingId=");
		builder.append(excellonBookingId);
		builder.append(", excellonResponseKey=");
		builder.append(excellonResponseKey);
		builder.append(", paymentCaseId=");
		builder.append(paymentCaseId);
		builder.append(", billDeskTransactionId=");
		builder.append(billDeskTransactionId);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the bookingCaseId
	 */
	public String getBookingCaseId() {
		return bookingCaseId;
	}

	/**
	 * @param bookingCaseId the bookingCaseId to set
	 */
	public void setBookingCaseId(String bookingCaseId) {
		this.bookingCaseId = bookingCaseId;
	}

	/**
	 * @return the dmsBookingId
	 */
	public String getDmsBookingId() {
		return dmsBookingId;
	}

	/**
	 * @param dmsBookingId the dmsBookingId to set
	 */
	public void setDmsBookingId(String dmsBookingId) {
		this.dmsBookingId = dmsBookingId;
	}

	/**
	 * @return the excellonBookingId
	 */
	public String getExcellonBookingId() {
		return excellonBookingId;
	}

	/**
	 * @param excellonBookingId the excellonBookingId to set
	 */
	public void setExcellonBookingId(String excellonBookingId) {
		this.excellonBookingId = excellonBookingId;
	}

	/**
	 * @return the excellonResponseKey
	 */
	public String getExcellonResponseKey() {
		return excellonResponseKey;
	}

	/**
	 * @param excellonResponseKey the excellonResponseKey to set
	 */
	public void setExcellonResponseKey(String excellonResponseKey) {
		this.excellonResponseKey = excellonResponseKey;
	}

	/**
	 * @return the paymentCaseId
	 */
	public String getPaymentCaseId() {
		return paymentCaseId;
	}

	/**
	 * @param paymentCaseId the paymentCaseId to set
	 */
	public void setPaymentCaseId(String paymentCaseId) {
		this.paymentCaseId = paymentCaseId;
	}

	/**
	 * @return the billDeskTransactionId
	 */
	public String getBillDeskTransactionId() {
		return billDeskTransactionId;
	}

	/**
	 * @param billDeskTransactionId the billDeskTransactionId to set
	 */
	public void setBillDeskTransactionId(String billDeskTransactionId) {
		this.billDeskTransactionId = billDeskTransactionId;
	}

}
