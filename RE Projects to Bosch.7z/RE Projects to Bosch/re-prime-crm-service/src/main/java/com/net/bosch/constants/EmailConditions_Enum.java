package com.net.bosch.constants;

/**
 * @author pushkarkhosla
 *
 */
public enum EmailConditions_Enum {

	/**
	 * 
	 * For : CUSTOMER_REGISTRATION_NUMBER_UPDATE (2 email will be fired one goes to
	 * customer & second goes to customer care on support@royalenfield.com)
	 * 
	 */
	CUSTOMER_REGISTRATION_NUMBER_UPDATE("customerRegis"), CUSTOMER_ADD_VEHICLE("customerAddVehicle");

	private String value;

	private EmailConditions_Enum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
