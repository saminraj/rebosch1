package com.net.bosch.crmmaster.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.crmmaster.dto.AppointmentSlotListDTO;
import com.net.bosch.domain.DomainObject;


@JsonInclude(Include.NON_NULL)
@RedisHash("AppointmentSlots")
public class AppointmentFullSlots implements DomainObject{

	private static final long serialVersionUID = -8179826601292545389L;

	@Id
	public String id;
	
	public AppointmentSlotListDTO slots;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public AppointmentSlotListDTO getSlots() {
		return slots;
	}

	public void setSlots(AppointmentSlotListDTO slots) {
		this.slots = slots;
	}
	
	
}
