package com.net.bosch.crmmaster.dto;


public class AppointmentFeedbackResponseDTO{	
		
    private String surveyInviteLink;
    
    private String status;

	public String getSurveyInviteLink() {
		return surveyInviteLink;
	}

	public void setSurveyInviteLink(String surveyInviteLink) {
		this.surveyInviteLink = surveyInviteLink;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
