package com.net.bosch.dto.base;

import com.net.bosch.domain.DomainObject;

/**
 * @author pushkarkhosla
 *
 */
public class REBaseResponse implements DomainObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3414309655411886020L;

	private boolean error;
	private String code;
	private transient Object data;
	private String errorMessage;

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
