package com.net.bosch.crmmaster.dto;

import java.util.List;

/**
 * @author pushkarkhosla
 *
 */
public class UpdateDatesAndServiceHistoryRequestDTO {

	private boolean updateRecords;
	private List<String> chassisNumbers;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateDatesAndServiceHistoryRequestDTO [updateRecords=");
		builder.append(updateRecords);
		builder.append(", chassisNumbers=");
		builder.append(chassisNumbers);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the updateRecords
	 */
	public boolean isUpdateRecords() {
		return updateRecords;
	}

	/**
	 * @param updateRecords the updateRecords to set
	 */
	public void setUpdateRecords(boolean updateRecords) {
		this.updateRecords = updateRecords;
	}

	/**
	 * @return the chassisNumbers
	 */
	public List<String> getChassisNumbers() {
		return chassisNumbers;
	}

	/**
	 * @param chassisNumbers the chassisNumbers to set
	 */
	public void setChassisNumbers(List<String> chassisNumbers) {
		this.chassisNumbers = chassisNumbers;
	}

}
