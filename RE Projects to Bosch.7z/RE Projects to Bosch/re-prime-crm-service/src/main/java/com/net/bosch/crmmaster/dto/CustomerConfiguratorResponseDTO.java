package com.net.bosch.crmmaster.dto;

public class CustomerConfiguratorResponseDTO extends BaseResponseDTO {

	private CustomerConfiguratorResponse data;

	/**
	 * @return the data
	 */
	public CustomerConfiguratorResponse getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(CustomerConfiguratorResponse data) {
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerConfiguratorResponseDTO [data=");
		builder.append(data);
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}