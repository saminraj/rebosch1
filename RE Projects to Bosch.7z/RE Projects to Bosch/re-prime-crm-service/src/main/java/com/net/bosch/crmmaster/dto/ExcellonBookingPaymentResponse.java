package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class ExcellonBookingPaymentResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1541930932775304427L;

	private boolean isRequestSuccessful;
	private String timeStamp;
	private String lastErrorTitle;
	private String lastErrorMessage;
	private String lastErrorDetails;
	private String errorCode;
	private String errorID;
	private String requestKey;
	private long serverProcessingTicks;
	private String processingServer;
	private String responseKey;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSSZ")
	private Date postedTimestamp;

	/**
	 * @return the postedTimestamp
	 */
	public Date getPostedTimestamp() {
		return postedTimestamp;
	}

	/**
	 * @param postedTimestamp the postedTimestamp to set
	 */
	public void setPostedTimestamp(Date postedTimestamp) {
		this.postedTimestamp = postedTimestamp;
	}

	/**
	 * @return the isRequestSuccessful
	 */
	public boolean isRequestSuccessful() {
		return isRequestSuccessful;
	}

	/**
	 * @param isRequestSuccessful the isRequestSuccessful to set
	 */
	public void setRequestSuccessful(boolean isRequestSuccessful) {
		this.isRequestSuccessful = isRequestSuccessful;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the lastErrorTitle
	 */
	public String getLastErrorTitle() {
		return lastErrorTitle;
	}

	/**
	 * @param lastErrorTitle the lastErrorTitle to set
	 */
	public void setLastErrorTitle(String lastErrorTitle) {
		this.lastErrorTitle = lastErrorTitle;
	}

	/**
	 * @return the lastErrorMessage
	 */
	public String getLastErrorMessage() {
		return lastErrorMessage;
	}

	/**
	 * @param lastErrorMessage the lastErrorMessage to set
	 */
	public void setLastErrorMessage(String lastErrorMessage) {
		this.lastErrorMessage = lastErrorMessage;
	}

	/**
	 * @return the lastErrorDetails
	 */
	public String getLastErrorDetails() {
		return lastErrorDetails;
	}

	/**
	 * @param lastErrorDetails the lastErrorDetails to set
	 */
	public void setLastErrorDetails(String lastErrorDetails) {
		this.lastErrorDetails = lastErrorDetails;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorID
	 */
	public String getErrorID() {
		return errorID;
	}

	/**
	 * @param errorID the errorID to set
	 */
	public void setErrorID(String errorID) {
		this.errorID = errorID;
	}

	/**
	 * @return the requestKey
	 */
	public String getRequestKey() {
		return requestKey;
	}

	/**
	 * @param requestKey the requestKey to set
	 */
	public void setRequestKey(String requestKey) {
		this.requestKey = requestKey;
	}

	/**
	 * @return the serverProcessingTicks
	 */
	public long getServerProcessingTicks() {
		return serverProcessingTicks;
	}

	/**
	 * @param serverProcessingTicks the serverProcessingTicks to set
	 */
	public void setServerProcessingTicks(long serverProcessingTicks) {
		this.serverProcessingTicks = serverProcessingTicks;
	}

	/**
	 * @return the processingServer
	 */
	public String getProcessingServer() {
		return processingServer;
	}

	/**
	 * @param processingServer the processingServer to set
	 */
	public void setProcessingServer(String processingServer) {
		this.processingServer = processingServer;
	}

	/**
	 * @return the responseKey
	 */
	public String getResponseKey() {
		return responseKey;
	}

	/**
	 * @param responseKey the responseKey to set
	 */
	public void setResponseKey(String responseKey) {
		this.responseKey = responseKey;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcellonBookingPaymentResponse [isRequestSuccessful=");
		builder.append(isRequestSuccessful);
		builder.append(", timeStamp=");
		builder.append(timeStamp);
		builder.append(", lastErrorTitle=");
		builder.append(lastErrorTitle);
		builder.append(", lastErrorMessage=");
		builder.append(lastErrorMessage);
		builder.append(", lastErrorDetails=");
		builder.append(lastErrorDetails);
		builder.append(", errorCode=");
		builder.append(errorCode);
		builder.append(", errorID=");
		builder.append(errorID);
		builder.append(", requestKey=");
		builder.append(requestKey);
		builder.append(", serverProcessingTicks=");
		builder.append(serverProcessingTicks);
		builder.append(", processingServer=");
		builder.append(processingServer);
		builder.append(", responseKey=");
		builder.append(responseKey);
		builder.append(", postedTimestamp=");
		builder.append(postedTimestamp);
		builder.append("]");
		return builder.toString();
	}

}
