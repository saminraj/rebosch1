package com.net.bosch.crmmaster.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.net.bosch.dto.base.RequestDTO;

/**
 * @author pushkarkhosla
 *
 */
public class UpdateRegisNumberStatusDTO extends RequestDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3559047002290970619L;

	@NotNull
	@NotBlank
	private String transactionType;
	private String customerName;

	@NotNull
	@NotBlank
	private String chassisNumber;
	private String newMobileNumber;
	private String oldMobileNumber;

	private String newRegistrationNumber;
	private String oldRegistrationNumber;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdateRegisNumberStatusDTO [transactionType=");
		builder.append(transactionType);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", chassisNumber=");
		builder.append(chassisNumber);
		builder.append(", newMobileNumber=");
		builder.append(newMobileNumber);
		builder.append(", oldMobileNumber=");
		builder.append(oldMobileNumber);
		builder.append(", newRegistrationNumber=");
		builder.append(newRegistrationNumber);
		builder.append(", oldRegistrationNumber=");
		builder.append(oldRegistrationNumber);
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the chassisNumber
	 */
	public String getChassisNumber() {
		return chassisNumber;
	}

	/**
	 * @param chassisNumber the chassisNumber to set
	 */
	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	/**
	 * @return the newMobileNumber
	 */
	public String getNewMobileNumber() {
		return newMobileNumber;
	}

	/**
	 * @param newMobileNumber the newMobileNumber to set
	 */
	public void setNewMobileNumber(String newMobileNumber) {
		this.newMobileNumber = newMobileNumber;
	}

	/**
	 * @return the oldMobileNumber
	 */
	public String getOldMobileNumber() {
		return oldMobileNumber;
	}

	/**
	 * @param oldMobileNumber the oldMobileNumber to set
	 */
	public void setOldMobileNumber(String oldMobileNumber) {
		this.oldMobileNumber = oldMobileNumber;
	}

	/**
	 * @return the newRegistrationNumber
	 */
	public String getNewRegistrationNumber() {
		return newRegistrationNumber;
	}

	/**
	 * @param newRegistrationNumber the newRegistrationNumber to set
	 */
	public void setNewRegistrationNumber(String newRegistrationNumber) {
		this.newRegistrationNumber = newRegistrationNumber;
	}

	/**
	 * @return the oldRegistrationNumber
	 */
	public String getOldRegistrationNumber() {
		return oldRegistrationNumber;
	}

	/**
	 * @param oldRegistrationNumber the oldRegistrationNumber to set
	 */
	public void setOldRegistrationNumber(String oldRegistrationNumber) {
		this.oldRegistrationNumber = oldRegistrationNumber;
	}

}
