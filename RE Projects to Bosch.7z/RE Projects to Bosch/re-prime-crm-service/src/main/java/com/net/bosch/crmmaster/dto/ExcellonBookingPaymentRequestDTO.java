package com.net.bosch.crmmaster.dto;

import java.io.Serializable;
import java.util.List;

public class ExcellonBookingPaymentRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3132148025141865244L;

	private int testRideTaken;
	private int testRidedenialReason;
	private int usage;
	private int modeOfRegistration;
	private int tentativedeliverydays;
	private int possiblepersona;
	private int actualpersona;
	private int stageOfLife;
	private String badgeName;
	private int purchasetimeframe;
	private String panNumber;
	private List<ExcellonMyoAccessoriesDataRequestDTO> myoAccessoriesData = null;
	private String configid;
	private String configdescription;
	private String firstName;
	private String lastName;
	private String fatherName;
	private String mobile;
	private String email;
	private String dateOfBirth;
	private String addressLine1;
	private String addressLine2;
	private String zipCode;
	private String storeCode;
	private String dealerCode;
	private String bookingmodel;
	private int typeofInquiry;
	private int secondarySource;
	private int primarySource;
	private int ownershipStatus;
	private int profession;
	private int gender;
	private int purposeOfUse;
	private String alternateMobileNo;
	private String country;
	private String state;
	private String district;
	private String area;
	private String importfileName;
	private String impportedDate;
	private String bookingDate;
	private String creationSource;
	private String transactionID;
	private String city;
	private String salutation;
	private int financeRequired;
	private String preferredFinancier;
	private int interestedInExchange;
	private String haveYouBeenOnAnyRides;
	private String doYouOwnA4Wheeler;
	private int twoWExchangedModel;
	private String websiteBookingDateTime;
	private String paymentRefNo;

	/**
	 * @return the secondarySource
	 */
	public int getSecondarySource() {
		return secondarySource;
	}

	/**
	 * @param secondarySource the secondarySource to set
	 */
	public void setSecondarySource(int secondarySource) {
		this.secondarySource = secondarySource;
	}

	/**
	 * @return the testRideTaken
	 */
	public int getTestRideTaken() {
		return testRideTaken;
	}

	/**
	 * @param testRideTaken the testRideTaken to set
	 */
	public void setTestRideTaken(int testRideTaken) {
		this.testRideTaken = testRideTaken;
	}

	/**
	 * @return the testRidedenialReason
	 */
	public int getTestRidedenialReason() {
		return testRidedenialReason;
	}

	/**
	 * @param testRidedenialReason the testRidedenialReason to set
	 */
	public void setTestRidedenialReason(int testRidedenialReason) {
		this.testRidedenialReason = testRidedenialReason;
	}

	/**
	 * @return the usage
	 */
	public int getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(int usage) {
		this.usage = usage;
	}

	/**
	 * @return the modeOfRegistration
	 */
	public int getModeOfRegistration() {
		return modeOfRegistration;
	}

	/**
	 * @param modeOfRegistration the modeOfRegistration to set
	 */
	public void setModeOfRegistration(int modeOfRegistration) {
		this.modeOfRegistration = modeOfRegistration;
	}

	/**
	 * @return the tentativedeliverydays
	 */
	public int getTentativedeliverydays() {
		return tentativedeliverydays;
	}

	/**
	 * @param tentativedeliverydays the tentativedeliverydays to set
	 */
	public void setTentativedeliverydays(int tentativedeliverydays) {
		this.tentativedeliverydays = tentativedeliverydays;
	}

	/**
	 * @return the possiblepersona
	 */
	public int getPossiblepersona() {
		return possiblepersona;
	}

	/**
	 * @param possiblepersona the possiblepersona to set
	 */
	public void setPossiblepersona(int possiblepersona) {
		this.possiblepersona = possiblepersona;
	}

	/**
	 * @return the actualpersona
	 */
	public int getActualpersona() {
		return actualpersona;
	}

	/**
	 * @param actualpersona the actualpersona to set
	 */
	public void setActualpersona(int actualpersona) {
		this.actualpersona = actualpersona;
	}

	/**
	 * @return the stageOfLife
	 */
	public int getStageOfLife() {
		return stageOfLife;
	}

	/**
	 * @param stageOfLife the stageOfLife to set
	 */
	public void setStageOfLife(int stageOfLife) {
		this.stageOfLife = stageOfLife;
	}

	/**
	 * @return the badgeName
	 */
	public String getBadgeName() {
		return badgeName;
	}

	/**
	 * @param badgeName the badgeName to set
	 */
	public void setBadgeName(String badgeName) {
		this.badgeName = badgeName;
	}

	/**
	 * @return the purchasetimeframe
	 */
	public int getPurchasetimeframe() {
		return purchasetimeframe;
	}

	/**
	 * @param purchasetimeframe the purchasetimeframe to set
	 */
	public void setPurchasetimeframe(int purchasetimeframe) {
		this.purchasetimeframe = purchasetimeframe;
	}

	/**
	 * @return the panNumber
	 */
	public String getPanNumber() {
		return panNumber;
	}

	/**
	 * @param panNumber the panNumber to set
	 */
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	/**
	 * @return the myoAccessoriesData
	 */
	public List<ExcellonMyoAccessoriesDataRequestDTO> getMyoAccessoriesData() {
		return myoAccessoriesData;
	}

	/**
	 * @param myoAccessoriesData the myoAccessoriesData to set
	 */
	public void setMyoAccessoriesData(List<ExcellonMyoAccessoriesDataRequestDTO> myoAccessoriesData) {
		this.myoAccessoriesData = myoAccessoriesData;
	}

	/**
	 * @return the configid
	 */
	public String getConfigid() {
		return configid;
	}

	/**
	 * @param configid the configid to set
	 */
	public void setConfigid(String configid) {
		this.configid = configid;
	}

	/**
	 * @return the configdescription
	 */
	public String getConfigdescription() {
		return configdescription;
	}

	/**
	 * @param configdescription the configdescription to set
	 */
	public void setConfigdescription(String configdescription) {
		this.configdescription = configdescription;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the fatherName
	 */
	public String getFatherName() {
		return fatherName;
	}

	/**
	 * @param fatherName the fatherName to set
	 */
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the storeCode
	 */
	public String getStoreCode() {
		return storeCode;
	}

	/**
	 * @param storeCode the storeCode to set
	 */
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the bookingmodel
	 */
	public String getBookingmodel() {
		return bookingmodel;
	}

	/**
	 * @param bookingmodel the bookingmodel to set
	 */
	public void setBookingmodel(String bookingmodel) {
		this.bookingmodel = bookingmodel;
	}

	/**
	 * @return the typeofInquiry
	 */
	public int getTypeofInquiry() {
		return typeofInquiry;
	}

	/**
	 * @param typeofInquiry the typeofInquiry to set
	 */
	public void setTypeofInquiry(int typeofInquiry) {
		this.typeofInquiry = typeofInquiry;
	}

	/**
	 * @return the primarySource
	 */
	public int getPrimarySource() {
		return primarySource;
	}

	/**
	 * @param primarySource the primarySource to set
	 */
	public void setPrimarySource(int primarySource) {
		this.primarySource = primarySource;
	}

	/**
	 * @return the ownershipStatus
	 */
	public int getOwnershipStatus() {
		return ownershipStatus;
	}

	/**
	 * @param ownershipStatus the ownershipStatus to set
	 */
	public void setOwnershipStatus(int ownershipStatus) {
		this.ownershipStatus = ownershipStatus;
	}

	/**
	 * @return the profession
	 */
	public int getProfession() {
		return profession;
	}

	/**
	 * @param profession the profession to set
	 */
	public void setProfession(int profession) {
		this.profession = profession;
	}

	/**
	 * @return the gender
	 */
	public int getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(int gender) {
		this.gender = gender;
	}

	/**
	 * @return the purposeOfUse
	 */
	public int getPurposeOfUse() {
		return purposeOfUse;
	}

	/**
	 * @param purposeOfUse the purposeOfUse to set
	 */
	public void setPurposeOfUse(int purposeOfUse) {
		this.purposeOfUse = purposeOfUse;
	}

	/**
	 * @return the alternateMobileNo
	 */
	public String getAlternateMobileNo() {
		return alternateMobileNo;
	}

	/**
	 * @param alternateMobileNo the alternateMobileNo to set
	 */
	public void setAlternateMobileNo(String alternateMobileNo) {
		this.alternateMobileNo = alternateMobileNo;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the importfileName
	 */
	public String getImportfileName() {
		return importfileName;
	}

	/**
	 * @param importfileName the importfileName to set
	 */
	public void setImportfileName(String importfileName) {
		this.importfileName = importfileName;
	}

	/**
	 * @return the impportedDate
	 */
	public String getImpportedDate() {
		return impportedDate;
	}

	/**
	 * @param impportedDate the impportedDate to set
	 */
	public void setImpportedDate(String impportedDate) {
		this.impportedDate = impportedDate;
	}

	/**
	 * @return the bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * @param bookingDate the bookingDate to set
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * @return the creationSource
	 */
	public String getCreationSource() {
		return creationSource;
	}

	/**
	 * @param creationSource the creationSource to set
	 */
	public void setCreationSource(String creationSource) {
		this.creationSource = creationSource;
	}

	/**
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}

	/**
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * @param salutation the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	/**
	 * @return the financeRequired
	 */
	public int getFinanceRequired() {
		return financeRequired;
	}

	/**
	 * @param financeRequired the financeRequired to set
	 */
	public void setFinanceRequired(int financeRequired) {
		this.financeRequired = financeRequired;
	}

	/**
	 * @return the preferredFinancier
	 */
	public String getPreferredFinancier() {
		return preferredFinancier;
	}

	/**
	 * @param preferredFinancier the preferredFinancier to set
	 */
	public void setPreferredFinancier(String preferredFinancier) {
		this.preferredFinancier = preferredFinancier;
	}

	/**
	 * @return the interestedInExchange
	 */
	public int getInterestedInExchange() {
		return interestedInExchange;
	}

	/**
	 * @param interestedInExchange the interestedInExchange to set
	 */
	public void setInterestedInExchange(int interestedInExchange) {
		this.interestedInExchange = interestedInExchange;
	}

	/**
	 * @return the haveYouBeenOnAnyRides
	 */
	public String getHaveYouBeenOnAnyRides() {
		return haveYouBeenOnAnyRides;
	}

	/**
	 * @param haveYouBeenOnAnyRides the haveYouBeenOnAnyRides to set
	 */
	public void setHaveYouBeenOnAnyRides(String haveYouBeenOnAnyRides) {
		this.haveYouBeenOnAnyRides = haveYouBeenOnAnyRides;
	}

	/**
	 * @return the doYouOwnA4Wheeler
	 */
	public String getDoYouOwnA4Wheeler() {
		return doYouOwnA4Wheeler;
	}

	/**
	 * @param doYouOwnA4Wheeler the doYouOwnA4Wheeler to set
	 */
	public void setDoYouOwnA4Wheeler(String doYouOwnA4Wheeler) {
		this.doYouOwnA4Wheeler = doYouOwnA4Wheeler;
	}

	/**
	 * @return the twoWExchangedModel
	 */
	public int getTwoWExchangedModel() {
		return twoWExchangedModel;
	}

	/**
	 * @param twoWExchangedModel the twoWExchangedModel to set
	 */
	public void setTwoWExchangedModel(int twoWExchangedModel) {
		this.twoWExchangedModel = twoWExchangedModel;
	}

	/**
	 * @return the websiteBookingDateTime
	 */
	public String getWebsiteBookingDateTime() {
		return websiteBookingDateTime;
	}

	/**
	 * @param websiteBookingDateTime the websiteBookingDateTime to set
	 */
	public void setWebsiteBookingDateTime(String websiteBookingDateTime) {
		this.websiteBookingDateTime = websiteBookingDateTime;
	}

	/**
	 * @return the paymentRefNo
	 */
	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	/**
	 * @param paymentRefNo the paymentRefNo to set
	 */
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcellonBookingPaymentRequestDTO [testRideTaken=");
		builder.append(testRideTaken);
		builder.append(", testRidedenialReason=");
		builder.append(testRidedenialReason);
		builder.append(", usage=");
		builder.append(usage);
		builder.append(", modeOfRegistration=");
		builder.append(modeOfRegistration);
		builder.append(", tentativedeliverydays=");
		builder.append(tentativedeliverydays);
		builder.append(", possiblepersona=");
		builder.append(possiblepersona);
		builder.append(", actualpersona=");
		builder.append(actualpersona);
		builder.append(", stageOfLife=");
		builder.append(stageOfLife);
		builder.append(", badgeName=");
		builder.append(badgeName);
		builder.append(", purchasetimeframe=");
		builder.append(purchasetimeframe);
		builder.append(", panNumber=");
		builder.append(panNumber);
		builder.append(", myoAccessoriesData=");
		builder.append(myoAccessoriesData);
		builder.append(", configid=");
		builder.append(configid);
		builder.append(", configdescription=");
		builder.append(configdescription);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", fatherName=");
		builder.append(fatherName);
		builder.append(", mobile=");
		builder.append(mobile);
		builder.append(", email=");
		builder.append(email);
		builder.append(", dateOfBirth=");
		builder.append(dateOfBirth);
		builder.append(", addressLine1=");
		builder.append(addressLine1);
		builder.append(", addressLine2=");
		builder.append(addressLine2);
		builder.append(", zipCode=");
		builder.append(zipCode);
		builder.append(", storeCode=");
		builder.append(storeCode);
		builder.append(", dealerCode=");
		builder.append(dealerCode);
		builder.append(", bookingmodel=");
		builder.append(bookingmodel);
		builder.append(", typeofInquiry=");
		builder.append(typeofInquiry);
		builder.append(", primarySource=");
		builder.append(primarySource);
		builder.append(", ownershipStatus=");
		builder.append(ownershipStatus);
		builder.append(", profession=");
		builder.append(profession);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", purposeOfUse=");
		builder.append(purposeOfUse);
		builder.append(", alternateMobileNo=");
		builder.append(alternateMobileNo);
		builder.append(", country=");
		builder.append(country);
		builder.append(", state=");
		builder.append(state);
		builder.append(", district=");
		builder.append(district);
		builder.append(", area=");
		builder.append(area);
		builder.append(", importfileName=");
		builder.append(importfileName);
		builder.append(", impportedDate=");
		builder.append(impportedDate);
		builder.append(", bookingDate=");
		builder.append(bookingDate);
		builder.append(", creationSource=");
		builder.append(creationSource);
		builder.append(", transactionID=");
		builder.append(transactionID);
		builder.append(", city=");
		builder.append(city);
		builder.append(", salutation=");
		builder.append(salutation);
		builder.append(", financeRequired=");
		builder.append(financeRequired);
		builder.append(", preferredFinancier=");
		builder.append(preferredFinancier);
		builder.append(", interestedInExchange=");
		builder.append(interestedInExchange);
		builder.append(", haveYouBeenOnAnyRides=");
		builder.append(haveYouBeenOnAnyRides);
		builder.append(", doYouOwnA4Wheeler=");
		builder.append(doYouOwnA4Wheeler);
		builder.append(", twoWExchangedModel=");
		builder.append(twoWExchangedModel);
		builder.append(", websiteBookingDateTime=");
		builder.append(websiteBookingDateTime);
		builder.append(", paymentRefNo=");
		builder.append(paymentRefNo);
		builder.append("]");
		return builder.toString();
	}

}
