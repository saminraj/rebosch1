package com.net.bosch.utils;

import static com.net.bosch.constants.Constants.CHASSIS_NUMBER_LEN;
import static com.net.bosch.constants.Constants.MAXIMUM_REGIS_NUM_LEN;
import static com.net.bosch.constants.Constants.MINIMUM_REGIS_NUM_LEN;
import static com.net.bosch.constants.REResponse.INVALID_REGISTRATION_NUMBER_LENGTH;
import static com.net.bosch.constants.REResponse.REGISTRATION_NUMBER_MUST_BE_ALPHANUMERIC;
import static com.net.bosch.constants.REResponse.SUCCESS;
import static org.apache.commons.lang3.StringUtils.isAlphanumeric;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.net.bosch.constants.REResponse;
import com.net.bosch.crmmaster.dto.RegistrationNumberRequest;
import com.net.bosch.crmmaster.dto.VehicleVerifyRequestDTO;

/**
 * @author pushkarkhosla
 *
 */
public class ValidationUtil {

	private static final Logger logger = LoggerFactory.getLogger(ValidationUtil.class);

	private ValidationUtil() {

	}

	/**
	 * @param date
	 * @param engineNumber
	 * @return
	 */
	public static REResponse validateVerifyApiParams(VehicleVerifyRequestDTO dto) {
		String chassisNo = trimToNull(dto.getChassisNumber());
		String registrationNo = trimToNull(dto.getRegistrationNumber());
		if (isEmpty(chassisNo) && isEmpty(registrationNo)) {
			logger.error("Chassis Number & Registration Number is Blank/Empty.");
			return REResponse.ONE_FIELD_IS_MANDATORY;
		}
		if (isNotEmpty(chassisNo) && isNotEmpty(registrationNo)) {
			REResponse chassisResult = validateChassisNumber(chassisNo);
			return chassisResult != SUCCESS ? chassisResult : validateRegistrationNumber(registrationNo);
		}
		return isNotEmpty(chassisNo) ? validateChassisNumber(chassisNo) : validateRegistrationNumber(registrationNo);
	}

	/**
	 * @param registrationNo
	 * @return
	 */
	private static REResponse validateRegistrationNumber(String registrationNo) {
		if (registrationNo.length() < MINIMUM_REGIS_NUM_LEN || registrationNo.length() > MAXIMUM_REGIS_NUM_LEN) {

			logger.error("Registration Number {{}} Length {{}} must be between {{}} - {{}} characters.", registrationNo,
					registrationNo.length(), MINIMUM_REGIS_NUM_LEN, MAXIMUM_REGIS_NUM_LEN);

			return REResponse.INVALID_REGIS_NUMBER_LENGTH;
		}
		if (!isAlphanumeric(registrationNo)) {
			return REResponse.REGISTRATION_NUMBER_MUST_BE_ALPHANUMERIC;
		}
		return SUCCESS;
	}

	/**
	 * @param chassisNo
	 * @return
	 */
	private static REResponse validateChassisNumber(String chassisNo) {

		if (chassisNo.length() > CHASSIS_NUMBER_LEN) {

			logger.error("Chassis Number {{}} Length {{}} must be of {{}} characters.", chassisNo, chassisNo.length(),
					CHASSIS_NUMBER_LEN);

			return REResponse.INVALID_CHASSIS_NUMBER_LENGTH;
		}

		if (!isAlphanumeric(chassisNo)) {
			return REResponse.CHASSIS_NUMBER_MUST_BE_ALPHANUMERIC;
		}
		return SUCCESS;
	}

	/**
	 * @param regisNumber
	 * @return
	 */
	public static REResponse validateRegistrationNumber(List<RegistrationNumberRequest> vehicleList) {
		for (RegistrationNumberRequest bean : vehicleList) {
			String regisNumber = trimToNull(bean.getUpdatedRegistrationNumber());
			if (bean.isRemoveBike()) {
				logger.info("Not Validating Remove Bike Chassis No {{}} & Engine No {{}}", bean.getChassisNo(),
						bean.getEngineNo());
				continue;
			}
			if (isEmpty(regisNumber)) {
				logger.error("Registration Number is Blank/Empty.");
				return INVALID_REGISTRATION_NUMBER_LENGTH;
			}
			if (regisNumber.length() < MINIMUM_REGIS_NUM_LEN || regisNumber.length() > MAXIMUM_REGIS_NUM_LEN) {

				logger.error("Registration Number {{}} Length {{}} Must be between {{}} - {{}} Characters.",
						regisNumber, regisNumber.length(), MINIMUM_REGIS_NUM_LEN, MAXIMUM_REGIS_NUM_LEN);

				return INVALID_REGISTRATION_NUMBER_LENGTH;
			}
			if (!isAlphanumeric(regisNumber)) {
				return REGISTRATION_NUMBER_MUST_BE_ALPHANUMERIC;
			}
		}
		return SUCCESS;
	}

}
