package com.net.bosch.utils;

import static org.apache.commons.lang3.StringUtils.isEmpty;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import com.net.bosch.constants.Constants;

public class DateHelper {

	private DateHelper() {

	}

	private static final Logger logger = LoggerFactory.getLogger(DateHelper.class);

	public static final String DATE_TIME_PATTERN = "dd-MMM-yyyy K:mm a z";

	public static final String DATE_ONLY_PATTERN = "dd-MMM-yyyy";

	public static final String SERVICE_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss.S";// 2012-01-31 23:59:59.9

	public static final String TASK_DUE_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss.S";// 2012-01-31 23:59:59.9

	public static final String RE_PRIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";

	public static final String YYYY_MM_DD = "yyyy-MM-dd";

	public static final String DDMMYYYY_HYPHEN = "dd-MM-yyyy";
	public static final String DDMMYYYY_SLASH = "dd/MM/yyyy";
	public static final String DDMMYYYY_SLASH_PATTERN_REGIX = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";

	public static final String DMS_EXCELLON_BALANCE_PAYMENT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	public static String convertDateTime(long timestamp) {
		SimpleDateFormat format = new SimpleDateFormat(DATE_TIME_PATTERN);
		return format.format(timestamp);
	}

	public static String convertToDateOnly(long timestamp) {
		SimpleDateFormat format = new SimpleDateFormat(DATE_ONLY_PATTERN);
		return format.format(timestamp);
	}

	public static String convertToTaskDueDateFormat(long timestamp) {
		SimpleDateFormat format = new SimpleDateFormat(TASK_DUE_DATE_PATTERN);
		return format.format(timestamp);
	}

	public static Date convertToTaskDueDateFormatDate(long timestamp) {
		String dateString = convertToTaskDueDateFormat(timestamp);
		try {
			return new SimpleDateFormat(TASK_DUE_DATE_PATTERN).parse(dateString);
		} catch (ParseException e) {
			logger.error(
					"Exception Occured in convertToTaskDueDateFormatDate(). Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
		return null;
	}

	public static String convertDateToStringYYYYMMDD(long timestamp) {
		SimpleDateFormat format = new SimpleDateFormat(YYYY_MM_DD);
		return format.format(timestamp);
	}

	public static String convertDateStringToNewPattern(String dateString, String pattern) throws ParseException {
		Date date = DateUtils.parseDate(dateString, pattern);
		return org.apache.http.client.utils.DateUtils.formatDate(date, Constants.RE_PRIME_PATTERN);
	}

	public static String convertAppointmentDateToNewPattern(String input) {
		SimpleDateFormat format = new SimpleDateFormat(SERVICE_DATE_PATTERN);
		Date date = null;
		try {
			date = format.parse(input);
		} catch (ParseException e) {
			logger.error(
					"Exception Occured in convertAppointmentDateToNewPattern(). Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
		}
		return org.apache.http.client.utils.DateUtils.formatDate(date, Constants.RE_PRIME_PATTERN);

	}

	/**
	 * @param strDate
	 * @param pattern
	 * @return
	 */
	public static String formatDateToMMMDDYYYY(String strDate, String pattern) {
		strDate = StringUtils.trimToNull(strDate);
		if (StringUtils.isEmpty(strDate)) {
			logger.error("strDate is Blank in formatDateToMMMDDYYYY().");
			return StringUtils.EMPTY;
		}
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		try {
			Date mfgDate = format.parse(strDate);
			return org.apache.http.client.utils.DateUtils.formatDate(mfgDate, Constants.RE_PRIME_PATTERN);
		} catch (Exception e) {
			logger.error("Exception Occured While Date {{}} Parsing in format {{}}", strDate,
					Constants.RE_PRIME_PATTERN);
			logger.error(
					"Exception Occured in formatStringDateInString(). Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return strDate;
		}
	}

	/**
	 * @param strDate
	 * @param pattern
	 * @return
	 */
	public static Calendar convertStringDateToCalender(String strDate, String pattern) {
		try {
			strDate = StringUtils.trimToNull(strDate);
			if (StringUtils.isEmpty(strDate)) {
				logger.error("strDate is Blank in convertStringDateToCalender().");
				return null;
			}
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			/**
			 * setLenient(false) Means : Input to be parsed should strictly follow the
			 * defined date format.
			 */
			simpleDateFormat.setLenient(false);
			Calendar calender = Calendar.getInstance();
			calender.setTime(simpleDateFormat.parse(strDate));
			return calender;
		} catch (Exception e) {
			logger.error(
					"Exception Occured in convertStringDateToCalender(). Exception Message {{}},Exception Details {{}}",
					e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param calender
	 * @param pattern
	 * @return
	 */
	public static String convertCalenderToStringDate(Calendar calender, String pattern) {
		if (ObjectUtils.isEmpty(calender)) {
			logger.error("calender is Blank in convertCalenderToStringDate().");
			return StringUtils.EMPTY;
		}
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		return format.format(calender.getTime());
	}

	/**
	 * @param date
	 * @return
	 */
	public static String formatExcellonServiceHistoryDate(String date) {
		return formatExcellonDate(date, "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * @param date
	 * @return
	 */
	public static String formatExcellonServiceHistoryDateForFireBaseKey(String date) {
		return formatExcellonDate(date, "yyyy-MM-dd-HH:mm:ss");
	}

	/**
	 * @param date
	 * @param outputFormat
	 * @return
	 */
	private static String formatExcellonDate(String date, String outputFormat) {
		if (isEmpty(date)) {
			logger.error("ActualDeliveryDateandTime is Null/Blank.");
			return null;
		}
		try {
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date parseDate = simpleDateFormat1.parse(date);

			SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(outputFormat);
			return simpleDateFormat2.format(parseDate).concat(".0");
		} catch (Exception e) {
			logger.error(
					"Exception Occured While Formatting Excellon Service History ActualDeliveryDateandTime {{}} for Firebase Key. Exception Message {{}}, Exception Details {{}}",
					date, e.getMessage(), e);
			return null;
		}
	}

	public static String convertDateToString(Date date, String pattern) {
		String dateString = null;
		if (null == date) {
			return null;
		}
		try {
			SimpleDateFormat sdfr = new SimpleDateFormat(pattern);
			sdfr.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			dateString = sdfr.format(date);
		} catch (Exception ex) {
			logger.error("Exception Occured While Parsing Date {{}}", date);
			return null;
		}
		return dateString;
	}

	/**
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Date formatStrToDates(String date) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return simpleDateFormat.parse(date);
	}
}
