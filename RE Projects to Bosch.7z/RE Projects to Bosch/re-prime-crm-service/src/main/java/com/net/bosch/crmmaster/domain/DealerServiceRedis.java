package com.net.bosch.crmmaster.domain;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.domain.DomainObject;

@JsonInclude(Include.NON_NULL)
@RedisHash(value = "DealerService", timeToLive = 2592000)
public class DealerServiceRedis implements DomainObject{

	private static final long serialVersionUID = -3874574926830778247L;

	@Id 
	private String id;	
	
	@NotNull
	private String dealerCode;
	
	private Integer doorStepVehiclesCount = 0;	
	
	private Integer pickupTechnicianCount = 0;
	
	private String doorStepServiceEnabled = "N";
	
	private String pickupServiceEnabled = "N";

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public Integer getDoorStepVehiclesCount() {
		return doorStepVehiclesCount;
	}

	public void setDoorStepVehiclesCount(Integer doorStepVehiclesCount) {
		this.doorStepVehiclesCount = doorStepVehiclesCount;
	}

	public Integer getPickupTechnicianCount() {
		return pickupTechnicianCount;
	}

	public void setPickupTechnicianCount(Integer pickupTechnicianCount) {
		this.pickupTechnicianCount = pickupTechnicianCount;
	}

	public String getDoorStepServiceEnabled() {
		return doorStepServiceEnabled;
	}

	public void setDoorStepServiceEnabled(String doorStepServiceEnabled) {
		this.doorStepServiceEnabled = doorStepServiceEnabled;
	}

	public String getPickupServiceEnabled() {
		return pickupServiceEnabled;
	}

	public void setPickupServiceEnabled(String pickupServiceEnabled) {
		this.pickupServiceEnabled = pickupServiceEnabled;
	}

	
	
	
	
			
}
