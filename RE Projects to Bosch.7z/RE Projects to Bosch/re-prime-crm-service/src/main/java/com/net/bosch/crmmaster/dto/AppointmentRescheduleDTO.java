package com.net.bosch.crmmaster.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppointmentRescheduleDTO{
	
	@JsonProperty("AppointmentId")
	private String appointmentId;
	@JsonProperty("AppointmentDate")
    private String appointmentDate;
	@JsonProperty("AttachmentKey")
    private String attachmentKey;
	@JsonProperty("CustomerRemarks")
    private String customerRemarks;
	@JsonProperty("DropAddress")
    private String dropAddress;
	@JsonProperty("SlotID")
    private String slotID;
	@JsonProperty("IsPickUpDrop")
    private String isPickUpDrop;
	@JsonProperty("PickUpAddress")
    private String pickUpAddress;
	@JsonProperty("ServiceType")
    private String serviceType;
	@JsonProperty("Creation_Source")
    private String creation_Source;
	@JsonProperty("BranchID")
    private String branchID;
	@JsonProperty("Mobile")
	private String mobile;
	@JsonProperty("RegNo")
    private String regNo;
	/* new json request string */
	@JsonProperty("Booking Reschedule")
	private String bookingReschedule;
	@JsonProperty("ChassisNo")
    private String chassisNo;
		
	private Boolean isDummySlots;
	
	private String appointmentCategory;
	
	@JsonProperty("Reschedule_Reason")
    private String rescheduleReason;
	@JsonProperty("ChassisNoSow")
    private String chassisNoSow;	
	@JsonProperty("OldSlotID")
	private String oldSlotID;
	@JsonProperty("AnyThingSpecific")
	private String anyThingSpecific;
	
	public String getAppointmentId() {
		return appointmentId;
	}
	public String getBookingReschedule() {
		return bookingReschedule;
	}
	public void setBookingReschedule(String bookingReschedule) {
		this.bookingReschedule = bookingReschedule;
	}
	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAttachmentKey() {
		return attachmentKey;
	}
	public void setAttachmentKey(String attachmentKey) {
		this.attachmentKey = attachmentKey;
	}
	public String getCustomerRemarks() {
		return customerRemarks;
	}
	public void setCustomerRemarks(String customerRemarks) {
		this.customerRemarks = customerRemarks;
	}
	public String getDropAddress() {
		return dropAddress;
	}
	public void setDropAddress(String dropAddress) {
		this.dropAddress = dropAddress;
	}
	public String getSlotID() {
		return slotID;
	}
	public void setSlotID(String slotID) {
		this.slotID = slotID;
	}
	public String getIsPickUpDrop() {
		return isPickUpDrop;
	}
	public void setIsPickUpDrop(String isPickUpDrop) {
		this.isPickUpDrop = isPickUpDrop;
	}
	public String getPickUpAddress() {
		return pickUpAddress;
	}
	public void setPickUpAddress(String pickUpAddress) {
		this.pickUpAddress = pickUpAddress;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCreation_Source() {
		return creation_Source;
	}
	public void setCreation_Source(String creation_Source) {
		this.creation_Source = creation_Source;
	}
	public String getBranchID() {
		return branchID;
	}
	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public Boolean getIsDummySlots() {
		return isDummySlots;
	}
	public void setIsDummySlots(Boolean isDummySlots) {
		this.isDummySlots = isDummySlots;
	}
	public String getChassisNo() {
		return chassisNo;
	}
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}
	public String getAppointmentCategory() {
		return appointmentCategory;
	}
	public void setAppointmentCategory(String appointmentCategory) {
		this.appointmentCategory = appointmentCategory;
	}
	public String getRescheduleReason() {
		return rescheduleReason;
	}
	public void setRescheduleReason(String rescheduleReason) {
		this.rescheduleReason = rescheduleReason;
	}
	public String getChassisNoSow() {
		return chassisNoSow;
	}
	public void setChassisNoSow(String chassisNoSow) {
		this.chassisNoSow = chassisNoSow;
	}
	public String getOldSlotID() {
		return oldSlotID;
	}
	public void setOldSlotID(String oldSlotID) {
		this.oldSlotID = oldSlotID;
	}
	public String getAnyThingSpecific() {
		return anyThingSpecific;
	}
	public void setAnyThingSpecific(String anyThingSpecific) {
		this.anyThingSpecific = anyThingSpecific;
	}
	
}
