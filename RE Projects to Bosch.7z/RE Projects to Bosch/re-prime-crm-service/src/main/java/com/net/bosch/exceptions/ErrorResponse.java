package com.net.bosch.exceptions;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;

@JsonInclude(Include.NON_NULL)
public class ErrorResponse {
	
	private AppExceptionErrorCode errorCode;
	private String errorMessage;
	private String result = "failed";
	private List<ErrorField> fieldErrors;
	
	public AppExceptionErrorCode getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(AppExceptionErrorCode errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public void addFieldError(String objectName, String fieldName, String errorMessage){
		if (fieldErrors == null)
			fieldErrors = new ArrayList<ErrorField>();
		fieldErrors.add(new ErrorField(objectName, fieldName, errorMessage));
	}
	public List<ErrorField> getFieldErrors() {
		return fieldErrors;
	}
	public void setFieldErrors(List<ErrorField> fieldErrors) {
		this.fieldErrors = fieldErrors;
	}
	public String getResult() {
		return result;
	}
}

@JsonInclude(Include.NON_NULL)
class ErrorField{
	private String objectName;
	private String fieldName;
	private String message;
	
	public ErrorField(String objectName, String fieldName, String message){
		this.objectName = objectName;
		this.fieldName = fieldName;
		this.message = message;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
