package com.net.bosch.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.net.bosch.otap.utils.TokenValidatorUtil;

@Component
public class AppFilter implements Filter {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Environment env;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		logger.debug("Inside the App Filter---------------->");
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;		
		domainHandler(chain, request, response);		
	}

	@Override
	public void destroy() {
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}
	
	
	private boolean domainHandler(FilterChain chain, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		HttpSession session = request.getSession();
		String path = ( request).getRequestURI();
		logger.debug("Inside the App Filter getRequestURI ---------------->"+path);
		if( path.startsWith("/js/") || path.startsWith("/dataTables/") || path.startsWith("/css/") || path.startsWith("/images/")) {
			//Skip DomainCheck
			logger.debug("Skip DomainCheck ---------------->");
		} else {			

			/*String jwtToken = request.getHeader("Authorization");
			String app_id = StringUtils.trimToNull(request.getHeader("app_id"));
			logger.info("App Id {{}} ,JWT Token {{}} ,myHeader {{}}", app_id, jwtToken);
			if(app_id == null || app_id.isEmpty())app_id = request.getHeader("app_id");
			logger.info(" Second time App Id {{}} ,JWT Token {{}} ,myHeader {{}}", app_id, jwtToken);
			if (StringUtils.isEmpty(app_id)) {
				logger.debug("App Id is Required.");
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "App Id is Blank.");
				return false;
			}
			if (StringUtils.isEmpty(jwtToken)) {
				logger.debug("UI sent a null or empty token");
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authorization Token is Required.");
				return false;
			}
			Boolean isValid = TokenValidatorUtil.validateAuthenticationToken(jwtToken, env.getProperty("spring.jwt.url"));
			if (!isValid) {
				logger.debug("Invalid authentication token ----------------> " + jwtToken);
				// response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "jwt token is invalid or incorrect");
				return false;
			}*/
		}
		chain.doFilter(request, response);
		return false;
	}
	
	
}
