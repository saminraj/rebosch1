package com.net.bosch.notification.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class MessageDTO{

	@NotNull
	private String app_id = "4";
	
	@NotNull
	private String channel = "OTAPUSH";
	
	@NotNull
	private String priority = "1";
	
	private ContentDTO content;

	private RecipientDTO recipient; 
	
	private SenderDTO sender;
	
	private PreferencesDTO preferences;

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public ContentDTO getContent() {
		return content;
	}

	public void setContent(ContentDTO content) {
		this.content = content;
	}

	public RecipientDTO getRecipient() {
		return recipient;
	}

	public void setRecipient(RecipientDTO recipient) {
		this.recipient = recipient;
	}

	public SenderDTO getSender() {
		return sender;
	}

	public void setSender(SenderDTO sender) {
		this.sender = sender;
	}

	public PreferencesDTO getPreferences() {
		return preferences;
	}

	public void setPreferences(PreferencesDTO preferences) {
		this.preferences = preferences;
	}
			
}
