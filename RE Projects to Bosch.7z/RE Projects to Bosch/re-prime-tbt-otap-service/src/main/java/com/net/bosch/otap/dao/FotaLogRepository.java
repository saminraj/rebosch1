package com.net.bosch.otap.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.otap.domain.FotaLog;

@Repository
public interface FotaLogRepository extends JpaRepository<FotaLog, Long> {	
	
	List<FotaLog> findAllByVinNumber(String vinNumber);
	List<FotaLog> findAllByCampaignName(String campaignName);
	
	Page<FotaLog> findAllByCampaignName(String campaignName, Pageable pageable);
	Page<FotaLog> findAllByCampaignNameAndCurrentStatus(String campaignName, String currentStatus, Pageable pageable);
	
}