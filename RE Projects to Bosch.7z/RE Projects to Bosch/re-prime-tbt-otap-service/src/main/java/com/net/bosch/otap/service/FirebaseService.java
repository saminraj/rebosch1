package com.net.bosch.otap.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import com.net.bosch.constants.Constants;

@Service
public class FirebaseService {

private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private Environment env;
	
	ObjectMapper mapper = new ObjectMapper();
	
	public static String firebaseDBURL = ""; // value will change from propery file at init method
		
	@PostConstruct
	public void init() throws FileNotFoundException{
		logger.info("init FirebaseService");
		firebaseDBURL = env.getProperty("spring.firebase.db.url");    	
		logger.info("firebaseDBURL: "+firebaseDBURL);
		
		try {
			
			FirebaseApp firebaseApp = null;
			List<FirebaseApp> firebaseApps = FirebaseApp.getApps();
		    if(firebaseApps==null || firebaseApps.isEmpty()){
		    	String firebasePath = null;
		    	try {
			    	firebasePath = env.getProperty("spring.firebase.path");		    		
		    	}catch (Exception e) {}
		    	logger.info("firebasePath: "+firebasePath);				
				InputStream serviceAccount = new FileInputStream(firebasePath);				
				GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);				
				 FirebaseOptions options = new FirebaseOptions.Builder().setCredentials(credentials)
						 .setDatabaseUrl(firebaseDBURL).build();
				firebaseApp = FirebaseApp.initializeApp(options);
		    }			
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    }
	
	public String addFirmware(String version,Long id,String releaseDate,String downloadUrl, String firmwareMappingUrl,
			String desc, String firmwareVersion, String updateType, boolean isOldVersion, String firmwareBaseVersion,
			String firmwareDeviceType, String releaseNoteURL, String campainManagment, String region, String checkSum) {
		logger.info("addFirmware()");		
		Firestore db = FirestoreClient.getFirestore();	
		DocumentReference docRef = null;
		//For supporting old version
		if(isOldVersion) docRef = db.collection("RE_FOTA_FULL").document(version);
		//else docRef = db.collection("RE_FOTA").document(version);
		else if(firmwareDeviceType.equalsIgnoreCase(Constants.FOTA_DEVICETYPE_KDASH))docRef = db.collection("RE_FOTA_KDASH").document(version);
		else if(firmwareDeviceType.equalsIgnoreCase(Constants.FOTA_DEVICETYPE_TRIPPER))docRef = db.collection("RE_FOTA_TRIPPER").document(version);
		else docRef = db.collection("RE_FOTA_V2_1").document(version);
		Map<String, Object> data = new HashMap<>();
		data.put("id", id);
		data.put("firmwareUrl", downloadUrl);
		data.put("firmwareMappingUrl", firmwareMappingUrl);
		data.put("updateType", updateType);
		data.put("description", desc);
		data.put("releaseDate", releaseDate);
		data.put("firmwareVersion", firmwareVersion);
		data.put("firmwareBaseVersion", firmwareBaseVersion);
		data.put("firmwareDeviceType", firmwareDeviceType);
		data.put("releaseNoteURL", releaseNoteURL);
		data.put("campainManagment", campainManagment);
		data.put("region", region);
		data.put("checkSum", checkSum);
		docRef.set(data);		
		return "success";
	
	}
	
	
	
}
