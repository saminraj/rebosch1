package com.net.bosch.constants;

public class Constants {
	
	public static final String LONG_DATE_FORMAT = "hh:mm a MMM dd yyyy";
	public static final String SHORT_DATE_FORMAT = "dd-MMM-yyyy";
	public static final Integer FIRMWARE_UPDATE_SUCCESS = 1;
	public static final Integer FIRMWARE_UPDATE_FAILURE = 0;
	public static final Integer FIRMWARE_UPDATE_IN_PROGRESS = 2;
	
	public static final String FOTA_SUCCESS = "FOTA_SUCCESS";	
	public static final String FOTA_FAILURE = "FOTA_FAILURE";
	
	public static final Integer PAGE_ELEMENTS = 20;
	
	public static final String FOTA_DEVICETYPE_KDASH = "KDASH";
	public static final String FOTA_DEVICETYPE_TRIPPER = "TRIPPER";	
	
	public static final String FOTA_ALL_STATUS = "ALL";	
	
	
}
