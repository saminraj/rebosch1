package com.net.bosch.otap.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class FirmwareDTO implements Serializable{

	private static final long serialVersionUID = 8754825822452695067L;

	private Long id;	
	
	private String firmwareId;
		
	private String firmwareVersion;
	
	private String vehicleVariant;
	
	private String distributeFirmware;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="MM/dd/yyyy HH:mm")
	private Date releaseDate;
	
	private String downloadURL;
	
	private String description;
	
	private String firmwareBaseVersion;
	
	private String firmwareDeviceType;
	
	private String region;
	
	private String campaignName;
	
	private String releaseNoteURL;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirmwareId() {
		return firmwareId;
	}

	public void setFirmwareId(String firmwareId) {
		this.firmwareId = firmwareId;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getDownloadURL() {
		return downloadURL;
	}

	public void setDownloadURL(String downloadURL) {
		this.downloadURL = downloadURL;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getVehicleVariant() {
		return vehicleVariant;
	}

	public void setVehicleVariant(String vehicleVariant) {
		this.vehicleVariant = vehicleVariant;
	}

	public String getDistributeFirmware() {
		return distributeFirmware;
	}

	public void setDistributeFirmware(String distributeFirmware) {
		this.distributeFirmware = distributeFirmware;
	}

	public String getFirmwareBaseVersion() {
		return firmwareBaseVersion;
	}

	public void setFirmwareBaseVersion(String firmwareBaseVersion) {
		this.firmwareBaseVersion = firmwareBaseVersion;
	}

	public String getFirmwareDeviceType() {
		return firmwareDeviceType;
	}

	public void setFirmwareDeviceType(String firmwareDeviceType) {
		this.firmwareDeviceType = firmwareDeviceType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getReleaseNoteURL() {
		return releaseNoteURL;
	}

	public void setReleaseNoteURL(String releaseNoteURL) {
		this.releaseNoteURL = releaseNoteURL;
	}
	
	
}
