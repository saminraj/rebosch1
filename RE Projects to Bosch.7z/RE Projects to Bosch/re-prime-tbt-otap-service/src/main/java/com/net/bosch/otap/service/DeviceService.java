package com.net.bosch.otap.service;

import java.lang.reflect.InvocationTargetException;

import javax.transaction.Transactional;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;
import com.net.bosch.otap.dao.DeviceRepository;
import com.net.bosch.otap.dao.FirmwareRepository;
import com.net.bosch.otap.domain.Device;
import com.net.bosch.otap.domain.Firmware;
import com.net.bosch.otap.dto.DeviceDTO;
import com.net.bosch.otap.dto.FirmwareDTO;


@Service
public class DeviceService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private DeviceRepository deviceRepository;	
	
	@Autowired
	private FirmwareRepository firmwareRepository;	
	
	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
		
	ObjectMapper mapper = new ObjectMapper();	
	
	@Transactional
	public ResponseDTO saveDevice(DeviceDTO deviceDTO) throws AppException {
		Device device = deviceRepository.findByPhoneNumberAndChassisNumber(deviceDTO.getPhoneNumber(), deviceDTO.getChassisNumber());
		if(device != null){
			throw new AppException(AppExceptionErrorCode.OBJECT_ALREADY_EXISTS, "Device already registered");
		}		
		try {
			device = new Device();
			PropertyUtils.copyProperties(device, deviceDTO);
			Firmware firmware = firmwareRepository.findByDeviceId(device.getDeviceId());
			if(firmware == null){
				firmware = new Firmware();
				PropertyUtils.copyProperties(firmware, deviceDTO.getFirmware());
				firmware.setDeviceId(device.getDeviceId());
				firmwareRepository.save(firmware);
			}
			deviceRepository.save(device);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return new ResponseDTO();
	}
	
	@Transactional
	public DataResponseDTO getDevice(DeviceDTO deviceDTO) throws AppException {
		DataResponseDTO responseDTO = new DataResponseDTO();
		Device device = deviceRepository.findByPhoneNumberAndChassisNumber(deviceDTO.getPhoneNumber(), deviceDTO.getChassisNumber());
		if(device != null){
			Firmware firmware = firmwareRepository.findByDeviceId(device.getDeviceId());
			FirmwareDTO firmwareDTO = new FirmwareDTO();
			try {
				PropertyUtils.copyProperties(deviceDTO,device);
				PropertyUtils.copyProperties(firmwareDTO, firmware);
				deviceDTO.setFirmware(firmwareDTO);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			throw new AppException(AppExceptionErrorCode.OBJECT_DOES_NOT_EXIST, "Device not exist");
		}
		responseDTO.setResponse(deviceDTO);
		return responseDTO;
	}
	
}
