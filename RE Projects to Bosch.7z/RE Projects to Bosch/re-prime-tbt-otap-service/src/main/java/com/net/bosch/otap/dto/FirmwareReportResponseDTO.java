package com.net.bosch.otap.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.DataResponseDTO;


@JsonInclude(Include.NON_NULL)
public class FirmwareReportResponseDTO implements Serializable{

	private static final long serialVersionUID = -7477509816314992513L;

	private String deviceId;
	
	private String mobileNumber;
	
	private String firmwareVersion;
	
	private String flashingStatus;

	

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public String getFlashingStatus() {
		return flashingStatus;
	}

	public void setFlashingStatus(String flashingStatus) {
		this.flashingStatus = flashingStatus;
	}

	
}
