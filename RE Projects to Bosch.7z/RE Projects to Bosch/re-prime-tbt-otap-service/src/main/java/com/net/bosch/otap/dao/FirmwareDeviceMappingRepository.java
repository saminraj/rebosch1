package com.net.bosch.otap.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.otap.domain.Firmware;
import com.net.bosch.otap.domain.FirmwareDeviceMapping;

@Repository
public interface FirmwareDeviceMappingRepository extends JpaRepository<FirmwareDeviceMapping, Long> {	
	
	Firmware findByFirmwareId(String firmwareId);
	FirmwareDeviceMapping findByFirmwareIdAndDeviceId(String firmwareId, String deviceId);
	Long countByStatusAndUpdatedBetween(Integer status, Date updated, Date updated1);	
	List<FirmwareDeviceMapping> findAllByStatusAndUpdatedBetween(Integer status, Date updated, Date updated1);

}