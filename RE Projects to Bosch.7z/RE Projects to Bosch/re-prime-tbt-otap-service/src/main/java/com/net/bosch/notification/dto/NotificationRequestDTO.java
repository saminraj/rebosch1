package com.net.bosch.notification.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class NotificationRequestDTO{

	@NotNull
	private MessageDTO message;
	
	@NotNull
	private MetaDataDTO metaData;

	public MessageDTO getMessage() {
		return message;
	}

	public void setMessage(MessageDTO message) {
		this.message = message;
	}

	public MetaDataDTO getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaDataDTO metaData) {
		this.metaData = metaData;
	}
			
}
