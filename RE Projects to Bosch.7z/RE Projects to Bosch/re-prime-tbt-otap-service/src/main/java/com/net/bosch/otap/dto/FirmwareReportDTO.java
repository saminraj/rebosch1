package com.net.bosch.otap.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.DataResponseDTO;


@JsonInclude(Include.NON_NULL)
public class FirmwareReportDTO extends DataResponseDTO{

	private Integer status;
	
	private String startDate;
	
	private String endDate;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

		
}
