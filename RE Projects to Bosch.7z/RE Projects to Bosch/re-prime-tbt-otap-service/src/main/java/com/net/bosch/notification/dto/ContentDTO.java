package com.net.bosch.notification.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;



@JsonInclude(Include.NON_NULL)
public class ContentDTO{

	private String preview_url;
	
	private String shorten_url;
	
	private String title;
	
	private String value;
	
	private PushDataDTO data;
	
	private String type;
	
	private String batchName;
	
	private String batchdataUrl;
	
	private TemplateDTO template;
	
	private TemplateDTO mediaTemplate;

	public String getPreview_url() {
		return preview_url;
	}

	public void setPreview_url(String preview_url) {
		this.preview_url = preview_url;
	}

	public String getShorten_url() {
		return shorten_url;
	}

	public void setShorten_url(String shorten_url) {
		this.shorten_url = shorten_url;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public PushDataDTO getData() {
		return data;
	}

	public void setData(PushDataDTO data) {
		this.data = data;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public TemplateDTO getTemplate() {
		return template;
	}

	public void setTemplate(TemplateDTO template) {
		this.template = template;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public String getBatchdataUrl() {
		return batchdataUrl;
	}

	public void setBatchdataUrl(String batchdataUrl) {
		this.batchdataUrl = batchdataUrl;
	}

	public TemplateDTO getMediaTemplate() {
		return mediaTemplate;
	}

	public void setMediaTemplate(TemplateDTO mediaTemplate) {
		this.mediaTemplate = mediaTemplate;
	}
}
