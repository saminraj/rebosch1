package com.net.bosch.otap.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.otap.dto.FeedbackDTO;
import com.net.bosch.otap.dto.FeedbackSaveResponseDTO;
import com.net.bosch.otap.dto.FirmwareDTO;
import com.net.bosch.otap.dto.FirmwareReportDTO;
import com.net.bosch.otap.dto.FirmwareSaveResponseDTO;
import com.net.bosch.otap.dto.FotaReportDTO;
import com.net.bosch.otap.service.FirmwareService;


@RestController
@CrossOrigin
@RequestMapping("/otap")
public class OtapController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	FirmwareService firmwareService;
	
	@PostMapping("/firmwareupload") // //new annotation since 4.3
    public FirmwareSaveResponseDTO firmwareUpload(@RequestParam("firmware_file") MultipartFile firmwareFile, @RequestParam(name ="firmware_mapping_file", required = false) MultipartFile firmwareMappingFile, @RequestParam("release_note") MultipartFile releaseNote,HttpServletRequest request) throws AppException, IOException, NoSuchAlgorithmException {
		Long startTime = System.currentTimeMillis();
		logger.debug("firmwareUpload called");
		FirmwareSaveResponseDTO firmwareSaveResponseDTO = firmwareService.saveFirmware(firmwareFile,firmwareMappingFile, releaseNote,request, false);
		logger.debug("[firmwareUpload]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return firmwareSaveResponseDTO;
    }
	
	@Deprecated
	@PostMapping("/firmwareupload/v1.1") // //new annotation since 4.3
    public FirmwareSaveResponseDTO firmwareUploadversion1_1(@RequestParam("firmware_file") MultipartFile firmwareFile, @RequestParam("firmware_mapping_file") MultipartFile firmwareMappingFile,HttpServletRequest request) throws AppException, IOException, NoSuchAlgorithmException {
		Long startTime = System.currentTimeMillis();
		logger.debug("firmwareUploadv1.1 called");
		FirmwareSaveResponseDTO firmwareSaveResponseDTO = firmwareService.saveFirmware(firmwareFile,firmwareMappingFile, null, request, true);
		logger.debug("[firmwareUploadv1.1]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return firmwareSaveResponseDTO;
    }
	
	/**
	 * POST method to fetch a report of firmware released for a specific period
	 */
	@PostMapping(value="/generatereport")
	public DataResponseDTO generateReport(@RequestBody @Valid FirmwareReportDTO firmwareReportDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("generatereport called");
		DataResponseDTO dataResponseDTO = firmwareService.generateReportByDate(firmwareReportDTO);
		logger.debug("[generatereport]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return dataResponseDTO;
	}
	
	@PostMapping(value="/feedback")
	public FeedbackSaveResponseDTO saveFeedback(@RequestBody @Valid FeedbackDTO feedbackDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("Feedback called");		
		FeedbackSaveResponseDTO feedbackSaveResponse = firmwareService.saveFeedback(feedbackDTO);
		logger.debug("[saveDevice]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return feedbackSaveResponse;
	}
	
	@PostMapping(value="/firmwaredownload")
	public FirmwareSaveResponseDTO firmwareDownload(@RequestBody @Valid FirmwareDTO firmwareDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("firmwareDownload called");		
		FirmwareSaveResponseDTO firmwareSaveResponseDTO = firmwareService.firmwareDownload(firmwareDTO);
		logger.debug("[firmwareDownload]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return firmwareSaveResponseDTO;
	}
	
	@PostMapping(value="/addFotaReport")
	public ResponseDTO addFotaReport(@RequestBody @Valid FotaReportDTO fotaReportDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("addFotaReport called");		
		ResponseDTO responseDTO = firmwareService.addFotaReport(fotaReportDTO);
		logger.debug("[addFotaReport]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@GetMapping(value="/getFotaReportForVinNumber/{vinNumber}")
	public ResponseDTO getFotaReportForVinNumber(@PathVariable("vinNumber") String vinNumber) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getFotaReportForVinNumber called");		
		ResponseDTO responseDTO = firmwareService.getFotaReportForVinNumber(vinNumber);
		logger.debug("[getFotaReportForVinNumber]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@PostMapping(value="/getFotaReportForCampaignName/{page}")
	public ResponseDTO getFotaReportForCampaignName(@RequestBody FotaReportDTO fotaReportDTO, @PathVariable("page") Integer page) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getFotaReportForCampaignName called");		
		ResponseDTO responseDTO = firmwareService.getFotaReportForCampaignName(fotaReportDTO.getCampaignName(), fotaReportDTO.getCurrentStatus(), page);
		logger.debug("[getFotaReportForCampaignName]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@PostMapping(value="/addFotaLogs")
	public ResponseDTO addFotaLogs(@RequestBody @Valid FotaReportDTO fotaReportDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("addFotaLogs called");		
		ResponseDTO responseDTO = firmwareService.addFotaLogs(fotaReportDTO);
		logger.debug("[addFotaLogs]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@GetMapping(value="/getFotaLogsForVinNumber/{vinNumber}")
	public ResponseDTO getFotaLogsForVinNumber(@PathVariable("vinNumber") String vinNumber) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getFotaLogsForVinNumber called");		
		ResponseDTO responseDTO = firmwareService.getFotaLogsForVinNumber(vinNumber);
		logger.debug("[getFotaLogsForVinNumber]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@PostMapping(value="/getFotaLogsForCampaignName/{page}")
	public ResponseDTO getFotaLogsForCampaignName(@RequestBody FotaReportDTO fotaReportDTO, @PathVariable("page") Integer page) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getFotaLogsForCampaignName called");		
		ResponseDTO responseDTO = firmwareService.getFotaLogsForCampaignName(fotaReportDTO.getCampaignName(), fotaReportDTO.getCurrentStatus(), page);
		logger.debug("[getFotaLogsForCampaignName]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	/**
	 * POST method to Generate SAS URL with read only access
	 * @throws Exception 
	 */
	@GetMapping(value = "/createSasURL/{documentName}")
	public String GenerateSasUrl(@PathVariable("documentName") String documentName) throws Exception {
		return firmwareService.createSasURL(documentName);		
	}
	
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String getTest() throws AppException {
		return "Success";
	}
	
	

}
