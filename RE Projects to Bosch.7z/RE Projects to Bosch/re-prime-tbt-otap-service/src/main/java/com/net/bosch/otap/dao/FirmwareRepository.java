package com.net.bosch.otap.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.otap.domain.Firmware;

@Repository
public interface FirmwareRepository extends JpaRepository<Firmware, Long> {	
	
	Firmware findByDeviceId(String deviceId);
	List<Firmware> findByFirmwareVersion(String firmwareVersion);
	Firmware findTopByFirmwareDeviceTypeAndRegionAndVehicleVariantOrderByUpdatedDesc(String firmwareDeviceType, String region, String vehicleVariant);
}