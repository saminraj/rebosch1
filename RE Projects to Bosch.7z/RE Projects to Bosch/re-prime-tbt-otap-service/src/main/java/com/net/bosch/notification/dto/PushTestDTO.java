package com.net.bosch.notification.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
public class PushTestDTO extends ResponseDTO{

	private static final long serialVersionUID = -1685794706784304178L;

	String deviceType;
//	String deviceToken;
	String jobCardNo;
	String jobCardStatus;
	String registrationNumber;
	String paybleAmount;
	String modelName;
	String chassisNumber;
	
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
//	public String getDeviceToken() {
//		return deviceToken;
//	}
//	public void setDeviceToken(String deviceToken) {
//		this.deviceToken = deviceToken;
//	}
	public String getJobCardNo() {
		return jobCardNo;
	}
	public void setJobCardNo(String jobCardNo) {
		this.jobCardNo = jobCardNo;
	}
	public String getJobCardStatus() {
		return jobCardStatus;
	}
	public void setJobCardStatus(String jobCardStatus) {
		this.jobCardStatus = jobCardStatus;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public String getPaybleAmount() {
		return paybleAmount;
	}
	public void setPaybleAmount(String paybleAmount) {
		this.paybleAmount = paybleAmount;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getChassisNumber() {
		return chassisNumber;
	}
	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}
	
	

}
