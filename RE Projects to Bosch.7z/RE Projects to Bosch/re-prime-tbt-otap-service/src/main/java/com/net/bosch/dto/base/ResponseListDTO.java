package com.net.bosch.dto.base;

import java.util.List;


public class ResponseListDTO {	

	private List list;
	
	private Integer totalPage = 0;

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}	
}
