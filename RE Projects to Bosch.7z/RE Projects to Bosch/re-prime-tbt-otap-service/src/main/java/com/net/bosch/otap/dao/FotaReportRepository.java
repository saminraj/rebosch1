package com.net.bosch.otap.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.otap.domain.FotaReport;

@Repository
public interface FotaReportRepository extends JpaRepository<FotaReport, Long> {	
	
	FotaReport findByVinNumber(String vinNumber);
	List<FotaReport> findByFirmwareVersion(String firmwareVersion);
	List<FotaReport> findAllByVinNumber(String vinNumber);
	List<FotaReport> findAllByCampaignName(String campaignName);
	
	Page<FotaReport> findAllByCampaignName(String campaignName, Pageable pageable);	
	Page<FotaReport> findAllByCampaignNameAndCurrentStatus(String campaignName, String currentStatus, Pageable pageable);
}