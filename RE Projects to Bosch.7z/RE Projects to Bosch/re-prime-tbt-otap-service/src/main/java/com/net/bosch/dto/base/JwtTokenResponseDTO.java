package com.net.bosch.dto.base;

import java.io.Serializable;

public class JwtTokenResponseDTO implements Serializable{
	
	private static final long serialVersionUID = -1756482182697182691L;

	private Integer code;	
	private String message;	
	private Boolean success;
	
	public Integer getCode() {
		return code;
	}
	
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Boolean getSuccess() {
		return success;
	}
	
	public void setSuccess(Boolean success) {
		this.success = success;
	}	
}
