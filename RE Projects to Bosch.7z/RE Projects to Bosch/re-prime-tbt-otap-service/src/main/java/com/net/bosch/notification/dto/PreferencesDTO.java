package com.net.bosch.notification.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class PreferencesDTO{

	@NotNull
	private String webHookDNId = "1001";

	public String getWebHookDNId() {
		return webHookDNId;
	}

	public void setWebHookDNId(String webHookDNId) {
		this.webHookDNId = webHookDNId;
	}

	
			
}
