package com.net.bosch.otap.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.otap.domain.ActivityLogger;

@Repository
public interface ActivityLoggerRepository extends JpaRepository<ActivityLogger, Long> {	
	

}