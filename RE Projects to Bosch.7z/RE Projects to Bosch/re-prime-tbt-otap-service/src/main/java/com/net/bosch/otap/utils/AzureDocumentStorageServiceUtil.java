package com.net.bosch.otap.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.EnumSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import com.microsoft.azure.storage.IPRange;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.StorageUri;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.SharedAccessBlobPermissions;
import com.microsoft.azure.storage.blob.SharedAccessBlobPolicy;

public class AzureDocumentStorageServiceUtil {
	
	
	
	
	private static AzureDocumentStorageServiceUtil instance=null;
	
	private static Environment env;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AzureDocumentStorageServiceUtil.class);
	
	private AzureDocumentStorageServiceUtil(Environment env) {}
	
	public static AzureDocumentStorageServiceUtil getInstance(Environment env) {
		if(instance==null) {
			instance = new AzureDocumentStorageServiceUtil(env);
		}
		return instance;
	}	
	
	public String uploadDocuments(String documentName,byte [] documentData, Integer maxFileSize, String accountName, String accountKey, String containerName){
		LOGGER.info("Entry in to azure documet upload service handler");
		LOGGER.info("Storing image to cloud");
		String blobName = "";
		CloudBlockBlob blob = null;
		blobName = documentName;
		URI storageLocation = null;
		try {
			
			blob = AzureConnection.getInstance().getContainer(accountName, accountKey, containerName).getBlockBlobReference(blobName);
			int offset = 0;
			LOGGER.info("Document size : "+documentData.length);
			if (documentData.length <1){
				throw new IOException("No data found in the file");
			}
			if (documentData.length>maxFileSize){
				throw new Exception("File size exceed max length"+documentData.length);
			}
			blob.uploadFromByteArray(documentData, offset, documentData.length);
			StorageUri storageUri = blob.getStorageUri();
			LOGGER.debug("storage uri"+ storageUri);
			LOGGER.debug("storage URL"+ storageUri.getPrimaryUri());
			LOGGER.debug("storage URL"+ storageUri.getPrimaryUri().toString());
			storageLocation = storageUri.getPrimaryUri();			
		}
		catch (Exception exception){
			LOGGER.debug("Exception occured while saving image"+exception);
			LOGGER.info("Exception occured while saving image"+exception);
		}
		LOGGER.info("Exit from upload task");
		return storageLocation.toString();
		
	}
	
	public String GetSasUrlToken(String accountName, String accountKey, String containerName, String documentName,
			int urlExpiry, String ipaddress) {
		CloudBlockBlob blob = null;

		try {

			blob = AzureConnection.getInstance().getContainer(accountName, accountKey, containerName)
					.getBlockBlobReference(documentName.trim());
			return getContainerSasUri(blob, urlExpiry, ipaddress);

		} catch (Exception exception) {
			LOGGER.error("Exception occured while getting container Object " + exception);
		}
		return null;
	}

	private String getContainerSasUri(CloudBlockBlob blob, int urlExpiry, String ipaddress)
			throws InvalidKeyException, StorageException, com.microsoft.azure.storage.StorageException {
		try {
			SharedAccessBlobPolicy sasConstraints = new SharedAccessBlobPolicy();
			Date expirationDate = Date.from(Instant.now().plus(Duration.ofHours(urlExpiry)));
			sasConstraints.setSharedAccessExpiryTime(expirationDate);

			EnumSet<SharedAccessBlobPermissions> permissions = EnumSet.of(SharedAccessBlobPermissions.READ);
			sasConstraints.setPermissions(permissions);

			String sasContainerToken;
			if (ipaddress == null) {
				sasContainerToken = blob.generateSharedAccessSignature(sasConstraints, null);
			} else {
				IPRange iprang = new IPRange(ipaddress);
				sasContainerToken = blob.generateSharedAccessSignature(sasConstraints, null, null, iprang, null);
			}
			return blob.getUri().toString() + "?" + sasContainerToken;
		} catch (Exception e) {
			LOGGER.error("Failed to genrate SAS url because ", e);
		}

		return null;
	}

}
