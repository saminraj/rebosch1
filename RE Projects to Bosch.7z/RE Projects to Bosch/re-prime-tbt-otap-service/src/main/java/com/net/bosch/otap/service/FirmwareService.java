package com.net.bosch.otap.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.constants.Constants;
import com.net.bosch.dto.base.DataResponseDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.dto.base.ResponseListDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.exceptions.AppException.AppExceptionErrorCode;
import com.net.bosch.notification.dto.ContentDTO;
import com.net.bosch.notification.dto.MessageDTO;
import com.net.bosch.notification.dto.MetaDataDTO;
import com.net.bosch.notification.dto.NotificationRequestDTO;
import com.net.bosch.notification.dto.PreferencesDTO;
import com.net.bosch.notification.dto.PushDataDTO;
import com.net.bosch.notification.dto.RecipientDTO;
import com.net.bosch.notification.dto.SenderDTO;
import com.net.bosch.otap.dao.FirmwareDeviceMappingRepository;
import com.net.bosch.otap.dao.FirmwareRepository;
import com.net.bosch.otap.dao.FotaLogRepository;
import com.net.bosch.otap.dao.FotaReportRepository;
import com.net.bosch.otap.domain.Firmware;
import com.net.bosch.otap.domain.FirmwareDeviceMapping;
import com.net.bosch.otap.domain.FotaLog;
import com.net.bosch.otap.domain.FotaReport;
import com.net.bosch.otap.dto.FeedbackDTO;
import com.net.bosch.otap.dto.FeedbackSaveResponseDTO;
import com.net.bosch.otap.dto.FirmwareDTO;
import com.net.bosch.otap.dto.FirmwareReportDTO;
import com.net.bosch.otap.dto.FirmwareReportResponseDTO;
import com.net.bosch.otap.dto.FirmwareSaveResponseDTO;
import com.net.bosch.otap.dto.FotaReportDTO;
import com.net.bosch.otap.utils.AzureDocumentStorageServiceUtil;
import com.net.bosch.otap.utils.HexEncoderDecoder;


@Service
public class FirmwareService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private FirmwareRepository firmwareRepository;	
	
	@Autowired
	private FotaReportRepository fotaReportRepository;	
	
	@Autowired
	private FotaLogRepository fotaLogRepository;
		
	@Autowired
	private FirebaseService firebaseService;
	
	@Autowired
	private ActivityloggerService activityloggerService;
	
	@Autowired
	private FirmwareDeviceMappingRepository firmwareDeviceMappingRepository;
	
	@Autowired
	private Environment env;
	
	ObjectMapper mapper = new ObjectMapper();
	
//    Saving file to a physical location is not using now. Keeping this line for later use
//    private static String UPLOADED_FOLDER = "";
	
	@Transactional
	public FirmwareSaveResponseDTO saveFirmware(MultipartFile firmwareFile, MultipartFile firmwareMappingFile, MultipartFile releaseNoteFile,HttpServletRequest request, boolean isOldVersion) throws AppException, IOException, NoSuchAlgorithmException {
		
		FirmwareSaveResponseDTO firmwareSaveResponse = new FirmwareSaveResponseDTO();	
		String firmwareVersion = request.getParameter("firmware_version");
		if(firmwareVersion ==  null  || firmwareVersion.isEmpty()){
			throw new AppException("firmwareVersion is a mandatory parameter");
		}
		String vehicleVariant = request.getParameter("vehicle_variant");
		if(vehicleVariant ==  null  || vehicleVariant.isEmpty()){
			throw new AppException("vehicleVariant is a mandatory parameter");
		}
		String distributeFirmware = request.getParameter("distribute_firmware");
		String firmwareDescription = request.getParameter("firmware_description");
		String updateType = request.getParameter("update_type");
		if(updateType ==  null  || updateType.isEmpty()){
			throw new AppException("updateType is a mandatory parameter");
		}
		if(firmwareDescription ==  null  || firmwareDescription.isEmpty()){
			throw new AppException("firmwareDescription is a mandatory parameter");
		}
		String firmwareBaseVersion = request.getParameter("firmware_base_version");
		String firmwareDeviceType = request.getParameter("firmware_device_type");
		if(firmwareDeviceType ==  null  || firmwareDeviceType.isEmpty()){
			throw new AppException("firmwareDeviceType is a mandatory parameter");
		}
		String region =  request.getParameter("region");
		if(region ==  null  || region.isEmpty()){
			throw new AppException("region is a mandatory parameter");
		}
		String 	campaignName = request.getParameter("campaign_name");
		String 	vendorName = request.getParameter("vendor_name");
		
		/*if(firmwareBaseVersion ==  null  || firmwareBaseVersion.isEmpty()){
			throw new AppException("firmwareBaseVersion is a mandatory parameter");
		}*/
				
		Integer maxFileSize = Integer.parseInt(env.getProperty("spring.azure.maxfilesize"));
		String accountName = env.getProperty("spring.azure.accountname");
		String accountKey =  env.getProperty("spring.azure.accountkey");
		String containerName =  env.getProperty("spring.azure.containername");
		String downloadFirmwareMappingURL = null;		
		if (firmwareFile.isEmpty()) {
			firmwareSaveResponse.setMessage("Firmware file is empty");
        } else {
        	String path = firmwareDeviceType+region+vehicleVariant+firmwareVersion;
			logger.info("checks whether firmwareMappingFile is available for upload");
			if (firmwareMappingFile== null || firmwareMappingFile.isEmpty()) {
				if(updateType.equalsIgnoreCase("partial"))throw new AppException("firmwareMappingFile is a mandatory for partial firmware upload");
				logger.info("empty firmware mapping file found");
			} else {
				logger.info("non empty firmware mapping file found");
				try {
					byte[] bytes = firmwareMappingFile.getBytes();
					downloadFirmwareMappingURL = AzureDocumentStorageServiceUtil.getInstance(env).uploadDocuments(path+firmwareMappingFile.getOriginalFilename(), bytes, maxFileSize, accountName, accountKey, containerName);
					firmwareSaveResponse.setFirmwareMappingUrl(downloadFirmwareMappingURL);
					activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Firmware mapping file of version" + firmwareVersion + " is uploaded to Azure Storage", "");
				} catch (IOException e) {
					activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_FAILURE, "Failed to upload the Firmware mapping file of version" + firmwareVersion + " to Azure Storage", "");
					e.printStackTrace();
				}
	        }        
		
			String downloadURL = null;
			String originalFileName = null;
			String checkSum = null;
			try {
	// 			Get the file and save it somewhere
				byte[] bytes = firmwareFile.getBytes();
	//			Saving file to a physical location is not using now. Keeping this line for later use
	//			Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
	//			Files.write(path, bytes);
				logger.info("firmware uploading started");
				originalFileName = path+firmwareFile.getOriginalFilename();
				downloadURL = AzureDocumentStorageServiceUtil.getInstance(env).uploadDocuments(originalFileName, bytes, maxFileSize, accountName, accountKey, containerName);
				byte[] hash = MessageDigest.getInstance("SHA-256").digest(bytes);				
				//checkSum = new BigInteger(1, hash).toString(16);
				checkSum = HexEncoderDecoder.encode(hash, false);
				logger.error("generateChecksumForFotaFile length checksum "+checkSum);
				
				activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "firmware " + firmwareVersion + " updated", "");
				firmwareSaveResponse.setFirmwareVersion(firmwareVersion);
				firmwareSaveResponse.setFlashingStatus(Constants.FIRMWARE_UPDATE_SUCCESS.toString());
				firmwareSaveResponse.setMessage("firmware " + firmwareVersion + " updated");
				firmwareSaveResponse.setFirmwareUrl(downloadURL);
			} catch (IOException e) {
				activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Failed to update firmware " + firmwareVersion, "");
				firmwareSaveResponse.setMessage("Failed to update firmware " + firmwareVersion);
			}
			
			String releaseNoteURL = null;
			if (!releaseNoteFile.isEmpty()) {
				byte[] bytes = releaseNoteFile.getBytes();
				releaseNoteURL = AzureDocumentStorageServiceUtil.getInstance(env).uploadDocuments(path+"note"+releaseNoteFile.getOriginalFilename(), bytes, maxFileSize, accountName, accountKey, containerName);
			}
			
			
			
			/*Firmware firmware = new Firmware();			
			List<Firmware> firmwareList = firmwareRepository.findByFirmwareVersion(firmwareVersion) ;
			if(firmwareList.size() > 0) {	
				firmware = firmwareRepository.findById(firmwareList.get(0).getId()).get();
			}*/	
			
			Firmware firmware = firmwareRepository.findTopByFirmwareDeviceTypeAndRegionAndVehicleVariantOrderByUpdatedDesc(firmwareDeviceType,region, vehicleVariant);		
				
			if(firmware == null) {
				firmware = new Firmware();
			}
			try {
				firmware.setDownloadURL(downloadURL);
				firmware.setDocumentName(originalFileName);
				firmware.setCheckSum(checkSum);
				firmware.setVehicleVariant(vehicleVariant);
				firmware.setFirmwareVersion(firmwareVersion);
				firmware.setDistributeFirmware(distributeFirmware);	
				firmware.setDescription(firmwareDescription);
				firmware.setRegion(region);
				firmware.setReleaseNoteURL(releaseNoteURL);
				firmware.setFirmwareDeviceType(firmwareDeviceType);
				firmware.setCampaignName(campaignName);
				firmware.setVendorName(vendorName);
				firmware.setUpdateType(updateType);
				firmwareRepository.save(firmware);
				firebaseService.addFirmware(firmwareVersion,firmware.getId(), new Date().toString(), downloadURL, downloadFirmwareMappingURL, firmwareDescription, 
						firmwareVersion, updateType,isOldVersion, firmwareBaseVersion, firmwareDeviceType, releaseNoteURL, campaignName, region, checkSum);
				activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Firmware " + firmwareVersion + " is updated to Firestore", "");
			} catch (Exception e) {
				activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Failed to update Firmware " + firmwareVersion + " to Firestore", "");
			}
			
			constructAndSendPushNotification();
        }
		
		return firmwareSaveResponse;
	}
	
	@Transactional
	public FeedbackSaveResponseDTO saveFeedback(FeedbackDTO feedbackDTO) throws AppException{	
		
		FeedbackSaveResponseDTO feedbackSaveResponse = new FeedbackSaveResponseDTO();
		FirmwareDeviceMapping firmwareDeviceMappingupdate = firmwareDeviceMappingRepository.findByFirmwareIdAndDeviceId(feedbackDTO.getFirmwareId(),feedbackDTO.getDeviceId());
		if(firmwareDeviceMappingupdate != null){
			firmwareDeviceMappingupdate.setStatus(feedbackDTO.getStatus());
			firmwareDeviceMappingRepository.save(firmwareDeviceMappingupdate);
			activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Flashing status of Firmware " + feedbackDTO.getFirmwareId() + " to Device " + feedbackDTO.getDeviceId() + "is updated as " + feedbackDTO.getStatus(), "");
			feedbackSaveResponse.setMessage("Flashing status of Firmware " + feedbackDTO.getFirmwareId() + " to Device " + feedbackDTO.getDeviceId() + "is updated as " + feedbackDTO.getStatus());
		}	
		else
		{
			
			try {
				logger.info("new mapping. need to add mapping information");
				FirmwareDeviceMapping firmwareDeviceMapping = new FirmwareDeviceMapping();
				firmwareDeviceMapping.setFirmwareId(feedbackDTO.getFirmwareId());
				firmwareDeviceMapping.setDeviceId(feedbackDTO.getDeviceId());
				firmwareDeviceMapping.setStatus(feedbackDTO.getStatus());
				firmwareDeviceMappingRepository.save(firmwareDeviceMapping);
				activityloggerService.saveActivity(Constants.FIRMWARE_UPDATE_SUCCESS, "Flashing status of Firmware " + feedbackDTO.getFirmwareId() + " to Device " + feedbackDTO.getDeviceId() + "is updated as " + feedbackDTO.getStatus(), "");
				feedbackSaveResponse.setMessage("Flashing status of Firmware " + feedbackDTO.getFirmwareId() + " to Device " + feedbackDTO.getDeviceId() + "is updated as " + feedbackDTO.getStatus());		
			} catch (Exception e) {
				feedbackSaveResponse.setMessage("Failed to update Flashing status of Firmware " + feedbackDTO.getFirmwareId() + " to Device " + feedbackDTO.getDeviceId() + "is updated as " + feedbackDTO.getStatus());
			}
		}
		
		return feedbackSaveResponse;
	}
	
	@Transactional
	public FirmwareSaveResponseDTO firmwareDownload(FirmwareDTO firmwareDTO) throws AppException{	
		String firmwareDeviceType = firmwareDTO.getFirmwareDeviceType();
		if(firmwareDeviceType ==  null  || firmwareDeviceType.isEmpty()){
			throw new AppException("firmwareDeviceType is a mandatory parameter");
		}
		String region =  firmwareDTO.getRegion();
		if(region ==  null  || region.isEmpty()){
			throw new AppException("region is a mandatory parameter");
		}
		String vehicleVariant =  firmwareDTO.getVehicleVariant();
		if(vehicleVariant ==  null  || vehicleVariant.isEmpty()){
			throw new AppException("vehicleVariant is a mandatory parameter");
		}
		FirmwareSaveResponseDTO firmwareSaveResponseDTO = new FirmwareSaveResponseDTO();
		Firmware firmware = firmwareRepository.findTopByFirmwareDeviceTypeAndRegionAndVehicleVariantOrderByUpdatedDesc(firmwareDeviceType,region, vehicleVariant);
		if(firmware != null){
			firmwareSaveResponseDTO.setFirmwareUrl(createSasURL(firmware.getDocumentName()));
			firmwareSaveResponseDTO.setFirmwareVersion(firmware.getFirmwareVersion());
			firmwareSaveResponseDTO.setCampaignName(firmware.getCampaignName());
			firmwareSaveResponseDTO.setVendorName(firmware.getVendorName());
			firmwareSaveResponseDTO.setCheckSum(firmware.getCheckSum());
			firmwareSaveResponseDTO.setDescription(firmware.getDescription());
			firmwareSaveResponseDTO.setFirmwareDeviceType(firmware.getFirmwareDeviceType());
			firmwareSaveResponseDTO.setRegion(firmware.getRegion());
			firmwareSaveResponseDTO.setReleaseNoteURL(firmware.getReleaseNoteURL());
			firmwareSaveResponseDTO.setVehicleVariant(firmware.getVehicleVariant());
			firmwareSaveResponseDTO.setUpdateType(firmware.getUpdateType());
		}else{
			throw new AppException(AppExceptionErrorCode.OBJECT_DOES_NOT_EXIST);
		}
		return firmwareSaveResponseDTO;
	}
	
	public DataResponseDTO generateReportByDate(FirmwareReportDTO firmwareReportDTO) throws AppException{	
		Integer firmwareStatus = firmwareReportDTO.getStatus();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		Date startDate = new Date();
		Date endDate = new Date();
		try {
			startDate = (Date)formatter.parse(firmwareReportDTO.getStartDate()); 
			endDate = (Date)formatter.parse(firmwareReportDTO.getEndDate());
		} catch (ParseException e) {
			e.printStackTrace();
		}	
		
		Calendar c = Calendar.getInstance();
		c.setTime(endDate);
		c.add(Calendar.DAY_OF_MONTH, 1);  
		Date newDate = c.getTime();  
		
		String flashingStatus = null;
		logger.info("firmware search params - Start Date: "+ firmwareReportDTO.getStartDate() + " End Date: "+ firmwareReportDTO.getEndDate()+ " Status: "+ firmwareReportDTO.getStatus());
		List<FirmwareDeviceMapping> firmwareDeviceMappingList = new ArrayList<FirmwareDeviceMapping>();
		List<FirmwareReportResponseDTO> firmwareReportList = new ArrayList<FirmwareReportResponseDTO>();
		
		firmwareDeviceMappingList = firmwareDeviceMappingRepository.findAllByStatusAndUpdatedBetween(firmwareStatus, startDate,newDate);
		
		for(FirmwareDeviceMapping firmwareDeviceMapping : firmwareDeviceMappingList) {
			FirmwareReportResponseDTO firmwareReportResponseDTO = new FirmwareReportResponseDTO();
			firmwareReportResponseDTO.setDeviceId(firmwareDeviceMapping.getDeviceId());
			Firmware firmware = firmwareRepository.findById(Long.parseLong(firmwareDeviceMapping.getFirmwareId())).get();
			firmwareReportResponseDTO.setFirmwareVersion(firmware.getFirmwareVersion());
			if(firmwareDeviceMapping.getStatus() == Constants.FIRMWARE_UPDATE_SUCCESS) {
				flashingStatus = "Success";
			} else if(firmwareDeviceMapping.getStatus() == Constants.FIRMWARE_UPDATE_FAILURE) {
				flashingStatus = "Failure";
			} else {
				flashingStatus = "In progress";
			}
			firmwareReportResponseDTO.setFlashingStatus(flashingStatus);
			firmwareReportList.add(firmwareReportResponseDTO);
		}
		
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		dataResponseDTO.setResponse(firmwareReportList);
		return dataResponseDTO;
	}
	
	@Transactional
	public ResponseDTO addFotaReport(FotaReportDTO fotaReportDTO) throws AppException {
		try {
			FotaReport fotaReport = new FotaReport();
			PropertyUtils.copyProperties(fotaReport, fotaReportDTO);			
			fotaReportRepository.save(fotaReport);
		} catch (Exception e) {
			e.printStackTrace();
		}
		addFotaLogs(fotaReportDTO);		
		return new ResponseDTO();
	}
	
	public DataResponseDTO getFotaReportForVinNumber(String vinNumber) throws AppException{	
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		dataResponseDTO.setResponse(populateFotaReports(fotaReportRepository.findAllByVinNumber(vinNumber)));
		return dataResponseDTO;
	}
	
	public DataResponseDTO getFotaReportForCampaignName(String campaignName, String status, Integer page) throws AppException{
		Pageable pageable = PageRequest.of(page, Constants.PAGE_ELEMENTS, Sort.by("created"));
		Page<FotaReport> fotaList;
		if(status.equalsIgnoreCase(Constants.FOTA_ALL_STATUS)){
			fotaList = fotaReportRepository.findAllByCampaignName(campaignName, pageable);
		}else {
			fotaList = fotaReportRepository.findAllByCampaignNameAndCurrentStatus(campaignName, status, pageable);
		}
		
		ResponseListDTO responseListDTO  = new ResponseListDTO();
		responseListDTO.setTotalPage(fotaList.getTotalPages());
		responseListDTO.setList( populateFotaReports(fotaList.getContent()));
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		dataResponseDTO.setResponse(responseListDTO);
		return dataResponseDTO;
	}
	
	private List<FotaReportDTO> populateFotaReports(List<FotaReport> fotaReportList) throws AppException{		
		List<FotaReportDTO> fotaReportDTOList = new ArrayList<FotaReportDTO>();		
		for(FotaReport fotaReport : fotaReportList) {
			FotaReportDTO fotaReportDTO = new FotaReportDTO();
			try {
				PropertyUtils.copyProperties(fotaReportDTO, fotaReport);
			} catch (Exception e) {
				e.printStackTrace();
			}
			fotaReportDTOList.add(fotaReportDTO);
		}		
		return fotaReportDTOList;
	}
	
	
	@Transactional
	public ResponseDTO addFotaLogs(FotaReportDTO fotaReportDTO) throws AppException {
		try {
			FotaLog fotaLog = new FotaLog();
			PropertyUtils.copyProperties(fotaLog, fotaReportDTO);			
			fotaLogRepository.save(fotaLog);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return new ResponseDTO();
	}
	
	public DataResponseDTO getFotaLogsForVinNumber(String vinNumber) throws AppException{
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		dataResponseDTO.setResponse(populateFotaLogs(fotaLogRepository.findAllByVinNumber(vinNumber)));
		return dataResponseDTO;
	}
	
	public DataResponseDTO getFotaLogsForCampaignName(String campaignName,String status, Integer page) throws AppException{	
		Pageable pageable = PageRequest.of(page, Constants.PAGE_ELEMENTS, Sort.by("logDate"));
		Page<FotaLog> fotaList;
		if(status.equalsIgnoreCase("ALL")){
			fotaList = fotaLogRepository.findAllByCampaignName(campaignName, pageable);
		}else {
			fotaList = fotaLogRepository.findAllByCampaignNameAndCurrentStatus(campaignName, status, pageable);
		}
		
		ResponseListDTO responseListDTO  = new ResponseListDTO();
		responseListDTO.setTotalPage(fotaList.getTotalPages());
		responseListDTO.setList( populateFotaLogs(fotaList.getContent()));
		DataResponseDTO dataResponseDTO = new DataResponseDTO();
		dataResponseDTO.setResponse(responseListDTO);
		return dataResponseDTO;
	}
	
	private List<FotaReportDTO> populateFotaLogs(List<FotaLog> fotaLogList) throws AppException{		
		List<FotaReportDTO> fotaReportDTOList = new ArrayList<FotaReportDTO>();		
		for(FotaLog fotaLog : fotaLogList) {
			FotaReportDTO fotaReportDTO = new FotaReportDTO();
			try {
				PropertyUtils.copyProperties(fotaReportDTO, fotaLog);
			} catch (Exception e) {
				e.printStackTrace();
			}
			fotaReportDTOList.add(fotaReportDTO);
		}		
		return fotaReportDTOList;
	}
	
	public String createSasURL(String DocumentName)  {
		try {
			String accountName = env.getProperty("spring.azure.accountname");
			String accountKey = env.getProperty("spring.azure.accountkey");
			String containerName = env.getProperty("spring.azure.containername");
			int urlExpiry = Integer.parseInt(env.getProperty("re.fota.sas.urlexpiry"));
			return AzureDocumentStorageServiceUtil.getInstance(env).GetSasUrlToken(accountName, accountKey,
					containerName, DocumentName, urlExpiry, null);
		} catch (Exception e) {
			logger.error("Expection in generateSas", e);
			throw new AppException("Expection in generateSas");
		}

	}
	
	public void constructAndSendPushNotification() {
		
		try {
			NotificationRequestDTO notificationDTO = new NotificationRequestDTO();
			MessageDTO messageDTO = new MessageDTO();
			ContentDTO contentDTO = new ContentDTO();
			RecipientDTO recipientDTO = new RecipientDTO();
			contentDTO.setTitle("FOTA updatel");
			contentDTO.setValue("New FOTA is available for your cluster.");
			contentDTO.setType("NON_TEMPLATE");
			Map<String, String> dataValues = new HashMap<String, String>();
			dataValues.put("id", "4.1");
			dataValues.put("notification_type", "action/reminder");
			dataValues.put("min_app_version", "7.1");
			PushDataDTO pushDataDTO = new PushDataDTO();
			pushDataDTO.setId("16.02");//FOTA UPDATE ID
			pushDataDTO.setType("1");//TEXT type
			pushDataDTO.setParams(dataValues);
			contentDTO.setData(pushDataDTO);
			messageDTO.setContent(contentDTO);
			//recipientDTO.setTo(customerMobileNumber);
			//recipientDTO.setGuid(guid);
			
			messageDTO.setRecipient(recipientDTO);
			messageDTO.setPreferences(new PreferencesDTO());
			messageDTO.setSender(new SenderDTO());
			notificationDTO.setMessage(messageDTO);
			notificationDTO.setMetaData(new MetaDataDTO());
			try {
				String notificationTemplate = mapper.writeValueAsString(notificationDTO);
				//logger.debug("sendnotification notificationDTO -> "+ notificationTemplate);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set("app_id", "4");
			HttpEntity<NotificationRequestDTO> request = new HttpEntity<>(notificationDTO, headers);
			ResponseEntity<String> response = restTemplate.postForEntity(env.getProperty("reprime.push.channel.url"), request,String.class);
			logger.debug("sendNotification reponse-> " + response.getBody());			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
