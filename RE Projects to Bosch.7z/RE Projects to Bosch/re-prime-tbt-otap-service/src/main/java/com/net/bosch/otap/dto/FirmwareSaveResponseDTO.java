package com.net.bosch.otap.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
public class FirmwareSaveResponseDTO extends ResponseDTO{

	private String message;
	
	private String firmwareVersion;
	
	private String flashingStatus;
	
	private String firmwareUrl;
	
	private String firmwareMappingUrl;
	
	private String campaignName;
	
	private String checkSum;
	
	private String vehicleVariant;
	
	private String firmwareDeviceType;
	
	private String region;
	
	private String releaseNoteURL;
	
	private String description;
	
	private String updateType;
	
	private String vendorName;
	
	

	public String getFirmwareUrl() {
		return firmwareUrl;
	}

	public void setFirmwareUrl(String firmwareUrl) {
		this.firmwareUrl = firmwareUrl;
	}

	public String getFirmwareMappingUrl() {
		return firmwareMappingUrl;
	}

	public void setFirmwareMappingUrl(String firmwareMappingUrl) {
		this.firmwareMappingUrl = firmwareMappingUrl;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public String getFlashingStatus() {
		return flashingStatus;
	}

	public void setFlashingStatus(String flashingStatus) {
		this.flashingStatus = flashingStatus;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getCheckSum() {
		return checkSum;
	}

	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}

	public String getVehicleVariant() {
		return vehicleVariant;
	}

	public void setVehicleVariant(String vehicleVariant) {
		this.vehicleVariant = vehicleVariant;
	}

	public String getFirmwareDeviceType() {
		return firmwareDeviceType;
	}

	public void setFirmwareDeviceType(String firmwareDeviceType) {
		this.firmwareDeviceType = firmwareDeviceType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getReleaseNoteURL() {
		return releaseNoteURL;
	}

	public void setReleaseNoteURL(String releaseNoteURL) {
		this.releaseNoteURL = releaseNoteURL;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUpdateType() {
		return updateType;
	}

	public void setUpdateType(String updateType) {
		this.updateType = updateType;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	
}
