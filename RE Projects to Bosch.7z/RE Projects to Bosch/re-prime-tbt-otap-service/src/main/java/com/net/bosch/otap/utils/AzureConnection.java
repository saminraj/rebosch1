package com.net.bosch.otap.utils;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.BlobContainerPublicAccessType;
import com.microsoft.azure.storage.blob.BlobRequestOptions;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;



public class AzureConnection {
	
	private static AzureConnection azureConnection;
	
	private static CloudBlobClient blobClient;
	
	private static CloudBlobContainer container;
	
	private static CloudStorageAccount storageAccocunt;
	
	private static String storageAccountString;
	private static Environment env;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AzureConnection.class);
	
	private AzureConnection(){}
	
	public static AzureConnection getInstance (){
		if (azureConnection == null){
			azureConnection = new AzureConnection();
		}
		return azureConnection;
	}
	
	public CloudBlobContainer getContainer(String accountName, String accountKey, String containerName){
		if (container == null ){
			try {
				storageAccountString = "DefaultEndpointsProtocol=https;" + 
				"AccountName="+accountName+";AccountKey="+accountKey+
				";EndpointSuffix=core.windows.net";
				storageAccocunt = CloudStorageAccount.parse(storageAccountString);
				blobClient = storageAccocunt.createCloudBlobClient();
				container = blobClient.getContainerReference(containerName);
				if (!container.exists()){
					container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());
				}
						
			}
			catch(InvalidKeyException | URISyntaxException|StorageException exception){
				LOGGER.info("Exception occured while connecting to azure container"+exception);
			}
		}
		return container;
	}
	

	
}
