package com.net.bosch.otap.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.net.bosch.exceptions.AppException;
import com.net.bosch.otap.dao.ActivityLoggerRepository;
import com.net.bosch.otap.domain.ActivityLogger;


@Service
public class ActivityloggerService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ActivityLoggerRepository activityLoggerRepository;	
	
	@Transactional
	public void saveActivity(int status, String message,String userId) throws AppException {
		ActivityLogger activityLogger = new ActivityLogger();
		activityLogger.setStatus(status);
		activityLogger.setMessage(message);
		activityLogger.setUserId(userId);
		try {
			activityLoggerRepository.save(activityLogger);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
