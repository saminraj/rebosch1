package com.net.bosch.notification.dto;

import java.util.Map;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class TemplateDTO{

	private String templateId;
	
	private String templateUrl;
	
	private Map<String, String> parameterValues;
	
	private Map<String, String> attachment;
	
	//private MediaDTO media;
	
	private Map<String, String> bodyParameterValues;
	
	private String mode;

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getTemplateUrl() {
		return templateUrl;
	}

	public void setTemplateUrl(String templateUrl) {
		this.templateUrl = templateUrl;
	}

	public Map<String, String> getParameterValues() {
		return parameterValues;
	}

	public void setParameterValues(Map<String, String> parameterValues) {
		this.parameterValues = parameterValues;
	}

	/*public MediaDTO getMedia() {
		return media;
	}

	public void setMedia(MediaDTO media) {
		this.media = media;
	}*/

	public Map<String, String> getBodyParameterValues() {
		return bodyParameterValues;
	}

	public void setBodyParameterValues(Map<String, String> bodyParameterValues) {
		this.bodyParameterValues = bodyParameterValues;
	}

	public Map<String, String> getAttachment() {
		return attachment;
	}

	public void setAttachment(Map<String, String> attachment) {
		this.attachment = attachment;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}
	
			
}
