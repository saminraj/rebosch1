package com.net.bosch.otap.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DeviceDTO implements Serializable{

	private static final long serialVersionUID = -3685794706784304178L;

	private Long id;	
	
	@NotNull
	private String phoneNumber;
	
	private String deviceId;	
	
	private String deviceVersion;
	
	@NotNull
	private String chassisNumber;
	
	private Boolean isActive;
	
	private FirmwareDTO firmware;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceVersion() {
		return deviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		this.deviceVersion = deviceVersion;
	}

	public String getChassisNumber() {
		return chassisNumber;
	}

	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public FirmwareDTO getFirmware() {
		return firmware;
	}

	public void setFirmware(FirmwareDTO firmware) {
		this.firmware = firmware;
	}
			
}
