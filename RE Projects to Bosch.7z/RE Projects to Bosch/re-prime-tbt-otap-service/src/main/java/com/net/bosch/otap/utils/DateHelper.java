package com.net.bosch.otap.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateHelper {
	
	public static final String DATE_TIME_PATTERN = "dd-MMM-yyyy K:mm a z";
	
	public static final String DATE_ONLY_PATTERN = "dd-MMM-yyyy";
	
	public static final String SERVICE_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss.S";//2012-01-31 23:59:59.9
	
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	
    public static String convertDateTime(long timestamp) {
	    SimpleDateFormat format = new SimpleDateFormat(DATE_TIME_PATTERN);
	    return format.format(timestamp);
	}
    
    public static String convertToDateOnly(long timestamp) {
	    SimpleDateFormat format = new SimpleDateFormat(DATE_ONLY_PATTERN);
	    return format.format(timestamp);
	}
    
    public static String convertToServiceDateFormat(long timestamp) {
	    SimpleDateFormat format = new SimpleDateFormat(SERVICE_DATE_PATTERN);
	    return format.format(timestamp);
	}
    
    public static Date convertToServiceDateFormatDate(long timestamp) {
	    String dateString = convertToServiceDateFormat(timestamp);
		try {
			Date date = new SimpleDateFormat(SERVICE_DATE_PATTERN).parse(dateString);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	    
	}
    
    public static String convertDateToStringYYYYMMDD(long timestamp) {
	    SimpleDateFormat format = new SimpleDateFormat(YYYY_MM_DD);
	    return format.format(timestamp);
	}
    
    

}
