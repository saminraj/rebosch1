
package com.net.bosch.otap.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.net.bosch.dto.base.JwtTokenResponseDTO;

public class TokenValidatorUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(TokenValidatorUtil.class);
	
	public static Boolean validateAuthenticationToken(String jwtToken, String jwtURL){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("authorization", jwtToken);
		logger.info("jwtToken from the Header -- > "+jwtToken);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(null, headers);
		logger.info("jwtURL  -- > "+jwtURL);
		ResponseEntity<JwtTokenResponseDTO> response =  restTemplate.exchange(jwtURL,HttpMethod.GET,entity,JwtTokenResponseDTO.class);
		return response.getBody().getSuccess();
	}	
}
