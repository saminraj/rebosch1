package com.net.bosch.auth.dto;

import java.io.Serializable;
import java.util.List;

public class DeleteImageRequestDTO implements Serializable{
	
	private static final long serialVersionUID = -4961247966474906131L;
	
	private List<String> urls;

	public List<String> getUrls() {
		return urls;
	}

	public void setUrls(List<String> urls) {
		this.urls = urls;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
}
