package com.net.bosch.datalogger.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.auth.dao.DeviceAuthenticationRepository;
import com.net.bosch.auth.domain.DeviceAuthentication;
import com.net.bosch.datalogger.dto.BodyDTO;
import com.net.bosch.datalogger.dto.DataLoggerDTO;
import com.net.bosch.datalogger.dto.LogDTO;
import com.net.bosch.datalogger.dto.MessageDTO;
import com.net.bosch.datalogger.dto.BodyRequestDTO;
import com.net.bosch.dto.base.RequestDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.notification.dto.DeviceDTO;
import com.net.bosch.utils.AzureKeyVaultExtractUtil;


@Service
public class DataLoggerService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private DeviceAuthenticationRepository deviceAuthenticationRepository;
	
	@Autowired
	private Environment env;	
		
	ObjectMapper mapper = new ObjectMapper();
	
	@Async
	public void addDataLog(String user) throws AppException, JSONException {		
		try {
			DataLoggerDTO dataLoggerDTO = new DataLoggerDTO();
			LogDTO logDTO = new LogDTO();
			MessageDTO messageDTO = new MessageDTO();
			BodyDTO bodyDTO = new BodyDTO();
			bodyDTO.setMessage("Generate token called");
			bodyDTO.setRequest(new BodyRequestDTO());
			bodyDTO.setResponse("200");
			bodyDTO.setStacktrace("NA");
			messageDTO.setBody(bodyDTO);
			BodyRequestDTO requestDTO = new BodyRequestDTO();
			requestDTO.setSource("tbtauth");
			bodyDTO.setRequest(requestDTO);
			messageDTO.setTitle("TBT Token generation");
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set("app_id", "reprime");	
			headers.set("app_name", "reprime");
			headers.set("module_name", "TBT");
			logDTO.setClassname("tbtutility");
			logDTO.setEnvironment("Microservice");
			logDTO.setMessage(messageDTO);
			logDTO.setMessageType("info");
			logDTO.setTimestamp(new Date().toString());
			logDTO.setUser(user);
			List<LogDTO> logs = new ArrayList<LogDTO>();
			logs.add(logDTO);
			dataLoggerDTO.setLogs(logs);
			logger.debug("datalake logger payload -> "+mapper.writeValueAsString(dataLoggerDTO));
			HttpEntity<DataLoggerDTO> request = new HttpEntity<>(dataLoggerDTO, headers);
			ResponseEntity<String> response =  restTemplate.postForEntity(env.getProperty("spring.datalake.logger.url"),request,String.class);
			logger.debug("datalake logger reponse-> "+response.getBody());						
		} catch (Exception e) {			
			logger.error(e.getMessage());
		}			
	}
	
	
	
}
