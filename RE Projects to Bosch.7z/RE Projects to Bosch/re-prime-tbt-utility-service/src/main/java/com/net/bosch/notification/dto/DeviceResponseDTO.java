package com.net.bosch.notification.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.net.bosch.dto.base.ResponseDTO;


@JsonInclude(Include.NON_NULL)
public class DeviceResponseDTO {	

	private String code;	
	
	private String success;
	
	private String message;	
	
	private DeviceDetailsDTO data;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DeviceDetailsDTO getData() {
		return data;
	}

	public void setData(DeviceDetailsDTO data) {
		this.data = data;
	}
			
}
