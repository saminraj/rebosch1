package com.net.bosch.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.authentication.KeyVaultCredentials;
import com.microsoft.azure.keyvault.models.SecretBundle;

public class AzureKeyVaultExtractUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(AzureKeyVaultExtractUtil.class);
	
    public static String getValue(String clientId, String clientSecret, String keyIdentifier) {
    	logger.info("client id ==> "+clientId);
    	logger.info("client secret ==> "+clientSecret);
    	logger.info("client key identifier ==> "+keyIdentifier);
    	try {
			KeyVaultCredentials keyVaultCredentials = new ClientSecretKeyVaultCredential(clientId, clientSecret);
			KeyVaultClient keyVaultClient = new KeyVaultClient(keyVaultCredentials);
			SecretBundle secretObject = keyVaultClient.getSecret(keyIdentifier);
			return secretObject == null ? null : secretObject.value();
		} catch (Exception e) {
			logger.info(e.toString());
			return null;
		}

	}
    
    

}
