package com.net.bosch;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.net.bosch.filter.AppFilter;

@EnableAutoConfiguration
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class REPrimeTBTUtilityApplication extends SpringBootServletInitializer{
	
	private static final Logger logger = LoggerFactory.getLogger(REPrimeTBTUtilityApplication.class);
	
	@Autowired
	private Environment env;
	
	@Value("${azure.storage.connection}")
	private String connectionString;
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(REPrimeTBTUtilityApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(REPrimeTBTUtilityApplication.class, args);
	}

	/*public static void main(String[] args) {
		SpringApplication.run(REPrimeTBTUtilityApplication.class, args);
		logger.debug("REPrimeTBTUtilityApplication Started");
	}*/
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean
	public FilterRegistrationBean registerAppFilter(AppFilter filter) {
		FilterRegistrationBean reg = new FilterRegistrationBean(filter);
		reg.setOrder(3);
		return reg;
	}
	
	@Bean
    public CloudStorageAccount createAzureInstance() throws InvalidKeyException, URISyntaxException {
		CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
		return storageAccount;
    }
	
}
