package com.net.bosch.dto.base;

import java.util.List;

/**
 * @author RohitKhandelwal
 *
 */
public class Response {

	private List<String> uriList;
	
	private String message;

	public List<String> getUriList() {
		return uriList;
	}

	public void setUriList(List<String> uriList) {
		this.uriList = uriList;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
