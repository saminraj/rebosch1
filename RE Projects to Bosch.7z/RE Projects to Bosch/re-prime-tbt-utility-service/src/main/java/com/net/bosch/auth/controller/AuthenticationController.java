package com.net.bosch.auth.controller;

import java.util.HashMap;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import redis.clients.jedis.Jedis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.net.bosch.auth.dto.AuthRequestDTO;
import com.net.bosch.auth.dto.DeleteImageRequestDTO;
import com.net.bosch.auth.dto.SaveTBTDeviceRequestDTO;
import com.net.bosch.auth.dto.TBTDeviceDTO;
import com.net.bosch.auth.dto.TripperRequestDTO;
import com.net.bosch.datalogger.service.DataLoggerService;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.notification.service.DeviceService;


@RestController
@CrossOrigin
@RequestMapping("/tbtutility/auth")
public class AuthenticationController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	DeviceService deviceService;
	
	@Autowired
	DataLoggerService dataLoggerService;
	
	@Autowired
	private Environment env;
	
	ObjectMapper mapper = new ObjectMapper();
	
	@RequestMapping(value="/getAuthenticationKey",method = RequestMethod.POST)
	public ResponseDTO getAuthenticationKey(@RequestBody @Valid AuthRequestDTO authRequestDTO, HttpServletRequest request) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getAuthenticationKey called");
		ResponseDTO responseDTO =  new ResponseDTO();
		//ResponseDTO responseDTO = deviceService.getDeviceTokenUsingGuid(authRequestDTO.getGuid(), request.getHeader("Authorization"));
		// New requirement adding every request to datalake 02 NOV 2020
		Boolean isloggingEnabled = env.getProperty("spring.datalake.logger.isloggingenabled",Boolean.class);		
		if(isloggingEnabled){
			dataLoggerService.addDataLog(authRequestDTO.getGuid());
		}
		logger.debug("[getAuthenticationKey]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/saveTBTDevices",method = RequestMethod.POST)
	public Object saveTBTDevices(@RequestBody @Valid TBTDeviceDTO tbtDeviceDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("saveTBTDevices called");
		try {
			logger.debug("saveTBTDeviceRequestDTO got json from app-> "+new ObjectMapper().writeValueAsString(tbtDeviceDTO));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object response = deviceService.saveTBTDeviceTokenUsingGuid(tbtDeviceDTO);
		logger.debug("[saveTBTDevices]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	@RequestMapping(value="/getTBTDevices",method = RequestMethod.POST)
	public Object getTBTDevices(@RequestBody @Valid TripperRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getTBTDevices called");
		Object responseDTO = deviceService.getTBTDevicesUsingGuidAndToken(requestDTO.getGuid(), requestDTO.getDeviceToken());
		logger.debug("[getTBTDevices]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/removeTBTDevice",method = RequestMethod.POST)
	public Object removeTBTDevice(@RequestBody @Valid TripperRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("removeTBTDevice called");
		Object responseDTO = deviceService.removeTBTDevicesUsingGuidAndToken(requestDTO.getGuid(), requestDTO.getDeviceToken(), requestDTO.getSerialNumber());
		logger.debug("[removeTBTDevice]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/updateTBTDevice",method = RequestMethod.POST)
	public Object updateTBTDevice(@RequestBody @Valid TBTDeviceDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("updateTBTDevice called");
		try {
			logger.debug("updateTBTDevice got json from app-> "+new ObjectMapper().writeValueAsString(requestDTO));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object responseDTO = deviceService.updateTBTDeviceUsingSerialNumber(requestDTO);
		logger.debug("[updateTBTDevice]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/saveTrip",method = RequestMethod.POST)
	public Object saveTrip(@RequestBody Object tripDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("saveTrip called");
		try {
			logger.debug("saveTrip got json from app-> "+new ObjectMapper().writeValueAsString(tripDTO));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object response = deviceService.saveTrip(tripDTO);
		logger.debug("[saveTrip]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return response;
	}
	
	@RequestMapping(value="/getTrip",method = RequestMethod.POST)
	public Object getTrip(@RequestBody @Valid TripperRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("getTrip called");
		Object responseDTO = deviceService.getTripUsingGuidAndToken(requestDTO.getGuid(), requestDTO.getSerialNumber());
		logger.debug("[getTrip]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/testRedisSearch/{searchKey}", method = RequestMethod.GET)
	public String testRedisSearch(@PathVariable String searchKey) throws AppException {
		if(searchKey.isEmpty())return null;
		Jedis jedis = new Jedis(env.getProperty("spring.redis.host"));
		//jedis.auth(env.getProperty("spring.redis.password"));
		logger.info("Key input---> *"+searchKey);
		Set<String> keys = jedis.keys("*"+searchKey+"*");
		logger.info("Key resultset ----> "+keys.toString()+" keys.size()  -> "+(keys.size()>0) );
		String value = "";
		if(keys != null && !keys.isEmpty() && keys.size() > 0){
			for (String key : keys) {
	        	value = jedis.get(key);
	        	logger.info("value "+value);
	        	if(value != null && !value.isEmpty()){
	        		String[] deviceDetails = value.split("\\|");
	        		logger.info("details guid "+deviceDetails[0]);
	        		logger.info("details phone "+deviceDetails[1]);
	        		logger.info("device token "+deviceDetails[2]);
	        		logger.info("device type "+deviceDetails[3]);
	        	}
	        	
	        	break;
	        }
		}
        jedis.close();
		return value;
	}
	
	@RequestMapping(value="/testRedisDirectAdd/{key}/{guid}", method = RequestMethod.GET)
	public String testRedisDirectAdd(@PathVariable String key, @PathVariable String guid) throws AppException {
		if(key.isEmpty())return null;
		JSONObject jsonObj = null;
		Jedis jedis = new Jedis(env.getProperty("spring.redis.host"));
		//jedis.auth(env.getProperty("spring.redis.password"));
		logger.info("Key input---> *"+key);
		HashMap<String, String> fieldValues = new HashMap<String, String>();
		fieldValues.put("key", "BGHJUYT");
		fieldValues.put("guid", guid);
		fieldValues.put("jwtToken", "");
		fieldValues.put("permissions", "Allow");
		jedis.hmset(key, fieldValues);
		jedis.expire(key, 7776000);
        jedis.close();
		return "200 OK";
	}
	
	@RequestMapping(value="/deleteImage",method = RequestMethod.POST)
	public Object deleteImage(@RequestBody @Valid DeleteImageRequestDTO requestDTO) throws AppException {
		Long startTime = System.currentTimeMillis();
		logger.debug("deleteImage called");
		Object responseDTO = deviceService.deleteImage(requestDTO.getUrls());
		logger.debug("[deleteImage]: elapsed time: "+(System.currentTimeMillis()-startTime));
		return responseDTO;
	}
	
	@RequestMapping(value="/test", method = RequestMethod.GET)
	public String getTest() throws AppException {
		return "Success";
	}
	

}
