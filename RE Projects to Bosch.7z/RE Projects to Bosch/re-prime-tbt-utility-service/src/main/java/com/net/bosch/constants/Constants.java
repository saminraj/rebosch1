package com.net.bosch.constants;

public class Constants {
	
	public static final String LONG_DATE_FORMAT = "hh:mm a MMM dd yyyy";
	public static final String SHORT_DATE_FORMAT = "dd-MMM-yyyy";
	
	public static final String RE_PRIME_APPOINTMENT_STATUS = "yyyy-MM-dd HH:mm:ss.S";
	
	public static final String DEVICE_TYPE_IOS = "IOS";
	public static final String DEVICE_TYPE_ANDROID = "Android";

}
