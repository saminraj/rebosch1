package com.net.bosch.datalogger.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DataLoggerDTO implements Serializable{

	private static final long serialVersionUID = -6534141874787264561L;

	private List<LogDTO> logs;

	public List<LogDTO> getLogs() {
		return logs;
	}

	public void setLogs(List<LogDTO> logs) {
		this.logs = logs;
	}

		
			
}
