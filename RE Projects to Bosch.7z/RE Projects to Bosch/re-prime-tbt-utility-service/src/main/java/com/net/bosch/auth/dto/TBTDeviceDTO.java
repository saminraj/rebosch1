package com.net.bosch.auth.dto;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TBTDeviceDTO implements Serializable{
	
	private static final long serialVersionUID = -6848194947562732517L;

	private String deviceToken;
	
	private String serialNumber;
	
	private String userGUID;
	
	@JsonProperty("OSVersion")
	private String osVersion;
	
	private String brickStatus;
	
	private String deviceOS;
	
	private String name;
	
	private String tripperID;
	
	private String uuid;
	
	private String tripperState;
	
	private String additionalInfo1;
	
	private String additionalInfo2;

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getUserGUID() {
		return userGUID;
	}

	public void setUserGUID(String userGUID) {
		this.userGUID = userGUID;
	}

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getBrickStatus() {
		return brickStatus;
	}

	public void setBrickStatus(String brickStatus) {
		this.brickStatus = brickStatus;
	}

	public String getDeviceOS() {
		return deviceOS;
	}

	public void setDeviceOS(String deviceOS) {
		this.deviceOS = deviceOS;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTripperID() {
		return tripperID;
	}

	public void setTripperID(String tripperID) {
		this.tripperID = tripperID;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getTripperState() {
		return tripperState;
	}

	public void setTripperState(String tripperState) {
		this.tripperState = tripperState;
	}

	public String getAdditionalInfo1() {
		return additionalInfo1;
	}

	public void setAdditionalInfo1(String additionalInfo1) {
		this.additionalInfo1 = additionalInfo1;
	}

	public String getAdditionalInfo2() {
		return additionalInfo2;
	}

	public void setAdditionalInfo2(String additionalInfo2) {
		this.additionalInfo2 = additionalInfo2;
	}

}
