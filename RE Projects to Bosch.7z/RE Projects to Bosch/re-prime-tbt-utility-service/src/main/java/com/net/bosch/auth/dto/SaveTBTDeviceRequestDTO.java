package com.net.bosch.auth.dto;

import java.io.Serializable;
import java.util.List;

public class SaveTBTDeviceRequestDTO implements Serializable{
	
	private static final long serialVersionUID = -8092178688750967609L;
	
	private String guid;
	
	private List<TBTDeviceDTO> devices;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public List<TBTDeviceDTO> getDevices() {
		return devices;
	}

	public void setDevices(List<TBTDeviceDTO> devices) {
		this.devices = devices;
	}
}
