package com.net.bosch.auth.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.net.bosch.auth.domain.DeviceAuthentication;


@Repository
public interface DeviceAuthenticationRepository extends CrudRepository<DeviceAuthentication, String> {
	
		
		

}