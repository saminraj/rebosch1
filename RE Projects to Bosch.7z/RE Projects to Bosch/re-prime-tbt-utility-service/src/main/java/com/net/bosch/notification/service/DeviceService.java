package com.net.bosch.notification.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.net.bosch.auth.dao.DeviceAuthenticationRepository;
import com.net.bosch.auth.domain.DeviceAuthentication;
import com.net.bosch.auth.dto.SaveTBTDeviceRequestDTO;
import com.net.bosch.auth.dto.TBTDeviceDTO;
import com.net.bosch.dto.base.ResponseDTO;
import com.net.bosch.exceptions.AppException;
import com.net.bosch.utils.AzureKeyVaultExtractUtil;


@Service
public class DeviceService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private DeviceAuthenticationRepository deviceAuthenticationRepository;
	
	@Autowired
	CloudStorageAccount storageAccount;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private MessageSource messageSource;	
		
	ObjectMapper mapper = new ObjectMapper();	
	
	
	
	public ResponseDTO getDeviceTokenUsingGuid(String guid, String jwtToken) throws AppException {
		ResponseDTO responseDTO = new ResponseDTO();
		logger.debug("getDeviceTokenUsingGuid called - > guid -> "+guid);
		
		String clientId = env.getProperty("azure.vault.clientid");
		String clientSecret = env.getProperty("azure.vault.clientsecret");
		String keyIdentifier = env.getProperty("azure.vault.keyidentifier");
		String azureSecretKey = AzureKeyVaultExtractUtil.getValue(clientId, clientSecret, keyIdentifier);
		DeviceAuthentication deviceAuthentication =  new DeviceAuthentication();
		deviceAuthentication.setId(guid);
		deviceAuthentication.setPermissions("Allow");
		deviceAuthentication.setKey(azureSecretKey);
		deviceAuthentication.setGuid(guid);
		deviceAuthentication.setJwtToken(jwtToken);
		deviceAuthenticationRepository.save(deviceAuthentication);
		responseDTO.setResult(azureSecretKey);
				
		return responseDTO;
	}
	
	public Object getTBTDevicesUsingGuidAndToken(String guid, String deviceToken) throws AppException {
		logger.debug("getDeviceTokenUsingGuid called - > guid -> "+guid);
		RestTemplate restTemplate = new RestTemplate();	     
		Object device = restTemplate.getForObject(env.getProperty("spring.getdevice.webapi.url")+"?userGUID="+guid+"&deviceToken="+deviceToken, Object.class);	
		try {
			logger.debug("getDeviceTokenUsingGuid response - > "+mapper.writeValueAsString(device));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return device;
	}
	
	public Object saveTBTDeviceTokenUsingGuid(TBTDeviceDTO deviceDTO) throws AppException {
		RestTemplate restTemplate = new RestTemplate();	     
		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("deviceToken", deviceDTO.getDeviceToken());
		map.add("serialNumber", deviceDTO.getSerialNumber());
		map.add("userGUID", deviceDTO.getUserGUID());
		map.add("OSVersion", deviceDTO.getOsVersion());
		map.add("brickStatus", deviceDTO.getBrickStatus());
		map.add("deviceOS", deviceDTO.getDeviceOS());
		map.add("name", deviceDTO.getName());
		map.add("tripperID", deviceDTO.getTripperID());
		map.add("uuid", deviceDTO.getUuid());
		map.add("tripperState", deviceDTO.getTripperState());
		map.add("additionalInfo1", deviceDTO.getAdditionalInfo1());
		map.add("additionalInfo2", deviceDTO.getAdditionalInfo2());
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, null);
		ResponseEntity<String> response =  restTemplate.postForEntity(env.getProperty("spring.getdevice.webapi.url"),request,String.class);
		logger.debug("saveTBTDeviceTokenUsingGuid reponse-> "+response.getBody());	
		return response;
	}
	
	public Object removeTBTDevicesUsingGuidAndToken(String guid, String deviceToken, String serialNumber) throws AppException {
		logger.debug("removeTBTDevicesUsingGuidAndToken called - > guid -> "+guid+" deviceToken-> "+deviceToken+" serialNumber-> "+serialNumber);
		RestTemplate restTemplate = new RestTemplate();		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("serialNumber", serialNumber);
		map.add("userGUID", guid);
		map.add("deviceToken", deviceToken);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(map, headers);	
		ResponseEntity<String> response = null;
		try {
		    response  = restTemplate.exchange(env.getProperty("spring.getdevice.webapi.url"), HttpMethod.DELETE, entity, String.class);
		} catch (HttpClientErrorException ex) {
		    String message = ex.getResponseBodyAsString();
		    logger.debug("removeTBTDevicesUsingGuidAndToken error-> "+message);	
		}
		
		return response;
	}
	
	public Object updateTBTDeviceUsingSerialNumber(TBTDeviceDTO deviceDTO) throws AppException {
		logger.debug("removeTBTDevicesUsingGuidAndToken called - >  serialNumber-> "+deviceDTO.getSerialNumber());
		RestTemplate restTemplate = new RestTemplate();		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("serialNumber", deviceDTO.getSerialNumber());
		map.add("OSVersion", deviceDTO.getOsVersion());
		map.add("brickStatus", deviceDTO.getBrickStatus());
		map.add("tripperState", deviceDTO.getTripperState());
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(map, headers);	
		ResponseEntity<String> response = null;
		try {
		    response  = restTemplate.exchange(env.getProperty("spring.getdevice.webapi.url"), HttpMethod.PUT, entity, String.class);
		} catch (HttpClientErrorException ex) {
		    String message = ex.getResponseBodyAsString();
		    logger.debug("removeTBTDevicesUsingGuidAndToken error-> "+message);	
		}
		logger.debug("saveTBTDeviceTokenUsingGuid reponse-> "+response.getBody());	
		return response;
	}
	
	
	public Object getTripUsingGuidAndToken(String guid, String serialNumber) throws AppException {
		logger.debug("getTripUsingGuidAndToken called - > guid -> "+guid);
		RestTemplate restTemplate = new RestTemplate();	     
		Object device = restTemplate.getForObject(env.getProperty("spring.gettrip.webapi.url")+"?userGUID="+guid+"&serialNumber="+serialNumber, Object.class);	
		try {
			logger.debug("getTripUsingGuidAndToken response - > "+mapper.writeValueAsString(device));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return device;
	}
	
	public Object saveTrip(Object tripDTO) throws AppException {
		RestTemplate restTemplate = new RestTemplate();	     
		ResponseEntity<String> response =  restTemplate.postForEntity(env.getProperty("spring.gettrip.webapi.url"),tripDTO,String.class);
		logger.debug("saveTrip reponse-> "+response.getBody());	
		return response;
	}
	
	public Object deleteImage(List<String> urls) throws AppException {
		CloudBlobClient blobClient = null;
		try {
			blobClient = storageAccount.createCloudBlobClient();
			CloudBlobContainer blobContainerClient = blobClient.getContainerReference(env.getProperty("azure.storage.container"));
			logger.info("Listing blobs in the container: " + blobContainerClient.getName());
			CloudBlob blob = null;
			for (String url : urls) {
				url = url.replaceAll(env.getProperty("azure.storage.container.baseurl"), "");
				logger.info("image path " + url);
				blob = blobContainerClient.getBlockBlobReference(url);
				logger.info("blob.getStorageUri() " + blob.getStorageUri());
				blob.deleteIfExists();
				
			}
			
		} catch (Exception ex) {
			logger.error("deviceService deleteImage "+ex.getMessage());
			ex.printStackTrace();
			
		}		
		return new ResponseDTO();
	}
	
}
