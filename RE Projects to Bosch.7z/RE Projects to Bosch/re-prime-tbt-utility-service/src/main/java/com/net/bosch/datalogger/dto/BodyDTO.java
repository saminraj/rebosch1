package com.net.bosch.datalogger.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class BodyDTO implements Serializable{

	private static final long serialVersionUID = -5622566119344975706L;
	
	private BodyRequestDTO request;

	private String response;
	
	private String stacktrace;
	
	private String message;

	public BodyRequestDTO getRequest() {
		return request;
	}

	public void setRequest(BodyRequestDTO request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getStacktrace() {
		return stacktrace;
	}

	public void setStacktrace(String stacktrace) {
		this.stacktrace = stacktrace;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
			
}
