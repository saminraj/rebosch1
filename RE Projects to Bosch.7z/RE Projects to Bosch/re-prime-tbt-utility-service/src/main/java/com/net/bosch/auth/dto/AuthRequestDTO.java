package com.net.bosch.auth.dto;

import java.io.Serializable;

public class AuthRequestDTO implements Serializable{
	
	private static final long serialVersionUID = 5780677917570668822L;
	
	private String guid;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}
}
