package com.net.bosch.auth.dto;

import java.io.Serializable;

public class TripperRequestDTO implements Serializable{
	
	private static final long serialVersionUID = 5780677917570668822L;
	
	private String guid;
	
	private String deviceToken;
	
	private String serialNumber;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
}
